const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { boot, itest, missing, PASSWORD } = require('./helpers');

let t;
before(async () => { if (!missing) t = await boot(); });
after(async () => { if (t) await t.close(); });

itest(test, 'registration: creates a PENDING student and never returns secrets', async () => {
  const res = await t.request.post('/api/auth/register').send({ name: 'New Student', email: 'new1@example.com', password: PASSWORD });
  assert.equal(res.status, 201);
  assert.equal(res.body.data.status, 'pending');
  const text = JSON.stringify(res.body);
  for (const secret of ['passwordHash', 'refreshTokens', 'emailVerificationToken', 'passwordResetToken']) assert.ok(!text.includes(secret), secret);
});

itest(test, 'registration: self-registering as teacher is silently downgraded to student (privilege escalation)', async () => {
  const res = await t.request.post('/api/auth/register').send({ name: 'Wannabe', email: 'wannabe@example.com', password: PASSWORD, role: 'teacher' });
  assert.equal(res.status, 201);
  assert.equal(res.body.data.role, 'student');
});

itest(test, 'registration: admin role is rejected outright', async () => {
  const res = await t.request.post('/api/auth/register').send({ name: 'Evil', email: 'evil@example.com', password: PASSWORD, role: 'admin' });
  assert.equal(res.status, 400);
});

itest(test, 'registration: weak, over-long and non-string passwords are rejected', async () => {
  for (const password of ['short1!', 'alllowercase1!', 'A'.repeat(80) + 'a1!', { $ne: 1 }]) {
    const res = await t.request.post('/api/auth/register').send({ name: 'X', email: `w${Math.random()}@example.com`, password });
    assert.equal(res.status, 400, JSON.stringify(password).slice(0, 40));
  }
});

itest(test, 'login: wrong password and unknown e-mail give the same response (no account enumeration)', async () => {
  const u = await t.makeUser('student');
  const wrong = await t.request.post('/api/auth/login').send({ email: u.email, password: 'Wrong!Passw0rd#9' });
  const unknown = await t.request.post('/api/auth/login').send({ email: 'nobody@example.com', password: 'Wrong!Passw0rd#9' });
  assert.equal(wrong.status, 401);
  assert.equal(unknown.status, 401);
  assert.equal(wrong.body.message, unknown.body.message);
});

itest(test, 'login: NoSQL operator objects instead of credentials are rejected', async () => {
  const res = await t.request.post('/api/auth/login').send({ email: { $gt: '' }, password: { $gt: '' } });
  assert.ok([400, 401].includes(res.status));
  assert.notEqual(res.status, 200);
});

itest(test, 'login: account locks after repeated failures, then even the right password is refused', async () => {
  const u = await t.makeUser('student');
  for (let i = 0; i < 5; i += 1) await t.request.post('/api/auth/login').send({ email: u.email, password: 'Wrong!Passw0rd#9' });
  const res = await t.request.post('/api/auth/login').send({ email: u.email, password: PASSWORD });
  assert.equal(res.status, 401);
});

itest(test, 'login: pending and suspended accounts cannot sign in', async () => {
  const pending = await t.makeUser('student', { status: 'pending' });
  const suspended = await t.makeUser('student', { status: 'suspended' });
  assert.equal((await t.request.post('/api/auth/login').send({ email: pending.email, password: PASSWORD })).status, 403);
  assert.equal((await t.request.post('/api/auth/login').send({ email: suspended.email, password: PASSWORD })).status, 403);
});

itest(test, 'JWT: a refresh token cannot be used as an access token', async () => {
  const a = await t.actor('student');
  const res = await t.request.get('/api/auth/me').set('Authorization', `Bearer ${a.refreshToken}`);
  assert.equal(res.status, 401);
});

itest(test, 'JWT: tampered, "alg:none" and garbage tokens are rejected', async () => {
  const a = await t.actor('student');
  const [h, p, s] = a.accessToken.split('.');
  const none = `${Buffer.from('{"alg":"none","typ":"JWT"}').toString('base64url')}.${p}.`;
  const flipped = `${h}.${p}.${s.slice(0, -2)}${s.endsWith('AA') ? 'BB' : 'AA'}`;
  for (const token of [none, flipped, 'garbage', '']) {
    const res = await t.request.get('/api/auth/me').set('Authorization', `Bearer ${token}`);
    assert.equal(res.status, 401, token.slice(0, 20));
  }
});

itest(test, 'JWT: role claims inside the token are ignored; the database decides', async () => {
  const a = await t.actor('student');
  const res = await a.api.get('/api/admin/users');
  assert.equal(res.status, 403);
});

itest(test, 'refresh: rotation works and re-using an old refresh token revokes the whole session family', async () => {
  const a = await t.actor('student');
  const first = await t.request.post('/api/auth/refresh').send({ refreshToken: a.refreshToken });
  assert.equal(first.status, 200);
  const replay = await t.request.post('/api/auth/refresh').send({ refreshToken: a.refreshToken });
  assert.equal(replay.status, 401);
  const afterReplay = await t.request.post('/api/auth/refresh').send({ refreshToken: first.body.data.refreshToken });
  assert.equal(afterReplay.status, 401, 'the legitimate newer token is also revoked after reuse is detected');
});

itest(test, 'refresh tokens are stored hashed, never raw', async () => {
  const a = await t.actor('student');
  const User = require('../../src/models/User');
  const u = await User.findById(a.user._id || a.user.id).select('+refreshTokens');
  assert.ok(u.refreshTokens.length > 0);
  assert.ok(!u.refreshTokens.includes(a.refreshToken));
  assert.match(u.refreshTokens[0], /^[a-f0-9]{64}$/);
});

itest(test, 'password reset: NoSQL-injection token cannot take over someone else\'s reset', async () => {
  const victim = await t.makeUser('student');
  await t.request.post('/api/auth/forgot-password').send({ email: victim.email });
  const res = await t.request.post('/api/auth/reset-password').send({ token: { $ne: null }, password: 'Hacked!Passw0rd#1' });
  assert.equal(res.status, 400);
  assert.equal((await t.request.post('/api/auth/login').send({ email: victim.email, password: PASSWORD })).status, 200);
});

itest(test, 'e-mail verification: operator-object tokens are rejected (query-string injection)', async () => {
  const res = await t.request.get('/api/auth/verify-email?token[$ne]=x');
  assert.equal(res.status, 400);
});

itest(test, 'password change invalidates the old access token immediately', async () => {
  const a = await t.actor('student');
  const change = await a.api.put('/api/auth/change-password').send({ currentPassword: PASSWORD, newPassword: 'N3w!Passw0rd#Better' });
  assert.equal(change.status, 200);
  const res = await a.api.get('/api/auth/me');
  assert.equal(res.status, 401);
});

itest(test, 'profile update cannot change role, status or e-mail (mass assignment)', async () => {
  const a = await t.actor('student');
  const res = await a.api.put('/api/auth/profile').send({ name: 'Renamed', role: 'admin', status: 'active', email: 'x@y.com' });
  assert.equal(res.status, 200);
  assert.equal(res.body.data.role, 'student');
  assert.equal(res.body.data.email, a.user.email);
});

itest(test, 'CORS: unknown origins get no CORS headers; the configured client origin does', async () => {
  const bad = await t.request.get('/api/health').set('Origin', 'https://evil.example');
  assert.equal(bad.headers['access-control-allow-origin'], undefined);
  const good = await t.request.get('/api/health').set('Origin', 'http://localhost:3000');
  assert.equal(good.headers['access-control-allow-origin'], 'http://localhost:3000');
});

itest(test, 'API responses are never cacheable and carry security headers', async () => {
  const res = await t.request.get('/api/billing/plans');
  assert.equal(res.headers['cache-control'], 'no-store');
  assert.equal(res.headers['x-content-type-options'], 'nosniff');
  assert.equal(res.headers['x-powered-by'], undefined);
});
