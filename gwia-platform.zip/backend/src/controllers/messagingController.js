const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const messagingService = require('../services/messagingService');
const presenceService = require('../services/presenceService');
const notificationService = require('../services/notificationService');
const { chatAttachmentKind } = require('../config/multer');
const { Course } = require('../models/course.model');

function conversationRoom(conversationId) {
  return `conversation:${conversationId}`;
}

// POST /api/messages/conversations  { recipientId, courseId? }
const startConversation = asyncHandler(async (req, res) => {
  const { recipientId, courseId } = req.body;

  if (req.user.role === 'teacher') {
    const sharedCourse = await Course.findOne({
      teacherIds: req.user.id,
      enrolledStudentIds: recipientId,
      ...(courseId ? { _id: courseId } : {})
    });
    if (!sharedCourse) {
      throw ApiError.forbidden('You may only message students enrolled in your courses');
    }
  }

  if (req.user.role === 'student') {
    const sharedCourse = await Course.findOne({
      enrolledStudentIds: req.user.id,
      teacherIds: recipientId,
      ...(courseId ? { _id: courseId } : {})
    });
    if (!sharedCourse) {
      throw ApiError.forbidden('You may only message teachers of courses you are enrolled in');
    }
  }

  const conversation = await messagingService.findOrCreateConversation(req.user.id, recipientId, courseId);
  return ApiResponse.ok(res, conversation, 'Conversation ready');
});

// GET /api/messages/conversations
const listConversations = asyncHandler(async (req, res) => {
  const conversations = await messagingService.listConversationsForUser(req.user.id);
  return ApiResponse.ok(res, conversations, 'Conversations retrieved');
});

// GET /api/messages/conversations/:conversationId/messages?before=&limit=
const listMessages = asyncHandler(async (req, res) => {
  const { before, limit } = req.query;
  const result = await messagingService.listMessages(req.params.conversationId, req.user.id, { before, limit });
  return ApiResponse.ok(res, result.messages, 'Messages retrieved', {
    hasMore: result.hasMore,
    nextCursor: result.nextCursor
  });
});

// POST /api/messages/conversations/:conversationId/messages  (multipart: text + files[])
const sendMessage = asyncHandler(async (req, res) => {
  const attachments = (req.files || []).map((file) => ({
    fileName: file.originalname,
    fileUrl: `/uploads/chat/${file.filename}`,
    mimeType: file.mimetype,
    size: file.size,
    kind: chatAttachmentKind(file.mimetype)
  }));

  const message = await messagingService.sendMessage(req.params.conversationId, req.user.id, {
    text: req.body.text,
    attachments
  });
  const conversation = await messagingService.getConversationById(req.params.conversationId);

  const io = req.app.get('io');
  if (io) {
    io.to(conversationRoom(req.params.conversationId)).emit('message:new', message);
  }

  const recipients = conversation.participantIds.filter((id) => id.toString() !== req.user.id);
  const preview = message.text
    ? message.text.length > 100
      ? `${message.text.slice(0, 100)}...`
      : message.text
    : `Sent ${attachments.length > 1 ? 'attachments' : `an ${attachments[0]?.kind || 'attachment'}`}`;

  await notificationService.createNotificationsForMany(recipients, 'message', 'New message', preview, {
    conversationId: req.params.conversationId,
    messageId: message._id
  });

  return ApiResponse.created(res, message, 'Message sent');
});

// PUT /api/messages/conversations/:conversationId/read  { messageIds? }
const markAsRead = asyncHandler(async (req, res) => {
  const { messageIds } = await messagingService.markAsRead(req.params.conversationId, req.user.id, req.body.messageIds);

  const io = req.app.get('io');
  if (io && messageIds.length > 0) {
    io.to(conversationRoom(req.params.conversationId)).emit('message:read-receipt', {
      conversationId: req.params.conversationId,
      readBy: req.user.id,
      messageIds
    });
  }

  return ApiResponse.ok(res, { messageIds }, 'Messages marked as read');
});

// DELETE /api/messages/:messageId?forEveryone=true
const deleteMessage = asyncHandler(async (req, res) => {
  const forEveryone = req.query.forEveryone === 'true';
  const message = await messagingService.deleteMessage(req.params.messageId, req.user.id, { forEveryone });

  const io = req.app.get('io');
  if (io) {
    if (forEveryone) {
      io.to(conversationRoom(message.conversationId)).emit('message:deleted', {
        messageId: message._id,
        forEveryone: true
      });
    } else {
      io.to(`user:${req.user.id}`).emit('message:deleted', { messageId: message._id, forEveryone: false });
    }
  }

  return ApiResponse.ok(res, null, 'Message deleted');
});

// GET /api/messages/search?q=&conversationId=
const searchMessages = asyncHandler(async (req, res) => {
  if (!req.query.q || !req.query.q.trim()) {
    throw ApiError.badRequest('Query parameter "q" is required');
  }
  const results = await messagingService.searchMessages(req.user.id, {
    query: req.query.q,
    conversationId: req.query.conversationId,
    limit: req.query.limit
  });
  return ApiResponse.ok(res, results, 'Search results retrieved');
});

// GET /api/messages/presence?userIds=a,b,c
const getPresence = asyncHandler(async (req, res) => {
  if (!req.query.userIds) {
    throw ApiError.badRequest('Query parameter "userIds" is required (comma-separated)');
  }
  const userIds = req.query.userIds.split(',').map((id) => id.trim()).filter(Boolean);
  const statuses = presenceService.getStatuses(userIds);
  return ApiResponse.ok(res, statuses, 'Presence retrieved');
});

module.exports = {
  startConversation,
  listConversations,
  listMessages,
  sendMessage,
  markAsRead,
  deleteMessage,
  searchMessages,
  getPresence
};
