const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const lessonService = require('../services/lessonService');
const notificationService = require('../services/notificationService');
const { Course } = require('../models/course.model');

// POST /api/courses/:courseId/subjects/:subjectId/modules/:moduleId/lessons
const createLesson = asyncHandler(async (req, res) => {
  const lesson = await lessonService.createLesson(req.course, req.params.subjectId, req.params.moduleId, req.user.id, req.body);

  if (lesson.status === 'published') {
    await notificationService.notifyNewLesson(req.course.enrolledStudentIds, {
      lessonId: lesson._id,
      courseId: lesson.courseId,
      title: lesson.title
    });
  }

  return ApiResponse.created(res, lesson, 'Lesson created successfully');
});

// GET /api/courses/:courseId/lessons  (optionally filtered by ?subjectId= or ?moduleId=)
const listLessons = asyncHandler(async (req, res) => {
  const filter = { courseId: req.course._id };
  if (req.query.subjectId) filter.subjectId = req.query.subjectId;
  if (req.query.moduleId) filter.moduleId = req.query.moduleId;
  const lessons = await lessonService.listLessons(filter);
  return ApiResponse.ok(res, lessons, 'Lessons retrieved');
});

// PUT /api/lessons/:id  (req.resource set by verifyResourceOwnership)
const updateLesson = asyncHandler(async (req, res) => {
  const wasPublished = req.resource.status === 'published';
  const lesson = await lessonService.updateLesson(req.resource, req.body);

  if (!wasPublished && lesson.status === 'published') {
    const course = await Course.findById(lesson.courseId);
    if (course) {
      await notificationService.notifyNewLesson(course.enrolledStudentIds, {
        lessonId: lesson._id,
        courseId: lesson.courseId,
        title: lesson.title
      });
    }
  }

  return ApiResponse.ok(res, lesson, 'Lesson updated successfully');
});

// DELETE /api/lessons/:id
const deleteLesson = asyncHandler(async (req, res) => {
  await lessonService.deleteLesson(req.resource);
  return ApiResponse.ok(res, null, 'Lesson deleted successfully');
});

// --- Text ---
// PUT /api/lessons/:id/text
const updateText = asyncHandler(async (req, res) => {
  const lesson = await lessonService.updateText(req.resource, req.body.text);
  return ApiResponse.ok(res, lesson, 'Lesson text updated');
});

// --- Images ---
const addImage = asyncHandler(async (req, res) => {
  const lesson = await lessonService.addImage(req.resource, req.file, req.body.caption);
  return ApiResponse.ok(res, lesson, 'Image added successfully');
});
const removeImage = asyncHandler(async (req, res) => {
  const lesson = await lessonService.removeImage(req.resource, req.params.imageId);
  return ApiResponse.ok(res, lesson, 'Image removed successfully');
});

// --- PDFs ---
const addPdf = asyncHandler(async (req, res) => {
  const lesson = await lessonService.addPdf(req.resource, req.file);
  return ApiResponse.ok(res, lesson, 'PDF added successfully');
});
const removePdf = asyncHandler(async (req, res) => {
  const lesson = await lessonService.removePdf(req.resource, req.params.pdfId);
  return ApiResponse.ok(res, lesson, 'PDF removed successfully');
});

// --- Audio ---
const addAudio = asyncHandler(async (req, res) => {
  const lesson = await lessonService.addAudio(req.resource, req.file, req.body.duration);
  return ApiResponse.ok(res, lesson, 'Audio added successfully');
});
const removeAudio = asyncHandler(async (req, res) => {
  const lesson = await lessonService.removeAudio(req.resource, req.params.audioId);
  return ApiResponse.ok(res, lesson, 'Audio removed successfully');
});

// --- Video ---
const setVideo = asyncHandler(async (req, res) => {
  const lesson = await lessonService.setVideo(req.resource, req.file, req.body.duration);
  return ApiResponse.ok(res, lesson, 'Video uploaded successfully');
});
const removeVideo = asyncHandler(async (req, res) => {
  const lesson = await lessonService.removeVideo(req.resource);
  return ApiResponse.ok(res, lesson, 'Video removed successfully');
});

// --- External resources ---
const addExternalResource = asyncHandler(async (req, res) => {
  const lesson = await lessonService.addExternalResource(req.resource, req.body);
  return ApiResponse.ok(res, lesson, 'External resource added successfully');
});
const removeExternalResource = asyncHandler(async (req, res) => {
  const lesson = await lessonService.removeExternalResource(req.resource, req.params.resourceId);
  return ApiResponse.ok(res, lesson, 'External resource removed successfully');
});

// --- Attachments ---
const addAttachment = asyncHandler(async (req, res) => {
  const lesson = await lessonService.addAttachment(req.resource, req.file);
  return ApiResponse.ok(res, lesson, 'Attachment added successfully');
});
const removeAttachment = asyncHandler(async (req, res) => {
  const lesson = await lessonService.removeAttachment(req.resource, req.params.attachmentId);
  return ApiResponse.ok(res, lesson, 'Attachment removed successfully');
});

module.exports = {
  createLesson,
  listLessons,
  updateLesson,
  deleteLesson,
  updateText,
  addImage,
  removeImage,
  addPdf,
  removePdf,
  addAudio,
  removeAudio,
  setVideo,
  removeVideo,
  addExternalResource,
  removeExternalResource,
  addAttachment,
  removeAttachment
};
