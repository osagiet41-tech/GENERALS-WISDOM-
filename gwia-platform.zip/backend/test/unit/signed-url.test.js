const test = require('node:test');
const assert = require('node:assert/strict');
const { createSigner } = require('../../src/utils/signedUrl');

const signer = createSigner(() => 'unit-test-secret-unit-test-secret-1234');
const P = '/uploads/videos/lesson1.mp4';
const parse = (signed) => Object.fromEntries(new URL(`http://x${signed}`).searchParams);

test('a freshly signed URL verifies', () => {
  const q = parse(signer.build(P, 'user1', 600));
  assert.ok(signer.verify(P, q));
});

test('signature is bound to the path, the user and the expiry', () => {
  const q = parse(signer.build(P, 'user1', 600));
  assert.ok(!signer.verify('/uploads/videos/other.mp4', q), 'different file');
  assert.ok(!signer.verify(P, { ...q, u: 'user2' }), 'different user');
  assert.ok(!signer.verify(P, { ...q, exp: String(Number(q.exp) + 1000) }), 'extended expiry');
  assert.ok(!signer.verify(P, { ...q, sig: 'a'.repeat(64) }), 'forged signature');
});

test('expired links are refused', () => {
  const q = parse(signer.build(P, 'user1', 600, Date.now() - 3600 * 1000));
  assert.ok(!signer.verify(P, q));
});

test('malformed or missing parameters are refused without throwing', () => {
  assert.ok(!signer.verify(P, {}));
  assert.ok(!signer.verify(P, undefined));
  assert.ok(!signer.verify(P, { u: 'x', exp: 'abc', sig: 'y' }));
  assert.ok(!signer.verify(P, { u: { $ne: 1 }, exp: '1999999999', sig: 'z' }));
});

test('a different secret cannot validate links', () => {
  const other = createSigner(() => 'a-completely-different-secret-value-0000');
  const q = parse(signer.build(P, 'user1', 600));
  assert.ok(!other.verify(P, q));
});
