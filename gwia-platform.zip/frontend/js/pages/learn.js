import { h, mount, icon } from '../core/dom.js';
import { requireRole } from '../core/session.js';
import { studentApi } from '../api/student.js';
import { createToolBar } from '../ui/shell.js';
import { errorState, loading, empty } from '../ui/states.js';
import { renderText } from '../ui/markdown.js';
import { toast } from '../ui/toast.js';
import { busy } from '../ui/states.js';
import { fmtPercent } from '../core/format.js';
import { signUrls, safeHref } from '../core/files.js';
import { idOf } from '../ui/page.js';

await requireRole('student');
const q = new URLSearchParams(location.search), courseId = q.get('course');
const side = h('nav', { class: 'learn-side', 'aria-label': 'Course contents' }), main = h('main', { class: 'learn-main', id: 'main', tabindex: '-1' });
const pct = h('span', { class: 'badge info' }, ''); document.body.append(h('div', { class: 'tool' }, createToolBar({ title: 'Course', backHref: 'student.html#/courses', backLabel: 'My courses', extra: [pct] }), h('div', { class: 'learn' }, side, main)));
if (!courseId) mount(main, empty({ title: 'No course selected', message: 'Open a course from your dashboard.', action: h('a', { class: 'btn', href: 'student.html#/courses' }, 'My courses') }));
else init();

let lessons = [], modules = [];
async function init() {
  mount(side, loading(6)); mount(main, loading(5));
  try {
    const [m, l, courses] = await Promise.all([studentApi.modules(courseId), studentApi.lessons(courseId), studentApi.courses()]);
    modules = m.data || []; lessons = l.data || [];
    const course = (courses.data || []).find((c) => idOf(c) === courseId); if (course) { document.getElementById('tool-title').textContent = course.title; document.title = `${course.title} · Learning`; }
    drawSide(); if (!lessons.length) return mount(main, empty({ title: 'No lessons published yet', message: 'Check back soon.', iconName: 'book' }));
    const first = lessons.find((x) => idOf(x) === q.get('lesson')) || lessons.find((x) => !x.isCompleted && !x.isLocked) || lessons[0]; open(first);
  } catch (e) { mount(main, errorState(e, init)); mount(side); }
}
function drawSide(activeId) {
  const done = lessons.filter((l) => l.isCompleted).length; pct.textContent = `${fmtPercent(lessons.length ? (done / lessons.length) * 100 : 0)} complete`;
  const row = (l) => h('button', { class: 'lesson-item', type: 'button', disabled: l.isLocked, 'aria-current': idOf(l) === activeId ? 'true' : null, title: l.isLocked ? 'Finish the prerequisite lessons first' : null, onclick: () => open(l) },
    h('span', { class: `tick ${l.isCompleted ? 'done' : ''}` }, l.isCompleted && icon('check')), h('span', { style: 'flex:1' }, l.title), l.isLocked && h('span', { class: 'badge' }, 'Locked'));
  const groups = modules.map((m) => ({ m, ls: lessons.filter((l) => String(l.moduleId) === String(idOf(m))) })).filter((g) => g.ls.length); const grouped = new Set(groups.flatMap((g) => g.ls.map(idOf)));
  mount(side, groups.map((g) => [h('div', { class: 'module-title' }, g.m.title), g.ls.map(row)]), lessons.filter((l) => !grouped.has(idOf(l))).map(row));
}
async function open(lesson) {
  history.replaceState(null, '', `?course=${courseId}&lesson=${idOf(lesson)}`); drawSide(idOf(lesson)); mount(main, loading(4));
  try {
    const { data: L } = await studentApi.lesson(idOf(lesson)); const i = lessons.findIndex((x) => idOf(x) === idOf(lesson)); const next = lessons.slice(i + 1).find((x) => !x.isLocked), prev = lessons[i - 1];
    const media = []; let lastSent = 0;
    const U = await signUrls([L.video?.fileUrl, ...(L.audio || []).map((a) => a.fileUrl), ...(L.images || []).map((im) => im.url || im.fileUrl), ...(L.pdfs || []).map((p) => p.fileUrl), ...(L.attachments || []).map((a) => a.fileUrl)]);
    if (L.video?.fileUrl) { const v = h('video', { class: 'lesson-media', controls: true, preload: 'metadata', src: U(L.video.fileUrl) });
      const send = (completed) => studentApi.videoProgress(idOf(L), Math.floor(v.currentTime), completed).then(() => { if (completed) { lesson.isCompleted = true; drawSide(idOf(L)); } }).catch(() => {});
      v.addEventListener('timeupdate', () => { if (v.currentTime - lastSent > 15) { lastSent = v.currentTime; send(false); } }); v.addEventListener('ended', () => send(true)); media.push(v); }
    (L.audio || []).forEach((a) => media.push(h('div', null, h('div', { class: 'small muted' }, a.fileName), h('audio', { controls: true, src: U(a.fileUrl), style: 'width:100%' }))));
    (L.images || []).forEach((im) => media.push(h('img', { src: U(im.url || im.fileUrl), alt: im.caption || im.fileName || 'Lesson image', loading: 'lazy' })));
    (L.pdfs || []).forEach((p) => media.push(h('div', { class: 'stack-sm' }, h('a', { class: 'btn btn-secondary btn-sm', href: U(p.fileUrl), target: '_blank', rel: 'noopener' }, icon('external'), `Open ${p.fileName}`), h('iframe', { class: 'lesson-frame', title: p.fileName, src: U(p.fileUrl), loading: 'lazy' }))));
    const files = [...(L.attachments || []).map((a) => ({ t: a.fileName, u: U(a.fileUrl) })), ...(L.externalResources || []).map((r) => ({ t: r.title, u: r.url, d: r.description }))];
    const completeBtn = h('button', { class: 'btn', type: 'button', disabled: lesson.isCompleted, onclick: async (e) => { try { await busy(e.currentTarget, () => studentApi.completeLesson(idOf(L))); lesson.isCompleted = true; toast.success('Lesson complete.'); drawSide(idOf(L)); e.currentTarget.disabled = true; e.currentTarget.textContent = 'Completed'; } catch (err) { toast.error(err.message); } } }, lesson.isCompleted ? 'Completed' : 'Mark as complete');
    mount(main, h('article', { class: 'stack' }, h('h1', { style: 'margin:0' }, L.title), L.description && h('p', { class: 'muted' }, L.description), renderText(L.text), ...media,
      files.length ? h('section', null, h('h2', null, 'Resources'), h('ul', null, files.map((f) => h('li', null, h('a', { href: safeHref(f.u), target: '_blank', rel: 'noopener noreferrer' }, f.t), f.d && h('span', { class: 'muted small' }, ` — ${f.d}`))))) : null,
      h('div', { class: 'spread', style: 'border-top:1px solid var(--line);padding-top:16px' }, h('div', { class: 'row' }, prev && h('button', { class: 'btn btn-secondary', type: 'button', onclick: () => open(prev) }, icon('back'), 'Previous'), completeBtn),
        h('div', { class: 'row' }, h('a', { class: 'btn btn-ghost', href: `ai.html?course=${courseId}&lesson=${idOf(L)}` }, icon('bot'), 'Ask the AI about this lesson'), next && h('button', { class: 'btn', type: 'button', onclick: () => open(next) }, 'Next lesson')))));
    main.focus({ preventScroll: true }); main.scrollTop = 0;
  } catch (e) { mount(main, errorState(e, () => open(lesson))); }
}
