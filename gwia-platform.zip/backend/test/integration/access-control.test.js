const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { boot, itest, missing } = require('./helpers');

let t, student, other, teacher, outsider, admin, course, paidCourse, lesson;
const oid = () => new (require('mongoose').Types.ObjectId)();

before(async () => {
  if (missing) return;
  t = await boot();
  [student, other, teacher, outsider, admin] = [await t.actor('student'), await t.actor('student'), await t.actor('teacher'), await t.actor('teacher'), await t.actor('admin')];
  const { Course } = require('../../src/models/course.model');
  const Lesson = require('../../src/models/lesson.model');
  course = await Course.create({ title: 'Python', teacherIds: [teacher.user.id || teacher.user._id], createdBy: teacher.user.id || teacher.user._id, status: 'published', enrolledStudentIds: [student.user.id || student.user._id] });
  paidCourse = await Course.create({ title: 'Paid', price: 5000, currency: 'NGN', teacherIds: [teacher.user.id || teacher.user._id], createdBy: teacher.user.id || teacher.user._id, status: 'published', enrolledStudentIds: [student.user.id || student.user._id] });
  lesson = await Lesson.create({ courseId: course._id, subjectId: oid(), moduleId: oid(), title: 'L1', status: 'published', createdBy: teacher.user.id || teacher.user._id,
    video: { fileUrl: '/uploads/videos/secret-lesson.mp4' }, pdfs: [{ fileName: 'n.pdf', fileUrl: '/uploads/pdfs/notes.pdf', mimeType: 'application/pdf', size: 10 }] });
});
after(async () => { if (t) await t.close(); });

/* ---------------- Courses / ownership (IDOR) ---------------- */
itest(test, 'IDOR: a teacher cannot modify or delete another teacher\'s course', async () => {
  const upd = await outsider.api.put(`/api/courses/${course._id}`).send({ title: 'Hijacked' });
  assert.equal(upd.status, 403);
  const del = await outsider.api.delete(`/api/courses/${course._id}`);
  assert.equal(del.status, 403);
});

itest(test, 'IDOR: a student cannot create, edit or delete courses', async () => {
  assert.equal((await student.api.post('/api/courses').send({ title: 'Nope' })).status, 403);
  assert.equal((await student.api.put(`/api/courses/${course._id}`).send({ title: 'Nope' })).status, 403);
});

itest(test, 'IDOR: a student not enrolled cannot read lessons of the course', async () => {
  const res = await other.api.get(`/api/student/lessons/${lesson._id}`);
  assert.equal(res.status, 403);
});

itest(test, 'enrolled student can read a free-course lesson', async () => {
  const res = await student.api.get(`/api/student/lessons/${lesson._id}`);
  assert.equal(res.status, 200);
});

itest(test, 'paid content: an enrolled student without payment gets 402, not the content', async () => {
  const res = await student.api.get(`/api/student/courses/${paidCourse._id}/lessons`);
  assert.equal(res.status, 402);
});

itest(test, 'draft lessons are invisible to students', async () => {
  const Lesson = require('../../src/models/lesson.model');
  const draft = await Lesson.create({ courseId: course._id, subjectId: oid(), moduleId: oid(), title: 'Draft', status: 'draft', createdBy: teacher.user.id || teacher.user._id });
  assert.equal((await student.api.get(`/api/student/lessons/${draft._id}`)).status, 404);
});

/* ---------------- Submissions / grading (IDOR) ---------------- */
itest(test, 'IDOR: only the owning teacher (or admin) may open or grade a submission; students never', async () => {
  const Submission = require('../../src/models/submission.model');
  const sub = await Submission.create({ refType: 'assignment', refId: oid(), courseId: course._id, studentId: student.user.id || student.user._id, status: 'submitted',
    files: [{ fileName: 'a.pdf', fileUrl: '/uploads/submissions/sub-1.pdf', mimeType: 'application/pdf', size: 5 }] });
  assert.equal((await student.api.get(`/api/submissions/${sub._id}`)).status, 403);
  assert.equal((await outsider.api.get(`/api/submissions/${sub._id}`)).status, 403);
  assert.equal((await outsider.api.put(`/api/submissions/${sub._id}/grade`).send({ score: 100 })).status, 403);
  assert.notEqual((await teacher.api.get(`/api/submissions/${sub._id}`)).status, 403);
});

/* ---------------- Messaging (IDOR) ---------------- */
itest(test, 'IDOR: users outside a conversation cannot read or post to it', async () => {
  const { Conversation, Message } = require('../../src/models/messaging.model');
  const conv = await Conversation.create({ participantIds: [student.user.id || student.user._id, teacher.user.id || teacher.user._id], participantRoles: ['student', 'teacher'] });
  await Message.create({ conversationId: conv._id, senderId: student.user.id || student.user._id, text: 'private', readBy: [student.user.id || student.user._id] });
  assert.equal((await other.api.get(`/api/messages/conversations/${conv._id}/messages`)).status, 403);
  assert.equal((await other.api.post(`/api/messages/conversations/${conv._id}/messages`).send({ text: 'intrude' })).status, 403);
  assert.equal((await teacher.api.get(`/api/messages/conversations/${conv._id}/messages`)).status, 200);
});

itest(test, 'messaging: students cannot start conversations with other students', async () => {
  const res = await student.api.post('/api/messages/conversations').send({ recipientId: String(other.user.id || other.user._id) });
  assert.ok([400, 403].includes(res.status));
});

/* ---------------- Notifications (IDOR) ---------------- */
itest(test, 'IDOR: a user cannot mark someone else\'s notification as read', async () => {
  const Notification = require('../../src/models/notification.model');
  const n = await Notification.create({ userId: student.user.id || student.user._id, type: 'system', title: 't', message: 'm' });
  const res = await other.api.put(`/api/notifications/${n._id}/read`);
  assert.ok([403, 404].includes(res.status));
  assert.equal((await Notification.findById(n._id)).read, false);
});

/* ---------------- Payments (IDOR, tampering) ---------------- */
itest(test, 'IDOR: payment, receipt and verify endpoints only work for the owner', async () => {
  const { Payment } = require('../../src/models/billing.model');
  const p = await Payment.create({ userId: student.user.id || student.user._id, purpose: 'course', courseId: paidCourse._id, description: 'x', amount: 5000, amountMinor: 500000, currency: 'NGN', provider: 'paystack', reference: 'GW-0123456789ab', status: 'completed', receiptNumber: 'R-1', customerEmail: 'a@b.c' });
  assert.equal((await other.api.get(`/api/billing/payments/${p._id}`)).status, 404);
  assert.equal((await other.api.get(`/api/billing/payments/${p._id}/receipt`)).status, 404);
  assert.equal((await other.api.post(`/api/billing/payments/${p.reference}/verify`).send({})).status, 404);
  const mine = await student.api.get(`/api/billing/payments/${p._id}`);
  assert.equal(mine.status, 200);
  assert.ok(!('providerPayload' in mine.body.data), 'raw gateway payload must never reach the browser');
  assert.ok(!('ipAddress' in mine.body.data));
});

itest(test, 'payment tampering: client-supplied amount, currency or price fields are ignored / rejected', async () => {
  const res = await student.api.post('/api/billing/checkout').send({ purpose: 'course', courseId: String(paidCourse._id), amount: 1, amountMinor: 1, price: 1 });
  // No gateway keys exist in the test environment, so a legitimate checkout fails with 503; what matters is that
  // a payment, if one was recorded, was priced by the server.
  const { Payment } = require('../../src/models/billing.model');
  const rec = await Payment.findOne({ userId: student.user.id || student.user._id, courseId: paidCourse._id, status: { $in: ['pending', 'failed'] } }).sort({ createdAt: -1 });
  if (rec) assert.equal(rec.amountMinor, 500000);
  assert.notEqual(res.status, 200);
});

itest(test, 'webhooks: unsigned or wrongly signed events are rejected', async () => {
  const body = JSON.stringify({ event: 'charge.success', data: { reference: 'GW-0123456789ab', status: 'success', amount: 1 } });
  for (const provider of ['paystack', 'flutterwave']) {
    const res = await t.request.post(`/api/webhooks/${provider}`).set('Content-Type', 'application/json').set('x-paystack-signature', 'bad').set('verif-hash', 'bad').send(body);
    assert.ok([400, 401, 503].includes(res.status), `${provider} -> ${res.status}`);
  }
});

itest(test, 'students cannot use admin payment/subscription tools', async () => {
  assert.equal((await student.api.post('/api/admin/payments').send({})).status, 403);
  assert.equal((await student.api.put('/api/admin/payments/x/status').send({ status: 'completed' })).status, 403);
});

/* ---------------- Certificates ---------------- */
itest(test, 'certificates: public verification returns nothing sensitive and 404 for unknown IDs', async () => {
  const res = await t.request.get('/api/certificates/verify/CERT-AAAA-BBBB-CCCC');
  assert.equal(res.status, 404);
  assert.ok(!JSON.stringify(res.body).includes('email'));
});

itest(test, 'IDOR: a student cannot download another student\'s certificate', async () => {
  const res = await other.api.get(`/api/student/certificates/${oid()}/download`);
  assert.ok([403, 404].includes(res.status));
});

/* ---------------- Admin functions ---------------- */
itest(test, 'admin: teacher accounts are created by admins only; the account can then sign in after password setup', async () => {
  assert.equal((await teacher.api.post('/api/admin/users').send({ name: 'T', email: 't@x.com', role: 'teacher' })).status, 403);
  const res = await admin.api.post('/api/admin/users').send({ name: 'New Teacher', email: 'newteacher@example.com', role: 'teacher' });
  assert.equal(res.status, 201);
  assert.equal(res.body.data.user.role, 'teacher');
  assert.equal((await admin.api.post('/api/admin/users').send({ name: 'Boss', email: 'boss@example.com', role: 'admin' })).status, 400);
});

itest(test, 'admin: cannot suspend or re-role yourself or another admin; suspended users are locked out at once', async () => {
  const adminId = admin.user.id || admin.user._id;
  assert.equal((await admin.api.post(`/api/admin/users/${adminId}/suspend`).send({})).status, 400);
  assert.equal((await admin.api.put(`/api/admin/users/${adminId}/role`).send({ role: 'student' })).status, 400);
  const victim = await t.actor('student');
  assert.equal((await admin.api.post(`/api/admin/users/${victim.user.id || victim.user._id}/suspend`).send({})).status, 200);
  assert.equal((await victim.api.get('/api/auth/me')).status, 403);
});

itest(test, 'admin: user listings never expose password hashes or tokens; search treats input literally', async () => {
  const res = await admin.api.get('/api/admin/users?limit=500&search=' + encodeURIComponent('(a+)+$'));
  assert.equal(res.status, 200);
  const text = JSON.stringify(res.body);
  for (const secret of ['passwordHash', 'refreshTokens', 'passwordResetToken', 'emailVerificationToken']) assert.ok(!text.includes(secret), secret);
  assert.ok(res.body.meta.limit <= 100, 'page size is capped');
});
