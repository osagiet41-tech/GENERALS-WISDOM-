import { api, download, openBlob } from '../core/http.js';
export const billingApi = {
  plans: () => api.get('/billing/plans', null, { auth: false }),
  subscription: () => api.get('/billing/subscription'),
  payments: (q) => api.get('/billing/payments', q),
  receipt: (id) => api.get(`/billing/payments/${id}/receipt`),
  receiptPdf: (id) => download(`/billing/payments/${id}/receipt.pdf`, `receipt-${id}.pdf`),
  courseAccess: (courseId) => api.get(`/billing/courses/${courseId}/access`),
  validateDiscount: (body) => api.post('/billing/discounts/validate', body),
  checkout: (body) => api.post('/billing/checkout', body),
  verify: (reference, transactionId) => api.post(`/billing/payments/${encodeURIComponent(reference)}/verify`, transactionId ? { transactionId } : {}),
  startTrial: (planCode) => api.post('/billing/trial', { planCode })
};
export { openBlob };
