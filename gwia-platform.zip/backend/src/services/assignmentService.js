const fs = require('fs');
const path = require('path');
const Assignment = require('../models/assignment.model');

async function createAssignment(courseId, teacherId, data) {
  return Assignment.create({
    courseId,
    subjectId: data.subjectId || null,
    moduleId: data.moduleId || null,
    lessonId: data.lessonId || null,
    title: data.title,
    instructions: data.instructions || '',
    totalMarks: data.totalMarks,
    dueDate: data.dueDate,
    allowLateSubmission: !!data.allowLateSubmission,
    allowResubmission: data.allowResubmission !== undefined ? !!data.allowResubmission : true,
    status: data.status || 'draft',
    createdBy: teacherId
  });
}

async function updateAssignment(assignment, updates) {
  const allowed = [
    'title',
    'instructions',
    'totalMarks',
    'dueDate',
    'allowLateSubmission',
    'allowResubmission',
    'status',
    'subjectId',
    'moduleId',
    'lessonId'
  ];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      assignment[field] = updates[field];
    }
  }
  await assignment.save();
  return assignment;
}

async function publishAssignment(assignment) {
  assignment.status = 'published';
  await assignment.save();
  return assignment;
}

async function unpublishAssignment(assignment) {
  assignment.status = 'draft';
  await assignment.save();
  return assignment;
}

async function deleteAssignment(assignment) {
  for (const attachment of assignment.attachments) {
    fs.unlink(path.join(__dirname, '..', '..', attachment.fileUrl.replace(/^\//, '')), () => {});
  }
  await assignment.deleteOne();
}

async function addAttachment(assignment, file) {
  assignment.attachments.push({
    fileName: file.originalname,
    fileUrl: `/uploads/materials/${file.filename}`,
    mimeType: file.mimetype,
    size: file.size
  });
  await assignment.save();
  return assignment;
}

async function listAssignments(courseId, status) {
  const filter = { courseId };
  if (status) filter.status = status;
  return Assignment.find(filter).sort({ dueDate: 1 });
}

module.exports = {
  createAssignment,
  updateAssignment,
  publishAssignment,
  unpublishAssignment,
  deleteAssignment,
  addAttachment,
  listAssignments
};
