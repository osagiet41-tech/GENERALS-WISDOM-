const { body } = require('express-validator');

const contextValidators = [
  body('courseId').optional().isMongoId(),
  body('subjectId').optional().isMongoId(),
  body('lessonId').optional().isMongoId()
];

const QUESTION_TYPES = ['mcq', 'true_false', 'short_answer', 'essay'];
const DIFFICULTIES = ['easy', 'medium', 'hard'];

const questionSetValidators = [
  body('topic').trim().notEmpty().withMessage('topic is required').isLength({ max: 300 }),
  body('numQuestions').optional().isInt({ min: 1, max: 30 }),
  body('difficulty').optional().isIn(DIFFICULTIES),
  body('questionTypes').optional().isArray(),
  body('questionTypes.*').optional().isIn(QUESTION_TYPES),
  body('marksPerQuestion').optional().isInt({ min: 1 })
];

const flashcardsValidators = [
  body('topic').trim().notEmpty().withMessage('topic is required').isLength({ max: 300 }),
  body('count').optional().isInt({ min: 1, max: 30 })
];

const TEACHER_VALIDATORS = {
  lessonPlan: [
    ...contextValidators,
    body('topic').trim().notEmpty().withMessage('topic is required').isLength({ max: 300 }),
    body('durationMinutes').optional().isInt({ min: 5, max: 480 }),
    body('objectives').optional().isString().isLength({ max: 1000 })
  ],
  lessonNotes: [
    ...contextValidators,
    body('topic').trim().notEmpty().withMessage('topic is required').isLength({ max: 300 }),
    body('depth').optional().isString().isLength({ max: 300 })
  ],
  quiz: [...contextValidators, ...questionSetValidators],
  examQuestions: [...contextValidators, ...questionSetValidators],
  assessmentQuestions: [...contextValidators, ...questionSetValidators],
  assignment: [
    ...contextValidators,
    body('topic').trim().notEmpty().withMessage('topic is required').isLength({ max: 300 }),
    body('instructions').optional().isString().isLength({ max: 2000 }),
    body('totalMarks').optional().isInt({ min: 1 })
  ],
  markingGuide: [
    ...contextValidators,
    body('questionText').trim().notEmpty().withMessage('questionText is required').isLength({ max: 2000 }),
    body('totalMarks').optional().isInt({ min: 1 })
  ],
  explainConcept: [
    ...contextValidators,
    body('concept').trim().notEmpty().withMessage('concept is required').isLength({ max: 300 })
  ],
  revisionMaterials: [
    ...contextValidators,
    body('topic').trim().notEmpty().withMessage('topic is required').isLength({ max: 300 }),
    body('format').optional().isString().isLength({ max: 300 })
  ],
  summary: [
    ...contextValidators,
    body('text').trim().notEmpty().withMessage('text is required').isLength({ max: 20000 }),
    body('length').optional().isString().isLength({ max: 100 })
  ],
  flashcards: [...contextValidators, ...flashcardsValidators],
  teachingActivities: [
    ...contextValidators,
    body('topic').trim().notEmpty().withMessage('topic is required').isLength({ max: 300 }),
    body('classLevel').optional().isString().isLength({ max: 100 }),
    body('duration').optional().isInt({ min: 5, max: 180 })
  ],
  learningObjectives: [
    ...contextValidators,
    body('topic').trim().notEmpty().withMessage('topic is required').isLength({ max: 300 }),
    body('count').optional().isInt({ min: 1, max: 10 })
  ]
};

const STUDENT_VALIDATORS = {
  explainConcept: [
    ...contextValidators,
    body('concept').trim().notEmpty().withMessage('concept is required').isLength({ max: 300 })
  ],
  answerQuestion: [
    ...contextValidators,
    body('question').trim().notEmpty().withMessage('question is required').isLength({ max: 2000 })
  ],
  stepByStep: [
    ...contextValidators,
    body('problem').trim().notEmpty().withMessage('problem is required').isLength({ max: 2000 })
  ],
  practiceQuestions: [...contextValidators, ...questionSetValidators],
  revisionPlan: [
    ...contextValidators,
    body('topics')
      .custom((value) => typeof value === 'string' || Array.isArray(value))
      .withMessage('topics is required (string or array)'),
    body('daysAvailable').optional().isInt({ min: 1, max: 60 }),
    body('examDate').optional().isString()
  ],
  summarizeLesson: [
    body('lessonId').isMongoId().withMessage('lessonId is required to summarize a lesson'),
    body('courseId').optional().isMongoId(),
    body('subjectId').optional().isMongoId(),
    body('length').optional().isString().isLength({ max: 100 })
  ],
  flashcards: [...contextValidators, ...flashcardsValidators],
  hint: [
    ...contextValidators,
    body('question').trim().notEmpty().withMessage('question is required').isLength({ max: 2000 }),
    body('studentAttempt').optional().isString().isLength({ max: 2000 })
  ]
};

module.exports = { TEACHER_VALIDATORS, STUDENT_VALIDATORS };
