const { body } = require('express-validator');

const enrollValidator = [body('courseId').isMongoId().withMessage('A valid courseId is required')];

const videoProgressValidator = [
  body('watchedSeconds').isFloat({ min: 0 }).withMessage('watchedSeconds must be a non-negative number'),
  body('completed').optional().isBoolean()
];

const submitAssignmentValidator = [
  body('textAnswer').optional().isString().isLength({ max: 20000 })
];

const saveProgressValidator = [
  body('answers').isArray({ min: 1 }).withMessage('answers must be a non-empty array'),
  body('answers.*.questionId').isMongoId().withMessage('Each answer must reference a valid questionId'),
  body('answers.*.response').optional(),
  body('answers.*.markedForReview').optional().isBoolean(),
  body('answers.*.visited').optional().isBoolean()
];

const finalizeAssessmentValidator = [
  body('answers').optional().isArray().withMessage('answers must be an array'),
  body('answers.*.questionId').optional().isMongoId().withMessage('Each answer must reference a valid questionId'),
  body('answers.*.response').optional(),
  body('answers.*.markedForReview').optional().isBoolean(),
  body('answers.*.visited').optional().isBoolean()
];

module.exports = {
  enrollValidator,
  videoProgressValidator,
  submitAssignmentValidator,
  saveProgressValidator,
  finalizeAssessmentValidator
};
