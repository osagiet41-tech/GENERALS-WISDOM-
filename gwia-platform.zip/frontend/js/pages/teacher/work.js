import { bindFile } from '../../core/files.js';
import { h, mount, icon } from '../../core/dom.js';
import { teacherApi } from '../../api/teacher.js';
import { pageHead, items, idOf } from '../../ui/page.js';
import { courseSelect } from '../shared/courseSelect.js';
import { withState, empty, busy } from '../../ui/states.js';
import { tabs } from '../../ui/tabs.js';
import { dataTable, statusBadge } from '../../ui/table.js';
import { openModal } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { fmtDateTime } from '../../core/format.js';
import { ApiError } from '../../core/http.js';

export default async function render() {
  const { data: courses } = await teacherApi.courses(); const panel = h('div');
  const cs = courseSelect(courses, { storageKey: 'teacher.work.course', onChange: (id) => load(id) });
  if (!cs.count) return h('div', null, pageHead('Assessments & grading'), empty({ title: 'Create a course first', iconName: 'file' }));
  const load = (cid) => mount(panel, tabs([
    { id: 'a', label: 'Assignments', render: (p) => assignmentsTab(p, cid) }, { id: 'q', label: 'Quizzes', render: (p) => assessmentTab(p, 'quizzes', cid) }, { id: 'e', label: 'Exams', render: (p) => assessmentTab(p, 'exams', cid) }]));
  load(cs.value);
  return h('div', { class: 'stack' }, pageHead('Assessments & grading', 'Create assessments and mark submissions.'), cs.el, panel);
}

function assignmentsTab(panel, cid) {
  let reload;
  const act = (fn, msg) => async (e) => { try { await busy(e.currentTarget, fn); toast.success(msg); reload(); } catch (err) { toast.error(err.message); } };
  const create = () => { const m = openModal({ title: 'New assignment', size: 'lg', body: buildForm({ submitLabel: 'Create', onCancel: () => m.close(), fields: [
    { name: 'title', label: 'Title', required: true, full: true }, { name: 'instructions', label: 'Instructions', type: 'textarea', full: true, rows: 5 }, { name: 'totalMarks', label: 'Total marks', type: 'number', min: 1, required: true, value: 100 },
    { name: 'dueDate', label: 'Due', type: 'datetime-local', required: true }, { name: 'allowLateSubmission', label: 'Allow late submissions', type: 'checkbox' }, { name: 'allowResubmission', label: 'Allow resubmission', type: 'checkbox' },
    { name: 'status', label: 'Status', type: 'select', value: 'draft', options: ['draft', 'published'].map((v) => ({ value: v, label: v })) }],
    onSubmit: async (v) => { await teacherApi.createAssignment(cid, { ...v, dueDate: new Date(v.dueDate).toISOString() }); m.close(); toast.success('Assignment created.'); reload(); } }) }); };
  reload = withState(panel, () => teacherApi.assignments(cid).then((r) => items(r.data)), (rows) => h('div', { class: 'stack' }, h('div', null, h('button', { class: 'btn', type: 'button', onclick: create }, icon('plus'), 'New assignment')),
    h('div', { class: 'card card-flush' }, dataTable({ rows, caption: 'Assignments', emptyState: empty({ title: 'No assignments', iconName: 'file' }),
      columns: [{ label: 'Title', render: (r) => h('strong', null, r.title) }, { label: 'Due', render: (r) => fmtDateTime(r.dueDate) }, { label: 'Marks', key: 'totalMarks' }, { label: 'Status', render: (r) => statusBadge(r.status) }],
      actions: (r) => h('div', { class: 'row', style: 'justify-content:flex-end' }, h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: () => submissionsModal('assignments', r) }, 'Submissions'),
        r.status === 'published' ? h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: act(() => teacherApi.unpublishAssignment(idOf(r)), 'Unpublished.') }, 'Unpublish') : h('button', { class: 'btn btn-sm', type: 'button', onclick: act(() => teacherApi.publishAssignment(idOf(r)), 'Published.') }, 'Publish')) }))), { rows: 3 });
}

function assessmentTab(panel, kind, cid) {
  const label = kind === 'exams' ? 'exam' : 'quiz'; let reload;
  const create = async () => {
    let bank; try { bank = items((await teacherApi.questions(cid, { limit: 100 })).data); } catch (e) { return toast.error(e.message); }
    if (!bank.length) return toast.info('Add questions to the question bank first.');
    const picks = bank.map((q) => ({ q, box: h('input', { type: 'checkbox', 'aria-label': `Include: ${q.text}` }) }));
    const list = h('div', { style: 'max-height:220px;overflow:auto;border:1px solid var(--line);border-radius:8px' }, picks.map((p) => h('label', { class: 'check', style: 'padding:8px 12px;border-bottom:1px solid var(--line)' }, p.box, h('span', null, p.q.text, h('span', { class: 'small muted' }, ` (${p.q.type}, ${p.q.marks || 1} marks)`)))));
    const form = buildForm({ submitLabel: `Create ${label}`, onCancel: () => m.close(), fields: [
      { name: 'title', label: 'Title', required: true, full: true }, { name: 'instructions', label: 'Instructions', type: 'textarea', full: true, rows: 3 },
      { name: 'durationMinutes', label: 'Duration (minutes)', type: 'number', min: 1, required: true, value: kind === 'exams' ? 90 : 20 }, { name: 'passingMarks', label: 'Passing marks', type: 'number', min: 0 },
      { name: 'availableFrom', label: 'Opens', type: 'datetime-local', required: true }, { name: 'availableUntil', label: 'Closes', type: 'datetime-local', required: true }, { name: 'maxAttempts', label: 'Max attempts', type: 'number', min: 1, value: 1 },
      { name: 'shuffleQuestions', label: 'Shuffle questions', type: 'checkbox' }, { name: 'shuffleOptions', label: 'Shuffle options', type: 'checkbox' }, { name: 'status', label: 'Status', type: 'select', value: 'draft', options: ['draft', 'published'].map((v) => ({ value: v, label: v })) }],
      onSubmit: async (v) => {
        const questions = picks.filter((p) => p.box.checked).map((p) => ({ questionId: idOf(p.q), marks: p.q.marks || 1 }));
        if (!questions.length) throw new ApiError(400, 'Select at least one question.');
        await teacherApi.createAssessment(kind, cid, { ...v, questions, availableFrom: new Date(v.availableFrom).toISOString(), availableUntil: new Date(v.availableUntil).toISOString() }); m.close(); toast.success(`${label[0].toUpperCase() + label.slice(1)} created.`); reload();
      } });
    form.insertBefore(h('div', { class: 'field' }, h('span', { class: 'label' }, `Questions (${bank.length} in bank)`), list), form.lastChild);
    const m = openModal({ title: `New ${label}`, size: 'lg', body: form });
  };
  reload = withState(panel, () => teacherApi[kind](cid).then((r) => items(r.data)), (rows) => h('div', { class: 'stack' }, h('div', null, h('button', { class: 'btn', type: 'button', onclick: create }, icon('plus'), `New ${label}`)),
    h('div', { class: 'card card-flush' }, dataTable({ rows, caption: `${label}s`, emptyState: empty({ title: `No ${label}s yet`, iconName: 'file' }),
      columns: [{ label: 'Title', render: (r) => h('strong', null, r.title) }, { label: 'Duration', render: (r) => `${r.durationMinutes} min` }, { label: 'Window', render: (r) => `${fmtDateTime(r.availableFrom)} → ${fmtDateTime(r.availableUntil)}` }, { label: 'Status', render: (r) => statusBadge(r.status) }],
      actions: (r) => h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: () => submissionsModal(kind, r) }, 'Results & grading') }))), { rows: 3 });
}

function submissionsModal(kind, item) {
  const body = h('div'); openModal({ title: `${item.title}: submissions`, size: 'lg', body });
  const load = () => withState(body, () => teacherApi.submissions(kind, idOf(item)).then((r) => items(r.data)), (rows) => dataTable({ rows, caption: 'Submissions', emptyState: empty({ title: 'No submissions yet' }), rowKey: (r) => idOf(r),
    columns: [{ label: 'Student', render: (r) => r.studentId?.name || 'Student' }, { label: 'Submitted', render: (r) => fmtDateTime(r.submittedAt) }, { label: 'Status', render: (r) => statusBadge(r.status) }, { label: 'Score', render: (r) => (r.grade ? `${r.grade.score} / ${r.grade.totalMarks}` : '—') }],
    actions: (r) => h('button', { class: 'btn btn-sm', type: 'button', onclick: () => gradeModal(r, load) }, r.status === 'graded' ? 'Regrade' : 'Grade') }), { rows: 3 });
  load();
}
function gradeModal(sub, done) {
  const m = openModal({ title: `Grade ${sub.studentId?.name || 'submission'}`, body: h('div', { class: 'stack' }, sub.textAnswer && h('div', { class: 'card', style: 'white-space:pre-wrap' }, sub.textAnswer),
    (sub.files || sub.attachments || []).length ? h('ul', null, (sub.files || sub.attachments).map((f) => h('li', null, f.fileUrl ? bindFile(h('a', { target: '_blank', rel: 'noopener' }, f.fileName || f.originalName || 'Open file'), 'href', f.fileUrl) : (f.fileName || f.originalName)))) : null,
    buildForm({ grid: false, submitLabel: 'Save grade', onCancel: () => m.close(), fields: [{ name: 'score', label: 'Score', type: 'number', min: 0, step: '0.5', required: true, value: sub.grade?.score }, { name: 'feedback', label: 'Feedback', type: 'textarea', maxlength: 3000, value: sub.grade?.feedback }],
      onSubmit: async (v) => { await teacherApi.grade(idOf(sub), v); m.close(); toast.success('Grade saved.'); done(); } })) });
}
