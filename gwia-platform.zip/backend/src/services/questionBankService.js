const { Question } = require('../models/assessment.model');
const ApiError = require('../utils/ApiError');

async function createQuestion(courseId, teacherId, data) {
  return Question.create({
    courseId,
    type: data.type,
    text: data.text,
    options: data.options || [],
    correctAnswer: data.correctAnswer,
    marks: data.marks || 1,
    difficulty: data.difficulty || 'medium',
    tags: data.tags || [],
    createdBy: teacherId
  });
}

async function updateQuestion(question, updates) {
  const allowed = ['type', 'text', 'options', 'correctAnswer', 'marks', 'difficulty', 'tags'];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      question[field] = updates[field];
    }
  }
  await question.save();
  return question;
}

async function deleteQuestion(question) {
  await question.deleteOne();
}

async function listQuestions(courseId, { tag, difficulty, type, page = 1, limit = 50 } = {}) {
  const filter = { courseId };
  if (tag) filter.tags = tag;
  if (difficulty) filter.difficulty = difficulty;
  if (type) filter.type = type;

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    Question.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
    Question.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function bulkImportQuestions(courseId, teacherId, rows) {
  const docs = rows.map((row) => ({
    courseId,
    type: row.type,
    text: row.text,
    options: row.options ? String(row.options).split('|').map((s) => s.trim()) : [],
    correctAnswer: row.correctAnswer,
    marks: Number(row.marks) || 1,
    difficulty: row.difficulty || 'medium',
    tags: row.tags ? String(row.tags).split(',').map((s) => s.trim()) : [],
    createdBy: teacherId
  }));

  if (docs.length === 0) {
    throw ApiError.badRequest('No valid question rows found in the uploaded file');
  }

  return Question.insertMany(docs);
}

module.exports = { createQuestion, updateQuestion, deleteQuestion, listQuestions, bulkImportQuestions };
