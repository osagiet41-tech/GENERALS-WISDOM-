const env = require('../config/env');
const logger = require('../utils/logger');
const PushSubscription = require('../models/pushSubscription.model');

/**
 * Push notification architecture
 *
 *   notificationService.createNotification()  --(fire and forget)-->  pushService.sendToUser()
 *        |                                                              |
 *        +-- Socket.IO 'notification:new' (app open)                    +-- Web Push (VAPID) -> service worker 'push' event
 *                                                                       +-- FCM (native app): add a sender here, see docs/PUSH.md
 *
 * Everything is optional: with no VAPID keys or no `web-push` package installed, sending is a silent no-op.
 */
let webpush = null;
let configured = false;
let fcm = null;
let fcmConfigured = false;

/* Native Android (Capacitor) devices are reached through Firebase Cloud Messaging. Optional: needs `npm i firebase-admin`
   and FCM_SERVICE_ACCOUNT_FILE pointing at a service-account JSON that stays on the server (never in git or the app). */
function initFcm() {
  if (fcmConfigured) return fcm;
  fcmConfigured = true;
  if (!env.push.fcmServiceAccountFile) return null;
  try {
    // eslint-disable-next-line global-require
    const admin = require('firebase-admin');
    // eslint-disable-next-line global-require, import/no-dynamic-require
    const credentials = require(require('path').resolve(env.push.fcmServiceAccountFile));
    admin.initializeApp({ credential: admin.credential.cert(credentials) });
    fcm = admin.messaging();
  } catch (err) {
    logger.warn(`FCM push disabled: ${err.message}`);
    fcm = null;
  }
  return fcm;
}

function init() {
  if (configured) return webpush;
  configured = true;
  if (!env.push.publicKey || !env.push.privateKey) return null;
  try {
    // eslint-disable-next-line global-require
    webpush = require('web-push');
    webpush.setVapidDetails(env.push.subject, env.push.publicKey, env.push.privateKey);
  } catch (err) {
    logger.warn(`Web Push disabled: ${err.message}`);
    webpush = null;
  }
  return webpush;
}

const isEnabled = () => Boolean(init() || initFcm());

async function subscribe(userId, { kind = 'webpush', endpoint, keys, userAgent }) {
  return PushSubscription.findOneAndUpdate(
    { endpoint },
    { $set: { userId, kind, endpoint, keys: keys || {}, userAgent: userAgent || null, failureCount: 0 } },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );
}

async function unsubscribe(userId, endpoint) {
  await PushSubscription.deleteOne({ userId, endpoint });
}

/** Payloads are kept tiny and carry no sensitive content: the service worker opens the app, which fetches the details. */
async function sendToUser(userId, { title, body, url = '/', tag }) {
  const wp = init();
  const fcmClient = initFcm();
  if (!wp && !fcmClient) return { sent: 0 };
  const subs = await PushSubscription.find({ userId, kind: wp && fcmClient ? { $in: ['webpush', 'fcm'] } : wp ? 'webpush' : 'fcm' });
  const payload = JSON.stringify({ title: String(title || '').slice(0, 100), body: String(body || '').slice(0, 200), url, tag });
  let sent = 0;
  await Promise.all(
    subs.map(async (sub) => {
      try {
        if (sub.kind === 'fcm') {
          if (!fcmClient) return;
          await fcmClient.send({
            token: sub.endpoint,
            notification: { title: String(title || '').slice(0, 100), body: String(body || '').slice(0, 200) },
            data: { url: String(url || '/') },
            android: { priority: 'high', notification: { channelId: 'default' } }
          });
        } else {
          if (!wp) return;
          await wp.sendNotification({ endpoint: sub.endpoint, keys: sub.keys }, payload, { TTL: 3600 });
        }
        sent += 1;
        await PushSubscription.updateOne({ _id: sub._id }, { $set: { lastSuccessAt: new Date(), failureCount: 0 } });
      } catch (err) {
        if (err.statusCode === 404 || err.statusCode === 410 || err.code === 'messaging/registration-token-not-registered') {
          await PushSubscription.deleteOne({ _id: sub._id }); // the browser says this subscription is gone
        } else {
          await PushSubscription.updateOne({ _id: sub._id }, { $inc: { failureCount: 1 } });
          logger.warn(`Push to ${sub._id} failed: ${err.statusCode || err.message}`);
        }
      }
    })
  );
  return { sent };
}

module.exports = { isEnabled, subscribe, unsubscribe, sendToUser };
