const mongoose = require('mongoose');
const { Schema } = mongoose;

const aiUsageLogSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    role: { type: String, enum: ['teacher', 'student', 'admin'], required: true },
    feature: { type: String, required: true, index: true },

    courseId: { type: Schema.Types.ObjectId, ref: 'Course', default: null },
    subjectId: { type: Schema.Types.ObjectId, ref: 'Subject', default: null },
    lessonId: { type: Schema.Types.ObjectId, ref: 'Lesson', default: null },

    inputTokens: { type: Number, default: null },
    outputTokens: { type: Number, default: null },

    durationMs: { type: Number, default: null },
    success: { type: Boolean, required: true },
    errorMessage: { type: String, default: null }
  },
  { timestamps: true }
);

aiUsageLogSchema.index({ userId: 1, createdAt: -1 });

module.exports = mongoose.model('AiUsageLog', aiUsageLogSchema);
