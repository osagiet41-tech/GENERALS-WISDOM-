const mongoose = require('mongoose');
const crypto = require('crypto');
const { Schema } = mongoose;

const certificateSchema = new Schema(
  {
    studentId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },

    // Public, unguessable identifier printed on the PDF: CERT-XXXX-XXXX-XXXX
    certificateId: { type: String, default: null, trim: true, uppercase: true },

    title: { type: String, required: true },
    issuedAt: { type: Date, default: Date.now },
    completionDate: { type: Date, default: null },

    status: { type: String, enum: ['valid', 'revoked'], default: 'valid', index: true },
    revokedAt: { type: Date, default: null },
    revokedReason: { type: String, default: null, maxlength: 500 },
    revokedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null },

    // Frozen at issue time. The certificate must keep saying what it said when it was issued even if the
    // student renames their account, the course is retitled, or an instructor leaves.
    snapshot: {
      studentName: { type: String, default: null },
      courseTitle: { type: String, default: null },
      institutionName: { type: String, default: null },
      instructors: [
        {
          _id: false,
          name: { type: String },
          signatureFile: { type: String, default: null } // file in storage/signatures/ (content-addressed, never overwritten)
        }
      ],
      signatory: {
        name: { type: String, default: null },
        title: { type: String, default: null },
        signatureFile: { type: String, default: null }
      },
      finalScorePercent: { type: Number, default: null },
      showScore: { type: Boolean, default: false }
    },
    // The requirement checks that were satisfied at issue (audit trail)
    requirementsMet: { type: Schema.Types.Mixed, default: null },

    emailedAt: { type: Date, default: null },

    // Legacy fields kept for certificates issued before this rewrite
    pdfUrl: { type: String, default: null },
    verificationCode: { type: String, unique: true, default: () => crypto.randomBytes(8).toString('hex').toUpperCase() }
  },
  { timestamps: true }
);

certificateSchema.index({ studentId: 1, courseId: 1 }, { unique: true }); // one certificate per student per course
certificateSchema.index(
  { certificateId: 1 },
  { unique: true, partialFilterExpression: { certificateId: { $type: 'string' } } }
);

module.exports = mongoose.model('Certificate', certificateSchema);
