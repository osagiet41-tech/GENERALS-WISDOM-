/* Signed file URLs. The API serves lesson media, chat attachments and submissions only through short-lived signed links
   (an <img>/<video>/<iframe> cannot send an Authorization header). This module asks the API to sign the paths once,
   caches the result, and returns absolute URLs. Avatars and thumbnails are public and are not signed. */
import { api } from './http.js';
import { config } from './config.js';

const PRIVATE = /^\/uploads\/(materials|videos|pdfs|audio|images|submissions|chat)\//;
const cache = new Map(); /* path -> { url, expires } */
const SAFETY_MS = 5 * 60 * 1000;
const TTL_FALLBACK_MS = 2 * 60 * 60 * 1000;

const absolute = (p) => (/^https?:/i.test(p) ? p : `${config.socketUrl}${p}`);

/* Resolves to a function: url(path) -> absolute, ready-to-use URL ('' when the path is empty). */
export async function signUrls(paths) {
  const wanted = [...new Set((paths || []).filter((p) => typeof p === 'string' && PRIVATE.test(p)))];
  const now = Date.now();
  const missing = wanted.filter((p) => !cache.has(p) || cache.get(p).expires - SAFETY_MS < now);
  for (let i = 0; i < missing.length; i += 50) {
    const batch = missing.slice(i, i + 50);
    try {
      const { data } = await api.post('/files/sign', { paths: batch });
      const ttl = (data.expiresInSeconds ? data.expiresInSeconds * 1000 : TTL_FALLBACK_MS);
      for (const p of batch) if (data.urls && data.urls[p]) cache.set(p, { url: absolute(data.urls[p]), expires: now + ttl });
    } catch { /* leave unsigned: the media simply will not load, the rest of the page still works */ }
  }
  return (p) => {
    if (!p) return '';
    if (!PRIVATE.test(p)) return absolute(p);
    const hit = cache.get(p);
    return hit ? hit.url : '';
  };
}

/* For elements built synchronously: sets el[attr] as soon as the signed URL is ready. */
export function bindFile(el, attr, path) {
  signUrls([path]).then((url) => { const u = url(path); if (u) el.setAttribute(attr, u); });
  return el;
}

/* Only http(s) links may be placed in an href (blocks javascript: and data: URLs from teacher-entered resources). */
export function safeHref(u) {
  try { const x = new URL(u, location.href); return x.protocol === 'http:' || x.protocol === 'https:' ? x.href : '#'; } catch { return '#'; }
}
