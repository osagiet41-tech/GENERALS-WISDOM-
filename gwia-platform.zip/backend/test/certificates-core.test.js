const test = require('node:test');
const assert = require('node:assert/strict');
const { generateCertificateId, normalizeCertificateId, isLegacyCode } = require('../src/utils/certificateId');
const { resolveRequirements, evaluateEligibility } = require('../src/services/certificates/eligibility');

test('certificate id: format, uniqueness, alphabet', () => {
  const ids = new Set();
  for (let i = 0; i < 5000; i += 1) {
    const id = generateCertificateId();
    assert.match(id, /^CERT-[0-9A-HJKMNP-TV-Z]{4}-[0-9A-HJKMNP-TV-Z]{4}-[0-9A-HJKMNP-TV-Z]{4}$/);
    ids.add(id);
  }
  assert.equal(ids.size, 5000);
});

test('certificate id: forgiving normalisation, strict rejection', () => {
  const id = 'CERT-7F3K-9QXD-M2WA';
  assert.equal(normalizeCertificateId(id), id);
  assert.equal(normalizeCertificateId(' cert 7f3k 9qxd m2wa '), id);
  assert.equal(normalizeCertificateId('7F3K9QXDM2WA'), id);
  assert.equal(normalizeCertificateId('CERT-7F3K-9QXD-M2WA'.replace('2', 'Z')), 'CERT-7F3K-9QXD-MZWA');
  assert.equal(normalizeCertificateId('CERT-OOOO-IIII-LLLL'), 'CERT-0000-1111-1111'); // O->0, I/L->1
  assert.equal(normalizeCertificateId('CERT-7F3K-9QXD'), null);
  assert.equal(normalizeCertificateId('CERT-7F3U-9QXD-M2WA'), null); // U is not in the alphabet
  assert.equal(normalizeCertificateId('../../etc/passwd'), null);
  assert.equal(normalizeCertificateId({ $ne: null }), null); // NoSQL-injection shaped input
  assert.equal(normalizeCertificateId(undefined), null);
  assert.equal(isLegacyCode('A1B2C3D4E5F60718'), true);
  assert.equal(isLegacyCode('CERT-7F3K-9QXD-M2WA'), false);
});

const stats = (o = {}) => ({
  lessons: { completed: 10, total: 10 },
  assessments: { total: 3, graded: 3, averagePercent: 72 },
  attendance: { counted: 0, present: 0 },
  ...o
});

test('eligibility: defaults require ALL lessons and a 50% average', () => {
  const req = resolveRequirements({});
  assert.equal(req.minLessonCompletionPercent, 100);
  assert.equal(req.minAverageScorePercent, 50);
  assert.equal(evaluateEligibility(req, stats()).eligible, true);
  assert.equal(evaluateEligibility(req, stats({ lessons: { completed: 9, total: 10 } })).eligible, false);
});

test('eligibility: finishing every lesson with a failing score is NOT enough (old code allowed it)', () => {
  const req = resolveRequirements({});
  const r = evaluateEligibility(req, stats({ assessments: { total: 3, graded: 3, averagePercent: 20 } }));
  assert.equal(r.eligible, false);
  assert.equal(r.checks.find((c) => c.key === 'averageScore').met, false);
});

test('eligibility: a course with no assessments can still certify (old code capped it at 60%)', () => {
  const req = resolveRequirements({});
  const r = evaluateEligibility(req, stats({ assessments: { total: 0, graded: 0, averagePercent: null } }));
  assert.equal(r.eligible, true);
  assert.equal(r.checks.some((c) => c.key === 'averageScore'), false);
});

test('eligibility: assessments exist but none graded yet -> not eligible', () => {
  const req = resolveRequirements({});
  const r = evaluateEligibility(req, stats({ assessments: { total: 2, graded: 0, averagePercent: null } }));
  assert.equal(r.eligible, false);
});

test('eligibility: null disables the score check; boundary values are inclusive', () => {
  const noScore = resolveRequirements({ minAverageScorePercent: null });
  assert.equal(evaluateEligibility(noScore, stats({ assessments: { total: 2, graded: 0, averagePercent: null } })).eligible, true);
  const req = resolveRequirements({ minAverageScorePercent: 50, minLessonCompletionPercent: 80 });
  assert.equal(evaluateEligibility(req, stats({ lessons: { completed: 8, total: 10 }, assessments: { total: 1, graded: 1, averagePercent: 50 } })).eligible, true);
  assert.equal(evaluateEligibility(req, stats({ lessons: { completed: 79, total: 100 } })).eligible, false);
});

test('eligibility: requireAllAssessments, attendance, disabled, no lessons', () => {
  const all = resolveRequirements({ requireAllAssessments: true });
  assert.equal(evaluateEligibility(all, stats({ assessments: { total: 3, graded: 2, averagePercent: 90 } })).eligible, false);
  const att = resolveRequirements({ minAttendancePercent: 75 });
  assert.equal(evaluateEligibility(att, stats({ attendance: { counted: 8, present: 5 } })).eligible, false); // 62.5%
  assert.equal(evaluateEligibility(att, stats({ attendance: { counted: 8, present: 6 } })).eligible, true); // 75%
  assert.equal(evaluateEligibility(att, stats({ attendance: { counted: 0, present: 0 } })).eligible, true); // no sessions held
  assert.equal(evaluateEligibility(resolveRequirements({ enabled: false }), stats()).eligible, false);
  assert.equal(evaluateEligibility(resolveRequirements({}), stats({ lessons: { completed: 0, total: 0 } })).eligible, false);
});
