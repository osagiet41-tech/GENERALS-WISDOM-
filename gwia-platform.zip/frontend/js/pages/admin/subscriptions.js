import { h } from '../../core/dom.js';
import { adminApi } from '../../api/admin.js';
import { pageHead, idOf } from '../../ui/page.js';
import { listView } from '../shared/listView.js';
import { statusBadge } from '../../ui/table.js';
import { openModal, confirmDialog } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { fmtMoney, fmtDate, cap } from '../../core/format.js';

export default async function render() {
  const lv = listView({ search: false, caption: 'Subscriptions', fetcher: (q) => adminApi.subscriptions(q), filters: [{ name: 'status', label: 'All statuses', options: ['active', 'trialing', 'expired', 'cancelled'].map((v) => ({ value: v, label: v })) }],
    columns: [{ label: 'User', render: (s) => s.userId?.name || s.userId?.email || String(s.userId || '—') }, { label: 'Plan', render: (s) => cap(s.plan) }, { label: 'Amount', render: (s) => fmtMoney(s.amount, s.currency) }, { label: 'Ends', render: (s) => fmtDate(s.endDate) }, { label: 'Status', render: (s) => statusBadge(s.status) }],
    actions: (s) => h('div', { class: 'row', style: 'justify-content:flex-end' },
      h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: () => { const m = openModal({ title: 'Extend subscription', body: buildForm({ grid: false, submitLabel: 'Extend', onCancel: () => m.close(), fields: [{ name: 'endDate', label: 'New end date', type: 'date', required: true }], onSubmit: async (v) => { await adminApi.extendSubscription(idOf(s), new Date(v.endDate).toISOString()); m.close(); toast.success('Extended.'); lv.reload(); } }) }); } }, 'Extend'),
      ['active', 'trialing'].includes(s.status) && h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: async () => { if (await confirmDialog({ title: 'Cancel subscription?', message: 'Access ends according to the plan rules.', confirmLabel: 'Cancel subscription', danger: true })) { try { await adminApi.cancelSubscription(idOf(s)); toast.success('Cancelled.'); lv.reload(); } catch (e) { toast.error(e.message); } } } }, 'Cancel')) });
  return h('div', { class: 'stack' }, pageHead('Subscriptions'), lv.el);
}
