import { api } from '../core/http.js';
/* Features mirror backend/src/routes/aiRoutes.js. `fields` drives the generated form (name matches the validator). */
const T = (name, label, extra = {}) => ({ name, label, type: 'text', required: true, ...extra });
const N = (name, label, min, max, extra = {}) => ({ name, label, type: 'number', min, max, ...extra });
export const AI_FEATURES = {
  student: [
    { key: 'explain-concept', label: 'Explain a concept', fields: [T('concept', 'Concept')] },
    { key: 'answer-question', label: 'Answer a question', fields: [T('question', 'Your question', { type: 'textarea' })] },
    { key: 'step-by-step', label: 'Step-by-step solution', fields: [T('problem', 'Problem', { type: 'textarea' })] },
    { key: 'practice-questions', label: 'Practice questions', fields: [T('topic', 'Topic'), N('count', 'How many (1–30)', 1, 30)] },
    { key: 'revision-plan', label: 'Revision plan', fields: [T('topics', 'Topics (comma separated)'), N('daysAvailable', 'Days available', 1, 60), { name: 'examDate', label: 'Exam date', type: 'date' }] },
    { key: 'summarize-lesson', label: 'Summarize a lesson', fields: [T('lessonId', 'Lesson ID', { hint: 'Open a lesson and copy its ID from the address bar' })] },
    { key: 'flashcards', label: 'Flashcards', fields: [T('topic', 'Topic'), N('count', 'How many (1–10)', 1, 10)] },
    { key: 'hint', label: 'Get a hint', fields: [T('question', 'Question', { type: 'textarea' })] }
  ],
  teacher: [
    { key: 'lesson-plan', label: 'Lesson plan', fields: [T('topic', 'Topic'), N('durationMinutes', 'Duration (min)', 5, 480), { name: 'objectives', label: 'Objectives', type: 'textarea' }] },
    { key: 'lesson-notes', label: 'Lesson notes', fields: [T('topic', 'Topic'), { name: 'depth', label: 'Depth', type: 'text' }] },
    { key: 'quiz', label: 'Quiz questions', fields: [T('topic', 'Topic'), N('numQuestions', 'Questions (1–30)', 1, 30), { name: 'difficulty', label: 'Difficulty', type: 'select', options: ['easy', 'medium', 'hard'] }] },
    { key: 'exam-questions', label: 'Exam questions', fields: [T('topic', 'Topic'), N('numQuestions', 'Questions (1–30)', 1, 30), { name: 'difficulty', label: 'Difficulty', type: 'select', options: ['easy', 'medium', 'hard'] }, N('marksPerQuestion', 'Marks per question', 1, 100)] },
    { key: 'assessment-questions', label: 'Assessment questions', fields: [T('topic', 'Topic'), N('numQuestions', 'Questions (1–30)', 1, 30)] },
    { key: 'assignment', label: 'Assignment', fields: [T('topic', 'Topic'), { name: 'instructions', label: 'Instructions', type: 'textarea' }, N('totalMarks', 'Total marks', 1, 1000)] },
    { key: 'marking-guide', label: 'Marking guide', fields: [T('questionText', 'Question', { type: 'textarea' }), N('totalMarks', 'Total marks', 1, 1000)] },
    { key: 'explain-concept', label: 'Explain a concept', fields: [T('concept', 'Concept')] },
    { key: 'revision-materials', label: 'Revision materials', fields: [T('topic', 'Topic'), { name: 'format', label: 'Format', type: 'text' }] },
    { key: 'summary', label: 'Summarize text', fields: [T('text', 'Text to summarize', { type: 'textarea' }), { name: 'length', label: 'Length', type: 'text' }] },
    { key: 'flashcards', label: 'Flashcards', fields: [T('topic', 'Topic'), N('count', 'How many (1–30)', 1, 30)] },
    { key: 'teaching-activities', label: 'Teaching activities', fields: [T('topic', 'Topic'), { name: 'classLevel', label: 'Class level', type: 'text' }, N('duration', 'Duration (min)', 5, 180)] },
    { key: 'learning-objectives', label: 'Learning objectives', fields: [T('topic', 'Topic'), N('count', 'How many (1–10)', 1, 10)] }
  ]
};
export const aiApi = {
  generate: (role, key, body) => api.post(`/ai/${role}/${key}`, body),
  usage: () => api.get('/ai/usage')
};
