const mongoose = require('mongoose');
const crypto = require('crypto');
const { Schema } = mongoose;

const sharedMaterialSchema = new Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 200 },
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true },
    mimeType: { type: String, required: true },
    size: { type: Number, required: true },
    sharedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    sharedAt: { type: Date, default: Date.now }
  },
  { _id: true }
);

// One entry per continuous join->leave span, so a participant who
// reconnects mid-class gets multiple entries rather than overwriting
// their attendance record. Attendance is derived by summing these.
const participantLogEntrySchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    role: { type: String, enum: ['teacher', 'student'], required: true },
    joinedAt: { type: Date, required: true },
    leftAt: { type: Date, default: null } // null while still connected
  },
  { _id: true }
);

const liveClassSchema = new Schema(
  {
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    subjectId: { type: Schema.Types.ObjectId, ref: 'Subject', default: null },

    title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 200 },
    description: { type: String, trim: true, maxlength: 2000, default: '' },

    teacherId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },

    scheduledAt: { type: Date, required: [true, 'Scheduled start time is required'] },
    durationMinutes: { type: Number, required: true, min: 5, max: 480 },

    // Internal room identifier used only server-side to key Socket.IO rooms and
    // (later) SFU room/session names. NEVER returned in any API response —
    // clients authenticate to the classroom namespace with a short-lived signed
    // join token instead (see classroomAuthService), which the server maps
    // back to this document without the client ever seeing roomId itself.
    roomId: { type: String, unique: true, default: () => crypto.randomBytes(16).toString('hex') },
    meetingUrl: { type: String, default: null }, // reserved for an externally hosted meeting, if ever used

    status: {
      type: String,
      enum: ['scheduled', 'live', 'completed', 'cancelled'],
      default: 'scheduled',
      index: true
    },

    // --- Class timer: actual (not scheduled) start/end, tracked from teacher actions ---
    timer: {
      actualStartedAt: { type: Date, default: null },
      actualEndedAt: { type: Date, default: null }
    },

    // Set once the pre-class reminder notification has gone out, so the
    // reminder sweep never sends it twice for the same session.
    reminderSentAt: { type: Date, default: null },

    // --- Recording metadata (the file itself lives on disk/cloud storage; this is only metadata) ---
    recording: {
      status: {
        type: String,
        enum: ['not_started', 'recording', 'processing', 'available', 'failed'],
        default: 'not_started'
      },
      startedAt: { type: Date, default: null },
      endedAt: { type: Date, default: null },
      fileUrl: { type: String, default: null },
      sizeBytes: { type: Number, default: null },
      durationSeconds: { type: Number, default: null }
    },

    // --- Session settings, controlled by the teacher ---
    settings: {
      chatEnabled: { type: Boolean, default: true },
      studentMicEnabledByDefault: { type: Boolean, default: false },
      studentCameraEnabledByDefault: { type: Boolean, default: false },
      studentScreenShareAllowed: { type: Boolean, default: false }
    },

    sharedMaterials: { type: [sharedMaterialSchema], default: [] },
    participantLog: { type: [participantLogEntrySchema], default: [] },

    recordingRef: { type: String, default: null } // legacy/simple pointer, kept for backward compatibility
  },
  { timestamps: true }
);

liveClassSchema.index({ courseId: 1, scheduledAt: 1 });
liveClassSchema.index({ 'participantLog.userId': 1 });

// roomId is an internal credential — it must never appear in an API response,
// even to the owning teacher, since the only supported way to actually
// connect media is the short-lived join token (classroomAuthService), not
// the raw room id. Every controller response for a LiveClass should go
// through this instead of returning the raw Mongoose document.
liveClassSchema.methods.toSafeObject = function toSafeObject() {
  const obj = this.toObject();
  delete obj.roomId;
  return obj;
};

module.exports = mongoose.model('LiveClass', liveClassSchema);
