const { Payment, CourseAccess } = require('../models/billing.model');
const { Course } = require('../models/course.model');
const Progress = require('../models/progress.model');
const notificationService = require('./notificationService');
const subscriptionService = require('./subscriptionService');
const discountService = require('./discountService');
const receiptService = require('./receiptService');
const logger = require('../utils/logger');

const LOCK_STALE_MS = 2 * 60 * 1000;

async function grantCourse(payment) {
  try {
    // paymentId is unique (partial index): replaying this for the same payment is a no-op.
    await CourseAccess.updateOne(
      { paymentId: payment._id },
      {
        $setOnInsert: {
          userId: payment.userId,
          courseId: payment.courseId,
          source: 'purchase',
          status: 'active',
          grantedAt: new Date(),
          expiresAt: null
        }
      },
      { upsert: true }
    );
  } catch (err) {
    if (err.code !== 11000) throw err; // concurrent upsert lost the race: the winner's row is fine
  }

  // Paying students are enrolled automatically (no separate "enroll" step after paying).
  await Course.updateOne({ _id: payment.courseId }, { $addToSet: { enrolledStudentIds: payment.userId } });
  await Progress.findOneAndUpdate(
    { studentId: payment.userId, courseId: payment.courseId },
    { $setOnInsert: { studentId: payment.userId, courseId: payment.courseId, enrolledAt: new Date() } },
    { upsert: true, new: true }
  );
}

async function grant(payment) {
  if (payment.purpose === 'course') return grantCourse(payment);
  if (payment.purpose === 'subscription') {
    const sub = await subscriptionService.applyPaidPeriod(payment);
    await Payment.updateOne({ _id: payment._id }, { $set: { subscriptionId: sub._id } });
    return sub;
  }
  return null; // legacy/manual payments with no purpose grant nothing
}

/**
 * Grants what the payment bought. Safe to call any number of times, from any process, at any time:
 *  1. a lock (status 'pending' -> 'in_progress') makes one caller do the work (stale locks are retaken);
 *  2. every grant step is itself idempotent per payment id, so even a double run changes nothing.
 * Throws on failure after recording it, so webhooks return 5xx (gateway retries) and the job retries.
 */
async function ensureFulfilled(paymentId) {
  const now = new Date();
  const payment = await Payment.findOneAndUpdate(
    {
      _id: paymentId,
      status: 'completed',
      $or: [
        { 'fulfillment.status': 'pending' },
        { 'fulfillment.status': 'in_progress', 'fulfillment.lockedAt': { $lt: new Date(now.getTime() - LOCK_STALE_MS) } }
      ]
    },
    { $set: { 'fulfillment.status': 'in_progress', 'fulfillment.lockedAt': now }, $inc: { 'fulfillment.attempts': 1 } },
    { new: true }
  );
  if (!payment) return false; // already done, or another worker holds the lock

  try {
    await grant(payment);
    await receiptService.ensureReceipt(payment._id);
    await discountService.markRedeemed(payment._id);
    await Payment.updateOne(
      { _id: payment._id },
      { $set: { 'fulfillment.status': 'done', 'fulfillment.doneAt': new Date(), 'fulfillment.lastError': null } }
    );
  } catch (err) {
    await Payment.updateOne(
      { _id: payment._id },
      { $set: { 'fulfillment.status': 'pending', 'fulfillment.lockedAt': null, 'fulfillment.lastError': String(err.message).slice(0, 300) } }
    );
    logger.error(`Fulfilment failed for payment ${payment._id}: ${err.stack || err.message}`);
    throw err;
  }

  // Best-effort side effects: never allowed to fail the payment.
  notificationService
    .notifyPaymentConfirmation(payment.userId, {
      paymentId: payment._id,
      courseId: payment.courseId,
      amount: payment.amount,
      currency: payment.currency
    })
    .catch((e) => logger.error(`Payment notification failed: ${e.message}`));
  receiptService.emailReceipt(payment._id).catch((e) => logger.error(`Receipt email failed: ${e.message}`));
  return true;
}

/** Called once, by whoever wins the completed -> refunded transition. */
async function revoke(payment) {
  if (payment.purpose === 'course') {
    await CourseAccess.updateMany({ paymentId: payment._id, status: 'active' }, { $set: { status: 'revoked', revokedAt: new Date() } });
  } else if (payment.purpose === 'subscription') {
    await subscriptionService.revokePeriod(payment);
  }
}

module.exports = { ensureFulfilled, revoke, grant };
