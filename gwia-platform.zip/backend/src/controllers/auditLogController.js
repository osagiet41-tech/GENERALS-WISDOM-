const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const auditLogService = require('../services/auditLogService');

const listAuditLogs = asyncHandler(async (req, res) => {
  const { actorId, action, targetType, page, limit } = req.query;
  const result = await auditLogService.list({ actorId, action, targetType, page, limit });
  return ApiResponse.ok(res, result.items, 'Audit logs retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

module.exports = { listAuditLogs };
