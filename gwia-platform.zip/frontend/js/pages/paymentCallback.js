import { h, mount, icon } from '../core/dom.js';
import { billingApi } from '../api/billing.js';
import { requireRole } from '../core/session.js';
import { spinner } from '../ui/states.js';

/* Provider redirects here (set PAYMENT_CALLBACK_PATH=/payment-callback.html on the server).
   Paystack sends ?reference=&trxref=; Flutterwave sends ?tx_ref=&transaction_id=&status=. We never trust the query string: the server re-checks with the provider. */
await requireRole('student');
const q = new URLSearchParams(location.search);
const reference = q.get('reference') || q.get('tx_ref') || q.get('trxref'), tx = q.get('transaction_id');
const box = h('main', { class: 'auth-card', style: 'width:min(100%,520px)' }, h('h1', null, 'Confirming your payment'), h('p', { class: 'muted' }, spinner(), ' Please wait, do not close this page.'));
document.body.append(h('div', { class: 'auth-wrap' }, box));
const done = (ok, title, msg) => mount(box, h('h1', null, title), h('div', { class: `banner ${ok ? 'ok' : 'err'}`, role: 'status' }, icon(ok ? 'check' : 'alert'), msg), h('p', { style: 'margin-top:16px' }, h('a', { class: 'btn', href: ok ? 'student.html#/courses' : 'student.html#/billing?tab=pay' }, ok ? 'Go to my courses' : 'Back to billing')));
if (!reference) done(false, 'Payment not found', 'This page needs a payment reference. Open Billing to see your payments.');
else billingApi.verify(reference, tx).then(({ data, message }) => {
  const status = data?.status; status === 'completed' ? done(true, 'Payment confirmed', 'Thank you. Your access is now active.') : status === 'pending' ? done(false, 'Still processing', 'Your bank has not confirmed yet. Check Billing in a minute; you will not be charged twice.') : done(false, 'Payment not completed', message || 'The provider did not confirm this payment.');
}).catch((e) => done(false, 'We could not confirm the payment', e.message));
