const mongoose = require('mongoose');
const { Schema } = mongoose;

const notificationSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: {
      type: String,
      enum: [
        'new_assignment',
        'assignment_deadline',
        'grade_posted',
        'new_lesson',
        'new_course',
        'live_class_reminder',
        'live_class_starting',
        'exam_reminder',
        'message',
        'announcement',
        'certificate_issued',
        'payment_confirmation',
        'subscription_expiration',
        'forum_reply',
        'enrollment'
      ],
      required: true
    },
    title: { type: String, required: true, trim: true, maxlength: 200 },
    message: { type: String, required: true, trim: true, maxlength: 1000 },
    data: { type: Schema.Types.Mixed, default: {} },
    read: { type: Boolean, default: false, index: true }
  },
  { timestamps: true }
);

notificationSchema.index({ userId: 1, read: 1, createdAt: -1 });

module.exports = mongoose.model('Notification', notificationSchema);
