import { api } from '../core/http.js';
import { session } from '../core/session.js';
export const authApi = {
  async login(email, password) { const { data } = await api.post('/auth/login', { email, password }, { auth: false }); session.set(data); return data.user; },
  register: (body) => api.post('/auth/register', body, { auth: false }),
  verifyEmail: (token) => api.get('/auth/verify-email', { token }, { auth: false }),
  forgot: (email) => api.post('/auth/forgot-password', { email }, { auth: false }),
  reset: (token, password) => api.post('/auth/reset-password', { token, password }, { auth: false }),
  me: () => api.get('/auth/me'),
  updateProfile: (body) => api.put('/auth/profile', body),
  changePassword: (currentPassword, newPassword) => api.put('/auth/change-password', { currentPassword, newPassword }),
  uploadPicture(file) { const fd = new FormData(); fd.append('avatar', file); return api.post('/auth/profile/picture', fd); }
};
