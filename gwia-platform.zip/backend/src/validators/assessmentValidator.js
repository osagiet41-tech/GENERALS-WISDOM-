const { body } = require('express-validator');

const createAssessmentValidator = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 200 }),
  body('instructions').optional().isString(),
  body('questions').isArray({ min: 1 }).withMessage('At least one question is required'),
  body('questions.*.questionId').isMongoId().withMessage('Each question must reference a valid questionId'),
  body('questions.*.marks').isFloat({ min: 1 }).withMessage('Each question must have marks >= 1'),
  body('passingMarks').optional().isFloat({ min: 0 }),
  body('durationMinutes').isInt({ min: 1 }).withMessage('durationMinutes must be a positive integer'),
  body('availableFrom').isISO8601().withMessage('availableFrom must be a valid date'),
  body('availableUntil')
    .isISO8601()
    .withMessage('availableUntil must be a valid date')
    .custom((value, { req }) => {
      if (new Date(value) <= new Date(req.body.availableFrom)) {
        throw new Error('availableUntil must be after availableFrom');
      }
      return true;
    }),
  body('shuffleQuestions').optional().isBoolean(),
  body('shuffleOptions').optional().isBoolean(),
  body('randomization.enabled').optional().isBoolean(),
  body('randomization.questionCount').optional().isInt({ min: 1 }),
  body('maxAttempts').optional().isInt({ min: 1 }),
  body('allowedStudentIds').optional().isArray(),
  body('allowedStudentIds.*').optional().isMongoId(),
  body('status').optional().isIn(['draft', 'published', 'closed']),
  body('subjectId').optional().isMongoId(),
  body('moduleId').optional().isMongoId()
];

const updateAssessmentValidator = [
  body('title').optional().trim().isLength({ min: 1, max: 200 }),
  body('instructions').optional().isString(),
  body('questions').optional().isArray({ min: 1 }),
  body('questions.*.questionId').optional().isMongoId(),
  body('questions.*.marks').optional().isFloat({ min: 1 }),
  body('passingMarks').optional().isFloat({ min: 0 }),
  body('durationMinutes').optional().isInt({ min: 1 }),
  body('availableFrom').optional().isISO8601(),
  body('availableUntil').optional().isISO8601(),
  body('shuffleQuestions').optional().isBoolean(),
  body('shuffleOptions').optional().isBoolean(),
  body('randomization.enabled').optional().isBoolean(),
  body('randomization.questionCount').optional().isInt({ min: 1 }),
  body('maxAttempts').optional().isInt({ min: 1 }),
  body('allowedStudentIds').optional().isArray(),
  body('allowedStudentIds.*').optional().isMongoId(),
  body('status').optional().isIn(['draft', 'published', 'closed']),
  body('subjectId').optional().isMongoId(),
  body('moduleId').optional().isMongoId()
];

module.exports = { createAssessmentValidator, updateAssessmentValidator };
