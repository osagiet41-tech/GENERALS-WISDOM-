const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const progressService = require('../services/progressService');

// GET /api/student/progress
const getOverallProgress = asyncHandler(async (req, res) => {
  const progress = await progressService.getOverallProgress(req.user.id);
  return ApiResponse.ok(res, progress, 'Overall progress retrieved');
});

// GET /api/student/courses/:courseId/progress
const getCourseProgress = asyncHandler(async (req, res) => {
  const progress = await progressService.getCourseProgress(req.user.id, req.course._id);
  return ApiResponse.ok(res, progress, 'Course progress retrieved');
});

module.exports = { getOverallProgress, getCourseProgress };
