const crypto = require('crypto');

/** SHA-256 hex digest. Used to store refresh / verification / reset tokens at rest (a DB leak then yields no usable tokens). */
function hashToken(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}

/** Escapes user-controlled text before it is placed inside an HTML e-mail. */
function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Escapes a string for literal use inside a RegExp (prevents regex injection / ReDoS from search boxes). */
function escapeRegex(value) {
  return String(value == null ? '' : value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** Constant-time string comparison. */
function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

module.exports = { hashToken, escapeHtml, escapeRegex, safeEqual };
