import { h, mount } from '../../core/dom.js';
import { items } from '../../ui/page.js';
import { withState } from '../../ui/states.js';
import { dataTable } from '../../ui/table.js';
import { pagination } from '../../ui/pagination.js';
import { searchBox } from '../../ui/search.js';
/* Server-paginated, searchable, filterable table. fetcher(query) -> {data, meta}. Returns { el, reload }.
   filters: [{ name, label, options:[{value,label}] }] */
export function listView({ fetcher, columns, actions, caption, search = true, searchPlaceholder = 'Search…', filters = [], limit = 15, emptyState, extraTools = [] }) {
  const state = { page: 1, q: '' }; filters.forEach((f) => { state[f.name] = ''; });
  const body = h('div'); let reload;
  const load = () => { reload = withState(body, () => fetcher({ page: state.page, limit, ...(state.q && { search: state.q }), ...Object.fromEntries(filters.map((f) => [f.name, state[f.name]])) }),
    ({ data, meta }) => h('div', null, dataTable({ rows: items(data), columns, actions, caption, emptyState }), pagination({ page: state.page, limit, ...(meta || {}), onChange: (p) => { state.page = p; load(); } })), { rows: 5 }); };
  const tools = h('div', { class: 'toolbar' }, h('div', { class: 'row', style: 'flex:1' }, search && searchBox({ placeholder: searchPlaceholder, onSearch: (q) => { state.q = q; state.page = 1; load(); } }),
    filters.map((f) => { const s = h('select', { class: 'input', style: 'width:auto', 'aria-label': f.label, onchange: () => { state[f.name] = s.value; state.page = 1; load(); } }, [{ value: '', label: f.label }, ...f.options].map((o) => h('option', { value: o.value }, o.label))); return s; })), h('div', { class: 'row' }, extraTools));
  load();
  return { el: h('div', { class: 'card card-flush' }, tools, body), reload: () => reload() };
}
