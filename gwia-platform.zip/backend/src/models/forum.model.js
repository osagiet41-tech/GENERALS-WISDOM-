const mongoose = require('mongoose');
const { Schema } = mongoose;

const forumPostSchema = new Schema(
  {
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    parentId: { type: Schema.Types.ObjectId, ref: 'ForumPost', default: null, index: true },

    type: { type: String, enum: ['discussion', 'question'], default: 'discussion' },
    title: { type: String, trim: true, maxlength: 200, default: null },

    content: { type: String, required: [true, 'Content is required'], trim: true, maxlength: 5000 },

    authorId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    authorRole: { type: String, enum: ['admin', 'teacher', 'student'], required: true },

    likes: [{ type: Schema.Types.ObjectId, ref: 'User' }],

    replyCount: { type: Number, default: 0 },
    reportCount: { type: Number, default: 0 },
    lastActivityAt: { type: Date, default: Date.now },

    isPinned: { type: Boolean, default: false },
    isLocked: { type: Boolean, default: false },

    isHidden: { type: Boolean, default: false },
    hiddenBy: { type: Schema.Types.ObjectId, ref: 'User', default: null },
    hiddenAt: { type: Date, default: null },
    hiddenReason: { type: String, default: null },

    isDeleted: { type: Boolean, default: false },
    deletedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null },
    deletedAt: { type: Date, default: null }
  },
  { timestamps: true }
);

forumPostSchema.index({ courseId: 1, parentId: 1, isPinned: -1, lastActivityAt: -1 });
forumPostSchema.index({ parentId: 1, createdAt: 1 });
forumPostSchema.index({ title: 'text', content: 'text' });

const REPORT_REASONS = ['spam', 'harassment', 'inappropriate', 'off_topic', 'other'];

const forumReportSchema = new Schema(
  {
    postId: { type: Schema.Types.ObjectId, ref: 'ForumPost', required: true, index: true },
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    reporterId: { type: Schema.Types.ObjectId, ref: 'User', required: true },

    reason: { type: String, enum: REPORT_REASONS, required: true },
    details: { type: String, trim: true, maxlength: 1000, default: '' },

    status: { type: String, enum: ['pending', 'reviewed', 'dismissed'], default: 'pending', index: true },
    reviewedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null },
    reviewedAt: { type: Date, default: null },
    resultAction: { type: String, enum: ['none', 'hidden', 'deleted'], default: 'none' }
  },
  { timestamps: true }
);

forumReportSchema.index({ postId: 1, reporterId: 1 }, { unique: true });
forumReportSchema.index({ courseId: 1, status: 1 });

module.exports = {
  ForumPost: mongoose.model('ForumPost', forumPostSchema),
  ForumReport: mongoose.model('ForumReport', forumReportSchema),
  REPORT_REASONS
};
