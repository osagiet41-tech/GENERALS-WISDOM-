// node test/preview/make-previews.js <outDir>  -> writes <name>.json recordings for replay.py
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { render } = require('../helpers/sampleCertificates');

const outDir = process.argv[2] || '/tmp/cert-preview';
fs.mkdirSync(outDir, { recursive: true });

// tiny hand-made "signature": a PNG with a scribble, built without any image library
function pngScribble() {
  const w = 300, h = 90;
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y += 1) {
    raw[y * (w * 4 + 1)] = 0;
    for (let x = 0; x < w; x += 1) {
      const yy = 45 + 28 * Math.sin(x / 14) * Math.exp(-x / 220) + (x > 150 ? -10 : 0);
      const on = Math.abs(y - yy) < 2.2 && x > 10 && x < 285;
      const o = y * (w * 4 + 1) + 1 + x * 4;
      raw[o] = 20; raw[o + 1] = 40; raw[o + 2] = 120; raw[o + 3] = on ? 255 : 0;
    }
  }
  const crcT = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (b) => { let c = 0xffffffff; for (const x of b) c = crcT[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (t, d) => { const len = Buffer.alloc(4); len.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([len, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
const sig = pngScribble();

const cases = {
  standard: [{}, {}],
  yoruba_long: [{ studentName: 'Ọláòkúnṣẹ́ Adébáyọ̀ Ṣọlá-Ẹ̀gbẹ́yẹmí', courseTitle: 'Advanced Data Structures, Algorithms and Complexity Analysis for Modern Software Engineers', finalScorePercent: 87, instructors: [{ name: 'Dr. Ngozi Ọbiọ́ma-Adéwálé' }, { name: 'Mr. Osagie Thomas' }], signatory: { name: 'Mrs. Funmilayo Adeyemi', title: 'Principal' } }, { instructorImages: [sig, sig], signatoryImage: sig }],
  one_signed: [{ instructors: [{ name: 'Mr. Osagie Thomas' }] }, { instructorImages: [sig] }],
  extreme_name: [{ studentName: 'Maximilian Oluwaseyi Chukwuebuka Abdulrahman Bello-Nwachukwu Junior', courseTitle: 'Cybersecurity', institutionName: 'Generals Wisdom International Academy of Science, Technology and Vocational Studies' }, {}]
};
for (const [name, [data, assets]] of Object.entries(cases)) {
  const doc = render(data, assets);
  fs.writeFileSync(path.join(outDir, `${name}.json`), JSON.stringify({ page: doc.page, fonts: doc.fontPaths, ops: doc.ops }));
}
console.log('wrote', Object.keys(cases).join(', '));
