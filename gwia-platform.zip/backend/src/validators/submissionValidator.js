const { body } = require('express-validator');

const gradeAssignmentValidator = [
  body('score').isFloat({ min: 0 }).withMessage('score must be a non-negative number'),
  body('feedback').optional().isString().isLength({ max: 3000 })
];

const gradeAssessmentValidator = [
  body('feedback').optional().isString().isLength({ max: 3000 })
  // Per-question manual marks arrive as { "<questionId>": <marks>, ... } for
  // subjective questions; validated dynamically in the service since keys
  // are question ids rather than fixed field names.
];

module.exports = { gradeAssignmentValidator, gradeAssessmentValidator };
