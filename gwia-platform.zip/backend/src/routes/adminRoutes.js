const express = require('express');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireAdmin } = require('../middleware/roleMiddleware');
const validate = require('../middleware/validate.middleware');

const dashboardController = require('../controllers/adminDashboardController');
const adminUserController = require('../controllers/adminUserController');
const adminCourseController = require('../controllers/adminCourseController');
const billingController = require('../controllers/billingController');
const certificateController = require('../controllers/certificateController');
const auditLogController = require('../controllers/auditLogController');
const settingsController = require('../controllers/settingsController');
const backupController = require('../controllers/backupController');
const adminReportController = require('../controllers/adminReportController');

const {
  createPlanValidator,
  updatePlanValidator,
  createDiscountValidator,
  updateDiscountValidator
} = require('../validators/billingValidator');

const {
  createUserValidator,
  updateUserRoleValidator,
  suspendUserValidator,
  updateCourseStatusValidator,
  createPaymentValidator,
  updatePaymentStatusValidator,
  createSubscriptionValidator,
  extendSubscriptionValidator,
  updateSettingsValidator,
  restoreBackupValidator
} = require('../validators/adminValidator');

const router = express.Router();
router.use(authMiddleware, requireAdmin);

router.get('/dashboard/overview', dashboardController.getOverview);
router.get('/dashboard/revenue-trend', dashboardController.getRevenueTrend);
router.get('/dashboard/engagement', dashboardController.getEngagement);
router.get('/dashboard/course-performance', dashboardController.getCoursePerformance);
router.get('/dashboard/course-creation-trend', dashboardController.getCourseCreationTrend);

router.get('/users', adminUserController.listUsers);
router.post('/users', validate(createUserValidator), adminUserController.createUser);
router.get('/users/:id', adminUserController.getUser);
router.put('/users/:id/role', validate(updateUserRoleValidator), adminUserController.changeRole);
router.post('/users/:id/suspend', validate(suspendUserValidator), adminUserController.suspendUser);
router.post('/users/:id/restore', adminUserController.restoreUser);

router.get('/courses', adminCourseController.listCourses);
router.get('/courses/:id', adminCourseController.getCourse);
router.put('/courses/:id/status', validate(updateCourseStatusValidator), adminCourseController.updateCourseStatus);
router.get('/subjects', adminCourseController.listSubjects);

router.get('/payments', billingController.listPayments);
router.post('/payments', validate(createPaymentValidator), billingController.createPayment);
router.put('/payments/:id/status', validate(updatePaymentStatusValidator), billingController.updatePaymentStatus);

router.post('/payments/:id/verify', billingController.verifyPayment);
router.get('/payments/:id/receipt.pdf', billingController.downloadReceipt);

router.get('/plans', billingController.listPlans);
router.post('/plans', validate(createPlanValidator), billingController.createPlan);
router.put('/plans/:id', validate(updatePlanValidator), billingController.updatePlan);

router.get('/discount-codes', billingController.listDiscountCodes);
router.post('/discount-codes', validate(createDiscountValidator), billingController.createDiscountCode);
router.put('/discount-codes/:id', validate(updateDiscountValidator), billingController.updateDiscountCode);

router.get('/certificates', certificateController.adminList);
router.post('/certificates/:id/revoke', certificateController.adminRevoke);
router.post('/certificates/:id/restore', certificateController.adminRestore);

router.get('/subscriptions', billingController.listSubscriptions);
router.post('/subscriptions', validate(createSubscriptionValidator), billingController.createSubscription);
router.post('/subscriptions/:id/cancel', billingController.cancelSubscription);
router.put('/subscriptions/:id/extend', validate(extendSubscriptionValidator), billingController.extendSubscription);

router.get('/reports/:type', adminReportController.getReport);
router.get('/reports/:type/export', adminReportController.exportReport);

router.get('/audit-logs', auditLogController.listAuditLogs);

router.get('/settings', settingsController.getSettings);
router.put('/settings', validate(updateSettingsValidator), settingsController.updateSettings);

router.get('/backups', backupController.listBackups);
router.post('/backups', backupController.createBackup);
router.post('/backups/:id/restore', validate(restoreBackupValidator), backupController.restoreBackup);

module.exports = router;
