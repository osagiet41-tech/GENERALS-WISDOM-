// Creates starter monthly/annual plans if they don't exist. Edit prices here or in the admin dashboard.
// Amounts are MINOR units: 500000 NGN-kobo = NGN 5,000.00 ; 1200 USD-cents = USD 12.00
require('dotenv').config();
const mongoose = require('mongoose');
const env = require('../src/config/env');
const { Plan } = require('../src/models/billing.model');
const logger = require('../src/utils/logger');

const PLANS = [
  {
    code: 'monthly',
    name: 'Monthly',
    billingCycle: 'monthly',
    periodMonths: 1,
    trialDays: 7,
    sortOrder: 1,
    features: ['Access to every subscription-included course', 'Cancel any time'],
    prices: [{ currency: 'NGN', amountMinor: 500000 }, { currency: 'USD', amountMinor: 1200 }]
  },
  {
    code: 'annual',
    name: 'Annual',
    billingCycle: 'annual',
    periodMonths: 12,
    trialDays: 0,
    sortOrder: 2,
    features: ['Access to every subscription-included course', 'Two months free vs monthly'],
    prices: [{ currency: 'NGN', amountMinor: 5000000 }, { currency: 'USD', amountMinor: 12000 }]
  }
];

(async () => {
  await mongoose.connect(env.mongodbUri);
  for (const plan of PLANS) {
    const res = await Plan.updateOne({ code: plan.code }, { $setOnInsert: plan }, { upsert: true });
    logger.info(`Plan "${plan.code}": ${res.upsertedCount ? 'created' : 'already exists, left unchanged'}`);
  }
  await mongoose.disconnect();
})().catch((err) => {
  logger.error(`Plan seed failed: ${err.message}`);
  process.exit(1);
});
