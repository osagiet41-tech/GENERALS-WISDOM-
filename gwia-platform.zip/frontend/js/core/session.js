/* Session storage + role routing. Tokens live in localStorage (survives reloads); see README for the XSS trade-off. */
const KEY = 'gwia.session.v1';
const read = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } };
const write = (s) => localStorage.setItem(KEY, JSON.stringify(s));
export const session = {
  get user() { return read().user || null; },
  get accessToken() { return read().accessToken || null; },
  get refreshToken() { return read().refreshToken || null; },
  set({ user, accessToken, refreshToken }) { write({ ...read(), ...(user && { user }), ...(accessToken && { accessToken }), ...(refreshToken && { refreshToken }) }); },
  clear() { localStorage.removeItem(KEY); }
};
export const HOME = { student: 'student.html', teacher: 'teacher.html', admin: 'admin.html' };
export const homeFor = (role) => HOME[role] || 'index.html';
export function redirectToLogin() {
  const next = encodeURIComponent(location.pathname.split('/').pop() + location.search + location.hash);
  location.replace(`auth.html?mode=login&next=${next}`);
}
/* Call at the top of every protected page. Returns the user, or never resolves (redirects). */
export function requireRole(...roles) {
  const u = session.user;
  if (!session.accessToken || !u) { redirectToLogin(); return new Promise(() => {}); }
  if (roles.length && !roles.includes(u.role)) { location.replace(homeFor(u.role)); return new Promise(() => {}); }
  return Promise.resolve(u);
}
