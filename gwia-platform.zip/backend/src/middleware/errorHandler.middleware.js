const env = require('../config/env');
const logger = require('../utils/logger');
const ApiError = require('../utils/ApiError');

/**
 * Normalizes known error types (Mongoose, JWT, Multer) into ApiError
 * shapes before formatting the response.
 */
function normalizeError(err) {
  if (err instanceof ApiError) return err;

  // Mongoose validation errors
  if (err.name === 'ValidationError') {
    const details = Object.values(err.errors).map((e) => e.message);
    return new ApiError(400, 'Validation failed', details);
  }

  // Mongoose duplicate key error
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0];
    return new ApiError(409, `Duplicate value for field: ${field}`);
  }

  // Mongoose invalid ObjectId
  if (err.name === 'CastError') {
    return new ApiError(400, `Invalid value for field: ${err.path}`);
  }

  // JWT errors
  if (err.name === 'JsonWebTokenError') {
    return new ApiError(401, 'Invalid authentication token');
  }
  if (err.name === 'TokenExpiredError') {
    return new ApiError(401, 'Authentication token expired');
  }

  // Multer errors
  if (err.name === 'MulterError') {
    return new ApiError(400, `File upload error: ${err.message}`);
  }

  // Unknown/unexpected error
  return new ApiError(500, env.nodeEnv === 'production' ? 'Internal server error' : err.message);
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const apiError = normalizeError(err);

  const logPayload = `${req.method} ${req.originalUrl} -> ${apiError.statusCode} ${apiError.message}`;
  if (apiError.statusCode >= 500) {
    logger.error(`${logPayload}\n${err.stack}`);
  } else {
    logger.warn(logPayload);
  }

  res.status(apiError.statusCode).json({
    success: false,
    message: apiError.message,
    ...(apiError.details ? { details: apiError.details } : {}),
    ...(env.nodeEnv !== 'production' && apiError.statusCode >= 500 ? { stack: err.stack } : {})
  });
}

module.exports = errorHandler;
