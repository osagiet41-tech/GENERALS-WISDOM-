import { requireRole } from '../core/session.js';
import { createShell } from '../ui/shell.js';
import { startRouter } from '../ui/router.js';

const user = await requireRole('student');
const shell = createShell({ user, nav: [
  { id: 'overview', label: 'Overview', icon: 'home' }, { id: 'courses', label: 'My courses', icon: 'book' }, { id: 'work', label: 'Assignments & exams', icon: 'file' },
  { id: 'live', label: 'Live classes', icon: 'video' }, { id: 'progress', label: 'Progress', icon: 'chart' }, { id: 'certificates', label: 'Certificates', icon: 'award' },
  { id: 'billing', label: 'Billing', icon: 'card' }, { id: 'messages', label: 'Messages', icon: 'message', href: 'messages.html' }, { id: 'ai', label: 'AI study assistant', icon: 'bot', href: 'ai.html' }, { id: 'profile', label: 'Profile', icon: 'settings' }] });
startRouter({ shell, ctx: { user }, fallback: 'overview', routes: {
  overview: () => import('./student/overview.js'), courses: () => import('./student/courses.js'), work: () => import('./student/work.js'), live: () => import('./student/live.js'),
  progress: () => import('./student/progress.js'), certificates: () => import('./student/certificates.js'), billing: () => import('./student/billing.js'), profile: () => import('./shared/profile.js') } });
