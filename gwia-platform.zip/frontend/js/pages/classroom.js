import { h, mount, icon } from '../core/dom.js';
import { requireRole, homeFor } from '../core/session.js';
import { config } from '../core/config.js';
import { studentApi } from '../api/student.js';
import { teacherApi } from '../api/teacher.js';
import { connect } from '../ui/socket.js';
import { createToolBar } from '../ui/shell.js';
import { errorState, loading, empty } from '../ui/states.js';
import { toast } from '../ui/toast.js';
import { confirmDialog } from '../ui/modal.js';
import { initials, fmtTime, fmtDateTime } from '../core/format.js';

const user = await requireRole('student', 'teacher', 'admin'); const isTeacher = user.role !== 'student';
const q = new URLSearchParams(location.search), classId = q.get('id'), me = user.id || user._id;
const dash = homeFor(user.role) + '#/live'; const holder = h('div'); document.body.append(holder);
const shellMsg = (node) => mount(holder, h('div', { class: 'tool' }, createToolBar({ title: 'Live classroom', backHref: dash, backLabel: 'Back' }), h('div', { class: 'main' }, node)));
if (!classId) shellMsg(errorState({ message: 'No class selected.' })); else prepare();

async function prepare() {
  shellMsg(loading(3));
  try {
    let token;
    if (isTeacher) token = (await teacherApi.joinToken(classId)).data.token;
    else { const { data } = await studentApi.joinLive(classId); if (data.status !== 'live') return shellMsg(empty({ title: data.status === 'completed' ? 'This class has ended' : 'This class has not started yet', message: data.message, iconName: 'video', action: h('a', { class: 'btn', href: dash }, 'Back to live classes') })); token = data.token; }
    lobby(token);
  } catch (e) { shellMsg(errorState(e, prepare)); }
}
function lobby(token) {
  const preview = h('video', { autoplay: true, muted: true, playsinline: true, style: 'width:100%;border-radius:10px;background:#000;aspect-ratio:16/9' }); let stream = null;
  const mic = h('input', { type: 'checkbox', checked: true }), cam = h('input', { type: 'checkbox', checked: true });
  const test = async () => { try { stream?.getTracks().forEach((t) => t.stop()); stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true }); preview.srcObject = stream; } catch { toast.info('Camera or microphone is unavailable. You can still join and listen.'); } };
  shellMsg(h('section', { class: 'card stack', style: 'max-width:560px;margin:auto' }, h('h1', null, 'Ready to join?'), preview, h('button', { class: 'btn btn-secondary', type: 'button', onclick: test }, 'Test camera & microphone'),
    h('label', { class: 'check' }, mic, 'Join with microphone on'), h('label', { class: 'check' }, cam, 'Join with camera on'),
    h('button', { class: 'btn btn-lg', type: 'button', onclick: () => { stream?.getTracks().forEach((t) => t.stop()); room(token, { mic: mic.checked, cam: cam.checked }); } }, icon('video'), 'Join class')));
}

async function room(token, initial) {
  shellMsg(loading(2)); let socket;
  try { socket = await connect('/classroom', token); } catch (e) { return shellMsg(errorState(e)); }
  const peers = new Map(), people = new Map(), tiles = new Map(); let local = null, screen = null, micOn = initial.mic, camOn = initial.cam, hand = false, ended = false;
  const tilesEl = h('div', { class: 'tiles' }), chatLog = h('div', { class: 'messages', role: 'log', 'aria-live': 'polite' }), peopleEl = h('ul', { class: 'list' });
  const nameOf = (id) => people.get(id)?.name || 'Participant';
  const send = (ev, data) => new Promise((res) => socket.emit(ev, data, res));

  function tile(id, name) {
    if (tiles.has(id)) return tiles.get(id); const video = h('video', { autoplay: true, playsinline: true, muted: id === me }); const avatar = h('span', { class: 'avatar' }, initials(name)); const label = h('span', { class: 'name' }, id === me ? `${name} (you)` : name); const handEl = h('span', { class: 'hand', hidden: true, 'aria-label': 'Hand raised' }, '✋');
    const el = h('div', { class: 'tile', 'data-user': id }, avatar, video, label, handEl); video.hidden = true; tilesEl.append(el); const t = { el, video, avatar, handEl }; tiles.set(id, t); return t;
  }
  const setStream = (id, stream) => { const t = tile(id, nameOf(id)); t.video.srcObject = stream; t.video.hidden = !stream || !stream.getVideoTracks().some((x) => x.enabled && x.readyState === 'live'); t.avatar.hidden = !t.video.hidden; };
  const showVideo = (id, on) => { const t = tiles.get(id); if (t) { t.video.hidden = !on; t.avatar.hidden = on; } };
  function drawPeople() { mount(peopleEl, [...people.values()].map((p) => h('li', null, h('span', null, `${p.name}${p.role === 'teacher' ? ' (teacher)' : ''}`, p.handRaised && ' ✋'), h('span', { class: 'row' }, h('span', { class: 'small muted' }, p.micOn ? 'mic on' : 'muted'),
    isTeacher && p.userId !== me && h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => socket.emit('teacher:mute-participant', { targetUserId: p.userId }) }, 'Mute'))))); }
  function addChat(m) { const mine = m.senderId === me; chatLog.append(h('div', { class: `bubble ${mine ? 'me' : ''}`, style: m.announcement ? 'border-color:var(--gold)' : null }, h('strong', { class: 'small' }, m.announcement ? 'Announcement' : mine ? 'You' : nameOf(m.senderId)), h('div', null, m.text), h('time', null, fmtTime(m.createdAt || Date.now())))); chatLog.scrollTop = chatLog.scrollHeight; }

  // ---- WebRTC (mesh: the newcomer calls everyone already in the room) ----
  function peer(id) {
    if (peers.has(id)) return peers.get(id); const pc = new RTCPeerConnection({ iceServers: config.iceServers });
    pc.onicecandidate = (e) => e.candidate && socket.emit('webrtc:signal', { toUserId: id, candidate: e.candidate });
    pc.ontrack = (e) => setStream(id, e.streams[0]); pc.onconnectionstatechange = () => { if (['failed', 'closed'].includes(pc.connectionState)) showVideo(id, false); };
    (local ? local.getTracks() : []).forEach((t) => pc.addTrack(t, local)); peers.set(id, pc); return pc;
  }
  async function call(id) { const pc = peer(id); const offer = await pc.createOffer(); await pc.setLocalDescription(offer); socket.emit('webrtc:signal', { toUserId: id, description: pc.localDescription }); }
  socket.on('webrtc:signal', async (m) => {
    const from = m.fromUserId || m.from; if (!from) return; const pc = peer(from);
    try { if (m.description) { await pc.setRemoteDescription(m.description); if (m.description.type === 'offer') { const ans = await pc.createAnswer(); await pc.setLocalDescription(ans); socket.emit('webrtc:signal', { toUserId: from, description: pc.localDescription }); } } else if (m.candidate) await pc.addIceCandidate(m.candidate); } catch { /* stale signal */ }
  });
  const drop = (id) => { peers.get(id)?.close(); peers.delete(id); tiles.get(id)?.el.remove(); tiles.delete(id); people.delete(id); drawPeople(); };
  try { local = await navigator.mediaDevices.getUserMedia({ audio: true, video: true }); } catch { toast.info('No camera or microphone access. You joined as a viewer.'); }
  local?.getAudioTracks().forEach((t) => { t.enabled = micOn; }); local?.getVideoTracks().forEach((t) => { t.enabled = camOn; });

  const ack = await send('classroom:join', { name: user.name });
  if (!ack || ack.error) { socket.close(); return shellMsg(errorState({ message: ack?.error || 'Could not join the class.' }, () => location.reload())); }
  people.set(me, { userId: me, name: user.name, role: user.role, micOn, cameraOn: camOn }); tile(me, user.name); if (local) setStream(me, local); showVideo(me, !!local && camOn);
  (ack.existingParticipants || []).forEach((p) => { people.set(p.userId, p); tile(p.userId, p.name); if (p.handRaised) tiles.get(p.userId).handEl.hidden = false; call(p.userId); }); drawPeople();
  const chatOn = ack.settings?.chatEnabled !== false;
  if (!isTeacher && ack.settings && !ack.settings.studentScreenShareAllowed) { /* hide screen share below */ }

  socket.on('classroom:participant-joined', (p) => { people.set(p.userId, p); tile(p.userId, p.name); drawPeople(); toast.info(`${p.name} joined`); });
  socket.on('classroom:participant-left', ({ userId }) => drop(userId));
  socket.on('classroom:participant-updated', (u) => { const p = people.get(u.userId); if (!p) return; Object.assign(p, u); if ('cameraOn' in u) showVideo(u.userId, u.cameraOn && !!tiles.get(u.userId)?.video.srcObject); drawPeople(); });
  socket.on('classroom:hand-raised', ({ userId }) => { const p = people.get(userId); if (p) p.handRaised = true; const t = tiles.get(userId); if (t) t.handEl.hidden = false; drawPeople(); if (isTeacher) toast.info(`${nameOf(userId)} raised a hand`); });
  socket.on('classroom:hand-lowered', ({ userId }) => { const p = people.get(userId); if (p) p.handRaised = false; const t = tiles.get(userId); if (t) t.handEl.hidden = true; drawPeople(); });
  socket.on('classroom:force-muted', () => { micOn = false; local?.getAudioTracks().forEach((t) => { t.enabled = false; }); paint(); toast.info('The teacher muted your microphone.'); });
  socket.on('classroom:chat-message', addChat); socket.on('classroom:announcement', (m) => { addChat({ ...m, announcement: true }); toast.info(m.text); });
  socket.on('classroom:error', (e) => toast.error(e.message)); socket.on('classroom:screen-share-started', ({ userId }) => userId !== me && toast.info(`${nameOf(userId)} is sharing their screen`));
  socket.on('disconnect', (why) => { if (!ended && why !== 'io client disconnect') toast.error('Connection lost. Trying to reconnect…'); });
  socket.on('connect_error', (e) => toast.error(e.message)); socket.io.on('reconnect', () => toast.success('Reconnected. If video is frozen, rejoin the class.'));

  // ---- Controls ----
  const btn = (name, label, fn) => h('button', { class: 'btn', type: 'button', 'aria-label': label, 'aria-pressed': 'false', title: label, onclick: fn }, icon(name));
  const bMic = btn('mic', 'Toggle microphone', () => { micOn = !micOn; local?.getAudioTracks().forEach((t) => { t.enabled = micOn; }); socket.emit('media:toggle', { micOn }); paint(); });
  const bCam = btn('video', 'Toggle camera', () => { camOn = !camOn; local?.getVideoTracks().forEach((t) => { t.enabled = camOn; }); socket.emit('media:toggle', { cameraOn: camOn }); showVideo(me, camOn && !screen); paint(); });
  const bHand = btn('hand', 'Raise hand', () => { hand = !hand; socket.emit(hand ? 'hand:raise' : 'hand:lower'); paint(); });
  const bShare = btn('screen', 'Share screen', async () => {
    if (screen) return stopShare();
    try { screen = await navigator.mediaDevices.getDisplayMedia({ video: true }); const track = screen.getVideoTracks()[0]; track.onended = stopShare; swapVideo(track); socket.emit('screen-share:start'); setStream(me, screen); showVideo(me, true); paint(); } catch { /* cancelled */ }
  });
  function swapVideo(track) { peers.forEach((pc) => { const s = pc.getSenders().find((x) => x.track && x.track.kind === 'video'); s ? s.replaceTrack(track) : pc.addTrack(track, screen || local); }); }
  function stopShare() { screen?.getTracks().forEach((t) => t.stop()); screen = null; const cam = local?.getVideoTracks()[0]; if (cam) swapVideo(cam); socket.emit('screen-share:stop'); if (local) setStream(me, local); showVideo(me, camOn); paint(); }
  const roomEl = h('div', { class: 'room', 'data-panel': 'closed' }); const bPanel = btn('message', 'Chat and participants', () => { roomEl.dataset.panel = roomEl.dataset.panel === 'open' ? 'closed' : 'open'; paint(); });
  function paint() { bMic.firstChild.replaceWith(icon(micOn ? 'mic' : 'micoff')); bMic.setAttribute('aria-pressed', !micOn); bCam.firstChild.replaceWith(icon(camOn ? 'video' : 'camoff')); bCam.setAttribute('aria-pressed', !camOn); bHand.setAttribute('aria-pressed', hand); bShare.setAttribute('aria-pressed', !!screen); bPanel.setAttribute('aria-pressed', roomEl.dataset.panel === 'open'); }
  const leave = async () => { ended = true; local?.getTracks().forEach((t) => t.stop()); screen?.getTracks().forEach((t) => t.stop()); peers.forEach((p) => p.close()); socket.emit('classroom:leave'); socket.close(); if (!isTeacher) await studentApi.leaveLive(classId).catch(() => {}); location.href = dash; };
  const canShare = isTeacher || ack.settings?.studentScreenShareAllowed;
  const input = h('input', { class: 'input', placeholder: chatOn ? 'Message the class…' : 'Chat is turned off', 'aria-label': 'Chat message', disabled: !chatOn, maxlength: 1000 });
  const sendChat = async (e) => { e.preventDefault(); const text = input.value.trim(); if (!text) return; input.value = ''; const r = await send('chat:message', { text }); if (r?.error) toast.error(r.error); };
  const announce = isTeacher && h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: async () => { const text = prompt('Announcement to the whole class:'); if (text?.trim()) { const r = await send('announcement:post', { text: text.trim() }); if (r?.error) toast.error(r.error); } } }, 'Announce');
  mount(roomEl, h('div', { class: 'stage' }, tilesEl, h('div', { class: 'controls', role: 'toolbar', 'aria-label': 'Class controls' }, bMic, bCam, canShare && bShare, !isTeacher && bHand, bPanel,
    isTeacher && h('button', { class: 'btn', type: 'button', onclick: () => socket.emit('teacher:mute-all') }, 'Mute all'),
    isTeacher && h('button', { class: 'btn leave', type: 'button', onclick: async () => { if (await confirmDialog({ title: 'End class for everyone?', message: 'All participants will be disconnected.', confirmLabel: 'End class', danger: true })) { await teacherApi.endLive(classId).catch((e) => toast.error(e.message)); leave(); } } }, 'End class'),
    h('button', { class: 'btn leave', type: 'button', onclick: leave }, icon('phone'), 'Leave'))),
    h('aside', { class: 'side-panel', 'aria-label': 'Chat and participants' }, h('div', { class: 'spread', style: 'padding:12px 16px;border-bottom:1px solid var(--line)' }, h('strong', null, 'Class chat'), announce), h('div', { style: 'display:grid;grid-template-rows:auto 1fr;min-height:0' }, h('details', { open: true, style: 'border-bottom:1px solid var(--line)' }, h('summary', { style: 'padding:8px 16px;cursor:pointer' }, 'Participants'), peopleEl), chatLog),
      h('form', { class: 'composer', onsubmit: sendChat }, input, h('button', { class: 'btn btn-icon', type: 'submit', 'aria-label': 'Send message', disabled: !chatOn }, icon('send')))));
  mount(holder, h('div', { class: 'tool' }, createToolBar({ title: 'Live classroom' }), roomEl)); paint(); drawPeople();
  if (!isTeacher) studentApi.liveChat(classId).then(({ data }) => (Array.isArray(data) ? data : data?.items || []).forEach(addChat)).catch(() => {});
  addEventListener('beforeunload', () => { if (!ended) socket.emit('classroom:leave'); });
  if (!initial.mic) socket.emit('media:toggle', { micOn: false }); if (!initial.cam) socket.emit('media:toggle', { cameraOn: false });
}
