const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const studentLiveClassService = require('../services/studentLiveClassService');
const classroomService = require('../services/classroomService');

// GET /api/student/courses/:courseId/live-classes
const listLiveClasses = asyncHandler(async (req, res) => {
  const liveClasses = await studentLiveClassService.listLiveClasses(req.course._id, {
    upcoming: req.query.upcoming === 'true'
  });
  return ApiResponse.ok(res, liveClasses, 'Live classes retrieved');
});

// GET /api/student/live-classes/:id/join  (req.resource set by verifyResourceAccess, no status field on LiveClass)
const joinLiveClass = asyncHandler(async (req, res) => {
  const joinInfo = await studentLiveClassService.getJoinInfo(req.resource, req.user);
  return ApiResponse.ok(res, joinInfo, 'Join info retrieved');
});

// POST /api/student/live-classes/:id/leave
// A REST fallback for logging departure (the Socket.IO disconnect/leave
// event handles this in the normal case; this covers a client that
// never established the socket connection cleanly).
const leaveLiveClass = asyncHandler(async (req, res) => {
  await classroomService.logParticipantLeave(req.resource._id, req.user.id);
  return ApiResponse.ok(res, null, 'Left classroom');
});

// GET /api/student/live-classes/:id/chat
const getChatHistory = asyncHandler(async (req, res) => {
  const messages = await classroomService.getChatHistory(req.resource._id, req.query);
  return ApiResponse.ok(res, messages, 'Chat history retrieved');
});

module.exports = { listLiveClasses, joinLiveClass, leaveLiveClass, getChatHistory };
