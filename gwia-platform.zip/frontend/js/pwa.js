/* PWA glue: service-worker registration + update prompt, install button, offline banner, push-notification opt-in.
   Loaded on every page. Safe to load where the browser lacks support: every feature is feature-detected. */
import { api } from './core/http.js';
import { session } from './core/session.js';

const secure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
const el = (tag, attrs = {}, ...kids) => { const n = document.createElement(tag); for (const [k, v] of Object.entries(attrs)) { if (k === 'onclick') n.addEventListener('click', v); else n.setAttribute(k, v); } n.append(...kids); return n; };

let bar;
function banner() {
  if (!bar) { bar = el('div', { class: 'pwa-bar', role: 'status', 'aria-live': 'polite' }); document.body.append(bar); }
  return bar;
}
function showBar(id, text, ...buttons) {
  const b = banner(); b.querySelector(`[data-id="${id}"]`)?.remove();
  const row = el('div', { class: 'pwa-row', 'data-id': id }, el('span', {}, text), ...buttons);
  b.append(row); return row;
}
const hideBar = (id) => { bar?.querySelector(`[data-id="${id}"]`)?.remove(); };

/* ---------- Offline / online ---------- */
function trackConnection() {
  const paint = () => (navigator.onLine ? hideBar('offline') : showBar('offline', 'You are offline. Saved pages still work; changes need a connection.'));
  window.addEventListener('online', paint); window.addEventListener('offline', paint); paint();
}

/* ---------- Service worker + update prompt ---------- */
let registration = null;
async function registerWorker() {
  if (!('serviceWorker' in navigator) || !secure) return;
  try {
    registration = await navigator.serviceWorker.register('sw.js');
    const prompt = (worker) => showBar('update', 'A new version is ready.', el('button', { type: 'button', onclick: () => { worker.postMessage({ type: 'SKIP_WAITING' }); } }, 'Update'));
    if (registration.waiting && navigator.serviceWorker.controller) prompt(registration.waiting);
    registration.addEventListener('updatefound', () => {
      const w = registration.installing;
      w?.addEventListener('statechange', () => { if (w.state === 'installed' && navigator.serviceWorker.controller) prompt(w); });
    });
    let reloaded = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => { if (reloaded) return; reloaded = true; location.reload(); });
    setInterval(() => registration.update().catch(() => {}), 60 * 60 * 1000); // look for a new version hourly
  } catch { /* unsupported or blocked: the site simply works online-only */ }
}

/* ---------- Install ("Add to Home screen") ---------- */
let deferred = null;
const DISMISS_KEY = 'gwia.install.dismissed';
function setupInstall() {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault(); deferred = e;
    const dismissed = Number(localStorage.getItem(DISMISS_KEY) || 0);
    if (Date.now() - dismissed < 14 * 864e5) return;
    showBar('install', 'Install this app for faster, full-screen access.',
      el('button', { type: 'button', onclick: install }, 'Install'),
      el('button', { type: 'button', class: 'ghost', onclick: () => { localStorage.setItem(DISMISS_KEY, String(Date.now())); hideBar('install'); } }, 'Not now'));
  });
  window.addEventListener('appinstalled', () => { deferred = null; hideBar('install'); });
}
export async function install() {
  if (!deferred) return false;
  deferred.prompt(); const { outcome } = await deferred.userChoice; deferred = null; hideBar('install'); return outcome === 'accepted';
}
export const canInstall = () => Boolean(deferred);

/* ---------- Push notifications ---------- */
const urlBase64ToUint8Array = (b64) => { const pad = '='.repeat((4 - (b64.length % 4)) % 4); const raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from([...raw].map((c) => c.charCodeAt(0))); };

/* 'unsupported' | 'blocked' | 'disabled' (server has no VAPID keys) | 'off' | 'on' */
const isNative = () => Boolean(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
const FCM_KEY = 'gwia.fcm.registered';

export async function pushState() {
  if (isNative()) {
    if (!window.Capacitor.Plugins?.PushNotifications) return 'unsupported';
    try { const { data } = await api.get('/push/public-key'); if (!data.enabled) return 'disabled'; } catch { return 'unsupported'; }
    return localStorage.getItem(FCM_KEY) ? 'on' : 'off';
  }
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window) || !secure) return 'unsupported';
  if (Notification.permission === 'denied') return 'blocked';
  try {
    const { data } = await api.get('/push/public-key');
    if (!data.enabled) return 'disabled';
    const reg = await navigator.serviceWorker.ready;
    return (await reg.pushManager.getSubscription()) ? 'on' : 'off';
  } catch { return 'unsupported'; }
}
async function enableNativePush() {
  const P = window.Capacitor.Plugins.PushNotifications;
  const perm = await P.requestPermissions();
  if (perm.receive !== 'granted') throw new Error('Notification permission was not granted.');
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Could not register for notifications. Check your connection and try again.')), 20000);
    P.addListener('registration', async (t) => {
      try { await api.post('/push/subscribe', { endpoint: t.value, kind: 'fcm' }); localStorage.setItem(FCM_KEY, '1'); clearTimeout(timer); resolve(); }
      catch (e) { clearTimeout(timer); reject(e); }
    });
    P.addListener('registrationError', (e) => { clearTimeout(timer); reject(new Error(e?.error || 'Notification registration failed.')); });
    P.register();
  });
  P.addListener('pushNotificationActionPerformed', (a) => { const u = a?.notification?.data?.url; if (u && u.startsWith('./')) location.href = u; });
  return true;
}

export async function enablePush() {
  if (!session.accessToken) throw new Error('Sign in first.');
  if (isNative()) return enableNativePush();
  const { data } = await api.get('/push/public-key');
  if (!data.enabled || !data.publicKey) throw new Error('Notifications are not enabled on this server.');
  if ((await Notification.requestPermission()) !== 'granted') throw new Error('Notification permission was not granted.');
  const reg = await navigator.serviceWorker.ready;
  const sub = (await reg.pushManager.getSubscription()) || (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(data.publicKey) }));
  const json = sub.toJSON();
  await api.post('/push/subscribe', { endpoint: json.endpoint, keys: json.keys, kind: 'webpush' });
  return true;
}
export async function disablePush() {
  if (isNative()) { localStorage.removeItem(FCM_KEY); return; } /* the server drops the token on the first failed delivery */
  const reg = await navigator.serviceWorker.ready; const sub = await reg.pushManager.getSubscription();
  if (!sub) return;
  await api.post('/push/unsubscribe', { endpoint: sub.endpoint }).catch(() => {});
  await sub.unsubscribe();
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => { trackConnection(); setupInstall(); });
else { trackConnection(); setupInstall(); }
registerWorker();
