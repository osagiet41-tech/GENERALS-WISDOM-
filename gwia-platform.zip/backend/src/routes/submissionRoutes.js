const express = require('express');
const controller = require('../controllers/submissionController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { gradeAssignmentValidator, gradeAssessmentValidator } = require('../validators/submissionValidator');
const Assignment = require('../models/assignment.model');
const { Assessment } = require('../models/assessment.model');
const Submission = require('../models/submission.model');

// GET /api/assignments/:id/submissions
const assignmentSubmissionsRouter = express.Router();
assignmentSubmissionsRouter.use(authMiddleware, requireTeacherOrAdmin);
assignmentSubmissionsRouter.get(
  '/:id/submissions',
  verifyResourceOwnership(Assignment, 'id'),
  controller.listAssignmentSubmissions
);

// GET /api/quizzes/:id/submissions and /api/exams/:id/submissions
const assessmentSubmissionsRouter = express.Router();
assessmentSubmissionsRouter.use(authMiddleware, requireTeacherOrAdmin);
assessmentSubmissionsRouter.get(
  '/:id/submissions',
  verifyResourceOwnership(Assessment, 'id'),
  controller.listAssessmentSubmissions
);

// /api/submissions/:submissionId — item-level review and grading
const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);

itemRouter.get('/:submissionId', verifyResourceOwnership(Submission, 'submissionId'), controller.getSubmission);

itemRouter.put(
  '/:submissionId/grade',
  verifyResourceOwnership(Submission, 'submissionId'),
  (req, res, next) => {
    // Route to the right validator based on submission type before running it.
    const validator = req.resource.refType === 'assignment' ? gradeAssignmentValidator : gradeAssessmentValidator;
    return validate(validator)(req, res, next);
  },
  controller.gradeSubmission
);

itemRouter.put(
  '/:submissionId/return',
  verifyResourceOwnership(Submission, 'submissionId'),
  controller.returnToStudent
);

module.exports = { assignmentSubmissionsRouter, assessmentSubmissionsRouter, itemRouter };
