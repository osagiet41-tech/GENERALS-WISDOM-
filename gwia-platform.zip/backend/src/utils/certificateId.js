const crypto = require('crypto');

// Crockford base32: no I, L, O, U, so IDs survive being read aloud or typed from paper.
const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
const PREFIX = 'CERT';
const LENGTH = 12; // 12 symbols x 5 bits = 60 bits of randomness: not guessable, not enumerable

/** CERT-XXXX-XXXX-XXXX */
function generateCertificateId() {
  const n = crypto.randomBytes(8).readBigUInt64BE() >> 4n; // keep 60 bits
  let out = '';
  for (let i = 0; i < LENGTH; i += 1) {
    out = ALPHABET[Number((n >> BigInt(5 * i)) & 31n)] + out;
  }
  return `${PREFIX}-${out.slice(0, 4)}-${out.slice(4, 8)}-${out.slice(8, 12)}`;
}

/**
 * Accepts what a human might type or scan (any case, with/without hyphens or spaces, O/0 and I/L/1 mix-ups)
 * and returns the canonical ID, or null if it can't be a certificate ID.
 */
function normalizeCertificateId(input) {
  if (typeof input !== 'string') return null;
  let s = input.toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (s.startsWith(PREFIX)) s = s.slice(PREFIX.length);
  if (s.length !== LENGTH) return null;
  s = s.replace(/O/g, '0').replace(/[IL]/g, '1');
  if ([...s].some((c) => !ALPHABET.includes(c))) return null;
  return `${PREFIX}-${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}`;
}

/** Pre-existing certificates used a 16-char hex verification code. */
function isLegacyCode(input) {
  return typeof input === 'string' && /^[0-9A-F]{16}$/i.test(input.trim());
}

module.exports = { generateCertificateId, normalizeCertificateId, isLegacyCode };
