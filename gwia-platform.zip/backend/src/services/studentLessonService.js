const Lesson = require('../models/lesson.model');
const Progress = require('../models/progress.model');

/**
 * Lists published lessons for a course (optionally scoped to a subject
 * and/or module), annotating each with whether the student has
 * completed it and whether it is currently locked behind unmet
 * prerequisites. Locked lessons are still listed (so the student can
 * see the course structure and what's required) but their content is
 * only reachable once verifyLessonPrerequisites allows the request.
 */
async function listPublishedLessons(studentId, courseId, { subjectId, moduleId } = {}) {
  const filter = { courseId, status: 'published' };
  if (subjectId) filter.subjectId = subjectId;
  if (moduleId) filter.moduleId = moduleId;

  const [lessons, progress] = await Promise.all([
    Lesson.find(filter).sort({ order: 1 }),
    Progress.findOne({ studentId, courseId })
  ]);

  const completedIds = new Set((progress ? progress.completedLessonIds : []).map((id) => id.toString()));

  return lessons.map((lesson) => {
    const missingPrerequisites = lesson.prerequisiteLessonIds
      .map((id) => id.toString())
      .filter((id) => !completedIds.has(id));

    return {
      ...lesson.toObject(),
      isCompleted: completedIds.has(lesson._id.toString()),
      isLocked: missingPrerequisites.length > 0,
      missingPrerequisiteLessonIds: missingPrerequisites
    };
  });
}

async function getLesson(lessonId) {
  return Lesson.findOne({ _id: lessonId, status: 'published' });
}

async function markLessonComplete(studentId, courseId, lessonId) {
  const progress = await Progress.findOneAndUpdate(
    { studentId, courseId },
    {
      $addToSet: { completedLessonIds: lessonId },
      $set: { lastAccessedAt: new Date() }
    },
    { upsert: true, new: true }
  );
  return progress;
}

async function trackVideoProgress(studentId, courseId, lessonId, watchedSeconds, completed) {
  let progress = await Progress.findOne({ studentId, courseId });
  if (!progress) {
    progress = new Progress({ studentId, courseId });
  }

  const entry = progress.videoProgress.find((v) => v.lessonId.toString() === lessonId);
  if (entry) {
    entry.watchedSeconds = Math.max(entry.watchedSeconds, watchedSeconds);
    entry.completed = entry.completed || !!completed;
    entry.lastWatchedAt = new Date();
  } else {
    progress.videoProgress.push({
      lessonId,
      watchedSeconds,
      completed: !!completed,
      lastWatchedAt: new Date()
    });
  }

  // A fully watched video also counts the lesson itself as complete.
  if (completed && !progress.completedLessonIds.some((id) => id.toString() === lessonId)) {
    progress.completedLessonIds.push(lessonId);
  }

  progress.lastAccessedAt = new Date();
  await progress.save();
  return progress;
}

module.exports = { listPublishedLessons, getLesson, markLessonComplete, trackVideoProgress };
