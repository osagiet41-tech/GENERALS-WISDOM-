import { h, mount, $ } from '../core/dom.js';
import { icon } from '../core/dom.js';
import { toggleTheme } from '../core/theme.js';
import { verifyCertificate } from '../ui/certResult.js';

const out = h('div', { 'aria-live': 'polite' });
const input = h('input', { class: 'input', id: 'cid', name: 'id', required: true, autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', placeholder: 'CERT-XXXX-XXXX-XXXX' });
async function run(id) { mount(out, h('p', { class: 'muted' }, 'Checking…')); mount(out, await verifyCertificate(id)); }
const form = h('form', { class: 'stack-sm', novalidate: true, onsubmit: (e) => { e.preventDefault(); if (!input.value.trim()) return input.focus(); history.replaceState(null, '', `?id=${encodeURIComponent(input.value.trim())}`); run(input.value); } },
  h('div', { class: 'field' }, h('label', { for: 'cid' }, 'Certificate ID'), input), h('button', { class: 'btn', type: 'submit' }, 'Check certificate'));
document.body.append(h('div', { class: 'auth-wrap' }, h('main', { class: 'auth-card', style: 'width:min(100%,560px)' },
  h('a', { href: 'index.html', class: 'small' }, '← Back to the academy'), h('h1', { style: 'margin-top:12px' }, 'Verify a certificate'),
  h('p', { class: 'muted' }, 'Anyone can confirm a certificate is genuine using the ID printed on it. No sign-in needed.'), form, h('div', { style: 'margin-top:16px' }, out),
  h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: toggleTheme, style: 'margin-top:12px' }, icon('moon'), 'Switch theme'))));
const id = new URLSearchParams(location.search).get('id'); if (id) { input.value = id; run(id); }
