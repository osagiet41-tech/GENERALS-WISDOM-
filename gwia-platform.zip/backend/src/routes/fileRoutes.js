const path = require('path');
const express = require('express');
const { body } = require('express-validator');
const { authMiddleware } = require('../middleware/authMiddleware');
const validate = require('../middleware/validate.middleware');
const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const fileAccess = require('../services/fileAccessService');
const { MIME_TO_EXT } = require('../utils/fileSignature');
const { UPLOAD_ROOT } = require('../config/multer');

const ALLOWED_EXT = new Set(Object.values(MIME_TO_EXT));
const INLINE_EXT = new Set(['.jpg', '.png', '.webp', '.gif', '.pdf', '.mp4', '.webm', '.mov', '.mp3', '.wav', '.ogg', '.m4a']);

/* POST /api/files/sign  { paths: ["/uploads/videos/..."] }  ->  { urls: { "<path>": "<signed path>" } }
   Only paths the caller is allowed to open come back; the rest are silently omitted. */
const apiRouter = express.Router();
apiRouter.post(
  '/sign',
  authMiddleware,
  validate([
    body('paths').isArray({ min: 1, max: 50 }).withMessage('paths must be an array of 1-50 upload paths'),
    body('paths.*').isString().isLength({ max: 300 })
  ]),
  asyncHandler(async (req, res) => {
    const urls = await fileAccess.signMany(req.user, req.body.paths);
    return ApiResponse.ok(res, { urls, expiresInSeconds: require('../config/env').security.fileUrlTtlSeconds }, 'File URLs signed');
  })
);

/* GET /uploads/:folder/:file  — public folders are open; everything else needs a valid signature. */
const uploadsRouter = express.Router();

uploadsRouter.use((req, res, next) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return next(ApiError.notFound('Not found'));

  const urlPath = `/uploads${req.path}`;
  const parsed = fileAccess.parseUploadPath(urlPath);
  const ext = path.extname(req.path).toLowerCase();
  if (!parsed || !ALLOWED_EXT.has(ext)) return next(ApiError.notFound('Not found'));

  if (!parsed.isPublic && !fileAccess.verifySignature(urlPath, req.query)) {
    return next(ApiError.forbidden('This file link is missing, invalid or expired. Reload the page to get a fresh link.'));
  }

  // Uploaded content must never execute in the API's origin, and must not be sniffed into another type.
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; sandbox");
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin'); // the frontend is served from a different origin
  res.setHeader('Cache-Control', parsed.isPublic ? 'public, max-age=86400' : 'private, max-age=300');
  if (!INLINE_EXT.has(ext)) res.setHeader('Content-Disposition', 'attachment');
  next();
});

uploadsRouter.use(
  express.static(UPLOAD_ROOT, {
    index: false,
    dotfiles: 'deny',
    redirect: false,
    fallthrough: true,
    setHeaders(res, filePath) {
      // PDFs need to render in an <iframe>: a sandbox CSP would disable the viewer. They are served as application/pdf + nosniff.
      if (filePath.toLowerCase().endsWith('.pdf')) res.removeHeader('Content-Security-Policy');
    }
  })
);

module.exports = { apiRouter, uploadsRouter };
