/* Deployment settings. Edit this file only; nothing else needs to change per environment.
   Serve the frontend from the origin set as CLIENT_URL in the backend .env (CORS is locked to it). */
window.APP_CONFIG = {
  apiBase: 'http://localhost:5000/api',
  socketUrl: 'http://localhost:5000',
  institution: 'Generals Wisdom International Academy',
  locale: 'en-NG',
  defaultCurrency: 'NGN',
  /* Live classroom uses peer-to-peer video. Add a TURN server here for students behind strict networks. */
  iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
};
