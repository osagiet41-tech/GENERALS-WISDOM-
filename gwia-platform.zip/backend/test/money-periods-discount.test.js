const test = require('node:test');
const assert = require('node:assert/strict');
const { toMinor, fromMinor, formatMoney } = require('../src/utils/money');
const { addMonths, addDays } = require('../src/utils/periods');
const { computeDiscount } = require('../src/services/discountMath');

test('money: float-safe conversion to minor units', () => {
  assert.equal(toMinor(19.99, 'USD'), 1999);
  assert.equal(toMinor(0.1 + 0.2, 'USD'), 30);
  assert.equal(toMinor(5000, 'NGN'), 500000);
  assert.equal(toMinor(1500, 'XOF'), 1500); // zero-decimal currency
  assert.equal(fromMinor(1999, 'USD'), 19.99);
  assert.equal(fromMinor(1500, 'XOF'), 1500);
  assert.throws(() => toMinor(-1, 'USD'));
  assert.throws(() => toMinor('abc', 'USD'));
  assert.equal(formatMoney(500000, 'NGN'), 'NGN 5,000.00');
});

test('periods: month arithmetic never overflows', () => {
  assert.equal(addMonths(new Date('2026-01-31T10:00:00Z'), 1).toISOString(), '2026-02-28T10:00:00.000Z');
  assert.equal(addMonths(new Date('2028-01-31T10:00:00Z'), 1).toISOString(), '2028-02-29T10:00:00.000Z');
  assert.equal(addMonths(new Date('2026-10-09T00:00:00Z'), 12).toISOString(), '2027-10-09T00:00:00.000Z');
  assert.equal(addMonths(new Date('2026-03-31T00:00:00Z'), -1).toISOString(), '2026-02-28T00:00:00.000Z');
  assert.equal(addDays(new Date('2026-10-09T00:00:00Z'), 7).toISOString(), '2026-10-16T00:00:00.000Z');
});

test('discount: percent, cap, fixed, currency mismatch, never below zero', () => {
  assert.deepEqual(computeDiscount({ type: 'percent', percentOff: 20 }, 500000, 'NGN'), { discountMinor: 100000, finalMinor: 400000 });
  assert.deepEqual(computeDiscount({ type: 'percent', percentOff: 100 }, 500000, 'NGN'), { discountMinor: 500000, finalMinor: 0 });
  assert.deepEqual(computeDiscount({ type: 'percent', percentOff: 50, maxDiscountMinor: 100000 }, 500000, 'NGN'), { discountMinor: 100000, finalMinor: 400000 });
  const fixed = { type: 'fixed', fixedAmounts: [{ currency: 'NGN', amountMinor: 200000 }, { currency: 'USD', amountMinor: 500 }] };
  assert.deepEqual(computeDiscount(fixed, 500000, 'NGN'), { discountMinor: 200000, finalMinor: 300000 });
  assert.equal(computeDiscount(fixed, 1000, 'GBP'), null);
  assert.deepEqual(computeDiscount(fixed, 300, 'USD'), { discountMinor: 300, finalMinor: 0 }); // capped at price
});
