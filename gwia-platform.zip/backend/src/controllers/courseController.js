const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const courseService = require('../services/courseService');
const notificationService = require('../services/notificationService');
const { Course } = require('../models/course.model');

// POST /api/courses
const createCourse = asyncHandler(async (req, res) => {
  const course = await courseService.createCourse(req.user.id, req.body);
  return ApiResponse.created(res, course, 'Course created successfully');
});

// PUT /api/courses/:courseId  (requires verifyCourseOwnership -> req.course)
const updateCourse = asyncHandler(async (req, res) => {
  const wasPublished = req.course.status === 'published';
  const course = await courseService.updateCourse(req.course, req.body);

  // Notify students who already learn from this teacher elsewhere — a
  // freshly published course has no enrollees yet (enrollment requires
  // status === 'published'), so "enrolled students of this course"
  // wouldn't be a meaningful audience here.
  if (!wasPublished && course.status === 'published') {
    const otherCourses = await Course.find({
      teacherIds: req.user.id,
      _id: { $ne: course._id },
      status: 'published'
    });
    const interestedStudentIds = [
      ...new Set(otherCourses.flatMap((c) => c.enrolledStudentIds.map((id) => id.toString())))
    ];

    await notificationService.notifyNewCourse(interestedStudentIds, {
      courseId: course._id,
      title: course.title,
      teacherName: req.user.name
    });
  }

  return ApiResponse.ok(res, course, 'Course updated successfully');
});

// DELETE /api/courses/:courseId
const deleteCourse = asyncHandler(async (req, res) => {
  await courseService.deleteCourse(req.course);
  return ApiResponse.ok(res, null, 'Course deleted successfully');
});

// GET /api/courses/mine
const listMyCourses = asyncHandler(async (req, res) => {
  const { page, limit, status } = req.query;
  const result = await courseService.listCoursesForTeacher(req.user.id, { page, limit, status });
  return ApiResponse.ok(res, result.items, 'Courses retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

// GET /api/courses/:courseId
const getCourse = asyncHandler(async (req, res) => {
  return ApiResponse.ok(res, req.course, 'Course retrieved');
});

// POST /api/courses/:courseId/co-teachers
const addCoTeacher = asyncHandler(async (req, res) => {
  const course = await courseService.addCoTeacher(req.course, req.body.teacherId);
  return ApiResponse.ok(res, course, 'Co-teacher added successfully');
});

// POST /api/courses/:courseId/thumbnail
const uploadThumbnail = asyncHandler(async (req, res) => {
  const course = await courseService.setThumbnail(req.course, req.file);
  return ApiResponse.ok(res, course, 'Thumbnail uploaded successfully');
});

// --- Subjects ---

// POST /api/courses/:courseId/subjects
const createSubject = asyncHandler(async (req, res) => {
  const subject = await courseService.createSubject(req.course._id, req.user.id, req.body);
  return ApiResponse.created(res, subject, 'Subject created successfully');
});

// PUT /api/courses/:courseId/subjects/:subjectId
const updateSubject = asyncHandler(async (req, res) => {
  const subject = await courseService.updateSubject(req.params.subjectId, req.course._id, req.body);
  return ApiResponse.ok(res, subject, 'Subject updated successfully');
});

// DELETE /api/courses/:courseId/subjects/:subjectId
const deleteSubject = asyncHandler(async (req, res) => {
  await courseService.deleteSubject(req.params.subjectId, req.course._id);
  return ApiResponse.ok(res, null, 'Subject deleted successfully');
});

// GET /api/courses/:courseId/subjects
const listSubjects = asyncHandler(async (req, res) => {
  const subjects = await courseService.listSubjects(req.course._id);
  return ApiResponse.ok(res, subjects, 'Subjects retrieved');
});

module.exports = {
  createCourse,
  updateCourse,
  deleteCourse,
  listMyCourses,
  getCourse,
  addCoTeacher,
  uploadThumbnail,
  createSubject,
  updateSubject,
  deleteSubject,
  listSubjects
};
