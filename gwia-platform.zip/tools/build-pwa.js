#!/usr/bin/env node
/**
 * Generates frontend/sw.js from frontend/sw.template.js:
 *   - PRECACHE = every HTML/CSS/JS/icon/manifest file of the app shell (config.js is excluded: it is edited per deployment)
 *   - VERSION  = hash of all those files, so any change produces a new cache and the update prompt appears.
 *
 *   node tools/build-pwa.js            (also run automatically by `npm run build` at the project root)
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.join(__dirname, '..', 'frontend');
const INCLUDE = /\.(html|css|js|json|png|svg|ico|webmanifest)$/;
const EXCLUDE = new Set(['sw.js', 'sw.template.js', 'config.js']);

function* walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) { if (!['node_modules', '.git'].includes(e.name)) yield* walk(full); }
    else yield full;
  }
}

const files = [...walk(root)]
  .map((f) => path.relative(root, f).split(path.sep).join('/'))
  .filter((f) => INCLUDE.test(f) && !EXCLUDE.has(f))
  .sort();

const hash = crypto.createHash('sha256');
for (const f of files) { hash.update(f); hash.update(fs.readFileSync(path.join(root, f))); }
const version = hash.digest('hex').slice(0, 12);

const precache = ['./', ...files.filter((f) => f !== 'index.html').map((f) => `./${f}`), './index.html'];
const out = fs.readFileSync(path.join(root, 'sw.template.js'), 'utf8')
  .replace('__VERSION__', version)
  .replace('__PRECACHE__', JSON.stringify(precache, null, 2));
fs.writeFileSync(path.join(root, 'sw.js'), out);
const bytes = files.reduce((n, f) => n + fs.statSync(path.join(root, f)).size, 0);
console.log(`sw.js written: version ${version}, ${precache.length} precached files, ${(bytes / 1024).toFixed(0)} KB`);
