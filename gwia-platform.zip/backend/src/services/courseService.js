const fs = require('fs');
const path = require('path');
const { Course, Subject } = require('../models/course.model');
const ApiError = require('../utils/ApiError');

// --- Courses ---

async function createCourse(teacherId, data) {
  const course = await Course.create({
    title: data.title,
    description: data.description,
    category: data.category,
    price: data.price || 0,
    currency: data.currency || null,
    prices: data.prices || [],
    includedInSubscription: data.includedInSubscription !== false,
    ...(data.certificate ? { certificate: data.certificate } : {}),
    durationHours: data.durationHours || null,
    level: data.level || 'beginner',
    learningObjectives: data.learningObjectives || [],
    prerequisites: data.prerequisites || [],
    institutionId: data.institutionId || null,
    teacherIds: [teacherId],
    createdBy: teacherId,
    status: 'draft'
  });
  return course;
}

async function updateCourse(course, updates) {
  const allowed = [
    'title',
    'description',
    'category',
    'price',
    'currency',
    'prices',
    'includedInSubscription',
    'certificate',
    'durationHours',
    'level',
    'learningObjectives',
    'prerequisites',
    'thumbnailUrl',
    'status'
  ];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      course[field] = updates[field];
    }
  }
  await course.save();
  return course;
}

async function setThumbnail(course, file) {
  if (!file) throw ApiError.badRequest('No thumbnail file uploaded');

  if (course.thumbnailUrl && course.thumbnailUrl.startsWith('/uploads/')) {
    fs.unlink(path.join(__dirname, '..', '..', course.thumbnailUrl.replace(/^\//, '')), () => {});
  }

  course.thumbnailUrl = `/uploads/thumbnails/${file.filename}`;
  await course.save();
  return course;
}

async function deleteCourse(course) {
  await Subject.deleteMany({ courseId: course._id });
  await course.deleteOne();
}

async function listCoursesForTeacher(teacherId, { page = 1, limit = 20, status } = {}) {
  const filter = { teacherIds: teacherId };
  if (status) filter.status = status;

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    Course.find(filter).sort({ updatedAt: -1 }).skip(skip).limit(limit),
    Course.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function addCoTeacher(course, newTeacherId) {
  if (!course.teacherIds.some((id) => id.toString() === newTeacherId)) {
    course.teacherIds.push(newTeacherId);
    await course.save();
  }
  return course;
}

// --- Subjects ---

async function createSubject(courseId, teacherId, data) {
  const subject = await Subject.create({
    courseId,
    title: data.title,
    description: data.description,
    order: data.order || 0,
    createdBy: teacherId
  });
  return subject;
}

async function updateSubject(subjectId, courseId, updates) {
  const subject = await Subject.findOne({ _id: subjectId, courseId });
  if (!subject) {
    throw ApiError.notFound('Subject not found in this course');
  }

  const allowed = ['title', 'description', 'order'];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      subject[field] = updates[field];
    }
  }
  await subject.save();
  return subject;
}

async function deleteSubject(subjectId, courseId) {
  const subject = await Subject.findOneAndDelete({ _id: subjectId, courseId });
  if (!subject) {
    throw ApiError.notFound('Subject not found in this course');
  }
}

async function listSubjects(courseId) {
  return Subject.find({ courseId }).sort({ order: 1 });
}

module.exports = {
  createCourse,
  updateCourse,
  deleteCourse,
  listCoursesForTeacher,
  addCoTeacher,
  setThumbnail,
  createSubject,
  updateSubject,
  deleteSubject,
  listSubjects
};
