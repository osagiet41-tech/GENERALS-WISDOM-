#!/usr/bin/env node
/**
 * Route inventory (static, dependency-free).
 *
 * Loads src/app.js with a fake `express` and stubbed third-party modules, so it works with NO node_modules and
 * NO database. It records every route with its full path, whether authMiddleware guards it and which roles may call it.
 *
 *   node scripts/route-inventory.js            # prints a table
 *   node scripts/route-inventory.js --json     # machine readable
 *   node scripts/route-inventory.js --md       # markdown (used for docs/API_ROUTES.md)
 *
 * It is also imported by test/unit/route-security.test.js: any route that is neither authenticated nor on the
 * explicit PUBLIC allow-list fails the test, so a forgotten authMiddleware can never ship unnoticed.
 */
const Module = require('module');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const METHODS = ['get', 'post', 'put', 'patch', 'delete', 'all'];

function makeStub() {
  const fn = function stub() {};
  return new Proxy(fn, {
    get: (t, p) => {
      if (p === Symbol.toPrimitive) return () => '';
      if (p === 'then') return undefined; // never look like a promise
      if (p === '__esModule' || (typeof p === 'string' && p.startsWith('__'))) return undefined; // __isRouter / __roles probes must not look truthy
      return makeStub();
    },
    apply: () => makeStub(),
    construct: () => makeStub()
  });
}

function makeRouter() {
  const r = { __isRouter: true, stack: [] };
  for (const m of METHODS) r[m] = (p, ...handlers) => { r.stack.push({ kind: 'route', method: m.toUpperCase(), path: p, handlers: handlers.flat() }); return r; };
  r.use = (...args) => {
    let p = '/';
    if (typeof args[0] === 'string') p = args.shift();
    r.stack.push({ kind: 'use', path: p, handlers: args.flat() });
    return r;
  };
  r.route = (p) => {
    const chain = {};
    for (const m of METHODS) chain[m] = (...handlers) => { r.stack.push({ kind: 'route', method: m.toUpperCase(), path: p, handlers: handlers.flat() }); return chain; };
    return chain;
  };
  r.param = () => r;
  r.set = () => r;
  r.disable = () => r;
  return r;
}

function loadApp() {
  const fakeExpress = () => makeRouter();
  fakeExpress.Router = makeRouter;
  fakeExpress.json = () => function json() {};
  fakeExpress.urlencoded = () => function urlencoded() {};
  fakeExpress.raw = () => function raw() {};
  fakeExpress.static = () => function staticHandler() {};

  const originalLoad = Module._load;
  Module._load = function patched(request, parent, isMain) {
    if (request === 'express') return fakeExpress;
    const isRelative = request.startsWith('.') || path.isAbsolute(request);
    const isBuiltin = Module.builtinModules.includes(request) || request.startsWith('node:');
    if (!isRelative && !isBuiltin) return makeStub();
    return originalLoad.apply(this, arguments);
  };
  // Required env so config/env.js does not exit
  const keep = { ...process.env };
  Object.assign(process.env, {
    MONGODB_URI: 'mongodb://x/x', JWT_SECRET: 'a'.repeat(48), JWT_EXPIRES_IN: '15m', EMAIL_HOST: 'x', EMAIL_PORT: '587',
    EMAIL_USER: 'x', EMAIL_PASSWORD: 'x', CLIENT_URL: 'http://localhost:3000', NODE_ENV: 'test'
  });
  try {
    // eslint-disable-next-line global-require
    const app = require(path.join(ROOT, 'src', 'app.js'));
    const auth = require(path.join(ROOT, 'src', 'middleware', 'authMiddleware.js'));
    return { app, authMiddleware: auth.authMiddleware };
  } finally {
    Module._load = originalLoad;
    process.env = keep;
  }
}

function describeHandlers(handlers, authMiddleware) {
  const info = { auth: false, roles: null };
  for (const h of handlers) {
    if (h === authMiddleware) info.auth = true;
    if (typeof h === 'function' && h.__roles) info.roles = h.__roles;
  }
  return info;
}

function walk(router, prefix, inherited, authMiddleware, out) {
  const local = { ...inherited };
  for (const layer of router.stack) {
    if (layer.kind === 'use') {
      const sub = layer.handlers.find((h) => h && h.__isRouter);
      const info = describeHandlers(layer.handlers.filter((h) => !(h && h.__isRouter)), authMiddleware);
      if (sub) {
        walk(sub, joinPath(prefix, layer.path), { auth: local.auth || info.auth, roles: info.roles || local.roles, limiters: local.limiters }, authMiddleware, out);
      } else {
        // router.use(authMiddleware, roleMiddleware(...)) guards everything registered AFTER it in this router
        if (info.auth) local.auth = true;
        if (info.roles) local.roles = info.roles;
      }
    } else {
      const info = describeHandlers(layer.handlers, authMiddleware);
      out.push({
        method: layer.method,
        path: joinPath(prefix, layer.path),
        auth: local.auth || info.auth,
        roles: info.roles || local.roles || null
      });
    }
  }
}

const joinPath = (a, b) => (`${a}/${b}`.replace(/\/+/g, '/').replace(/\/$/, '') || '/');

function buildInventory() {
  // Tag role guards so they can be recognised later.
  const roleModulePath = path.join(ROOT, 'src', 'middleware', 'roleMiddleware.js');
  const roleMod = require(roleModulePath);
  const wrap = (fn, roles) => { fn.__roles = roles; return fn; };
  const original = roleMod.roleMiddleware;
  roleMod.roleMiddleware = (...roles) => wrap(original(...roles), roles.map((r) => r.toLowerCase()));
  wrap(roleMod.requireAdmin, ['admin']);
  wrap(roleMod.requireTeacherOrAdmin, ['admin', 'teacher']);
  wrap(roleMod.requireStudent, ['student']);

  const { app, authMiddleware } = loadApp();
  const out = [];
  walk(app, '', { auth: false, roles: null }, authMiddleware, out);
  roleMod.roleMiddleware = original;
  return out.filter((r) => r.method !== 'ALL' || r.path !== '/');
}

module.exports = { buildInventory };

if (require.main === module) {
  const routes = buildInventory().sort((a, b) => a.path.localeCompare(b.path) || a.method.localeCompare(b.method));
  const arg = process.argv[2];
  if (arg === '--json') console.log(JSON.stringify(routes, null, 2));
  else if (arg === '--md') {
    console.log('| Method | Path | Auth | Roles |\n|---|---|---|---|');
    for (const r of routes) console.log(`| ${r.method} | \`${r.path}\` | ${r.auth ? 'yes' : '**public**'} | ${r.roles ? r.roles.join(', ') : (r.auth ? 'any signed-in user' : '-')} |`);
  } else {
    for (const r of routes) console.log(`${r.method.padEnd(6)} ${r.path.padEnd(70)} ${r.auth ? 'auth' : 'PUBLIC'}  ${r.roles ? r.roles.join('|') : ''}`);
    console.log(`\n${routes.length} routes, ${routes.filter((r) => !r.auth).length} public`);
  }
}
