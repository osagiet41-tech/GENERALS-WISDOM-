const test = require('node:test');
const assert = require('node:assert/strict');
const { matchesMime, extensionFor } = require('../../src/utils/fileSignature');

const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);
const jpg = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0x10]);
const pdf = Buffer.from('%PDF-1.7\n...');
const zip = Buffer.from([0x50, 0x4b, 0x03, 0x04, 0, 0]);
const html = Buffer.from('<html><script>alert(1)</script></html>');
const exe = Buffer.from([0x4d, 0x5a, 0x90, 0x00, 0x03]);

test('real files match their declared MIME type', () => {
  assert.ok(matchesMime(png, 'image/png'));
  assert.ok(matchesMime(jpg, 'image/jpeg'));
  assert.ok(matchesMime(pdf, 'application/pdf'));
  assert.ok(matchesMime(zip, 'application/zip'));
  assert.ok(matchesMime(zip, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'));
  assert.ok(matchesMime(Buffer.from('hello world'), 'text/plain'));
});

test('disguised files are rejected: HTML/EXE sent as an image, PDF or Word file', () => {
  assert.ok(!matchesMime(html, 'image/png'));
  assert.ok(!matchesMime(html, 'application/pdf'));
  assert.ok(!matchesMime(exe, 'image/jpeg'));
  assert.ok(!matchesMime(exe, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'));
  assert.ok(!matchesMime(png, 'image/jpeg'));
  assert.ok(!matchesMime(Buffer.from([0x4d, 0x5a, 0x00, 0x01]), 'text/plain'), 'binary with NUL byte is not text');
});

test('unknown MIME types and empty buffers are rejected', () => {
  assert.ok(!matchesMime(png, 'image/svg+xml'));
  assert.ok(!matchesMime(png, 'text/html'));
  assert.ok(!matchesMime(Buffer.alloc(0), 'image/png'));
});

test('extension comes from the MIME type, never from the client file name', () => {
  assert.equal(extensionFor('image/png'), '.png');
  assert.equal(extensionFor('application/pdf'), '.pdf');
  assert.equal(extensionFor('text/html'), '');
});
