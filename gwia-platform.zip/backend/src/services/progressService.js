const Progress = require('../models/progress.model');
const Lesson = require('../models/lesson.model');
const Submission = require('../models/submission.model');
const Attendance = require('../models/attendance.model');
const { Course } = require('../models/course.model');

async function getCourseProgress(studentId, courseId) {
  const [progress, totalLessons, submissions, attendanceSessions] = await Promise.all([
    Progress.findOne({ studentId, courseId }),
    Lesson.countDocuments({ courseId, status: 'published' }),
    Submission.find({ studentId, courseId, status: 'graded' }),
    Attendance.find({ courseId, 'records.studentId': studentId })
  ]);

  const completedLessons = progress ? progress.completedLessonIds.length : 0;
  const lessonCompletionPercent = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;

  const byType = { assignment: [], quiz: [], exam: [] };
  for (const s of submissions) {
    if (s.grade.totalMarks > 0) {
      byType[s.refType].push((s.grade.score / s.grade.totalMarks) * 100);
    }
  }
  const average = (arr) => (arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : null);

  const attendancePresent = attendanceSessions.filter((session) => {
    const record = session.records.find((r) => r.studentId.toString() === studentId);
    return record && (record.status === 'present' || record.status === 'late');
  }).length;
  const attendanceRate =
    attendanceSessions.length > 0 ? Math.round((attendancePresent / attendanceSessions.length) * 100) : null;

  // Overall course completion blends lesson progress with assessment engagement,
  // weighted toward actually consuming content over being graded.
  const overallCompletionPercent = Math.round(
    lessonCompletionPercent * 0.6 +
      (byType.assignment.length > 0 ? 100 : 0) * 0.15 +
      (byType.quiz.length > 0 ? 100 : 0) * 0.125 +
      (byType.exam.length > 0 ? 100 : 0) * 0.125
  );

  return {
    courseId,
    studentId,
    lessonCompletion: { completed: completedLessons, total: totalLessons, percent: lessonCompletionPercent },
    performance: {
      assignments: { averagePercent: average(byType.assignment), count: byType.assignment.length },
      quizzes: { averagePercent: average(byType.quiz), count: byType.quiz.length },
      exams: { averagePercent: average(byType.exam), count: byType.exam.length }
    },
    attendance: {
      totalSessions: attendanceSessions.length,
      present: attendancePresent,
      ratePercent: attendanceRate
    },
    overallCompletionPercent,
    lastAccessedAt: progress ? progress.lastAccessedAt : null
  };
}

async function getOverallProgress(studentId) {
  const courses = await Course.find({ enrolledStudentIds: studentId });
  const perCourse = await Promise.all(courses.map((c) => getCourseProgress(studentId, c._id)));

  const completionValues = perCourse.map((p) => p.overallCompletionPercent);
  const averageCompletion =
    completionValues.length > 0 ? Math.round(completionValues.reduce((a, b) => a + b, 0) / completionValues.length) : 0;

  return {
    studentId,
    enrolledCourseCount: courses.length,
    averageCompletionPercent: averageCompletion,
    courses: perCourse.map((p, i) => ({ courseId: courses[i]._id, title: courses[i].title, ...p }))
  };
}

module.exports = { getCourseProgress, getOverallProgress };
