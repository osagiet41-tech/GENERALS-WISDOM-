const test = require('node:test');
const assert = require('node:assert/strict');
const { createLimiter, isObjectId } = require('../../src/sockets/rateLimit');

test('token bucket allows a burst up to capacity then blocks', () => {
  const allow = createLimiter({ capacity: 3, refillPerSec: 0.0001 });
  assert.ok(allow('s1', 'e')); assert.ok(allow('s1', 'e')); assert.ok(allow('s1', 'e'));
  assert.ok(!allow('s1', 'e'));
});

test('buckets are independent per socket and per event', () => {
  const allow = createLimiter({ capacity: 1, refillPerSec: 0.0001 });
  assert.ok(allow('s1', 'chat'));
  assert.ok(!allow('s1', 'chat'));
  assert.ok(allow('s2', 'chat'));
  assert.ok(allow('s1', 'typing'));
});

test('isObjectId only accepts 24-hex strings (no objects, no operators)', () => {
  assert.ok(isObjectId('64b7f0f0f0f0f0f0f0f0f0f0'));
  assert.ok(!isObjectId({ $ne: 1 }));
  assert.ok(!isObjectId('123'));
  assert.ok(!isObjectId(undefined));
});
