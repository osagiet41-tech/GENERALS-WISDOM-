const express = require('express');

const { authMiddleware } = require('../middleware/authMiddleware');
const { requireStudent } = require('../middleware/roleMiddleware');
const { verifyEnrollment, verifyResourceAccess, verifyLessonPrerequisites } = require('../middleware/studentEnrollment.middleware');
const validate = require('../middleware/validate.middleware');
const { uploadSubmission } = require('../config/multer');
const ApiError = require('../utils/ApiError');

const dashboardController = require('../controllers/dashboardController');
const enrollmentController = require('../controllers/enrollmentController');
const studentLessonController = require('../controllers/studentLessonController');
const studentLiveClassController = require('../controllers/studentLiveClassController');
const studentAssignmentController = require('../controllers/studentAssignmentController');
const studentAssessmentController = require('../controllers/studentAssessmentController');
const progressController = require('../controllers/progressController');
const certificateController = require('../controllers/certificateController');
const courseModuleService = require('../services/courseModuleService');
const ApiResponse = require('../utils/ApiResponse');
const asyncHandler = require('../utils/asyncHandler');

const {
  enrollValidator,
  videoProgressValidator,
  submitAssignmentValidator,
  saveProgressValidator,
  finalizeAssessmentValidator
} = require('../validators/studentValidator');

const Lesson = require('../models/lesson.model');
const LiveClass = require('../models/liveClass.model');
const Assignment = require('../models/assignment.model');
const { Assessment } = require('../models/assessment.model');

function requireKind(kind) {
  return (req, res, next) => {
    if (req.resource.kind !== kind) return next(ApiError.notFound(`${kind} not found`));
    next();
  };
}

const router = express.Router();
router.use(authMiddleware, requireStudent);

// --- Dashboard ---
router.get('/dashboard', dashboardController.getDashboard);

// --- Enrollment ---
router.post('/enrollments', validate(enrollValidator), enrollmentController.enroll);
router.get('/courses', enrollmentController.listMyCourses);
router.delete('/enrollments/:courseId', enrollmentController.unenroll);

// --- Modules (read-only for students) ---
router.get(
  '/courses/:courseId/modules',
  verifyEnrollment(),
  asyncHandler(async (req, res) => {
    const modules = await courseModuleService.listModulesForCourse(req.course._id);
    return ApiResponse.ok(res, modules, 'Modules retrieved');
  })
);

// --- Lessons ---
router.get('/courses/:courseId/lessons', verifyEnrollment(), studentLessonController.listLessons);
router.get(
  '/lessons/:id',
  verifyResourceAccess(Lesson, 'id'),
  verifyLessonPrerequisites(),
  studentLessonController.getLesson
);
router.post(
  '/lessons/:id/complete',
  verifyResourceAccess(Lesson, 'id'),
  verifyLessonPrerequisites(),
  studentLessonController.markComplete
);
router.post(
  '/lessons/:id/video-progress',
  verifyResourceAccess(Lesson, 'id'),
  verifyLessonPrerequisites(),
  validate(videoProgressValidator),
  studentLessonController.trackVideoProgress
);

// --- Live classes ---
router.get('/courses/:courseId/live-classes', verifyEnrollment(), studentLiveClassController.listLiveClasses);
router.get(
  '/live-classes/:id/join',
  verifyResourceAccess(LiveClass, 'id', { statusField: null }),
  studentLiveClassController.joinLiveClass
);
router.post(
  '/live-classes/:id/leave',
  verifyResourceAccess(LiveClass, 'id', { statusField: null }),
  studentLiveClassController.leaveLiveClass
);
router.get(
  '/live-classes/:id/chat',
  verifyResourceAccess(LiveClass, 'id', { statusField: null }),
  studentLiveClassController.getChatHistory
);

// --- Assignments ---
router.get('/courses/:courseId/assignments', verifyEnrollment(), studentAssignmentController.listAssignments);
router.get('/assignments/:id', verifyResourceAccess(Assignment, 'id'), studentAssignmentController.getAssignment);
router.post(
  '/assignments/:id/submit',
  verifyResourceAccess(Assignment, 'id'),
  uploadSubmission.array('files', 5),
  validate(submitAssignmentValidator),
  studentAssignmentController.submitAssignment
);

// --- Quizzes ---
router.get('/courses/:courseId/quizzes', verifyEnrollment(), studentAssessmentController.quiz.list);
router.post(
  '/quizzes/:id/start',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('quiz'),
  studentAssessmentController.quiz.start
);
router.get(
  '/quizzes/:id/attempt',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('quiz'),
  studentAssessmentController.quiz.getAttemptState
);
router.put(
  '/quizzes/:id/attempt/save',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('quiz'),
  validate(saveProgressValidator),
  studentAssessmentController.quiz.saveProgress
);
router.post(
  '/quizzes/:id/attempt/submit',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('quiz'),
  validate(finalizeAssessmentValidator),
  studentAssessmentController.quiz.submit
);
router.get(
  '/quizzes/:id/result/:submissionId',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('quiz'),
  studentAssessmentController.quiz.getResult
);
router.get(
  '/quizzes/:id/history',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('quiz'),
  studentAssessmentController.quiz.getHistory
);

// --- Examinations ---
router.get('/courses/:courseId/exams', verifyEnrollment(), studentAssessmentController.exam.list);
router.post(
  '/exams/:id/start',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('exam'),
  studentAssessmentController.exam.start
);
router.get(
  '/exams/:id/attempt',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('exam'),
  studentAssessmentController.exam.getAttemptState
);
router.put(
  '/exams/:id/attempt/save',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('exam'),
  validate(saveProgressValidator),
  studentAssessmentController.exam.saveProgress
);
router.post(
  '/exams/:id/attempt/submit',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('exam'),
  validate(finalizeAssessmentValidator),
  studentAssessmentController.exam.submit
);
router.get(
  '/exams/:id/result/:submissionId',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('exam'),
  studentAssessmentController.exam.getResult
);
router.get(
  '/exams/:id/history',
  verifyResourceAccess(Assessment, 'id'),
  requireKind('exam'),
  studentAssessmentController.exam.getHistory
);

// --- Progress tracking ---
router.get('/progress', progressController.getOverallProgress);
router.get('/courses/:courseId/progress', verifyEnrollment(), progressController.getCourseProgress);

// Notifications now live in the shared module: see /api/notifications
// (routes/notificationRoutes.js) — every role has its own inbox there.

// --- Certificates ---
router.get('/certificates', certificateController.list);
router.get('/certificates/:id', certificateController.details);
router.get('/certificates/:id/download', certificateController.download);
router.get('/courses/:courseId/certificate/eligibility', verifyEnrollment(), certificateController.eligibility);
router.post('/courses/:courseId/certificate', verifyEnrollment(), certificateController.requestCertificate);

// Discussion forums now live in the unified module: see /api/courses/:courseId/forum
// and /api/forum-posts (routes/forumRoutes.js) — shared by students and teachers alike.

module.exports = router;
