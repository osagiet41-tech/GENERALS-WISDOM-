const LiveClass = require('../models/liveClass.model');
const ApiError = require('../utils/ApiError');
const classroomAuthService = require('./classroomAuthService');

// Fields safe to return to a student: excludes roomId (the internal room
// credential) and participantLog (which would otherwise leak every other
// student's join/leave timestamps).
const STUDENT_SAFE_FIELDS = '-roomId -participantLog';

async function listLiveClasses(courseId, { upcoming } = {}) {
  const filter = { courseId, status: { $ne: 'cancelled' } };
  if (upcoming) filter.scheduledAt = { $gte: new Date() };
  return LiveClass.find(filter, STUDENT_SAFE_FIELDS).sort({ scheduledAt: 1 });
}

async function getJoinInfo(liveClass, student) {
  if (liveClass.status === 'cancelled') {
    throw ApiError.badRequest('This live class has been cancelled');
  }
  if (liveClass.status === 'completed') {
    return {
      status: 'completed',
      recordingAvailable: liveClass.recording.status === 'available',
      recordingUrl: liveClass.recording.status === 'available' ? liveClass.recording.fileUrl : null,
      message:
        liveClass.recording.status === 'available' ? 'This class has ended; a recording is available.' : 'This class has ended.'
    };
  }
  if (liveClass.status === 'scheduled') {
    return {
      status: 'scheduled',
      scheduledAt: liveClass.scheduledAt,
      message: 'This class has not started yet.'
    };
  }

  // status === 'live': issue a short-lived, classroom-scoped Socket.IO join
  // token. The raw roomId never leaves the server — the client connects to
  // the /classroom namespace with this token and the server resolves it
  // back to the classroom internally (see classroomAuthService, classroom.socket.js).
  const token = classroomAuthService.issueJoinToken(liveClass, { id: student.id, role: 'student', name: student.name });

  return {
    status: 'live',
    token
  };
}

module.exports = { listLiveClasses, getJoinInfo };
