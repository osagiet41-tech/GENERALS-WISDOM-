const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const certificateService = require('../services/certificateService');
const auditLogService = require('../services/auditLogService');
const env = require('../config/env');

/* ------------------------------ student ------------------------------ */

// GET /api/student/certificates
const list = asyncHandler(async (req, res) => {
  const certificates = await certificateService.listCertificates(req.user.id);
  return ApiResponse.ok(res, certificates, 'Certificates retrieved');
});

// GET /api/student/certificates/:id   (Mongo id or CERT-XXXX-XXXX-XXXX)
const details = asyncHandler(async (req, res) => {
  const certificate = await certificateService.getCertificate(req.params.id, req.user.id);
  return ApiResponse.ok(res, certificateService.summarize(certificate), 'Certificate retrieved');
});

// POST /api/student/courses/:courseId/certificate
// Normally unnecessary (certificates are issued automatically); kept so a student can trigger a check on demand.
const requestCertificate = asyncHandler(async (req, res) => {
  const certificate = await certificateService.issueCertificateIfEligible(req.user.id, req.course._id);
  return ApiResponse.ok(res, certificateService.summarize(certificate), 'Certificate issued');
});

// GET /api/student/courses/:courseId/certificate/eligibility
const eligibility = asyncHandler(async (req, res) => {
  const report = await certificateService.getEligibilityReport(req.user.id, req.course._id);
  return ApiResponse.ok(res, report, 'Certificate eligibility retrieved');
});

// GET /api/student/certificates/:id/download[?inline=1]
const download = asyncHandler(async (req, res) => {
  const certificate = await certificateService.getCertificate(req.params.id, req.user.id);
  if (certificate.status === 'revoked') throw ApiError.forbidden('This certificate has been revoked');

  const pdf = await certificateService.renderPdf(certificate);
  const id = certificate.certificateId || certificate.verificationCode;
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `${req.query.inline ? 'inline' : 'attachment'}; filename="Certificate-${id}.pdf"`);
  res.setHeader('Cache-Control', 'private, no-store');
  return res.send(pdf);
});

/* ------------------------------ public ------------------------------- */

// GET /api/certificates/verify/:certificateId   (no auth)
const verify = asyncHandler(async (req, res) => {
  const result = await certificateService.verifyCertificate(req.params.certificateId);
  res.setHeader('Cache-Control', 'no-store');
  if (!result) {
    return res.status(404).json({ success: false, valid: false, message: 'No certificate matches this ID' });
  }
  return ApiResponse.ok(res, result, result.valid ? 'Certificate is valid' : 'This certificate has been revoked');
});

const esc = (v) => String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (d) => new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });

// GET /verify/:certificateId   (plain HTML page for people who scan the QR code; no scripts, everything escaped)
const verifyPage = asyncHandler(async (req, res) => {
  const result = await certificateService.verifyCertificate(req.params.certificateId);
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Robots-Tag', 'noindex');

  let status = 404;
  let banner = ['#8a1c1c', '#fdecec', 'Certificate not found'];
  let body = '<p>No certificate matches this ID. Check the ID printed on the certificate and try again.</p>';
  if (result && result.valid) {
    status = 200;
    banner = ['#14602f', '#e8f6ed', 'Valid certificate'];
    body = `<table>
      <tr><th>Awarded to</th><td>${esc(result.studentName)}</td></tr>
      <tr><th>Course</th><td>${esc(result.courseTitle)}</td></tr>
      <tr><th>Institution</th><td>${esc(result.institutionName)}</td></tr>
      <tr><th>Instructor${result.instructors.length > 1 ? 's' : ''}</th><td>${esc(result.instructors.join(', ') || '-')}</td></tr>
      <tr><th>Completed</th><td>${esc(fmt(result.completionDate))}</td></tr>
      <tr><th>Certificate ID</th><td>${esc(result.certificateId)}</td></tr>
    </table><p class="note">Compare these details with the certificate you were given. If anything differs, the document has been altered.</p>`;
  } else if (result) {
    status = 200;
    banner = ['#8a1c1c', '#fdecec', 'This certificate has been revoked'];
    body = `<p>Certificate ${esc(result.certificateId)} is no longer valid.</p>`;
  }

  res.status(status).type('html').send(`<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title>Certificate verification</title>
<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f4f5f8;margin:0;padding:24px;color:#1f2430}
.card{max-width:560px;margin:40px auto;background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.08);overflow:hidden}
.banner{padding:18px 24px;font-weight:700;font-size:18px;color:${banner[0]};background:${banner[1]}}
.inner{padding:20px 24px}table{width:100%;border-collapse:collapse}th{text-align:left;color:#5b6270;font-weight:600;padding:8px 12px 8px 0;width:36%;vertical-align:top}
td{padding:8px 0}.note{color:#5b6270;font-size:13px;margin-top:16px}.foot{padding:12px 24px;background:#fafbfc;color:#8a909c;font-size:12px}</style></head>
<body><div class="card"><div class="banner">${esc(banner[2])}</div><div class="inner">${body}</div>
<div class="foot">${esc(env.certificates.institutionName)} &middot; certificate verification</div></div></body></html>`);
});

/* ---------------------- instructor signature ------------------------- */

// PUT /api/certificates/signature   multipart field "signature" (PNG/JPEG <= 500KB, transparent PNG looks best)
const uploadSignature = asyncHandler(async (req, res) => {
  if (!req.file) throw ApiError.badRequest('Attach the signature image as the "signature" field');
  const fileName = await certificateService.setInstructorSignature(req.user.id, req.file.buffer);
  return ApiResponse.ok(res, { signatureFile: fileName }, 'Signature saved. It will appear on certificates issued from now on.');
});

// DELETE /api/certificates/signature
const removeSignature = asyncHandler(async (req, res) => {
  await certificateService.clearInstructorSignature(req.user.id);
  return ApiResponse.ok(res, null, 'Signature removed. Certificates will show your typed name instead.');
});

/* ------------------------------ admin -------------------------------- */

// GET /api/admin/certificates
const adminList = asyncHandler(async (req, res) => {
  const result = await certificateService.listAll(req.query);
  return ApiResponse.ok(res, result.items, 'Certificates retrieved', { page: result.page, limit: result.limit, total: result.total, pages: result.pages });
});

// POST /api/admin/certificates/:id/revoke   { reason }
const adminRevoke = asyncHandler(async (req, res) => {
  const cert = await certificateService.revoke(req.params.id, req.body.reason, req.user.id);
  await auditLogService.record(req.user.id, 'certificate.revoke', 'Certificate', cert._id, { certificateId: cert.certificateId, reason: req.body.reason || null }, req.ip);
  return ApiResponse.ok(res, certificateService.summarize(cert), 'Certificate revoked');
});

// POST /api/admin/certificates/:id/restore
const adminRestore = asyncHandler(async (req, res) => {
  const cert = await certificateService.restore(req.params.id);
  await auditLogService.record(req.user.id, 'certificate.restore', 'Certificate', cert._id, { certificateId: cert.certificateId }, req.ip);
  return ApiResponse.ok(res, certificateService.summarize(cert), 'Certificate restored');
});

module.exports = {
  list,
  details,
  requestCertificate,
  eligibility,
  download,
  verify,
  verifyPage,
  uploadSignature,
  removeSignature,
  adminList,
  adminRevoke,
  adminRestore
};
