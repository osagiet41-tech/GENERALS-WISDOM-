/**
 * QR code as a module matrix, drawn as vector squares by the renderer (no image files, no canvas).
 * Uses the optional `qrcode` package; if it is not installed the certificate is still produced, just
 * without a QR (the printed URL + ID remain the verification route).
 */
const logger = require('../../utils/logger');

let warned = false;

function buildQr(text) {
  try {
    // eslint-disable-next-line global-require
    const QRCode = require('qrcode');
    const qr = QRCode.create(text, { errorCorrectionLevel: 'M' });
    const { modules } = qr;
    return { size: modules.size, get: (row, col) => Boolean(modules.get(row, col)) };
  } catch (err) {
    if (!warned) {
      warned = true;
      logger.warn(`Certificate QR codes disabled (${err.code === 'MODULE_NOT_FOUND' ? 'install the "qrcode" package' : err.message})`);
    }
    return null;
  }
}

module.exports = { buildQr };
