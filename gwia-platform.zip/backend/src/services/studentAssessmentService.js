const { Assessment } = require('../models/assessment.model');
const examAttemptService = require('./examAttemptService');

/**
 * Lists assessments currently open for this student — published,
 * within their availability window, and (if the assessment restricts
 * to a specific class/group) the student must be on that list.
 */
async function listAssessments(kind, courseId, studentId) {
  const now = new Date();
  const assessments = await Assessment.find({
    kind,
    courseId,
    status: 'published',
    availableFrom: { $lte: now },
    availableUntil: { $gte: now }
  }).sort({ availableFrom: 1 });

  return assessments.filter((a) => examAttemptService.isEligibleForAssessment(a, studentId));
}

module.exports = { listAssessments };
