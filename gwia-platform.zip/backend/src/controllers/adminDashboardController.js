const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const adminDashboardService = require('../services/adminDashboardService');

const getOverview = asyncHandler(async (req, res) => {
  const stats = await adminDashboardService.getOverviewStats();
  return ApiResponse.ok(res, stats, 'Overview stats retrieved');
});

const getRevenueTrend = asyncHandler(async (req, res) => {
  const trend = await adminDashboardService.getRevenueTrend({ months: req.query.months });
  return ApiResponse.ok(res, trend, 'Revenue trend retrieved');
});

const getEngagement = asyncHandler(async (req, res) => {
  const engagement = await adminDashboardService.getStudentEngagement();
  return ApiResponse.ok(res, engagement, 'Student engagement retrieved');
});

const getCoursePerformance = asyncHandler(async (req, res) => {
  const performance = await adminDashboardService.getCoursePerformance({ limit: req.query.limit });
  return ApiResponse.ok(res, performance, 'Course performance retrieved');
});

const getCourseCreationTrend = asyncHandler(async (req, res) => {
  const trend = await adminDashboardService.getCourseCreationTrend({ months: req.query.months });
  return ApiResponse.ok(res, trend, 'Course creation trend retrieved');
});

module.exports = { getOverview, getRevenueTrend, getEngagement, getCoursePerformance, getCourseCreationTrend };
