const express = require('express');
const controller = require('../controllers/courseController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership } = require('../middleware/teacherOwnership.middleware');
const { uploadThumbnail } = require('../config/multer');
const {
  createCourseValidator,
  updateCourseValidator,
  subjectValidator,
  addCoTeacherValidator
} = require('../validators/courseValidator');

const router = express.Router();

router.use(authMiddleware, requireTeacherOrAdmin);

router.get('/mine', controller.listMyCourses);
router.post('/', validate(createCourseValidator), controller.createCourse);

router.get('/:courseId', verifyCourseOwnership(), controller.getCourse);
router.put('/:courseId', verifyCourseOwnership(), validate(updateCourseValidator), controller.updateCourse);
router.delete('/:courseId', verifyCourseOwnership(), controller.deleteCourse);
router.post(
  '/:courseId/co-teachers',
  verifyCourseOwnership(),
  validate(addCoTeacherValidator),
  controller.addCoTeacher
);
router.post(
  '/:courseId/thumbnail',
  verifyCourseOwnership(),
  uploadThumbnail.single('thumbnail'),
  controller.uploadThumbnail
);

router.get('/:courseId/subjects', verifyCourseOwnership(), controller.listSubjects);
router.post(
  '/:courseId/subjects',
  verifyCourseOwnership(),
  validate(subjectValidator),
  controller.createSubject
);
router.put(
  '/:courseId/subjects/:subjectId',
  verifyCourseOwnership(),
  validate(subjectValidator),
  controller.updateSubject
);
router.delete('/:courseId/subjects/:subjectId', verifyCourseOwnership(), controller.deleteSubject);

module.exports = router;
