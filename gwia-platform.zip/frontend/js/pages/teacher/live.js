import { h, icon } from '../../core/dom.js';
import { teacherApi } from '../../api/teacher.js';
import { pageHead, items, idOf } from '../../ui/page.js';
import { courseSelect } from '../shared/courseSelect.js';
import { withState, empty, busy } from '../../ui/states.js';
import { dataTable, statusBadge } from '../../ui/table.js';
import { openModal, confirmDialog } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { fmtDateTime } from '../../core/format.js';

export default async function render() {
  const { data: courses } = await teacherApi.courses(); const panel = h('div', { class: 'card card-flush' }); let reloadFn;
  const cs = courseSelect(courses, { storageKey: 'teacher.live.course', onChange: (id) => load(id) });
  if (!cs.count) return h('div', null, pageHead('Live classes'), empty({ title: 'Create a course first', iconName: 'video' }));
  const act = (fn, msg) => async (e) => { try { await busy(e.currentTarget, fn); toast.success(msg); reloadFn(); } catch (err) { toast.error(err.message); } };
  const load = (id) => { reloadFn = withState(panel, () => teacherApi.liveClasses(id).then((r) => items(r.data)), (rows) => dataTable({ rows, caption: 'Live classes', emptyState: empty({ title: 'Nothing scheduled', iconName: 'video' }),
    columns: [{ label: 'Class', render: (r) => h('strong', null, r.title) }, { label: 'When', render: (r) => fmtDateTime(r.scheduledAt) }, { label: 'Length', render: (r) => `${r.durationMinutes} min` }, { label: 'Status', render: (r) => statusBadge(r.status) }],
    actions: (r) => h('div', { class: 'row', style: 'justify-content:flex-end' },
      r.status === 'scheduled' && h('button', { class: 'btn btn-sm', type: 'button', onclick: act(() => teacherApi.startLive(idOf(r)), 'Class started.') }, 'Start'),
      (r.status === 'scheduled' || r.status === 'live') && h('a', { class: 'btn btn-secondary btn-sm', href: `classroom.html?id=${idOf(r)}&course=${cs.value}` }, icon('video'), 'Enter room'),
      r.status === 'live' && h('button', { class: 'btn btn-danger btn-sm', type: 'button', onclick: async (e) => { if (await confirmDialog({ title: 'End class for everyone?', message: 'Participants will be disconnected.', confirmLabel: 'End class', danger: true })) act(() => teacherApi.endLive(idOf(r)), 'Class ended.')(e); } }, 'End'),
      r.status === 'scheduled' && h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: async (e) => { if (await confirmDialog({ title: 'Cancel this class?', message: 'Students will see it as cancelled.', confirmLabel: 'Cancel class', danger: true })) act(() => teacherApi.cancelLive(idOf(r)), 'Class cancelled.')(e); } }, 'Cancel')) }), { rows: 3 }); };
  const schedule = () => { const m = openModal({ title: 'Schedule a live class', body: buildForm({ submitLabel: 'Schedule', onCancel: () => m.close(), fields: [
    { name: 'title', label: 'Title', required: true, full: true, maxlength: 200 }, { name: 'description', label: 'Description', type: 'textarea', full: true, rows: 3 },
    { name: 'scheduledAt', label: 'Starts', type: 'datetime-local', required: true }, { name: 'durationMinutes', label: 'Duration (minutes)', type: 'number', min: 5, max: 480, value: 60, required: true },
    { name: 'chatEnabled', label: 'Enable chat', type: 'checkbox', value: true }, { name: 'studentMicEnabledByDefault', label: 'Students’ mics on at join', type: 'checkbox' }, { name: 'studentCameraEnabledByDefault', label: 'Students’ cameras on at join', type: 'checkbox' }, { name: 'studentScreenShareAllowed', label: 'Students may share screen', type: 'checkbox' }],
    onSubmit: async (v) => { await teacherApi.scheduleLive(cs.value, { ...v, scheduledAt: new Date(v.scheduledAt).toISOString() }); m.close(); toast.success('Class scheduled.'); reloadFn(); } }) }); };
  load(cs.value);
  return h('div', { class: 'stack' }, pageHead('Live classes', 'Schedule, start and run virtual classes.', h('button', { class: 'btn', type: 'button', onclick: schedule }, icon('plus'), 'Schedule class')), cs.el, panel);
}
