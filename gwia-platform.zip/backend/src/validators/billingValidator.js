const { body, param } = require('express-validator');

const checkoutValidator = [
  body('purpose').isIn(['course', 'subscription']).withMessage('purpose must be "course" or "subscription"'),
  body('courseId').if(body('purpose').equals('course')).isMongoId().withMessage('A valid courseId is required'),
  body('planCode').if(body('purpose').equals('subscription')).isString().trim().notEmpty().withMessage('planCode is required'),
  body('currency').optional().isLength({ min: 3, max: 3 }).withMessage('currency must be a 3-letter code'),
  body('provider').optional().isIn(['paystack', 'flutterwave']),
  body('discountCode').optional({ nullable: true, checkFalsy: true }).isString().trim().isLength({ max: 40 })
  // NOTE: no amount field exists on purpose. The server computes every price.
];

const validateDiscountValidator = [
  body('code').isString().trim().notEmpty().isLength({ max: 40 }),
  body('purpose').isIn(['course', 'subscription']),
  body('courseId').if(body('purpose').equals('course')).isMongoId(),
  body('planCode').if(body('purpose').equals('subscription')).isString().trim().notEmpty(),
  body('currency').optional().isLength({ min: 3, max: 3 })
];

const startTrialValidator = [body('planCode').isString().trim().notEmpty().withMessage('planCode is required')];

const verifyPaymentValidator = [
  param('reference').isString().trim().isLength({ min: 6, max: 100 }).matches(/^[A-Za-z0-9\-.=]+$/),
  body('transactionId').optional().isString().matches(/^\d+$/)
];

const createPlanValidator = [
  body('code').trim().matches(/^[a-zA-Z0-9\-]{2,60}$/).withMessage('code: letters, digits and hyphens only'),
  body('name').trim().notEmpty().isLength({ max: 120 }),
  body('billingCycle').isIn(['monthly', 'annual']),
  body('prices').isArray({ min: 1 }).withMessage('At least one price is required'),
  body('prices.*.currency').isLength({ min: 3, max: 3 }).toUpperCase(),
  body('prices.*.amountMinor').isInt({ min: 0 }).withMessage('amountMinor must be an integer in kobo/cents'),
  body('trialDays').optional().isInt({ min: 0, max: 90 }),
  body('features').optional().isArray(),
  body('active').optional().isBoolean(),
  body('sortOrder').optional().isInt()
];

const updatePlanValidator = [
  body('name').optional().trim().notEmpty().isLength({ max: 120 }),
  body('prices').optional().isArray({ min: 1 }),
  body('prices.*.currency').optional().isLength({ min: 3, max: 3 }).toUpperCase(),
  body('prices.*.amountMinor').optional().isInt({ min: 0 }),
  body('trialDays').optional().isInt({ min: 0, max: 90 }),
  body('features').optional().isArray(),
  body('active').optional().isBoolean(),
  body('sortOrder').optional().isInt()
];

const createDiscountValidator = [
  body('code').trim().matches(/^[a-zA-Z0-9\-_]{3,40}$/).withMessage('code: 3-40 letters, digits, - or _'),
  body('type').isIn(['percent', 'fixed']),
  body('percentOff').if(body('type').equals('percent')).isInt({ min: 1, max: 100 }),
  body('fixedAmounts').if(body('type').equals('fixed')).isArray({ min: 1 }),
  body('fixedAmounts.*.currency').optional().isLength({ min: 3, max: 3 }).toUpperCase(),
  body('fixedAmounts.*.amountMinor').optional().isInt({ min: 1 }),
  body('appliesTo').optional().isIn(['all', 'course', 'subscription']),
  body('courseIds').optional().isArray(),
  body('courseIds.*').optional().isMongoId(),
  body('planCodes').optional().isArray(),
  body('maxRedemptions').optional({ nullable: true }).isInt({ min: 1 }),
  body('perUserLimit').optional().isInt({ min: 1 }),
  body('maxDiscountMinor').optional({ nullable: true }).isInt({ min: 0 }),
  body('validFrom').optional({ nullable: true }).isISO8601(),
  body('validUntil').optional({ nullable: true }).isISO8601(),
  body('description').optional().isString().isLength({ max: 300 })
];

const updateDiscountValidator = [
  body('active').optional().isBoolean(),
  body('appliesTo').optional().isIn(['all', 'course', 'subscription']),
  body('courseIds').optional().isArray(),
  body('courseIds.*').optional().isMongoId(),
  body('planCodes').optional().isArray(),
  body('maxRedemptions').optional({ nullable: true }).isInt({ min: 1 }),
  body('perUserLimit').optional().isInt({ min: 1 }),
  body('maxDiscountMinor').optional({ nullable: true }).isInt({ min: 0 }),
  body('validFrom').optional({ nullable: true }).isISO8601(),
  body('validUntil').optional({ nullable: true }).isISO8601(),
  body('description').optional().isString().isLength({ max: 300 })
];

module.exports = {
  checkoutValidator,
  validateDiscountValidator,
  startTrialValidator,
  verifyPaymentValidator,
  createPlanValidator,
  updatePlanValidator,
  createDiscountValidator,
  updateDiscountValidator
};
