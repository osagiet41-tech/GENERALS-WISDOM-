const { body } = require('express-validator');

const createAssignmentValidator = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 200 }),
  body('instructions').optional().isString(),
  body('totalMarks').isFloat({ min: 1 }).withMessage('totalMarks must be a positive number'),
  body('dueDate').isISO8601().withMessage('dueDate must be a valid date'),
  body('allowLateSubmission').optional().isBoolean(),
  body('allowResubmission').optional().isBoolean(),
  body('status').optional().isIn(['draft', 'published', 'closed']),
  body('subjectId').optional().isMongoId(),
  body('moduleId').optional().isMongoId(),
  body('lessonId').optional().isMongoId()
];

const updateAssignmentValidator = [
  body('title').optional().trim().notEmpty().isLength({ max: 200 }),
  body('instructions').optional().isString(),
  body('totalMarks').optional().isFloat({ min: 1 }).withMessage('totalMarks must be a positive number'),
  body('dueDate').optional().isISO8601().withMessage('dueDate must be a valid date'),
  body('allowLateSubmission').optional().isBoolean(),
  body('allowResubmission').optional().isBoolean(),
  body('status').optional().isIn(['draft', 'published', 'closed']),
  body('subjectId').optional().isMongoId(),
  body('moduleId').optional().isMongoId(),
  body('lessonId').optional().isMongoId()
];

module.exports = { createAssignmentValidator, updateAssignmentValidator };
