import { h } from '../core/dom.js';
import { ApiError } from '../core/http.js';
import { toast } from './toast.js';
let uid = 0;
/* field({label,name,type,required,options:[{value,label}],hint,value,rows,min,max,step,placeholder,full}) -> { el, input } */
export function field(f) {
  const id = `f${++uid}-${f.name}`, common = { id, name: f.name, class: 'input', required: f.required, placeholder: f.placeholder, 'aria-describedby': `${id}-msg` };
  let input;
  if (f.type === 'select') input = h('select', common, (f.options || []).map((o) => h('option', { value: o.value, selected: String(o.value) === String(f.value ?? '') }, o.label)));
  else if (f.type === 'textarea') input = h('textarea', { ...common, rows: f.rows || 4, maxlength: f.maxlength }, f.value ?? '');
  else if (f.type === 'checkbox') { input = h('input', { id, name: f.name, type: 'checkbox', checked: !!f.value }); return { input, el: h('div', { class: 'field' }, h('label', { class: 'check', for: id }, input, h('span', null, f.label)), f.hint && h('div', { class: 'hint' }, f.hint), h('div', { class: 'field-error', id: `${id}-msg`, role: 'alert' })) }; }
  else input = h('input', { ...common, type: f.type || 'text', value: f.value ?? '', min: f.min, max: f.max, step: f.step, minlength: f.minlength, maxlength: f.maxlength, autocomplete: f.autocomplete, accept: f.accept, multiple: f.multiple });
  const el = h('div', { class: 'field', style: f.full ? 'grid-column:1/-1' : null }, h('label', { for: id }, f.label, f.required && h('span', { class: 'req', 'aria-hidden': 'true' }, '*')), input, f.hint && h('div', { class: 'hint' }, f.hint), h('div', { class: 'field-error', id: `${id}-msg`, role: 'alert' }));
  return { el, input };
}
export function valueOf(input) {
  if (input.type === 'checkbox') return input.checked;
  if (input.type === 'file') return input.files;
  if (input.type === 'number') return input.value === '' ? undefined : Number(input.value);
  return input.value.trim() === '' ? undefined : input.value.trim();
}
/* buildForm({ fields, submitLabel, onSubmit(values) -> Promise, cancel, grid }) -> <form>. Handles busy state and server field errors. */
export function buildForm({ fields, submitLabel = 'Save', onSubmit, onCancel, grid = true }) {
  const built = fields.map((f) => ({ f, ...field(f) }));
  const errBox = h('div', { class: 'form-error hidden', role: 'alert' });
  const submit = h('button', { class: 'btn', type: 'submit' }, submitLabel);
  const form = h('form', { class: 'stack', novalidate: true }, errBox, h('div', { class: grid ? 'form-grid' : 'stack' }, built.map((b) => b.el)),
    h('div', { class: 'row' }, submit, onCancel && h('button', { class: 'btn btn-secondary', type: 'button', onclick: onCancel }, 'Cancel')));
  const setErr = (b, msg) => { const m = b.el.querySelector('.field-error'); m.textContent = msg || ''; msg ? b.el.setAttribute('data-invalid', '') : b.el.removeAttribute('data-invalid'); };
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); errBox.classList.add('hidden'); let bad = null;
    built.forEach((b) => { const msg = !b.input.checkValidity() ? b.input.validationMessage : ''; setErr(b, msg); if (msg && !bad) bad = b; });
    if (bad) return bad.input.focus();
    const values = Object.fromEntries(built.map((b) => [b.f.name, valueOf(b.input)]));
    submit.disabled = true; submit.setAttribute('aria-busy', 'true');
    try { await onSubmit(values); }
    catch (err) {
      if (!(err instanceof ApiError)) throw err;
      const fe = err.fieldErrors; let any = false;
      built.forEach((b) => { if (fe[b.f.name]) { setErr(b, fe[b.f.name]); any = true; } });
      if (!any || err.status !== 400) { errBox.textContent = err.message; errBox.classList.remove('hidden'); } else toast.error('Please fix the highlighted fields.');
    } finally { submit.disabled = false; submit.removeAttribute('aria-busy'); }
  });
  form.fieldInputs = Object.fromEntries(built.map((b) => [b.f.name, b.input]));
  return form;
}
