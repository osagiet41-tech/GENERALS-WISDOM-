import { h, mount } from '../../core/dom.js';
import { studentApi } from '../../api/student.js';
import { billingApi } from '../../api/billing.js';
import { pageHead, items, idOf } from '../../ui/page.js';
import { empty } from '../../ui/states.js';
import { openModal, confirmDialog } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { searchBox } from '../../ui/search.js';
import { statusBadge } from '../../ui/table.js';
import { assetUrl } from '../../core/format.js';
import { config } from '../../core/config.js';
import { icon } from '../../core/dom.js';

export default async function render({ navigate }) {
  const { data } = await studentApi.courses(); const all = items(data); let term = '';
  const grid = h('div', { class: 'grid grid-3' });
  const open = (c) => h('a', { class: 'btn btn-sm', href: `learn.html?course=${idOf(c)}` }, icon('play'), 'Open');
  const draw = () => {
    const list = all.filter((c) => c.title.toLowerCase().includes(term.toLowerCase()));
    mount(grid, ...(list.length ? list.map((c) => {
      const locked = c.access && c.access.allowed === false;
      return h('article', { class: 'card course-card' }, h('div', { class: 'thumb' }, c.thumbnailUrl ? h('img', { src: assetUrl(c.thumbnailUrl, config.socketUrl), alt: '', loading: 'lazy' }) : icon('book')),
        h('div', { class: 'spread' }, h('h3', { style: 'margin:0' }, c.title), statusBadge(c.status)), h('p', { class: 'muted small', style: 'margin:0' }, (c.description || '').slice(0, 120)),
        locked && h('div', { class: 'banner' }, 'Access expired or unpaid.', h('a', { class: 'btn btn-sm', href: '#/billing' }, 'Renew')),
        h('div', { class: 'row' }, !locked && open(c), h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: async () => { if (await confirmDialog({ title: 'Leave this course?', message: `You will lose access to “${c.title}”. Your progress is kept if you rejoin.`, confirmLabel: 'Unenrol', danger: true })) { try { await studentApi.unenroll(idOf(c)); toast.success('You have left the course.'); navigate('#/courses?r=' + Date.now()); } catch (e) { toast.error(e.message); } } } }, 'Unenrol')));
    }) : [empty({ title: all.length ? 'No courses match your search' : 'You are not enrolled in any course yet', message: all.length ? '' : 'Ask your teacher for the course ID, then use “Enrol in a course”.', iconName: 'book' })]));
  };
  const enrol = () => {
    const form = buildForm({ grid: false, submitLabel: 'Enrol', fields: [{ name: 'courseId', label: 'Course ID', required: true, hint: 'A 24-character ID your teacher shares with you.' }],
      onSubmit: async (v) => {
        try { await studentApi.enroll(v.courseId); m.close(); toast.success('You are enrolled.'); location.hash = `#/courses?r=${Date.now()}`; }
        catch (e) {
          if (e.status === 402) { m.close(); toast.info('This course is paid. Complete payment to enrol.'); return startCoursePayment(v.courseId); }
          throw e;
        }
      } });
    const m = openModal({ title: 'Enrol in a course', body: form });
  };
  draw();
  return h('div', { class: 'stack' }, pageHead('My courses', `${all.length} enrolled`, h('button', { class: 'btn', type: 'button', onclick: enrol }, icon('plus'), 'Enrol in a course')),
    searchBox({ placeholder: 'Search my courses…', onSearch: (t) => { term = t; draw(); } }), grid);
}
/* Paid course: ask the server for a checkout (never trust the browser about payment), then go to the provider. */
export async function startCoursePayment(courseId) {
  try { const { data } = await billingApi.checkout({ purpose: 'course', courseId }); if (data.checkoutUrl) location.href = data.checkoutUrl; else toast.success('Enrolled.'); }
  catch (e) { toast.error(e.message); }
}
