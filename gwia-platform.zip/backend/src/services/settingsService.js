const { Settings } = require('../models/systemAdmin.model');

async function getSettings() {
  let settings = await Settings.findOne({});
  if (!settings) {
    settings = await Settings.create({});
  }
  return settings;
}

async function updateSettings(updates, adminId) {
  const settings = await getSettings();

  const allowed = [
    'siteName',
    'registrationOpen',
    'maintenanceMode',
    'defaultCurrency',
    'supportEmail',
    'maxUploadSizeMB'
  ];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      settings[field] = updates[field];
    }
  }
  settings.updatedBy = adminId;
  await settings.save();
  return settings;
}

module.exports = { getSettings, updateSettings };
