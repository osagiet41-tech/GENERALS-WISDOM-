const { verifyAccessToken } = require('../utils/tokens');
const logger = require('../utils/logger');
const User = require('../models/User');
const initClassroomNamespace = require('./classroom.socket');
const { registerMessagingHandlers } = require('./messaging.socket');

/**
 * Attaches Socket.IO to the given HTTP server, verifies the JWT on
 * handshake, and joins each socket into its personal/role/institution
 * rooms so services can emit to `user:<id>`, `role:<role>`, or
 * `institution:<id>` without knowing individual socket ids.
 */
function initSockets(io) {
  io.use(async (socket, next) => {
    try {
      // Token only from the handshake `auth` object: query-string tokens end up in proxy/access logs.
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('Authentication token missing'));

      const payload = verifyAccessToken(token); // pinned alg, must be an access token
      const user = await User.findById(payload.sub);
      if (!user || user.status !== 'active') {
        return next(new Error('Invalid or inactive user'));
      }
      if (user.passwordChangedAt && payload.iat * 1000 < user.passwordChangedAt.getTime() - 1000) {
        return next(new Error('Session expired'));
      }

      socket.user = {
        id: user._id.toString(),
        name: user.name,
        role: user.role,
        institutionId: user.institutionId ? user.institutionId.toString() : null
      };

      next();
    } catch (err) {
      next(new Error('Socket authentication failed'));
    }
  });

  io.on('connection', (socket) => {
    const { id, role, institutionId } = socket.user;

    socket.join(`user:${id}`);
    socket.join(`role:${role}`);
    if (institutionId) socket.join(`institution:${institutionId}`);

    logger.info(`Socket connected: user=${id} role=${role} socketId=${socket.id}`);

    socket.on('disconnect', (reason) => {
      logger.info(`Socket disconnected: user=${id} reason=${reason}`);
    });

    // Real-time messaging: conversation rooms, instant delivery, typing
    // indicators, read receipts, online/offline presence.
    registerMessagingHandlers(io, socket).catch((err) => {
      logger.error(`Failed to register messaging handlers for user ${id}: ${err.message}`);
    });

    // Other module-specific handlers register here, e.g.:
    // require('../modules/notifications/notifications.socket')(io, socket);
  });

  // The live virtual classroom runs on its own namespace with its own
  // auth scheme (a short-lived classroom join token, not the general
  // access token) — see classroom.socket.js and classroomAuthService.
  initClassroomNamespace(io);
}

module.exports = initSockets;
