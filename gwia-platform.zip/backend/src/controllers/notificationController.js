const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const notificationService = require('../services/notificationService');

// GET /api/notifications
const list = asyncHandler(async (req, res) => {
  const { unreadOnly, page, limit } = req.query;
  const result = await notificationService.listNotifications(req.user.id, {
    unreadOnly: unreadOnly === 'true',
    page,
    limit
  });
  return ApiResponse.ok(res, result.items, 'Notifications retrieved', {
    unreadCount: result.unreadCount,
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

// PUT /api/notifications/:id/read
const markAsRead = asyncHandler(async (req, res) => {
  const notification = await notificationService.markAsRead(req.params.id, req.user.id);
  return ApiResponse.ok(res, notification, 'Notification marked as read');
});

// PUT /api/notifications/read-all
const markAllAsRead = asyncHandler(async (req, res) => {
  await notificationService.markAllAsRead(req.user.id);
  return ApiResponse.ok(res, null, 'All notifications marked as read');
});

module.exports = { list, markAsRead, markAllAsRead };
