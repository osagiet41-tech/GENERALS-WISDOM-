import { h, icon, mount } from '../core/dom.js';
export const loading = (rows = 4) => h('div', { class: 'skeleton', role: 'status', 'aria-busy': 'true', 'aria-label': 'Loading' }, Array.from({ length: rows }, () => h('i')));
export const spinner = () => h('span', { class: 'spinner', role: 'status', 'aria-label': 'Loading' });
export function empty({ title = 'Nothing here yet', message = '', action, iconName = 'file' } = {}) {
  return h('div', { class: 'state' }, icon(iconName), h('h3', null, title), message && h('p', null, message), action);
}
export function errorState(err, retry) {
  const offline = err?.status === 0, denied = err?.status === 403, gone = err?.status === 404, pay = err?.status === 402;
  return h('div', { class: 'state err', role: 'alert' }, icon('alert'),
    h('h3', null, offline ? 'Connection problem' : denied ? 'Access denied' : gone ? 'Not found' : pay ? 'Payment required' : 'Something went wrong'),
    h('p', null, err?.message || 'Please try again.'),
    retry && h('button', { class: 'btn btn-secondary', type: 'button', onclick: retry }, icon('refresh'), 'Try again'));
}
/* withState(container, loader, render): loading skeleton -> render(data) or error state with retry. Returns a reload fn. */
export function withState(container, loader, render, { rows } = {}) {
  const run = async () => {
    mount(container, loading(rows));
    try { const result = await loader(); mount(container, render(result, run)); }
    catch (e) { if (e.name !== 'AbortError') mount(container, errorState(e, run)); }
  };
  run(); return run;
}
/* Disable a button while an async action runs; surfaces errors as toasts by default. */
export async function busy(btn, fn) {
  btn.setAttribute('aria-busy', 'true'); btn.disabled = true;
  try { return await fn(); } finally { btn.removeAttribute('aria-busy'); btn.disabled = false; }
}
