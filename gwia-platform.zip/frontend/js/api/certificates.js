import { api, download, openBlob } from '../core/http.js';
export const certificatesApi = {
  verify: (id) => api.get(`/certificates/verify/${encodeURIComponent(id.trim())}`, null, { auth: false }),
  list: () => api.get('/student/certificates'),
  details: (id) => api.get(`/student/certificates/${id}`),
  download: (id, name) => download(`/student/certificates/${id}/download`, `${name || 'certificate'}.pdf`),
  view: (id) => openBlob(`/student/certificates/${id}/download`, { inline: 1 }),
  eligibility: (courseId) => api.get(`/student/courses/${courseId}/certificate/eligibility`),
  request: (courseId) => api.post(`/student/courses/${courseId}/certificate`),
  adminList: (q) => api.get('/admin/certificates', q), revoke: (id) => api.post(`/admin/certificates/${id}/revoke`), restore: (id) => api.post(`/admin/certificates/${id}/restore`),
  uploadSignature(file) { const fd = new FormData(); fd.append('signature', file); return api.put('/certificates/signature', fd); },
  removeSignature: () => api.del('/certificates/signature')
};
