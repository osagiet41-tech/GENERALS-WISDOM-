const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

/**
 * Generates a PDF to disk from a list of draw instructions and resolves
 * with the file path once the stream has finished writing.
 *
 * @param {string} outputDir - directory to write the file into
 * @param {string} fileName - target file name, e.g. 'certificate-123.pdf'
 * @param {(doc: PDFKit.PDFDocument) => void} buildFn - callback that draws content on the doc
 * @returns {Promise<string>} absolute path to the generated PDF
 */
function generatePdf(outputDir, fileName, buildFn) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    const filePath = path.join(outputDir, fileName);
    const doc = new PDFDocument({ size: 'A4', margin: 50 });
    const stream = fs.createWriteStream(filePath);

    doc.pipe(stream);
    buildFn(doc);
    doc.end();

    stream.on('finish', () => resolve(filePath));
    stream.on('error', reject);
  });
}

/**
 * Example concrete generator: a certificate of completion.
 */
function buildCertificateContent(doc, { studentName, courseTitle, issuedAt, verificationCode }) {
  doc
    .fontSize(28)
    .text('Certificate of Completion', { align: 'center' })
    .moveDown(2)
    .fontSize(16)
    .text('This certifies that', { align: 'center' })
    .moveDown(0.5)
    .fontSize(22)
    .text(studentName, { align: 'center' })
    .moveDown(0.5)
    .fontSize(16)
    .text('has successfully completed the course', { align: 'center' })
    .moveDown(0.5)
    .fontSize(20)
    .text(courseTitle, { align: 'center' })
    .moveDown(2)
    .fontSize(12)
    .text(`Issued: ${new Date(issuedAt).toDateString()}`, { align: 'center' })
    .text(`Verification code: ${verificationCode}`, { align: 'center' });
}

module.exports = { generatePdf, buildCertificateContent };
