const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const adminUserService = require('../services/adminUserService');
const auditLogService = require('../services/auditLogService');

const listUsers = asyncHandler(async (req, res) => {
  const { role, status, search, page, limit } = req.query;
  const result = await adminUserService.listUsers({ role, status, search, page, limit });
  return ApiResponse.ok(res, result.items, 'Users retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

const getUser = asyncHandler(async (req, res) => {
  const detail = await adminUserService.getUserDetail(req.params.id);
  return ApiResponse.ok(res, detail, 'User detail retrieved');
});

const createUser = asyncHandler(async (req, res) => {
  const { name, email, role } = req.body;
  const { user, setupEmailSent } = await adminUserService.createUser({ name, email, role });
  await auditLogService.record(req.user.id, 'user.create', 'User', user._id, { role, email }, req.ip);
  return ApiResponse.created(
    res,
    { user, setupEmailSent },
    setupEmailSent ? 'Account created. A link to set the password was e-mailed to the user.' : 'Account created, but the set-password e-mail could not be sent. Ask the user to use "Forgot password".'
  );
});

const changeRole = asyncHandler(async (req, res) => {
  const user = await adminUserService.changeRole(req.params.id, req.body.role, req.user.id);
  await auditLogService.record(req.user.id, 'user.role_change', 'User', req.params.id, { role: req.body.role }, req.ip);
  return ApiResponse.ok(res, user, 'Role updated');
});

const suspendUser = asyncHandler(async (req, res) => {
  const user = await adminUserService.suspendUser(req.params.id, req.user.id);
  await auditLogService.record(req.user.id, 'user.suspend', 'User', req.params.id, { reason: req.body.reason }, req.ip);
  return ApiResponse.ok(res, user, 'Account suspended');
});

const restoreUser = asyncHandler(async (req, res) => {
  const user = await adminUserService.restoreUser(req.params.id);
  await auditLogService.record(req.user.id, 'user.restore', 'User', req.params.id, {}, req.ip);
  return ApiResponse.ok(res, user, 'Account restored');
});

module.exports = { createUser, changeRole, listUsers, getUser, suspendUser, restoreUser };
