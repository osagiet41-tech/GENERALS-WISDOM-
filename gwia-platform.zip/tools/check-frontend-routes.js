#!/usr/bin/env node
/**
 * Verifies that every API call written in the frontend (frontend/js/**) matches a route that really exists in the
 * backend (taken from backend/scripts/route-inventory.js). Catches wrong paths and wrong HTTP methods before runtime.
 *
 *   node tools/check-frontend-routes.js          (exit code 1 when something does not match)
 */
const fs = require('fs');
const path = require('path');
const { buildInventory } = require('../backend/scripts/route-inventory');

const FRONT = path.join(__dirname, '..', 'frontend', 'js');
const backend = buildInventory();

const seg = (p) => p.split('/').filter(Boolean);
const isParam = (s) => s.startsWith(':') || s === '*';
function matches(frontPath, route) {
  const a = seg(frontPath), b = seg(route.path);
  if (a.length !== b.length) return false;
  return a.every((s, i) => isParam(s) || isParam(b[i]) || s === b[i]);
}

function* walk(dir) {
  for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, f.name);
    if (f.isDirectory()) yield* walk(full);
    else if (f.name.endsWith('.js')) yield full;
  }
}

// api.get('/x') | api.post(`/x/${id}`) | download('/x') | openBlob('/x') | request('/x', { method: 'POST' })
const CALL = /\b(?:api\.(get|post|put|del)|(download)|(openBlob)|(request))\(\s*([`'"])((?:\\.|(?!\5).)*)\5(?:\s*,\s*(\{[^)]*\}))?/g;
const found = [];
for (const file of walk(FRONT)) {
  const src = fs.readFileSync(file, 'utf8');
  let m;
  while ((m = CALL.exec(src))) {
    const [, verb, dl, ob, req, , raw, opts] = m;
    let method = verb ? { get: 'GET', post: 'POST', put: 'PUT', del: 'DELETE' }[verb] : (dl || ob) ? 'GET' : 'GET';
    if (req && opts) { const mm = /method:\s*'([A-Z]+)'/.exec(opts); if (mm) method = mm[1]; }
    const p = raw.replace(/\$\{[^}]+\}/g, ':p').split('?')[0];
    if (!p.startsWith('/')) continue;
    found.push({ file: path.relative(path.join(__dirname, '..'), file), method, path: p });
  }
}

const problems = [];
for (const f of found) {
  const full = `/api${f.path}`;
  const candidates = backend.filter((r) => matches(full, r));
  if (candidates.length === 0) problems.push({ ...f, why: 'no such backend route' });
  else if (!candidates.some((r) => r.method === f.method || r.method === 'ALL')) {
    // dynamic segments such as /${kind}/${id}/... can legitimately resolve to another method; only flag fully static paths
    problems.push({ ...f, why: `route exists but not for ${f.method} (has: ${[...new Set(candidates.map((r) => r.method))].join(', ')})` });
  }
}

console.log(`Checked ${found.length} frontend API calls against ${backend.length} backend routes.`);
if (problems.length) {
  for (const p of problems) console.log(`MISMATCH  ${p.method.padEnd(6)} ${p.path}   (${p.file}) -> ${p.why}`);
  process.exit(1);
}
console.log('All frontend API calls match a backend route.');
