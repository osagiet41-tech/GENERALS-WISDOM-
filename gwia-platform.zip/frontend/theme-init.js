/* Render-blocking, 6 lines: sets the theme before first paint so there is no light/dark flash. */
(function () {
  var t = localStorage.getItem('gwia.theme');
  if (!t) t = window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  document.documentElement.dataset.theme = t;
})();
