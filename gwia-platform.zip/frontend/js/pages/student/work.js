import { h, mount, icon } from '../../core/dom.js';
import { studentApi } from '../../api/student.js';
import { pageHead, items, idOf } from '../../ui/page.js';
import { courseSelect } from '../shared/courseSelect.js';
import { withState, empty } from '../../ui/states.js';
import { tabs } from '../../ui/tabs.js';
import { dataTable, statusBadge } from '../../ui/table.js';
import { openModal } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { fmtDateTime } from '../../core/format.js';
import { ApiError } from '../../core/http.js';

export default async function render() {
  const { data: courses } = await studentApi.courses(); const panel = h('div');
  const cs = courseSelect(courses, { storageKey: 'student.work.course', onChange: (id) => load(id) });
  if (!cs.count) return h('div', null, pageHead('Assignments & exams'), empty({ title: 'No courses yet', message: 'Enrol in a course to see its assignments, quizzes and exams.', iconName: 'book' }));
  const load = (courseId) => mount(panel, tabs([
    { id: 'a', label: 'Assignments', render: (p) => withState(p, () => studentApi.assignments(courseId).then((r) => items(r.data)), (rows) => assignments(rows, courseId)) },
    { id: 'q', label: 'Quizzes', render: (p) => withState(p, () => studentApi.assessments('quizzes', courseId).then((r) => items(r.data)), (rows) => assessments('quizzes', rows, courseId)) },
    { id: 'e', label: 'Exams', render: (p) => withState(p, () => studentApi.assessments('exams', courseId).then((r) => items(r.data)), (rows) => assessments('exams', rows, courseId)) }]));
  load(cs.value);
  return h('div', { class: 'stack' }, pageHead('Assignments & exams', 'Submit work and sit assessments.'), cs.el, panel);
}

function assignments(rows, courseId) {
  return h('div', { class: 'card card-flush' }, dataTable({ caption: 'Assignments', rows, emptyState: empty({ title: 'No assignments published yet', iconName: 'file' }),
    columns: [{ label: 'Title', render: (r) => h('strong', null, r.title) }, { label: 'Due', render: (r) => fmtDateTime(r.dueDate) }, { label: 'Marks', key: 'totalMarks' },
      { label: 'Status', render: (r) => statusBadge(r.submission?.status || r.submissionStatus || (new Date(r.dueDate) < new Date() ? 'closed' : 'open')) }],
    actions: (r) => h('button', { class: 'btn btn-sm', type: 'button', onclick: () => submitModal(r) }, 'Open') }));
}
function submitModal(a) {
  const form = buildForm({ grid: false, submitLabel: 'Submit work', fields: [
    { name: 'textAnswer', label: 'Your answer', type: 'textarea', rows: 6, maxlength: 20000 },
    { name: 'files', label: 'Attach files (up to 5)', type: 'file', multiple: true }],
    onSubmit: async (v) => { if (!v.textAnswer && !(v.files && v.files.length)) throw new ApiError(400, 'Write an answer or attach a file.'); await studentApi.submitAssignment(idOf(a), { textAnswer: v.textAnswer, files: v.files }); toast.success('Submitted.'); m.close(); } });
  const m = openModal({ title: a.title, size: 'lg', body: h('div', { class: 'stack' }, a.instructions && h('p', { style: 'white-space:pre-wrap' }, a.instructions), h('p', { class: 'small muted' }, `Due ${fmtDateTime(a.dueDate)} · ${a.totalMarks} marks${a.allowLateSubmission ? ' · late submissions allowed' : ''}`), form) });
}
function assessments(kind, rows, courseId) {
  const label = kind === 'exams' ? 'Exam' : 'Quiz';
  return h('div', { class: 'card card-flush' }, dataTable({ caption: `${label}s`, rows, emptyState: empty({ title: `No ${label.toLowerCase()}s available`, iconName: 'file' }),
    columns: [{ label: 'Title', render: (r) => h('strong', null, r.title) }, { label: 'Duration', render: (r) => `${r.durationMinutes} min` }, { label: 'Window', render: (r) => `${fmtDateTime(r.availableFrom)} → ${fmtDateTime(r.availableUntil)}` },
      { label: 'Attempts', render: (r) => (r.maxAttempts ? `max ${r.maxAttempts}` : 'unlimited') }, { label: 'Status', render: (r) => statusBadge(r.status) }],
    actions: (r) => h('div', { class: 'row', style: 'justify-content:flex-end' }, h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => history_(kind, r) }, 'Results'),
      h('a', { class: 'btn btn-sm', href: `exam.html?kind=${kind}&id=${idOf(r)}&course=${courseId}` }, icon('play'), 'Start / resume')) }));
}
async function history_(kind, a) {
  const body = h('div'); const m = openModal({ title: `${a.title}: your attempts`, body, size: 'lg' });
  withState(body, () => studentApi.history(kind, idOf(a)).then((r) => items(r.data)), (rows) => dataTable({ rows, emptyState: empty({ title: 'No attempts yet' }), columns: [
    { label: '#', render: (r) => r.attemptNumber ?? '—' }, { label: 'Submitted', render: (r) => fmtDateTime(r.submittedAt || r.createdAt) }, { label: 'Status', render: (r) => statusBadge(r.status) },
    { label: 'Score', render: (r) => (r.grade ? `${r.grade.score} / ${r.grade.totalMarks}` : r.score != null ? `${r.score}` : 'Pending') }] }), { rows: 3 });
  return m;
}
