import { h } from '../core/dom.js';
export const pageHead = (title, subtitle, ...actions) => h('div', { class: 'page-head' }, h('div', null, h('h1', null, title), subtitle && h('p', null, subtitle)), actions.length ? h('div', { class: 'row' }, actions) : null);
export const statCard = (label, value, hint) => h('div', { class: 'card stat' }, h('div', { class: 'value' }, value ?? '—'), h('div', { class: 'label' }, label), hint && h('div', { class: 'small muted' }, hint));
export const card = (title, body, ...actions) => h('section', { class: 'card card-flush' }, title && h('div', { class: 'card-head' }, h('h2', null, title), actions.length ? h('div', { class: 'row' }, actions) : null), h('div', { style: 'padding:0' }, body));
export const items = (d) => (Array.isArray(d) ? d : d?.items || d?.data || []);
export const idOf = (o) => o?._id || o?.id;
