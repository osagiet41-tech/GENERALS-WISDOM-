const express = require('express');
const controller = require('../controllers/authController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { authLimiter, loginLimiter, refreshLimiter } = require('../middleware/rateLimiter.middleware');
const { uploadAvatar } = require('../config/multer');
const {
  registerValidator,
  loginValidator,
  forgotPasswordValidator,
  resetPasswordValidator,
  changePasswordValidator,
  updateProfileValidator,
  verifyEmailValidator,
  refreshValidator,
  logoutValidator
} = require('../validators/authValidator');

const router = express.Router();

// --- Public routes ---
router.post('/register', authLimiter, validate(registerValidator), controller.register);
router.get('/verify-email', authLimiter, validate(verifyEmailValidator), controller.verifyEmail);
router.post('/login', authLimiter, loginLimiter, validate(loginValidator), controller.login);
router.post('/refresh', refreshLimiter, validate(refreshValidator), controller.refresh);
router.post('/forgot-password', authLimiter, validate(forgotPasswordValidator), controller.forgotPassword);
router.post('/reset-password', authLimiter, validate(resetPasswordValidator), controller.resetPassword);

// --- Protected routes (require a valid access token) ---
router.post('/logout', authMiddleware, validate(logoutValidator), controller.logout);
router.get('/me', authMiddleware, controller.me);
router.put('/profile', authMiddleware, validate(updateProfileValidator), controller.updateProfile);
router.put('/change-password', authMiddleware, validate(changePasswordValidator), controller.changePassword);
router.post(
  '/profile/picture',
  authMiddleware,
  uploadAvatar.single('avatar'),
  controller.uploadProfilePicture
);

module.exports = router;
