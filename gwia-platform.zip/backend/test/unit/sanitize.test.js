const test = require('node:test');
const assert = require('node:assert/strict');
const { sanitizeRequest, normalizePagination, clean } = require('../../src/middleware/sanitize.middleware');

function run(mw, req) {
  let called = false;
  mw(req, {}, () => { called = true; });
  assert.ok(called, 'next() must be called');
  return req;
}

test('NoSQL injection: $-operator keys are stripped from body, query and params', () => {
  const req = run(sanitizeRequest, {
    body: { email: 'a@b.com', token: { $ne: null }, nested: { deep: { $gt: '' } } },
    query: { token: { $ne: '1' } },
    params: { id: 'x' }
  });
  assert.deepEqual(req.body.token, {});
  assert.deepEqual(req.body.nested.deep, {});
  assert.deepEqual(req.query.token, {});
  assert.equal(req.body.email, 'a@b.com');
});

test('dotted keys and prototype-pollution keys are dropped', () => {
  const polluted = JSON.parse('{"__proto__": {"admin": true}, "a.b": 1, "ok": 2, "constructor": {"x": 1}}');
  const out = clean(polluted);
  assert.deepEqual(Object.keys(out), ['ok']);
  assert.equal({}.admin, undefined);
});

test('arrays are cleaned element by element; primitives pass through', () => {
  assert.deepEqual(clean([{ $or: 1, a: 1 }, 'x', 3]), [{ a: 1 }, 'x', 3]);
  assert.equal(clean('plain'), 'plain');
  assert.equal(clean(7), 7);
});

test('pagination: limit is clamped to 100, garbage falls back to defaults', () => {
  const big = run(normalizePagination, { query: { limit: '1000000', page: '3' } });
  assert.equal(big.query.limit, '100');
  assert.equal(big.query.page, '3');
  const junk = run(normalizePagination, { query: { limit: '-5', page: 'abc' } });
  assert.equal(junk.query.limit, '20');
  assert.equal(junk.query.page, '1');
  const none = run(normalizePagination, { query: {} });
  assert.deepEqual(none.query, {});
});
