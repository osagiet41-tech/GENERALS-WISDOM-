#!/usr/bin/env node
/* Fails when the backend reads an environment variable that backend/.env.example does not document. */
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..', 'backend');

function* walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', 'test', 'uploads', 'logs', 'backups', 'storage'].includes(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) yield* walk(full); else if (e.name.endsWith('.js')) yield full;
  }
}
const used = new Set();
for (const f of walk(root)) for (const m of fs.readFileSync(f, 'utf8').matchAll(/process\.env\.([A-Z][A-Z0-9_]+)/g)) used.add(m[1]);
const documented = new Set([...fs.readFileSync(path.join(root, '.env.example'), 'utf8').matchAll(/^#?\s*([A-Z][A-Z0-9_]+)=/gm)].map((m) => m[1]));
const missing = [...used].filter((v) => !documented.has(v) && !['NODE_ENV'].includes(v)).sort();
const unused = [...documented].filter((v) => !used.has(v)).sort();
if (missing.length) { console.log(`Undocumented environment variables: ${missing.join(', ')}`); process.exit(1); }
console.log(`Env docs OK: ${used.size} variables used, all documented.${unused.length ? ` (documented but unused: ${unused.join(', ')})` : ''}`);
