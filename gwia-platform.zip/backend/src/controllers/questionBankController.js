const fs = require('fs');
const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const questionBankService = require('../services/questionBankService');
const { excelFileToJson } = require('../utils/excel.util');

// POST /api/courses/:courseId/question-bank
const createQuestion = asyncHandler(async (req, res) => {
  const question = await questionBankService.createQuestion(req.course._id, req.user.id, req.body);
  return ApiResponse.created(res, question, 'Question added to the bank successfully');
});

// GET /api/courses/:courseId/question-bank
const listQuestions = asyncHandler(async (req, res) => {
  const { tag, difficulty, type, page, limit } = req.query;
  const result = await questionBankService.listQuestions(req.course._id, { tag, difficulty, type, page, limit });
  return ApiResponse.ok(res, result.items, 'Questions retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

// PUT /api/question-bank/:id
const updateQuestion = asyncHandler(async (req, res) => {
  const question = await questionBankService.updateQuestion(req.resource, req.body);
  return ApiResponse.ok(res, question, 'Question updated successfully');
});

// DELETE /api/question-bank/:id
const deleteQuestion = asyncHandler(async (req, res) => {
  await questionBankService.deleteQuestion(req.resource);
  return ApiResponse.ok(res, null, 'Question deleted successfully');
});

// POST /api/courses/:courseId/question-bank/import
const bulkImport = asyncHandler(async (req, res) => {
  if (!req.file) throw ApiError.badRequest('No file uploaded');

  // The generic upload middleware accepts many document types; an import must be a spreadsheet or CSV.
  const IMPORT_TYPES = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel', 'text/plain'];
  let questions;
  try {
    if (!IMPORT_TYPES.includes(req.file.mimetype)) throw ApiError.badRequest('Import a spreadsheet (.xlsx, .xls) or CSV file');
    let rows;
    try { rows = excelFileToJson(req.file.path); } catch (err) { throw ApiError.badRequest('The file could not be read as a spreadsheet'); }
    questions = await questionBankService.bulkImportQuestions(req.course._id, req.user.id, rows);
  } finally {
    fs.unlink(req.file.path, () => {}); // the temp import file is removed whether parsing succeeded or not
  }

  return ApiResponse.created(res, { count: questions.length }, `${questions.length} questions imported successfully`);
});

module.exports = { createQuestion, listQuestions, updateQuestion, deleteQuestion, bulkImport };
