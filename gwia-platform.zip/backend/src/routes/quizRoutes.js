const express = require('express');
const controller = require('../controllers/quizController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership, verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { createAssessmentValidator, updateAssessmentValidator } = require('../validators/assessmentValidator');
const { Assessment } = require('../models/assessment.model');
const ApiError = require('../utils/ApiError');

// Ensures the loaded Assessment is actually a quiz, not an exam sharing the same id space.
function requireKindQuiz(req, res, next) {
  if (req.resource.kind !== 'quiz') return next(ApiError.notFound('Quiz not found'));
  next();
}

const nestedRouter = express.Router({ mergeParams: true });
nestedRouter.use(authMiddleware, requireTeacherOrAdmin);
nestedRouter.get('/', verifyCourseOwnership(), controller.listQuizzes);
nestedRouter.post('/', verifyCourseOwnership(), validate(createAssessmentValidator), controller.createQuiz);

const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);

itemRouter.get('/:id', verifyResourceOwnership(Assessment, 'id'), requireKindQuiz, controller.getQuiz);
itemRouter.put(
  '/:id',
  verifyResourceOwnership(Assessment, 'id'),
  requireKindQuiz,
  validate(updateAssessmentValidator),
  controller.updateQuiz
);
itemRouter.delete('/:id', verifyResourceOwnership(Assessment, 'id'), requireKindQuiz, controller.deleteQuiz);
itemRouter.get('/:id/results', verifyResourceOwnership(Assessment, 'id'), requireKindQuiz, controller.getResults);

module.exports = { nestedRouter, itemRouter };
