import { api } from '../core/http.js';
export const messagesApi = {
  conversations: () => api.get('/messages/conversations'),
  start: (recipientId, courseId) => api.post('/messages/conversations', { recipientId, ...(courseId && { courseId }) }),
  list: (id, q) => api.get(`/messages/conversations/${id}/messages`, q),
  send(id, text, files) { const fd = new FormData(); if (text) fd.append('text', text); [...(files || [])].forEach((f) => fd.append('files', f)); return api.post(`/messages/conversations/${id}/messages`, fd); },
  read: (id, messageIds) => api.put(`/messages/conversations/${id}/read`, messageIds ? { messageIds } : {}),
  remove: (messageId) => api.del(`/messages/${messageId}`),
  search: (q, conversationId) => api.get('/messages/search', { q, conversationId }),
  presence: () => api.get('/messages/presence')
};
