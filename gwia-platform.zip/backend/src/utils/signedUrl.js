const crypto = require('crypto');
const { safeEqual } = require('./security');

/** HMAC-signed, expiring, user-bound file URLs. Pure (no database, no env) so it is trivially unit-testable. */
function createSigner(getSecret) {
  const sign = (urlPath, userId, exp) =>
    crypto.createHmac('sha256', getSecret()).update(`${urlPath}|${userId}|${exp}`).digest('hex');

  return {
    sign,
    build(urlPath, userId, ttlSeconds, now = Date.now()) {
      const exp = Math.floor(now / 1000) + ttlSeconds;
      return `${urlPath}?u=${encodeURIComponent(userId)}&exp=${exp}&sig=${sign(urlPath, userId, exp)}`;
    },
    verify(urlPath, { u, exp, sig } = {}, now = Date.now()) {
      if (typeof u !== 'string' || typeof sig !== 'string' || !/^\d{9,12}$/.test(String(exp))) return false;
      if (Number(exp) * 1000 < now) return false;
      return safeEqual(sign(urlPath, u, exp), sig);
    }
  };
}

module.exports = { createSigner };
