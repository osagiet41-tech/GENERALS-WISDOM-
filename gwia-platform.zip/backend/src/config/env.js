const dotenv = require('dotenv');
dotenv.config();

const required = [
  'MONGODB_URI',
  'JWT_SECRET',
  'JWT_EXPIRES_IN',
  'EMAIL_HOST',
  'EMAIL_PORT',
  'EMAIL_USER',
  'EMAIL_PASSWORD',
  'CLIENT_URL'
];

const missing = required.filter((key) => !process.env[key]);

if (missing.length > 0) {
  // Fail fast on boot rather than surfacing obscure errors later.
  // eslint-disable-next-line no-console
  console.error(`Missing required environment variables: ${missing.join(', ')}`);
  process.exit(1);
}

// --- Secret strength checks (security audit) -------------------------------------------------
// A weak or reused JWT secret lets anyone forge tokens. In production these are fatal; in
// development/test they are warnings so local setup stays easy.
const isProd = (process.env.NODE_ENV || 'development') === 'production';
const PLACEHOLDER = /replace_with|changeme|change_me|secret_string|example|your_/i;
const secretProblems = [];
function checkSecret(name, value) {
  if (!value) return;
  if (value.length < 32) secretProblems.push(`${name} must be at least 32 characters`);
  if (PLACEHOLDER.test(value)) secretProblems.push(`${name} still contains a placeholder value`);
}
checkSecret('JWT_SECRET', process.env.JWT_SECRET);
if (isProd && !process.env.JWT_REFRESH_SECRET) secretProblems.push('JWT_REFRESH_SECRET is required in production');
if (process.env.JWT_REFRESH_SECRET) {
  checkSecret('JWT_REFRESH_SECRET', process.env.JWT_REFRESH_SECRET);
  if (process.env.JWT_REFRESH_SECRET === process.env.JWT_SECRET) {
    secretProblems.push('JWT_REFRESH_SECRET must be different from JWT_SECRET');
  }
}
if (secretProblems.length > 0) {
  const msg = `Insecure secret configuration: ${secretProblems.join('; ')}. Generate with: node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`;
  if (isProd) {
    // eslint-disable-next-line no-console
    console.error(msg);
    process.exit(1);
  } else {
    // eslint-disable-next-line no-console
    console.warn(`WARNING (fatal in production): ${msg}`);
  }
}

const csv = (v) => (v || '').split(',').map((s) => s.trim().replace(/\/$/, '')).filter(Boolean);

module.exports = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT, 10) || 5000,

  mongodbUri: process.env.MONGODB_URI,

  jwtSecret: process.env.JWT_SECRET,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN,
  // No silent fallback in production (enforced above). In development a derived key keeps the two secrets distinct.
  jwtRefreshSecret: process.env.JWT_REFRESH_SECRET || require('crypto').createHash('sha256').update(`refresh:${process.env.JWT_SECRET}`).digest('hex'),
  jwtRefreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',

  email: {
    host: process.env.EMAIL_HOST,
    port: parseInt(process.env.EMAIL_PORT, 10) || 587,
    user: process.env.EMAIL_USER,
    password: process.env.EMAIL_PASSWORD,
    from: process.env.EMAIL_FROM || process.env.EMAIL_USER
  },

  clientUrl: process.env.CLIENT_URL,

  // Browser origins allowed by CORS and Socket.IO. CLIENT_URL is always included. Add the Capacitor
  // Android origin (https://localhost) when you ship the APK, e.g. CORS_ORIGINS=https://localhost
  corsOrigins: Array.from(new Set([process.env.CLIENT_URL.replace(/\/$/, ''), ...csv(process.env.CORS_ORIGINS)])),

  // Set to the number of reverse proxies in front of Node (1 for Nginx/Render/Railway/Heroku).
  // Without it every client appears to have the proxy's IP and rate limits break.
  trustProxy: process.env.TRUST_PROXY === undefined || process.env.TRUST_PROXY === '' ? false : (Number.isNaN(Number(process.env.TRUST_PROXY)) ? process.env.TRUST_PROXY : Number(process.env.TRUST_PROXY)),

  security: {
    // Public sign-up can only ever create students unless you explicitly allow teacher self-registration.
    allowTeacherSelfRegistration: process.env.ALLOW_TEACHER_SELF_REGISTRATION === 'true',
    bcryptRounds: Math.min(Math.max(parseInt(process.env.BCRYPT_ROUNDS, 10) || 12, 10), 15),
    // HMAC key for short-lived signed file URLs. Falls back to a key derived from JWT_SECRET.
    fileUrlSecret: process.env.FILE_URL_SECRET || null,
    fileUrlTtlSeconds: parseInt(process.env.FILE_URL_TTL_SECONDS, 10) || 7200,
    jsonLimit: process.env.JSON_BODY_LIMIT || '1mb',
    uploadRateLimitMax: parseInt(process.env.UPLOAD_RATE_LIMIT_MAX, 10) || 120,
    loginRateLimitMax: parseInt(process.env.LOGIN_RATE_LIMIT_MAX, 10) || 10
  },

  // Where the links in verification / reset emails point (relative to CLIENT_URL). The token is appended
  // as &token=... . Defaults match the bundled frontend (auth.html).
  emailLinks: {
    verifyPath: process.env.EMAIL_VERIFY_PATH || '/auth.html?mode=verify-email',
    resetPath: process.env.EMAIL_RESET_PATH || '/auth.html?mode=reset'
  },

  // Web Push (optional). Generate keys with: npx web-push generate-vapid-keys
  push: {
    publicKey: process.env.VAPID_PUBLIC_KEY || null,
    privateKey: process.env.VAPID_PRIVATE_KEY || null,
    subject: process.env.VAPID_SUBJECT || `mailto:${process.env.EMAIL_FROM || process.env.EMAIL_USER}`,
    // Native Android push (Firebase Cloud Messaging). Path to a Firebase service-account JSON; needs `npm i firebase-admin`.
    fcmServiceAccountFile: process.env.FCM_SERVICE_ACCOUNT_FILE || null
  },

  certificates: {
    institutionName: process.env.CERTIFICATE_INSTITUTION_NAME || process.env.BUSINESS_NAME || 'Online Learning Platform',
    // Base of the public verification page printed on every certificate (the certificate ID is appended).
    // Default assumes your frontend has a /verify/:id page; the API also serves a plain HTML page at /verify/:id.
    // Default matches the bundled frontend page (verify.html reads ?id=). A base ending in '?id=' gets the ID appended;
    // any other base gets '/<id>' appended (e.g. the API's own page: https://api.example.com/verify).
    verifyBaseUrl: (process.env.CERTIFICATE_VERIFY_BASE_URL || `${process.env.CLIENT_URL.replace(/\/$/, '')}/verify.html?id=`).replace(/\/$/, ''),
    // Optional institution-level signatory printed alongside the instructor's signature.
    signatory: {
      name: process.env.CERTIFICATE_SIGNATORY_NAME || '',
      title: process.env.CERTIFICATE_SIGNATORY_TITLE || '',
      // File name inside storage/signatures/ (PNG or JPEG)
      imageFile: process.env.CERTIFICATE_SIGNATORY_IMAGE || ''
    }
  },

  // Payments & subscriptions — intentionally NOT in required[]: the app boots
  // without gateways configured; only checkout for a gateway without keys fails
  // (with a clear 503). Webhook endpoints reject everything until the matching
  // secret is set.
  payments: {
    // Kill switch for staged rollout. When 'false', paid-course / subscription
    // gating is not enforced on student routes (checkout still works).
    enforceAccess: process.env.PAYMENTS_ENFORCE_ACCESS !== 'false',
    defaultCurrency: (process.env.PAYMENT_DEFAULT_CURRENCY || 'NGN').toUpperCase(),
    // Frontend page the gateway redirects the browser to after payment. That page
    // must call POST /api/billing/payments/:reference/verify — the redirect itself proves nothing.
    callbackPath: process.env.PAYMENT_CALLBACK_PATH || '/payment-callback.html', // the bundled frontend page
    pendingExpiryHours: parseInt(process.env.PAYMENT_PENDING_EXPIRY_HOURS, 10) || 24,
    httpTimeoutMs: parseInt(process.env.PAYMENT_HTTP_TIMEOUT_MS, 10) || 20000,
    // 'NGN:paystack,USD:flutterwave' — which gateway handles which currency by default.
    providerByCurrency: (process.env.PAYMENT_PROVIDER_BY_CURRENCY || 'NGN:paystack')
      .split(',')
      .map((p) => p.trim().split(':'))
      .filter((p) => p.length === 2 && p[0] && p[1])
      .reduce((acc, [cur, prov]) => ({ ...acc, [cur.toUpperCase()]: prov.toLowerCase() }), {}),
    defaultProvider: (process.env.PAYMENT_DEFAULT_PROVIDER || 'flutterwave').toLowerCase(),
    business: {
      name: process.env.BUSINESS_NAME || 'Online Learning Platform',
      address: process.env.BUSINESS_ADDRESS || '',
      email: process.env.BUSINESS_EMAIL || process.env.EMAIL_FROM || process.env.EMAIL_USER,
      phone: process.env.BUSINESS_PHONE || '',
      taxId: process.env.BUSINESS_TAX_ID || ''
    },
    paystack: {
      secretKey: process.env.PAYSTACK_SECRET_KEY || null,
      baseUrl: process.env.PAYSTACK_BASE_URL || 'https://api.paystack.co',
      currencies: (process.env.PAYSTACK_CURRENCIES || 'NGN,GHS,ZAR,KES,USD').split(',').map((c) => c.trim().toUpperCase())
    },
    flutterwave: {
      secretKey: process.env.FLUTTERWAVE_SECRET_KEY || null,
      // The "secret hash" you configure in the Flutterwave dashboard webhook settings.
      secretHash: process.env.FLUTTERWAVE_SECRET_HASH || null,
      baseUrl: process.env.FLUTTERWAVE_BASE_URL || 'https://api.flutterwave.com/v3',
      currencies: (process.env.FLUTTERWAVE_CURRENCIES || 'NGN,USD,GBP,EUR,GHS,KES,ZAR')
        .split(',')
        .map((c) => c.trim().toUpperCase())
    }
  },

  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000,
    max: parseInt(process.env.RATE_LIMIT_MAX, 10) || 200
  },

  // AI teaching assistant — intentionally NOT in the required[] list above.
  // The rest of the app must boot and run fine without AI configured; only
  // the AI endpoints themselves fail (with a clear error) if the key is
  // missing at call time. This is checked in aiService, not here.
  ai: {
    apiKey: process.env.AI_API_KEY || null,
    apiUrl: process.env.AI_API_URL || 'https://api.anthropic.com/v1/messages',
    model: process.env.AI_MODEL || 'claude-sonnet-4-5',
    apiVersion: process.env.AI_API_VERSION || '2023-06-01',
    maxTokens: parseInt(process.env.AI_MAX_TOKENS, 10) || 2000,
    timeoutMs: parseInt(process.env.AI_TIMEOUT_MS, 10) || 30000,
    dailyQuota: parseInt(process.env.AI_DAILY_QUOTA, 10) || 50,
    rateLimit: {
      windowMs: parseInt(process.env.AI_RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000,
      max: parseInt(process.env.AI_RATE_LIMIT_MAX, 10) || 20
    }
  }
};
