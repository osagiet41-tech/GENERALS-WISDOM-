const test = require('node:test');
const assert = require('node:assert/strict');

let jwt = null;
try { jwt = require('jsonwebtoken'); require('dotenv'); } catch (e) { /* run `npm install` first */ }
const skip = jwt ? false : 'jsonwebtoken/dotenv not installed (run npm install)';

Object.assign(process.env, {
  NODE_ENV: 'test', MONGODB_URI: 'mongodb://x/x', JWT_EXPIRES_IN: '15m', EMAIL_HOST: 'x', EMAIL_PORT: '587', EMAIL_USER: 'x', EMAIL_PASSWORD: 'x',
  CLIENT_URL: 'http://localhost:3000', JWT_SECRET: 'unit-access-secret-0123456789-0123456789-abc', JWT_REFRESH_SECRET: 'unit-refresh-secret-0123456789-0123456789-xy'
});
const load = () => require('../../src/utils/tokens');
const user = { _id: { toString: () => '64b7f0f0f0f0f0f0f0f0f0f0' }, role: 'student' };

test('access token verifies as access', { skip }, () => {
  const t = load();
  const payload = t.verifyAccessToken(t.signAccessToken(user));
  assert.equal(payload.sub, '64b7f0f0f0f0f0f0f0f0f0f0');
  assert.equal(payload.type, 'access');
});

test('a refresh token is rejected as an access token, and vice versa', { skip }, () => {
  const t = load();
  assert.throws(() => t.verifyAccessToken(t.signRefreshToken(user)));
  assert.throws(() => t.verifyRefreshToken(t.signAccessToken(user)));
});

test('a classroom token is rejected as an access token', { skip }, () => {
  const t = load();
  const classroom = t.sign(t.TYPES.CLASSROOM, { liveClassId: 'x', userId: 'y', role: 'student' }, 600);
  assert.throws(() => t.verifyAccessToken(classroom));
});

test('alg:none and HS512-with-wrong-algorithm tokens are rejected (algorithm is pinned)', { skip }, () => {
  const t = load();
  const none = `${Buffer.from('{"alg":"none","typ":"JWT"}').toString('base64url')}.${Buffer.from(JSON.stringify({ sub: 'x', type: 'access' })).toString('base64url')}.`;
  assert.throws(() => t.verifyAccessToken(none));
  const hs512 = jwt.sign({ sub: 'x', type: 'access' }, process.env.JWT_SECRET, { algorithm: 'HS512', issuer: 'gwia-api', audience: 'access' });
  assert.throws(() => t.verifyAccessToken(hs512));
});

test('tokens signed with another secret, expired tokens and non-strings are rejected', { skip }, () => {
  const t = load();
  const forged = jwt.sign({ sub: 'x', type: 'access' }, 'attacker-secret-attacker-secret-attacker', { algorithm: 'HS256', issuer: 'gwia-api', audience: 'access' });
  assert.throws(() => t.verifyAccessToken(forged));
  const expired = jwt.sign({ sub: 'x', type: 'access' }, process.env.JWT_SECRET, { algorithm: 'HS256', issuer: 'gwia-api', audience: 'access', expiresIn: -10 });
  assert.throws(() => t.verifyAccessToken(expired));
  for (const bad of [undefined, null, 123, {}, '', 'x'.repeat(5000)]) assert.throws(() => t.verifyAccessToken(bad));
});

test('every signed token has a unique jti', { skip }, () => {
  const t = load();
  const a = jwt.decode(t.signRefreshToken(user)).jti;
  const b = jwt.decode(t.signRefreshToken(user)).jti;
  assert.notEqual(a, b);
});
