#!/usr/bin/env node
/* Idempotently patches the generated android/ project (run automatically by `npm run cap:add` and `npm run cap:sync`):
 *  - adds the permissions live classes, uploads and notifications need
 *  - forbids cleartext (http) traffic and disables app backups of local data
 *  - declares camera / microphone as optional hardware so devices without them can still install */
const fs = require('fs');
const path = require('path');

const manifestPath = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) { console.log('android/ not found yet: run `npm run cap:add` first.'); process.exit(0); }

let xml = fs.readFileSync(manifestPath, 'utf8');
const permissions = ['INTERNET', 'ACCESS_NETWORK_STATE', 'CAMERA', 'RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS', 'POST_NOTIFICATIONS', 'VIBRATE'];
const features = ['android.hardware.camera', 'android.hardware.microphone'];
let changed = false;

for (const p of permissions) {
  const tag = `<uses-permission android:name="android.permission.${p}" />`;
  if (!xml.includes(`android.permission.${p}"`)) { xml = xml.replace('</manifest>', `    ${tag}\n</manifest>`); changed = true; }
}
for (const f of features) {
  if (!xml.includes(`"${f}"`)) { xml = xml.replace('</manifest>', `    <uses-feature android:name="${f}" android:required="false" />\n</manifest>`); changed = true; }
}
const app = /<application\b[^>]*>/.exec(xml)[0];
let newApp = app;
if (!/usesCleartextTraffic=/.test(newApp)) newApp = newApp.replace('<application', '<application android:usesCleartextTraffic="false"');
if (!/allowBackup=/.test(newApp)) newApp = newApp.replace('<application', '<application android:allowBackup="false"');
else newApp = newApp.replace(/android:allowBackup="true"/, 'android:allowBackup="false"');
if (newApp !== app) { xml = xml.replace(app, newApp); changed = true; }

if (changed) { fs.writeFileSync(manifestPath, xml); console.log('AndroidManifest.xml patched (permissions, cleartext off, backups off).'); }
else console.log('AndroidManifest.xml already configured.');
