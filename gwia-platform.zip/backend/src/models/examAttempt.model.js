const mongoose = require('mongoose');
const { Schema } = mongoose;

// The question set actually presented for THIS attempt — fixed at start time so a
// reload/resume shows the exact same questions and option order throughout, even
// if the assessment uses random question selection and/or shuffled options.
const presentedQuestionSchema = new Schema(
  {
    questionId: { type: Schema.Types.ObjectId, ref: 'Question', required: true },
    marks: { type: Number, required: true },
    // Only populated for MCQ questions when the assessment has shuffleOptions on;
    // stores the option TEXTS in the order to display them. Grading compares the
    // student's selected text against Question.correctAnswer, so display order
    // never affects correctness.
    shuffledOptions: { type: [String], default: undefined }
  },
  { _id: false }
);

const draftAnswerSchema = new Schema(
  {
    questionId: { type: Schema.Types.ObjectId, ref: 'Question', required: true },
    response: { type: Schema.Types.Mixed, default: null },
    markedForReview: { type: Boolean, default: false },
    visited: { type: Boolean, default: false }
  },
  { _id: false }
);

const examAttemptSchema = new Schema(
  {
    assessmentId: { type: Schema.Types.ObjectId, ref: 'Assessment', required: true, index: true },
    studentId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    attemptNumber: { type: Number, required: true },

    questionOrder: { type: [presentedQuestionSchema], default: [] },
    answers: { type: [draftAnswerSchema], default: [] },

    startedAt: { type: Date, required: true, default: Date.now },
    // Absolute deadline for this attempt = min(startedAt + durationMinutes, assessment.availableUntil),
    // computed once at start so it survives page reloads / navigating away and back.
    expiresAt: { type: Date, required: true },

    status: {
      type: String,
      enum: ['in_progress', 'submitted', 'expired'],
      default: 'in_progress',
      index: true
    },

    submissionId: { type: Schema.Types.ObjectId, ref: 'Submission', default: null },
    lastSavedAt: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

// A student may have at most one in_progress attempt per assessment at a time —
// enforced in examAttemptService, not as a unique index, since past (submitted/
// expired) attempts for the same assessment+student must remain queryable for history.
examAttemptSchema.index({ assessmentId: 1, studentId: 1, status: 1 });

module.exports = mongoose.model('ExamAttempt', examAttemptSchema);
