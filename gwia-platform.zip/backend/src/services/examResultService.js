const Submission = require('../models/submission.model');
const ApiError = require('../utils/ApiError');

function buildResult(submission, assessment) {
  const isGraded = submission.status === 'graded';
  const percentage =
    isGraded && submission.grade.totalMarks > 0
      ? Math.round((submission.grade.score / submission.grade.totalMarks) * 10000) / 100
      : null;

  return {
    submissionId: submission._id,
    assessmentId: assessment._id,
    kind: assessment.kind,
    title: assessment.title,
    attemptNumber: submission.attemptNumber,
    submittedAt: submission.submittedAt,
    status: submission.status,
    score: isGraded ? submission.grade.score : null,
    totalMarks: isGraded ? submission.grade.totalMarks : null,
    percentage,
    passed: isGraded && assessment.passingMarks !== undefined ? submission.grade.score >= assessment.passingMarks : null,
    passingMarks: assessment.passingMarks,
    feedback: submission.grade ? submission.grade.feedback : null,
    gradedBy: submission.grade ? submission.grade.gradedBy : null,
    gradedAt: submission.grade ? submission.grade.gradedAt : null,
    questionBreakdown: submission.answers.map((a) => ({
      questionId: a.questionId,
      marksAwarded: a.marksAwarded
    }))
  };
}

async function getResult(assessment, studentId, submissionId) {
  const submission = await Submission.findOne({
    _id: submissionId,
    refType: assessment.kind,
    refId: assessment._id,
    studentId
  });
  if (!submission) {
    throw ApiError.notFound('Result not found');
  }
  return buildResult(submission, assessment);
}

async function getHistory(assessment, studentId) {
  const submissions = await Submission.find({
    refType: assessment.kind,
    refId: assessment._id,
    studentId
  }).sort({ attemptNumber: 1 });

  return submissions.map((s) => buildResult(s, assessment));
}

async function getAllResultsForAssessment(assessment) {
  const submissions = await Submission.find({ refType: assessment.kind, refId: assessment._id })
    .populate('studentId', 'name email')
    .sort({ studentId: 1, attemptNumber: 1 });

  return submissions.map((s) => ({ student: s.studentId, ...buildResult(s, assessment) }));
}

module.exports = { buildResult, getResult, getHistory, getAllResultsForAssessment };
