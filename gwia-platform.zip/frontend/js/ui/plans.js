import { h } from '../core/dom.js';
import { fmtMoney, cap } from '../core/format.js';
import { config } from '../core/config.js';
export const planCurrencies = (plans) => [...new Set(plans.flatMap((p) => (p.prices || []).map((x) => x.currency)))];
export const priceFor = (plan, currency) => (plan.prices || []).find((p) => p.currency === currency);
/* planCard(plan, { currency, cta: { label, onClick }, featured }) */
export function planCard(plan, { currency, cta, featured } = {}) {
  const price = priceFor(plan, currency);
  return h('article', { class: `card plan ${featured ? 'featured' : ''}` }, h('h3', null, plan.name), plan.description && h('p', { class: 'muted small' }, plan.description),
    h('div', { class: 'price' }, price ? fmtMoney(price.amountMinor, currency, { minor: true }) : '—', h('span', { class: 'small muted' }, ` / ${plan.billingCycle === 'annual' ? 'year' : 'month'}`)),
    plan.trialDays > 0 && h('span', { class: 'badge info' }, `${plan.trialDays}-day free trial`),
    h('ul', { class: 'small', style: 'padding-left:18px;margin:0' }, (plan.features || []).map((f) => h('li', null, f))),
    cta && h('button', { class: 'btn', type: 'button', disabled: !price, onclick: cta.onClick }, price ? cta.label : `Not offered in ${currency}`));
}
export function currencySelect(currencies, value, onChange) {
  const sel = h('select', { class: 'input', 'aria-label': 'Currency', style: 'width:auto', onchange: () => onChange(sel.value) }, currencies.map((c) => h('option', { value: c, selected: c === value }, c)));
  return sel;
}
export const defaultCurrency = (currencies) => (currencies.includes(config.defaultCurrency) ? config.defaultCurrency : currencies[0]);
export { cap };
