const PDFDocument = require('pdfkit');
const env = require('../config/env');
const { Counter, Payment } = require('../models/billing.model');
const User = require('../models/User');
const { sendEmail } = require('../utils/email.util');
const { formatMoney, fromMinor } = require('../utils/money');
const { escapeHtml } = require('../utils/security');
const logger = require('../utils/logger');

/** Atomic, per-month sequential number. A crash can skip a number but can never repeat one. */
async function nextReceiptNumber(now = new Date()) {
  const ym = `${now.getUTCFullYear()}${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
  const counter = await Counter.findOneAndUpdate({ _id: `receipt-${ym}` }, { $inc: { seq: 1 } }, { upsert: true, new: true });
  return `RCT-${ym}-${String(counter.seq).padStart(6, '0')}`;
}

/** Assigns a receipt number once. Concurrent callers: exactly one wins, the rest read the winner's. */
async function ensureReceipt(paymentId) {
  const existing = await Payment.findById(paymentId).select('receiptNumber receiptIssuedAt');
  if (existing?.receiptNumber) return existing;
  const number = await nextReceiptNumber();
  const won = await Payment.findOneAndUpdate(
    { _id: paymentId, receiptNumber: null },
    { $set: { receiptNumber: number, receiptIssuedAt: new Date() } },
    { new: true }
  );
  return won || Payment.findById(paymentId).select('receiptNumber receiptIssuedAt');
}

/** JSON receipt (also what the PDF is rendered from). Amounts come from the stored snapshot. */
function buildReceipt(payment, user) {
  const cur = payment.currency;
  const original = payment.originalAmountMinor ?? payment.amountMinor ?? 0;
  const discount = payment.discountAmountMinor || 0;
  const total = payment.amountMinor ?? 0;
  return {
    receiptNumber: payment.receiptNumber,
    issuedAt: payment.receiptIssuedAt || payment.paidAt,
    status: payment.status,
    business: env.payments.business,
    customer: { name: user?.name || '', email: payment.customerEmail || user?.email || '' },
    description: payment.description || 'Payment',
    currency: cur,
    lineItems: [{ description: payment.description || 'Payment', amount: formatMoney(original, cur) }],
    discount: discount ? { code: payment.discountCode, amount: `- ${formatMoney(discount, cur)}` } : null,
    total: formatMoney(total, cur),
    totalMajor: fromMinor(total, cur),
    paymentMethod: payment.provider === 'free' ? 'No charge' : `${payment.provider}${payment.channel ? ` (${payment.channel})` : ''}`,
    transactionReference: payment.reference,
    paidAt: payment.paidAt
  };
}

/** Renders the receipt to a PDF Buffer. Uses currency CODES (not symbols): the built-in PDF fonts lack ₦. */
function renderReceiptPdf(receipt) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 50 });
    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const b = receipt.business;
    doc.fontSize(20).text(b.name, { align: 'left' });
    doc.fontSize(9).fillColor('#555');
    [b.address, b.email, b.phone, b.taxId ? `Tax ID: ${b.taxId}` : ''].filter(Boolean).forEach((l) => doc.text(l));
    doc.moveDown(1.5).fillColor('#000').fontSize(16).text('PAYMENT RECEIPT');
    if (receipt.status === 'refunded') doc.fontSize(12).fillColor('#b00020').text('REFUNDED').fillColor('#000');

    doc.moveDown(0.5).fontSize(10);
    doc.text(`Receipt no: ${receipt.receiptNumber}`);
    doc.text(`Date: ${receipt.paidAt ? new Date(receipt.paidAt).toUTCString() : '-'}`);
    doc.text(`Reference: ${receipt.transactionReference}`);
    doc.text(`Payment method: ${receipt.paymentMethod}`);
    doc.moveDown().text('Billed to', { underline: true });
    doc.text(receipt.customer.name);
    doc.text(receipt.customer.email);

    doc.moveDown(1.5);
    const y = doc.y;
    doc.text('Description', 50, y).text('Amount', 400, y, { width: 145, align: 'right' });
    doc.moveTo(50, y + 14).lineTo(545, y + 14).stroke();
    let rowY = y + 22;
    receipt.lineItems.forEach((li) => {
      doc.text(li.description, 50, rowY, { width: 340 }).text(li.amount, 400, rowY, { width: 145, align: 'right' });
      rowY += 20;
    });
    if (receipt.discount) {
      doc.text(`Discount (${receipt.discount.code})`, 50, rowY).text(receipt.discount.amount, 400, rowY, { width: 145, align: 'right' });
      rowY += 20;
    }
    doc.moveTo(50, rowY).lineTo(545, rowY).stroke();
    doc.fontSize(12).text('Total paid', 50, rowY + 8).text(receipt.total, 400, rowY + 8, { width: 145, align: 'right' });
    doc.fontSize(8).fillColor('#777').text('Thank you for your payment. This receipt was generated electronically.', 50, 760, { align: 'center' });
    doc.end();
  });
}

/** Emails the receipt once. Failure never affects fulfilment; the flag lets a later retry skip sent ones. */
async function emailReceipt(paymentId) {
  const payment = await Payment.findById(paymentId);
  if (!payment || payment.receiptEmailedAt || !payment.receiptNumber) return false;
  const user = await User.findById(payment.userId);
  const to = payment.customerEmail || user?.email;
  if (!to) return false;

  const receipt = buildReceipt(payment, user);
  const pdf = await renderReceiptPdf(receipt);
  const claimed = await Payment.findOneAndUpdate(
    { _id: paymentId, receiptEmailedAt: null },
    { $set: { receiptEmailedAt: new Date() } }
  );
  if (!claimed) return false; // another worker is sending it

  try {
    await sendEmail({
      to,
      subject: `Your receipt ${receipt.receiptNumber} from ${receipt.business.name}`,
      text: `Thank you for your payment of ${receipt.total}. Your receipt ${receipt.receiptNumber} is attached.`,
      html: `<p>Hi ${escapeHtml(user?.name || '')},</p><p>Thank you for your payment of <strong>${escapeHtml(receipt.total)}</strong> for <em>${escapeHtml(receipt.description)}</em>.</p><p>Your receipt <strong>${escapeHtml(receipt.receiptNumber)}</strong> is attached.</p>`,
      attachments: [{ filename: `${receipt.receiptNumber}.pdf`, content: pdf, contentType: 'application/pdf' }]
    });
    return true;
  } catch (err) {
    logger.error(`Receipt email failed for payment ${paymentId}: ${err.message}`);
    await Payment.updateOne({ _id: paymentId }, { $set: { receiptEmailedAt: null } }); // allow a later retry
    return false;
  }
}

module.exports = { ensureReceipt, buildReceipt, renderReceiptPdf, emailReceipt };
