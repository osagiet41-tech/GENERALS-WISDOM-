const { Course, Subject } = require('../models/course.model');
const ApiError = require('../utils/ApiError');
const { escapeRegex } = require('../utils/security');

async function listCourses({ status, category, search, page = 1, limit = 20 } = {}) {
  const filter = {};
  if (status) filter.status = status;
  if (category) filter.category = category;
  if (search) filter.title = new RegExp(escapeRegex(String(search).slice(0, 100)), 'i');

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    Course.find(filter)
      .populate('teacherIds', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    Course.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function getCourseDetail(courseId) {
  const course = await Course.findById(courseId).populate('teacherIds', 'name email');
  if (!course) {
    throw ApiError.notFound('Course not found');
  }
  const subjects = await Subject.find({ courseId }).sort({ order: 1 });
  return { course, subjects };
}

async function updateCourseStatus(courseId, status) {
  const course = await Course.findById(courseId);
  if (!course) {
    throw ApiError.notFound('Course not found');
  }
  course.status = status;
  await course.save();
  return course;
}

async function listSubjects({ courseId, page = 1, limit = 50 } = {}) {
  const filter = {};
  if (courseId) filter.courseId = courseId;

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    Subject.find(filter).populate('courseId', 'title').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Subject.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

module.exports = { listCourses, getCourseDetail, updateCourseStatus, listSubjects };
