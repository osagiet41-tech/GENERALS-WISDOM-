/**
 * Tiny per-socket token bucket. Socket.IO events bypass express-rate-limit entirely, so without this a single
 * connected client could flood chat, typing or signalling events.
 *   const allow = createLimiter({ capacity: 20, refillPerSec: 5 });
 *   if (!allow(socket.id, 'message:send')) return ack?.({ error: 'Too many requests' });
 */
function createLimiter({ capacity = 20, refillPerSec = 5 } = {}) {
  const buckets = new Map();
  return function allow(key, event = '') {
    const k = `${key}|${event}`;
    const now = Date.now();
    let b = buckets.get(k);
    if (!b) {
      b = { tokens: capacity, last: now };
      buckets.set(k, b);
    }
    b.tokens = Math.min(capacity, b.tokens + ((now - b.last) / 1000) * refillPerSec);
    b.last = now;
    if (b.tokens < 1) return false;
    b.tokens -= 1;
    return true;
  };
}

/** Frees a socket's buckets on disconnect. */
function forget(limiter, key) {
  if (limiter.reset) limiter.reset(key);
}

const isObjectId = (v) => typeof v === 'string' && /^[a-f\d]{24}$/i.test(v);

module.exports = { createLimiter, forget, isObjectId };
