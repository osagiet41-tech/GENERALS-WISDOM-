const mongoose = require('mongoose');
const env = require('../config/env');
const Certificate = require('../models/certificate.model');
const { Course } = require('../models/course.model');
const User = require('../models/User');
const Progress = require('../models/progress.model');
const Lesson = require('../models/lesson.model');
const Submission = require('../models/submission.model');
const Attendance = require('../models/attendance.model');
const Assignment = require('../models/assignment.model');
const { Assessment } = require('../models/assessment.model');
const ApiError = require('../utils/ApiError');
const logger = require('../utils/logger');
const { sendEmail } = require('../utils/email.util');
const { generateCertificateId, normalizeCertificateId, isLegacyCode } = require('../utils/certificateId');
const notificationService = require('./notificationService');
const { resolveRequirements, evaluateEligibility } = require('./certificates/eligibility');
const signatureStore = require('./certificates/signatureStore');
const { buildQr } = require('./certificates/qr');
const { renderToBuffer } = require('./certificates/renderer');

/* ------------------------------------------------------------------ */
/* Gathering the facts                                                 */
/* ------------------------------------------------------------------ */

async function gatherStats(studentId, courseId) {
  const [lessons, progress, assessments, assignments, submissions, attendanceDocs] = await Promise.all([
    Lesson.find({ courseId, status: 'published' }).select('_id').lean(),
    Progress.findOne({ studentId, courseId }).select('completedLessonIds').lean(),
    Assessment.find({ courseId, status: { $in: ['published', 'closed'] } }).select('_id').lean(),
    Assignment.find({ courseId, status: { $in: ['published', 'closed'] } }).select('_id').lean(),
    Submission.find({ studentId, courseId, status: 'graded' }).select('refId grade').lean(),
    // $elemMatch returns only THIS student's row from each session document
    Attendance.find({ courseId, 'records.studentId': studentId }).select({ records: { $elemMatch: { studentId } } }).lean()
  ]);

  // Count only lessons that are still published (a completed-then-unpublished lesson must not inflate progress).
  const publishedIds = new Set(lessons.map((l) => l._id.toString()));
  const completed = new Set((progress?.completedLessonIds || []).map(String).filter((id) => publishedIds.has(id)));

  // Per assignment/quiz/exam: the student's BEST graded attempt (retakes are allowed).
  const requiredIds = new Set([...assessments, ...assignments].map((a) => a._id.toString()));
  const best = new Map();
  for (const s of submissions) {
    const key = String(s.refId);
    if (!requiredIds.has(key) || !s.grade || !(s.grade.totalMarks > 0)) continue;
    const pct = (s.grade.score / s.grade.totalMarks) * 100;
    if (!best.has(key) || pct > best.get(key)) best.set(key, pct);
  }
  const percents = [...best.values()];
  const averagePercent = percents.length ? Math.round(percents.reduce((a, b) => a + b, 0) / percents.length) : null;

  let counted = 0;
  let present = 0;
  for (const doc of attendanceDocs) {
    const rec = doc.records && doc.records[0];
    if (!rec || rec.status === 'excused') continue; // excused sessions don't count against the student
    counted += 1;
    if (rec.status === 'present' || rec.status === 'late') present += 1;
  }

  return {
    lessons: { completed: completed.size, total: publishedIds.size },
    assessments: { total: requiredIds.size, graded: best.size, averagePercent },
    attendance: { counted, present }
  };
}

async function evaluate(studentId, course) {
  const plain = typeof course.toObject === 'function' ? course.toObject() : course;
  const requirements = resolveRequirements(plain.certificate || {});
  const stats = await gatherStats(studentId, course._id);
  return { requirements, stats, ...evaluateEligibility(requirements, stats) };
}

/* ------------------------------------------------------------------ */
/* Issuing                                                             */
/* ------------------------------------------------------------------ */

async function loadInstructors(course) {
  const users = await User.find({ _id: { $in: course.teacherIds } }).select('name profile.signatureFile');
  const byId = new Map(users.map((u) => [u._id.toString(), u]));
  return course.teacherIds
    .map((id) => byId.get(id.toString()))
    .filter(Boolean)
    .map((u) => ({ name: u.name, signatureFile: u.profile?.signatureFile || null }));
}

function institutionSnapshot() {
  const s = env.certificates.signatory;
  return {
    institutionName: env.certificates.institutionName,
    signatory: s.name ? { name: s.name, title: s.title || null, signatureFile: s.imageFile || null } : { name: null, title: null, signatureFile: null }
  };
}

async function createCertificateRecord({ course, student, evaluation }) {
  const now = new Date();
  const instructors = await loadInstructors(course);
  const snapshot = {
    studentName: student.name,
    courseTitle: course.title,
    ...institutionSnapshot(),
    instructors,
    finalScorePercent: evaluation.finalScorePercent,
    showScore: Boolean(evaluation.requirements.showScore)
  };

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const certificateId = generateCertificateId();
    try {
      const certificate = await Certificate.create({
        studentId: student._id,
        courseId: course._id,
        certificateId,
        verificationCode: certificateId,
        title: `Certificate of Completion - ${course.title}`,
        issuedAt: now,
        completionDate: now,
        snapshot,
        requirementsMet: evaluation.checks
      });
      return { certificate, created: true };
    } catch (err) {
      if (err.code !== 11000) throw err;
      // Either another request just issued this student's certificate (fine: return it) or the random ID
      // collided (retry with a new one).
      const existing = await Certificate.findOne({ studentId: student._id, courseId: course._id });
      if (existing) return { certificate: existing, created: false };
    }
  }
  throw new Error('Could not allocate a unique certificate ID');
}

/**
 * Checks the requirements and, if met, issues the certificate (once, ever: unique index per student+course).
 * Never throws for "not eligible": that is a normal answer. Returns { certificate, issued, evaluation }.
 */
async function evaluateAndIssue(studentId, courseId) {
  const existing = await Certificate.findOne({ studentId, courseId });
  if (existing) return { certificate: existing, issued: false, evaluation: null };

  const [course, student] = await Promise.all([Course.findById(courseId), User.findById(studentId)]);
  if (!course || !student || student.role !== 'student') return { certificate: null, issued: false, evaluation: null };
  if (!course.enrolledStudentIds.some((id) => id.toString() === studentId.toString())) {
    return { certificate: null, issued: false, evaluation: null };
  }

  const evaluation = await evaluate(studentId, course);
  if (!evaluation.eligible) return { certificate: null, issued: false, evaluation };

  const { certificate, created } = await createCertificateRecord({ course, student, evaluation });
  if (created) afterIssue(certificate, course, student).catch((e) => logger.error(`Post-issue tasks failed for ${certificate._id}: ${e.message}`));
  return { certificate, issued: created, evaluation };
}

/** Student-triggered issuance (kept for the existing endpoint). Explains exactly what is still missing. */
async function issueCertificateIfEligible(studentId, courseId) {
  const result = await evaluateAndIssue(studentId, courseId);
  if (result.certificate) return result.certificate;
  const ev = result.evaluation;
  if (ev && !ev.enabled) throw ApiError.badRequest('Certificates are not offered for this course');
  throw new ApiError(400, 'You have not met all the requirements for a certificate yet', {
    code: 'CERTIFICATE_REQUIREMENTS_NOT_MET',
    checks: ev ? ev.checks : []
  });
}

async function afterIssue(certificate, course, student) {
  await notificationService.notifyCertificateAvailable(student._id, {
    certificateId: certificate.certificateId,
    courseId: course._id,
    courseTitle: course.title
  });
  await emailCertificate(certificate._id);
}

async function emailCertificate(certId) {
  const cert = await Certificate.findById(certId);
  if (!cert || cert.emailedAt || cert.status !== 'valid') return false;
  const student = await User.findById(cert.studentId).select('name email');
  if (!student?.email) return false;

  const claimed = await Certificate.findOneAndUpdate({ _id: certId, emailedAt: null }, { $set: { emailedAt: new Date() } });
  if (!claimed) return false; // someone else is sending it
  try {
    const pdf = await renderPdf(cert);
    const courseTitle = cert.snapshot?.courseTitle || cert.title;
    await sendEmail({
      to: student.email,
      subject: `Your certificate for ${courseTitle}`,
      text: `Congratulations ${student.name}! You completed ${courseTitle}. Your certificate (ID ${cert.certificateId}) is attached. Anyone can verify it at ${verifyUrl(cert)}.`,
      html: `<p>Congratulations ${escapeHtml(student.name)}!</p><p>You have completed <strong>${escapeHtml(courseTitle)}</strong>. Your certificate is attached.</p><p>Certificate ID: <strong>${cert.certificateId}</strong><br>Verify: <a href="${verifyUrl(cert)}">${verifyUrl(cert)}</a></p>`,
      attachments: [{ filename: `Certificate-${cert.certificateId}.pdf`, content: pdf, contentType: 'application/pdf' }]
    });
    return true;
  } catch (err) {
    await Certificate.updateOne({ _id: certId }, { $set: { emailedAt: null } }); // allow a later retry
    throw err;
  }
}

/* ------------------------------------------------------------------ */
/* Automatic triggering                                                */
/* ------------------------------------------------------------------ */

const MAX_CONCURRENT = 2;
const pending = new Set();
const queue = [];
let active = 0;

function pump() {
  while (active < MAX_CONCURRENT && queue.length) {
    const job = queue.shift();
    active += 1;
    evaluateAndIssue(job.studentId, job.courseId)
      .catch((err) => logger.error(`Certificate evaluation failed (${job.key}): ${err.message}`))
      .finally(() => {
        pending.delete(job.key);
        active -= 1;
        pump();
      });
  }
}

/**
 * Fire-and-forget re-check, called from the places where a requirement can become true: lesson completed,
 * work graded, attendance recorded. De-duplicated and rate-limited so a class-wide attendance save doesn't
 * stampede the database. Never throws.
 */
function queueEvaluation(studentId, courseId) {
  if (!studentId || !courseId) return;
  const key = `${studentId}:${courseId}`;
  if (pending.has(key)) return;
  pending.add(key);
  queue.push({ studentId: String(studentId), courseId: String(courseId), key });
  setImmediate(pump);
}

/** Safety net for anything the hooks missed (a process crash, direct DB edits, changed requirements). */
async function sweepRecentActivity(sinceMs = 3 * 60 * 60 * 1000) {
  const since = new Date(Date.now() - sinceMs);
  const pairs = new Map();
  const add = (s, c) => pairs.set(`${s}:${c}`, [s, c]);

  (await Progress.find({ updatedAt: { $gte: since } }).select('studentId courseId').lean()).forEach((p) => add(p.studentId, p.courseId));
  (await Submission.find({ status: 'graded', updatedAt: { $gte: since } }).select('studentId courseId').lean()).forEach((p) => add(p.studentId, p.courseId));
  (await Attendance.find({ updatedAt: { $gte: since } }).select('courseId records.studentId').lean()).forEach((a) =>
    a.records.forEach((r) => add(r.studentId, a.courseId))
  );
  pairs.forEach(([s, c]) => queueEvaluation(s, c));
  return pairs.size;
}

/** Evaluate every enrolled student of one course (or all courses). Used by the backfill script. */
async function evaluateCourse(courseId, { apply = true } = {}) {
  const course = await Course.findById(courseId).select('enrolledStudentIds');
  let eligible = 0;
  let issued = 0;
  for (const studentId of course?.enrolledStudentIds || []) {
    const existing = await Certificate.exists({ studentId, courseId });
    if (existing) continue;
    if (!apply) {
      const c = await Course.findById(courseId);
      const ev = await evaluate(studentId, c);
      if (ev.eligible) eligible += 1;
      continue;
    }
    const r = await evaluateAndIssue(studentId, courseId);
    if (r.certificate) {
      eligible += 1;
      if (r.issued) issued += 1;
    }
  }
  return { eligible, issued };
}

/* ------------------------------------------------------------------ */
/* Reading                                                             */
/* ------------------------------------------------------------------ */

const escapeHtml = (v) => String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function certIdOf(cert) {
  return cert.certificateId || cert.verificationCode;
}

function verifyUrl(cert) {
  const base = env.certificates.verifyBaseUrl;
  return /[?&]id=$/.test(base) ? `${base}${certIdOf(cert)}` : `${base}/${certIdOf(cert)}`;
}

function summarize(cert) {
  return {
    id: cert._id,
    certificateId: certIdOf(cert),
    title: cert.title,
    status: cert.status,
    issuedAt: cert.issuedAt,
    completionDate: cert.completionDate || cert.issuedAt,
    course: cert.courseId && cert.courseId.title ? { id: cert.courseId._id, title: cert.courseId.title } : { id: cert.courseId },
    verifyUrl: verifyUrl(cert)
  };
}

async function listCertificates(studentId) {
  const certs = await Certificate.find({ studentId }).populate('courseId', 'title').sort({ issuedAt: -1 });
  return certs.map(summarize);
}

/** Accepts the Mongo _id or the public certificate ID. Always scoped to the owner. */
async function getCertificate(idOrCertificateId, studentId) {
  const filter = { studentId };
  if (mongoose.isValidObjectId(idOrCertificateId) && String(idOrCertificateId).length === 24) {
    filter._id = idOrCertificateId;
  } else {
    const norm = normalizeCertificateId(idOrCertificateId);
    if (!norm) throw ApiError.notFound('Certificate not found');
    filter.certificateId = norm;
  }
  const certificate = await Certificate.findOne(filter).populate('courseId', 'title');
  if (!certificate) throw ApiError.notFound('Certificate not found');
  return certificate;
}

async function getEligibilityReport(studentId, courseId) {
  const course = await Course.findById(courseId);
  if (!course) throw ApiError.notFound('Course not found');
  const existing = await Certificate.findOne({ studentId, courseId }).populate('courseId', 'title');
  if (existing) return { issued: true, certificate: summarize(existing) };
  const ev = await evaluate(studentId, course);
  return { issued: false, enabled: ev.enabled, eligible: ev.eligible, checks: ev.checks, lessonCompletionPercent: ev.lessonCompletionPercent };
}

/**
 * Public verification. Returns only what a verifier needs: no email, no internal ids, no scores.
 * Accepts the new certificate ID or a legacy 16-character code.
 */
async function verifyCertificate(input) {
  let cert = null;
  const norm = normalizeCertificateId(input);
  if (norm) cert = await Certificate.findOne({ certificateId: norm });
  else if (isLegacyCode(input)) cert = await Certificate.findOne({ verificationCode: input.trim().toUpperCase() });
  if (!cert) return null;

  if (cert.status === 'revoked') {
    return { valid: false, status: 'revoked', certificateId: certIdOf(cert), revokedAt: cert.revokedAt };
  }

  const data = await buildRenderData(cert);
  return {
    valid: true,
    status: 'valid',
    certificateId: data.certificateId,
    studentName: data.studentName,
    courseTitle: data.courseTitle,
    institutionName: data.institutionName,
    instructors: data.instructors.map((i) => i.name),
    completionDate: data.completionDate,
    issuedAt: cert.issuedAt
  };
}

/* ------------------------------------------------------------------ */
/* PDF                                                                 */
/* ------------------------------------------------------------------ */

async function buildRenderData(cert) {
  const snap = cert.snapshot || {};
  let { studentName, courseTitle, instructors } = snap;
  let institutionName = snap.institutionName;
  let signatory = snap.signatory && snap.signatory.name ? snap.signatory : null;

  if (!studentName || !courseTitle) {
    // Certificate issued before snapshots existed: fall back to live data.
    const [student, course] = await Promise.all([User.findById(cert.studentId).select('name'), Course.findById(cert.courseId)]);
    studentName = studentName || student?.name || 'Student';
    courseTitle = courseTitle || course?.title || cert.title;
    instructors = instructors && instructors.length ? instructors : course ? await loadInstructors(course) : [];
    const inst = institutionSnapshot();
    institutionName = institutionName || inst.institutionName;
    signatory = signatory || (inst.signatory.name ? inst.signatory : null);
  }

  return {
    studentName,
    courseTitle,
    institutionName: institutionName || env.certificates.institutionName,
    completionDate: cert.completionDate || cert.issuedAt,
    issuedAt: cert.issuedAt,
    certificateId: certIdOf(cert),
    verifyUrl: verifyUrl(cert),
    instructors: (instructors || []).map((i) => ({ name: i.name, signatureFile: i.signatureFile || null })),
    signatory,
    finalScorePercent: snap.showScore ? snap.finalScorePercent ?? null : null
  };
}

async function renderPdf(cert) {
  // eslint-disable-next-line global-require
  const PDFDocument = require('pdfkit');
  const data = await buildRenderData(cert);
  const assets = {
    qr: buildQr(data.verifyUrl),
    instructorImages: data.instructors.map((i) => (i.signatureFile ? signatureStore.read(i.signatureFile) : null)),
    signatoryImage: data.signatory?.signatureFile ? signatureStore.read(data.signatory.signatureFile) : null
  };
  return renderToBuffer(PDFDocument, data, assets);
}

/* ------------------------------------------------------------------ */
/* Admin + instructor signature                                        */
/* ------------------------------------------------------------------ */

async function listAll({ status, courseId, certificateId, page = 1, limit = 20 } = {}) {
  const filter = {};
  if (status) filter.status = status;
  if (courseId) filter.courseId = courseId;
  if (certificateId) filter.certificateId = normalizeCertificateId(certificateId) || '__none__';
  const skip = (Number(page) - 1) * Number(limit);
  const [items, total] = await Promise.all([
    Certificate.find(filter).populate('studentId', 'name email').populate('courseId', 'title').sort({ issuedAt: -1 }).skip(skip).limit(Number(limit)),
    Certificate.countDocuments(filter)
  ]);
  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / Number(limit)) };
}

async function revoke(id, reason, adminId) {
  const cert = await Certificate.findOneAndUpdate(
    { _id: id, status: 'valid' },
    { $set: { status: 'revoked', revokedAt: new Date(), revokedReason: reason || null, revokedBy: adminId } },
    { new: true }
  );
  if (!cert) throw ApiError.badRequest('Certificate not found or already revoked');
  return cert;
}

async function restore(id) {
  const cert = await Certificate.findOneAndUpdate(
    { _id: id, status: 'revoked' },
    { $set: { status: 'valid', revokedAt: null, revokedReason: null, revokedBy: null } },
    { new: true }
  );
  if (!cert) throw ApiError.badRequest('Certificate not found or not revoked');
  return cert;
}

async function setInstructorSignature(userId, buffer) {
  const fileName = signatureStore.save(userId, buffer);
  await User.updateOne({ _id: userId }, { $set: { 'profile.signatureFile': fileName } });
  return fileName;
}

async function clearInstructorSignature(userId) {
  // The file stays on disk: certificates already issued still reference it.
  await User.updateOne({ _id: userId }, { $set: { 'profile.signatureFile': null } });
}

module.exports = {
  evaluateAndIssue,
  issueCertificateIfEligible,
  queueEvaluation,
  sweepRecentActivity,
  evaluateCourse,
  getEligibilityReport,
  listCertificates,
  getCertificate,
  verifyCertificate,
  renderPdf,
  listAll,
  revoke,
  restore,
  setInstructorSignature,
  clearInstructorSignature,
  emailCertificate,
  summarize,
  gatherStats
};
