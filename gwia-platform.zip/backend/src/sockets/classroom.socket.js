const LiveClass = require('../models/liveClass.model');
const ClassroomMessage = require('../models/classroomMessage.model');
const classroomAuthService = require('../services/classroomAuthService');
const classroomPresenceService = require('../services/classroomPresenceService');
const classroomService = require('../services/classroomService');
const mediaTransport = require('../services/mediaTransport');
const logger = require('../utils/logger');
const { createLimiter, isObjectId } = require('./rateLimit');

const MAX_CHAT_LENGTH = 2000;
const MAX_SIGNAL_BYTES = 16 * 1024; // SDP offers/answers and ICE candidates are a few KB at most
const allowChat = createLimiter({ capacity: 10, refillPerSec: 1 });
const allowSignal = createLimiter({ capacity: 200, refillPerSec: 100 });
const allowControl = createLimiter({ capacity: 20, refillPerSec: 4 });
const MATERIAL_URL = /^\/uploads\/materials\/[A-Za-z0-9._-]+$/;

function broadcastParticipantList(nsp, liveClassId) {
  const participants = classroomPresenceService.listParticipants(liveClassId).map((p) => ({
    userId: p.userId,
    name: p.name,
    role: p.role,
    micOn: p.micOn,
    cameraOn: p.cameraOn,
    handRaised: p.handRaised,
    screenSharing: p.screenSharing,
    joinedAt: p.joinedAt
  }));
  nsp.to(roomKey(liveClassId)).emit('classroom:participants', participants);
}

function roomKey(liveClassId) {
  return `classroom:${liveClassId}`;
}

function isTeacherOf(liveClass, userId) {
  return liveClass.teacherId.toString() === userId;
}

/**
 * Records a join in LiveClass.participantLog (a fresh entry with
 * leftAt: null) so attendance can later be derived from real connect
 * time rather than relying on the teacher marking it manually.
 */
async function logJoin(liveClass, userId, role) {
  liveClass.participantLog.push({ userId, role, joinedAt: new Date(), leftAt: null });
  await liveClass.save();
}

function initClassroomNamespace(io) {
  const nsp = io.of('/classroom');

  // --- Handshake auth: verify the short-lived classroom join token, not the general access token ---
  nsp.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('Classroom join token missing'));

      const claims = classroomAuthService.verifyJoinToken(token);
      socket.classroomClaims = claims; // { liveClassId, userId, role }
      next();
    } catch (err) {
      next(new Error(err.message || 'Classroom authentication failed'));
    }
  });

  nsp.on('connection', (socket) => {
    const { liveClassId, userId, role } = socket.classroomClaims;

    socket.on('classroom:join', async (payload, ack) => {
      try {
        const liveClass = await LiveClass.findById(liveClassId);
        if (!liveClass) return ack?.({ error: 'Classroom not found' });
        if (liveClass.status === 'cancelled') return ack?.({ error: 'This class has been cancelled' });
        if (liveClass.status === 'completed') return ack?.({ error: 'This class has already ended' });

        socket.join(roomKey(liveClassId));

        const participant = {
          userId,
          role,
          name: socket.classroomClaims.name || 'Participant', // from the signed token, never from the client
          socketId: socket.id,
          micOn: role === 'teacher' ? true : liveClass.settings.studentMicEnabledByDefault,
          cameraOn: role === 'teacher' ? true : liveClass.settings.studentCameraEnabledByDefault,
          handRaised: false,
          screenSharing: false,
          joinedAt: new Date()
        };
        classroomPresenceService.addParticipant(liveClassId, userId, participant);

        await logJoin(liveClass, userId, role);
        mediaTransport.onParticipantJoined(nsp, liveClassId, participant);

        const connectionInfo = await mediaTransport.getConnectionInfo(liveClass, participant);

        ack?.({
          success: true,
          connectionInfo,
          settings: liveClass.settings,
          timer: liveClass.timer,
          existingParticipants: classroomPresenceService
            .listParticipants(liveClassId)
            .filter((p) => p.userId !== userId)
        });

        socket.to(roomKey(liveClassId)).emit('classroom:participant-joined', {
          userId,
          name: participant.name,
          role
        });
        broadcastParticipantList(nsp, liveClassId);
      } catch (err) {
        logger.error(`classroom:join failed: ${err.message}`);
        ack?.({ error: 'Failed to join classroom' });
      }
    });

    // --- WebRTC signaling relay (mesh mode) ---
    socket.on('webrtc:signal', (message) => {
      if (!message || typeof message !== 'object' || typeof message.toUserId !== 'string') return;
      if (!allowSignal(socket.id, 'signal')) return;
      const { toUserId, ...payload } = message;
      if (toUserId === userId) return;
      let size = 0;
      try { size = Buffer.byteLength(JSON.stringify(payload)); } catch (e) { return; }
      if (size > MAX_SIGNAL_BYTES) return;
      mediaTransport.relaySignal(nsp, liveClassId, userId, toUserId, payload);
    });

    // --- Media controls ---
    socket.on('media:toggle', (payload) => {
      if (!allowControl(socket.id, 'media')) return;
      // Coerce to booleans so arbitrary objects can never be stored in presence state.
      const micOn = typeof payload?.micOn === 'boolean' ? payload.micOn : undefined;
      const cameraOn = typeof payload?.cameraOn === 'boolean' ? payload.cameraOn : undefined;
      const updated = classroomPresenceService.updateParticipant(liveClassId, userId, {
        ...(micOn !== undefined ? { micOn } : {}),
        ...(cameraOn !== undefined ? { cameraOn } : {})
      });
      if (updated) {
        nsp.to(roomKey(liveClassId)).emit('classroom:participant-updated', {
          userId,
          micOn: updated.micOn,
          cameraOn: updated.cameraOn
        });
      }
    });

    // --- Screen sharing ---
    socket.on('screen-share:start', async () => {
      const liveClass = await LiveClass.findById(liveClassId);
      if (!liveClass) return;

      const canShare = role === 'teacher' || liveClass.settings.studentScreenShareAllowed;
      if (!canShare) {
        return socket.emit('classroom:error', { message: 'Screen sharing is not permitted for students in this class' });
      }

      classroomPresenceService.updateParticipant(liveClassId, userId, { screenSharing: true });
      nsp.to(roomKey(liveClassId)).emit('classroom:screen-share-started', { userId });
    });

    socket.on('screen-share:stop', () => {
      classroomPresenceService.updateParticipant(liveClassId, userId, { screenSharing: false });
      nsp.to(roomKey(liveClassId)).emit('classroom:screen-share-stopped', { userId });
    });

    // --- Raise hand ---
    socket.on('hand:raise', () => {
      if (!allowControl(socket.id, 'hand')) return;
      classroomPresenceService.updateParticipant(liveClassId, userId, { handRaised: true });
      nsp.to(roomKey(liveClassId)).emit('classroom:hand-raised', { userId });
    });
    socket.on('hand:lower', () => {
      classroomPresenceService.updateParticipant(liveClassId, userId, { handRaised: false });
      nsp.to(roomKey(liveClassId)).emit('classroom:hand-lowered', { userId });
    });

    // --- Teacher mute controls (teacher-only, enforced server-side regardless of client UI) ---
    socket.on('teacher:mute-participant', async (payload) => {
      const targetUserId = payload?.targetUserId;
      if (typeof targetUserId !== 'string') return;
      const liveClass = await LiveClass.findById(liveClassId);
      if (!liveClass || !isTeacherOf(liveClass, userId)) {
        return socket.emit('classroom:error', { message: 'Only the teacher can mute participants' });
      }

      const target = classroomPresenceService.updateParticipant(liveClassId, targetUserId, { micOn: false });
      if (target) {
        nsp.to(target.socketId).emit('classroom:force-muted');
        nsp.to(roomKey(liveClassId)).emit('classroom:participant-updated', { userId: targetUserId, micOn: false });
      }
    });

    socket.on('teacher:mute-all', async () => {
      const liveClass = await LiveClass.findById(liveClassId);
      if (!liveClass || !isTeacherOf(liveClass, userId)) {
        return socket.emit('classroom:error', { message: 'Only the teacher can mute all participants' });
      }

      for (const participant of classroomPresenceService.listParticipants(liveClassId)) {
        if (participant.role === 'student') {
          classroomPresenceService.updateParticipant(liveClassId, participant.userId, { micOn: false });
          nsp.to(participant.socketId).emit('classroom:force-muted');
        }
      }
      broadcastParticipantList(nsp, liveClassId);
    });

    // --- Chat ---
    socket.on('chat:message', async (payload, ack) => {
      try {
        const text = payload?.text;
        if (typeof text !== 'string' || !text.trim()) return ack?.({ error: 'Message cannot be empty' });
        if (!allowChat(socket.id, 'chat')) return ack?.({ error: 'You are sending messages too quickly' });
        if (text.length > MAX_CHAT_LENGTH) return ack?.({ error: 'Message too long' });

        const liveClass = await LiveClass.findById(liveClassId);
        if (!liveClass || !liveClass.settings.chatEnabled) {
          return ack?.({ error: 'Chat is disabled for this class' });
        }

        const message = await ClassroomMessage.create({
          liveClassId,
          senderId: userId,
          senderRole: role,
          type: 'chat',
          text: text.trim()
        });

        nsp.to(roomKey(liveClassId)).emit('classroom:chat-message', {
          id: message._id,
          senderId: userId,
          senderRole: role,
          text: message.text,
          createdAt: message.createdAt
        });
        ack?.({ success: true });
      } catch (err) {
        logger.error(`chat:message failed: ${err.message}`);
        ack?.({ error: 'Failed to send message' });
      }
    });

    // --- Announcements (teacher-only) ---
    socket.on('announcement:post', async (payload, ack) => {
      try {
        const text = payload?.text;
        if (typeof text !== 'string' || text.length > MAX_CHAT_LENGTH) return ack?.({ error: 'Invalid announcement' });
        const liveClass = await LiveClass.findById(liveClassId);
        if (!liveClass || !isTeacherOf(liveClass, userId)) {
          return ack?.({ error: 'Only the teacher can post announcements' });
        }
        if (!text || !text.trim()) return ack?.({ error: 'Announcement cannot be empty' });

        const message = await ClassroomMessage.create({
          liveClassId,
          senderId: userId,
          senderRole: 'teacher',
          type: 'announcement',
          text: text.trim()
        });

        nsp.to(roomKey(liveClassId)).emit('classroom:announcement', {
          id: message._id,
          text: message.text,
          createdAt: message.createdAt
        });
        ack?.({ success: true });
      } catch (err) {
        logger.error(`announcement:post failed: ${err.message}`);
        ack?.({ error: 'Failed to post announcement' });
      }
    });

    // --- Shared materials (broadcast only; upload itself goes through the REST endpoint) ---
    // Teacher only, and only a fixed set of fields pointing at an uploaded material: previously any participant could push
    // arbitrary objects (and links) to every other participant.
    socket.on('material:shared-broadcast', (material) => {
      if (role !== 'teacher' || !material || typeof material !== 'object') return;
      if (typeof material.fileUrl !== 'string' || !MATERIAL_URL.test(material.fileUrl)) return;
      nsp.to(roomKey(liveClassId)).emit('classroom:material-shared', {
        title: String(material.title || material.fileName || 'Shared material').slice(0, 200),
        fileName: String(material.fileName || '').slice(0, 200),
        fileUrl: material.fileUrl
      });
    });

    // --- Explicit leave (clean alternative to just closing the tab) ---
    socket.on('classroom:leave', async () => {
      await handleDisconnect();
    });

    socket.on('disconnect', async () => {
      await handleDisconnect();
    });

    async function handleDisconnect() {
      try {
        classroomPresenceService.removeParticipant(liveClassId, userId);
        await classroomService.logParticipantLeave(liveClassId, userId);

        const liveClass = await LiveClass.findById(liveClassId);
        if (liveClass) mediaTransport.onParticipantLeft(nsp, liveClassId, { userId });

        socket.to(roomKey(liveClassId)).emit('classroom:participant-left', { userId });
        broadcastParticipantList(nsp, liveClassId);
      } catch (err) {
        logger.error(`classroom disconnect handling failed: ${err.message}`);
      }
    }
  });

  return nsp;
}

module.exports = initClassroomNamespace;
