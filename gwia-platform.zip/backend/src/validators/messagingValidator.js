const { body, query } = require('express-validator');

const startConversationValidator = [
  body('recipientId').isMongoId().withMessage('A valid recipientId is required'),
  body('courseId').optional().isMongoId()
];

const sendMessageValidator = [
  body('text').optional().trim().isLength({ max: 5000 })
];

const markAsReadValidator = [
  body('messageIds').optional().isArray(),
  body('messageIds.*').optional().isMongoId()
];

const searchMessagesValidator = [
  query('q').trim().notEmpty().withMessage('Query parameter "q" is required').isLength({ max: 200 }),
  query('conversationId').optional().isMongoId(),
  query('limit').optional().isInt({ min: 1, max: 100 })
];

module.exports = {
  startConversationValidator,
  sendMessageValidator,
  markAsReadValidator,
  searchMessagesValidator
};
