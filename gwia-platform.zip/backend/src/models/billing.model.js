const mongoose = require('mongoose');
const { Schema } = mongoose;

/* ------------------------------------------------------------------ */
/* Payment                                                             */
/* ------------------------------------------------------------------ */
// Money rules: `amountMinor` (integer kobo/cents) is the source of truth that is compared with the
// gateway's report. `amount` (major units) is kept because existing dashboards/reports sum it.
const paymentSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', default: null },
    subscriptionId: { type: Schema.Types.ObjectId, ref: 'Subscription', default: null },

    purpose: { type: String, enum: ['course', 'subscription', null], default: null },
    planId: { type: Schema.Types.ObjectId, ref: 'Plan', default: null },
    planCode: { type: String, default: null },
    billingCycle: { type: String, enum: ['monthly', 'annual', null], default: null },
    periodMonths: { type: Number, default: null },
    description: { type: String, default: '' }, // snapshot printed on the receipt

    amount: { type: Number, required: true, min: 0 }, // final charged amount, major units
    currency: { type: String, default: 'USD', uppercase: true, trim: true, maxlength: 3 },
    amountMinor: { type: Number, default: null, min: 0 },
    originalAmountMinor: { type: Number, default: null, min: 0 },
    discountAmountMinor: { type: Number, default: 0, min: 0 },
    discountCode: { type: String, default: null },
    discountCodeId: { type: Schema.Types.ObjectId, ref: 'DiscountCode', default: null },

    provider: { type: String, default: 'manual', trim: true }, // paystack | flutterwave | manual | free
    reference: { type: String, default: null, trim: true }, // OUR unique reference, sent to the gateway
    providerReference: { type: String, default: null, trim: true }, // the GATEWAY's transaction id
    checkoutUrl: { type: String, default: null },
    checkoutExpiresAt: { type: Date, default: null },
    channel: { type: String, default: null },

    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'refunded'],
      default: 'pending',
      index: true
    },
    failureReason: { type: String, default: null },
    needsReview: { type: Boolean, default: false, index: true }, // e.g. amount mismatch — a human must look
    paidAt: { type: Date, default: null },
    verifiedAt: { type: Date, default: null },
    lastVerifyAttemptAt: { type: Date, default: null },
    refundedAt: { type: Date, default: null },

    // Fulfilment (granting access) is tracked separately from "money received" so a crash between
    // the two is detectable and retryable. Granting is idempotent per payment.
    fulfillment: {
      status: { type: String, enum: ['none', 'pending', 'in_progress', 'done'], default: 'none' },
      lockedAt: { type: Date, default: null },
      attempts: { type: Number, default: 0 },
      doneAt: { type: Date, default: null },
      lastError: { type: String, default: null }
    },

    receiptNumber: { type: String, default: null },
    receiptIssuedAt: { type: Date, default: null },
    receiptEmailedAt: { type: Date, default: null },

    customerEmail: { type: String, default: null },
    ipAddress: { type: String, default: null },
    providerPayload: { type: Schema.Types.Mixed, default: null, select: false },
    notes: { type: String, default: '', maxlength: 1000 }
  },
  { timestamps: true }
);

paymentSchema.index({ status: 1, createdAt: -1 });
paymentSchema.index({ userId: 1, createdAt: -1 });
// Partial indexes: legacy rows without these fields are ignored, new rows are protected.
paymentSchema.index({ reference: 1 }, { unique: true, partialFilterExpression: { reference: { $type: 'string' } } });
paymentSchema.index(
  { provider: 1, providerReference: 1 },
  { unique: true, partialFilterExpression: { providerReference: { $type: 'string' } } }
);
paymentSchema.index({ receiptNumber: 1 }, { unique: true, partialFilterExpression: { receiptNumber: { $type: 'string' } } });
paymentSchema.index({ status: 1, 'fulfillment.status': 1, updatedAt: 1 });

/* ------------------------------------------------------------------ */
/* Subscription                                                        */
/* ------------------------------------------------------------------ */
// One live (active/trialing) subscription per user. Renewals extend endDate (compare-and-swap) and
// append the payment id to paymentIds, which is what makes extension idempotent per payment.
const subscriptionSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },

    plan: { type: String, required: true, trim: true }, // plan code (kept for backward compatibility)
    planId: { type: Schema.Types.ObjectId, ref: 'Plan', default: null },
    billingCycle: { type: String, enum: ['monthly', 'annual', null], default: null },
    amount: { type: Number, required: true, min: 0 },
    currency: { type: String, default: 'USD', uppercase: true, trim: true, maxlength: 3 },

    status: {
      type: String,
      enum: ['active', 'trialing', 'expired', 'cancelled'],
      default: 'active',
      index: true
    },
    source: { type: String, enum: ['payment', 'trial', 'admin'], default: 'admin' },

    startDate: { type: Date, required: true, default: Date.now },
    endDate: { type: Date, required: true },
    autoRenew: { type: Boolean, default: false },
    cancelledAt: { type: Date, default: null },

    trialStartedAt: { type: Date, default: null },
    trialMarker: { type: String, enum: ['trial', null], default: null }, // set once at trial start, never cleared
    paymentIds: [{ type: Schema.Types.ObjectId, ref: 'Payment' }],
    lastPaymentId: { type: Schema.Types.ObjectId, ref: 'Payment', default: null },

    reminder3dSentAt: { type: Date, default: null },
    reminder1dSentAt: { type: Date, default: null },
    expiredNotifiedAt: { type: Date, default: null }
  },
  { timestamps: true }
);

subscriptionSchema.index({ status: 1, endDate: 1 });
subscriptionSchema.index({ paymentIds: 1 });
// At most one ACTIVE subscription and one TRIAL-origin subscription per user, enforced by the database.
// (Key patterns differ from the plain {userId:1} index on purpose: same-key indexes with different options conflict.)
subscriptionSchema.index({ userId: 1, status: 1 }, { unique: true, name: 'one_active_sub_per_user', partialFilterExpression: { status: 'active' } });
subscriptionSchema.index({ userId: 1, trialMarker: 1 }, { unique: true, name: 'one_trial_per_user', partialFilterExpression: { trialMarker: 'trial' } });

/* ------------------------------------------------------------------ */
/* Plan                                                                */
/* ------------------------------------------------------------------ */
const planSchema = new Schema(
  {
    code: { type: String, required: true, unique: true, lowercase: true, trim: true, maxlength: 60 },
    name: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, default: '', maxlength: 1000 },
    billingCycle: { type: String, enum: ['monthly', 'annual'], required: true },
    periodMonths: { type: Number, required: true, min: 1 }, // 1 for monthly, 12 for annual
    prices: [
      {
        _id: false,
        currency: { type: String, required: true, uppercase: true, trim: true, maxlength: 3 },
        amountMinor: { type: Number, required: true, min: 0 }
      }
    ],
    trialDays: { type: Number, default: 0, min: 0, max: 90 },
    features: { type: [String], default: [] },
    active: { type: Boolean, default: true, index: true },
    sortOrder: { type: Number, default: 0 }
  },
  { timestamps: true }
);

/* ------------------------------------------------------------------ */
/* Discount codes                                                      */
/* ------------------------------------------------------------------ */
const discountCodeSchema = new Schema(
  {
    code: { type: String, required: true, unique: true, uppercase: true, trim: true, maxlength: 40 },
    description: { type: String, default: '', maxlength: 300 },
    type: { type: String, enum: ['percent', 'fixed'], required: true },
    percentOff: { type: Number, default: null, min: 1, max: 100 },
    maxDiscountMinor: { type: Number, default: null, min: 0 }, // optional cap for percent codes
    fixedAmounts: [
      {
        _id: false,
        currency: { type: String, uppercase: true, trim: true, maxlength: 3 },
        amountMinor: { type: Number, min: 0 }
      }
    ],
    appliesTo: { type: String, enum: ['all', 'course', 'subscription'], default: 'all' },
    courseIds: [{ type: Schema.Types.ObjectId, ref: 'Course' }], // empty = any course
    planCodes: { type: [String], default: [] }, // empty = any plan
    maxRedemptions: { type: Number, default: null, min: 1 }, // null = unlimited
    redeemedCount: { type: Number, default: 0, min: 0 }, // includes reserved (in-flight) redemptions
    perUserLimit: { type: Number, default: 1, min: 1 },
    validFrom: { type: Date, default: null },
    validUntil: { type: Date, default: null },
    active: { type: Boolean, default: true, index: true },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
  },
  { timestamps: true }
);

const discountRedemptionSchema = new Schema(
  {
    codeId: { type: Schema.Types.ObjectId, ref: 'DiscountCode', required: true, index: true },
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    paymentId: { type: Schema.Types.ObjectId, ref: 'Payment', required: true, unique: true },
    status: { type: String, enum: ['reserved', 'redeemed', 'released'], default: 'reserved' },
    amountMinor: { type: Number, default: 0 },
    currency: { type: String, default: null }
  },
  { timestamps: true }
);
discountRedemptionSchema.index({ codeId: 1, userId: 1, status: 1 });

/* ------------------------------------------------------------------ */
/* Course access (one-off course purchases / admin grants)             */
/* ------------------------------------------------------------------ */
const courseAccessSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true },
    source: { type: String, enum: ['purchase', 'admin', 'grandfathered'], required: true },
    paymentId: { type: Schema.Types.ObjectId, ref: 'Payment', default: null },
    status: { type: String, enum: ['active', 'revoked'], default: 'active' },
    grantedAt: { type: Date, default: Date.now },
    expiresAt: { type: Date, default: null }, // null = lifetime
    revokedAt: { type: Date, default: null }
  },
  { timestamps: true }
);
courseAccessSchema.index({ userId: 1, courseId: 1, status: 1 });
courseAccessSchema.index({ paymentId: 1 }, { unique: true, partialFilterExpression: { paymentId: { $type: 'objectId' } } });

/* ------------------------------------------------------------------ */
/* Webhook event log (duplicate-delivery protection + audit trail)     */
/* ------------------------------------------------------------------ */
const webhookEventSchema = new Schema(
  {
    provider: { type: String, required: true },
    eventKey: { type: String, required: true },
    eventType: { type: String, default: null },
    reference: { type: String, default: null },
    status: { type: String, enum: ['received', 'processed', 'ignored', 'failed'], default: 'received' },
    attempts: { type: Number, default: 1 },
    error: { type: String, default: null },
    processedAt: { type: Date, default: null }
  },
  { timestamps: true }
);
webhookEventSchema.index({ provider: 1, eventKey: 1 }, { unique: true });
webhookEventSchema.index({ createdAt: 1 }, { expireAfterSeconds: 180 * 24 * 60 * 60 });

/* ------------------------------------------------------------------ */
/* Counter (gap-tolerant, atomic receipt numbers)                      */
/* ------------------------------------------------------------------ */
const counterSchema = new Schema({ _id: { type: String }, seq: { type: Number, default: 0 } });

const models = {
  Payment: mongoose.model('Payment', paymentSchema),
  Subscription: mongoose.model('Subscription', subscriptionSchema),
  Plan: mongoose.model('Plan', planSchema),
  DiscountCode: mongoose.model('DiscountCode', discountCodeSchema),
  DiscountRedemption: mongoose.model('DiscountRedemption', discountRedemptionSchema),
  CourseAccess: mongoose.model('CourseAccess', courseAccessSchema),
  WebhookEvent: mongoose.model('WebhookEvent', webhookEventSchema),
  Counter: mongoose.model('Counter', counterSchema)
};

/**
 * autoIndex is OFF in production (see config/db.js), but the unique indexes above ARE the
 * duplicate-prevention guarantee. Call once at boot; it only creates what is missing.
 */
async function ensureBillingIndexes() {
  const warnings = [];
  for (const [name, model] of Object.entries(models)) {
    try {
      await model.createIndexes();
    } catch (err) {
      // Payment-critical collections must have their unique indexes: fail boot. The Subscription indexes are
      // a second line of defence (the code also guards), and legacy duplicate "active" rows can block them:
      // report loudly but let the app start so the problem can be fixed in place.
      if (name === 'Subscription') {
        warnings.push(`Subscription indexes not created: ${err.message}`);
      } else {
        throw err;
      }
    }
  }
  return warnings;
}

module.exports = { ...models, ensureBillingIndexes };
