const { Course } = require('../models/course.model');
const Lesson = require('../models/lesson.model');
const LiveClass = require('../models/liveClass.model');
const Assignment = require('../models/assignment.model');
const { Assessment } = require('../models/assessment.model');
const Submission = require('../models/submission.model');
const Attendance = require('../models/attendance.model');
const Notification = require('../models/notification.model');
const Certificate = require('../models/certificate.model');
const { Conversation } = require('../models/messaging.model');
const Progress = require('../models/progress.model');
const User = require('../models/User');

async function getDashboard(studentId) {
  const student = await User.findById(studentId);
  const now = new Date();
  const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  const courses = await Course.find({ enrolledStudentIds: studentId });
  const courseIds = courses.map((c) => c._id);

  const [
    upcomingLiveClasses,
    openAssignments,
    openQuizzes,
    openExams,
    recentGradedSubmissions,
    recentNotifications,
    unreadNotificationCount,
    certificates,
    unreadConversationCount,
    progressDocs
  ] = await Promise.all([
    LiveClass.find({ courseId: { $in: courseIds }, status: 'scheduled', scheduledAt: { $gte: now, $lte: nextWeek } })
      .sort({ scheduledAt: 1 })
      .limit(10),
    Assignment.find({ courseId: { $in: courseIds }, status: 'published', dueDate: { $gte: now } })
      .sort({ dueDate: 1 })
      .limit(10),
    Assessment.find({
      kind: 'quiz',
      courseId: { $in: courseIds },
      status: 'published',
      availableUntil: { $gte: now }
    })
      .sort({ availableFrom: 1 })
      .limit(10),
    Assessment.find({
      kind: 'exam',
      courseId: { $in: courseIds },
      status: 'published',
      availableUntil: { $gte: now }
    })
      .sort({ availableFrom: 1 })
      .limit(10),
    Submission.find({ studentId, status: 'graded' }).sort({ 'grade.gradedAt': -1 }).limit(10),
    Notification.find({ userId: studentId }).sort({ createdAt: -1 }).limit(10),
    Notification.countDocuments({ userId: studentId, read: false }),
    Certificate.find({ studentId }).populate('courseId', 'title').sort({ issuedAt: -1 }),
    Conversation.countDocuments({ participantIds: studentId }),
    Progress.find({ studentId, courseId: { $in: courseIds } })
  ]);

  // "Current lessons": the next unfinished lesson per enrolled course.
  const currentLessons = [];
  for (const course of courses) {
    const progress = progressDocs.find((p) => p.courseId.toString() === course._id.toString());
    const completedIds = progress ? progress.completedLessonIds.map((id) => id.toString()) : [];
    const nextLesson = await Lesson.findOne({
      courseId: course._id,
      status: 'published',
      _id: { $nin: completedIds }
    }).sort({ order: 1 });

    if (nextLesson) {
      currentLessons.push({ courseId: course._id, courseTitle: course.title, lesson: nextLesson });
    }
  }

  // Attendance snapshot across all enrolled courses.
  const attendanceSessions = await Attendance.find({ courseId: { $in: courseIds }, 'records.studentId': studentId });
  const attendancePresent = attendanceSessions.filter((s) => {
    const record = s.records.find((r) => r.studentId.toString() === studentId);
    return record && (record.status === 'present' || record.status === 'late');
  }).length;

  // Overall learning progress across all courses.
  const totalLessonsAcrossCourses = await Lesson.countDocuments({ courseId: { $in: courseIds }, status: 'published' });
  const completedLessonsAcrossCourses = progressDocs.reduce((sum, p) => sum + p.completedLessonIds.length, 0);

  return {
    welcome: {
      name: student.name,
      message: `Welcome back, ${student.name.split(' ')[0]}!`
    },
    enrolledCourses: courses.map((c) => ({ id: c._id, title: c.title, thumbnailUrl: c.thumbnailUrl, status: c.status })),
    currentLessons,
    upcomingLiveClasses,
    assignments: openAssignments,
    quizzes: openQuizzes,
    examinations: openExams,
    recentGrades: recentGradedSubmissions.map((s) => ({
      submissionId: s._id,
      refType: s.refType,
      courseId: s.courseId,
      score: s.grade.score,
      totalMarks: s.grade.totalMarks,
      gradedAt: s.grade.gradedAt
    })),
    attendance: {
      totalSessions: attendanceSessions.length,
      present: attendancePresent,
      ratePercent: attendanceSessions.length > 0 ? Math.round((attendancePresent / attendanceSessions.length) * 100) : null
    },
    learningProgress: {
      enrolledCourseCount: courses.length,
      lessonsCompleted: completedLessonsAcrossCourses,
      lessonsTotal: totalLessonsAcrossCourses,
      completionPercent:
        totalLessonsAcrossCourses > 0
          ? Math.round((completedLessonsAcrossCourses / totalLessonsAcrossCourses) * 100)
          : 0
    },
    notifications: { recent: recentNotifications, unreadCount: unreadNotificationCount },
    certificates,
    messages: { unreadConversationCount }
  };
}

module.exports = { getDashboard };
