const ApiError = require('../utils/ApiError');
const tokens = require('../utils/tokens');

const TOKEN_TYPE = tokens.TYPES.CLASSROOM;
const MIN_TOKEN_TTL_SECONDS = 15 * 60; // never issue a token valid for less than 15 minutes
const POST_CLASS_BUFFER_SECONDS = 15 * 60; // stay valid a little past the scheduled end, in case class runs long

/**
 * Mints a short-lived JWT scoped to exactly one classroom and one
 * user, used only to authenticate the Socket.IO /classroom namespace
 * connection. This is what the client receives — never the
 * LiveClass.roomId itself, and never a token usable for any other
 * classroom or for the general REST API.
 */
function issueJoinToken(liveClass, user) {
  const scheduledEndMs = new Date(liveClass.scheduledAt).getTime() + liveClass.durationMinutes * 60 * 1000;
  const ttlSeconds = Math.max(
    MIN_TOKEN_TTL_SECONDS,
    Math.ceil((scheduledEndMs - Date.now()) / 1000) + POST_CLASS_BUFFER_SECONDS
  );

  return tokens.sign(
    TOKEN_TYPE,
    {
      liveClassId: liveClass._id.toString(),
      userId: user.id,
      role: user.role,
      // Display name travels inside the signed token so a participant can never impersonate someone else's name.
      name: user.name || null
    },
    ttlSeconds
  );
}

/**
 * Verifies a join token presented on Socket.IO handshake, confirming
 * it's a classroom_join token (not a regular access/refresh token)
 * and returning its claims. Throws on anything invalid or expired.
 */
function verifyJoinToken(token) {
  try {
    return tokens.verify(TOKEN_TYPE, token);
  } catch (err) {
    throw ApiError.unauthorized('Invalid or expired classroom join token');
  } // { liveClassId, userId, role }
}

module.exports = { issueJoinToken, verifyJoinToken };
