const http = require('http');
const { Server } = require('socket.io');

const env = require('./src/config/env');
const app = require('./src/app');
const { connectDB, disconnectDB } = require('./src/config/db');
const initSockets = require('./src/sockets');
const logger = require('./src/utils/logger');
const { verifyEmailTransport } = require('./src/utils/email.util');
const { startExamAutoSubmitJob, stopExamAutoSubmitJob } = require('./src/jobs/examAutoSubmit.job');
const { startReminderJobs, stopReminderJobs } = require('./src/jobs/reminders.job');
const { startBillingJobs, stopBillingJobs } = require('./src/jobs/billing.job');
const { startCertificateJobs, stopCertificateJobs } = require('./src/jobs/certificates.job');
const Certificate = require('./src/models/certificate.model');
const { ensureBillingIndexes } = require('./src/models/billing.model');
const { setIO } = require('./src/utils/socketRegistry');

const httpServer = http.createServer(app);

const io = new Server(httpServer, {
  cors: {
    origin: env.corsOrigins,
    credentials: true
  },
  maxHttpBufferSize: 1e6, // 1 MB per event: chat/signalling never needs more
  pingTimeout: 30000
});

// Make io accessible to controllers (req.app.get('io')) and to plain
// services that have no req, via the socketRegistry singleton — used
// by notificationService to push real-time in-app notifications from
// anywhere a notification gets created, not just from request handlers.
app.set('io', io);
setIO(io);

initSockets(io);

let serverInstance;

async function start() {
  await connectDB();
  await verifyEmailTransport();
  try {
    // The unique indexes are what make duplicate-payment protection real; autoIndex is off in production.
    const warnings = await ensureBillingIndexes();
    warnings.forEach((w) => logger.error(`BILLING INDEX WARNING: ${w}`));
  } catch (err) {
    logger.error(`Could not create billing indexes: ${err.message}. Refusing to start without duplicate-payment protection.`);
    process.exit(1);
  }
  try {
    // The unique certificateId index also makes public verification an indexed lookup.
    await Certificate.createIndexes();
  } catch (err) {
    logger.error(`CERTIFICATE INDEX WARNING: ${err.message}`);
  }
  startExamAutoSubmitJob();
  startReminderJobs();
  startBillingJobs();
  startCertificateJobs();

  serverInstance = httpServer.listen(env.port, () => {
    logger.info(`Server running in ${env.nodeEnv} mode on port ${env.port}`);
  });
}

async function shutdown(signal) {
  logger.info(`${signal} received. Shutting down gracefully...`);
  stopExamAutoSubmitJob();
  stopReminderJobs();
  stopBillingJobs();
  stopCertificateJobs();

  if (serverInstance) {
    serverInstance.close(async () => {
      await disconnectDB();
      logger.info('Server closed. Process exiting.');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }

  // Force-exit if graceful shutdown hangs
  setTimeout(() => {
    logger.error('Forced shutdown after timeout');
    process.exit(1);
  }, 10000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

process.on('unhandledRejection', (reason) => {
  logger.error(`Unhandled Rejection: ${reason instanceof Error ? reason.stack : reason}`);
});

process.on('uncaughtException', (err) => {
  logger.error(`Uncaught Exception: ${err.stack}`);
  process.exit(1);
});

start();
