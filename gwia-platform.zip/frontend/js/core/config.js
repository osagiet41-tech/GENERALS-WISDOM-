const c = window.APP_CONFIG || {};
export const config = Object.freeze({
  apiBase: (c.apiBase || '/api').replace(/\/$/, ''),
  socketUrl: c.socketUrl || '',
  institution: c.institution || 'Academy',
  locale: c.locale || 'en',
  defaultCurrency: c.defaultCurrency || 'NGN',
  iceServers: c.iceServers || [{ urls: 'stun:stun.l.google.com:19302' }]
});
