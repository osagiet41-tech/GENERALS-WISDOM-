const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const analyticsService = require('../services/analyticsService');

// GET /api/courses/:courseId/analytics
const getCourseAnalytics = asyncHandler(async (req, res) => {
  const analytics = await analyticsService.getCourseAnalytics(req.course._id);
  return ApiResponse.ok(res, analytics, 'Course analytics retrieved');
});

// GET /api/courses/:courseId/analytics/students/:studentId
const getStudentPerformance = asyncHandler(async (req, res) => {
  const performance = await analyticsService.getStudentPerformance(req.course._id, req.params.studentId);
  return ApiResponse.ok(res, performance, 'Student performance retrieved');
});

// GET /api/assignments/:id/analytics  (req.resource = Assignment)
const getAssignmentDistribution = asyncHandler(async (req, res) => {
  const distribution = await analyticsService.getResourceScoreDistribution('assignment', req.resource._id);
  return ApiResponse.ok(res, distribution, 'Score distribution retrieved');
});

// GET /api/quizzes/:id/analytics and /api/exams/:id/analytics (req.resource = Assessment)
const getAssessmentDistribution = asyncHandler(async (req, res) => {
  const distribution = await analyticsService.getResourceScoreDistribution(req.resource.kind, req.resource._id);
  return ApiResponse.ok(res, distribution, 'Score distribution retrieved');
});

module.exports = { getCourseAnalytics, getStudentPerformance, getAssignmentDistribution, getAssessmentDistribution };
