const express = require('express');
const controller = require('../controllers/messagingController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { uploadChatAttachment } = require('../config/multer');
const {
  startConversationValidator,
  sendMessageValidator,
  markAsReadValidator,
  searchMessagesValidator
} = require('../validators/messagingValidator');

const router = express.Router();
router.use(authMiddleware);

router.get('/conversations', controller.listConversations);
router.post('/conversations', validate(startConversationValidator), controller.startConversation);

router.get('/conversations/:conversationId/messages', controller.listMessages);
router.post(
  '/conversations/:conversationId/messages',
  uploadChatAttachment.array('files', 5),
  validate(sendMessageValidator),
  controller.sendMessage
);
router.put('/conversations/:conversationId/read', validate(markAsReadValidator), controller.markAsRead);

router.delete('/:messageId', controller.deleteMessage);

router.get('/search', validate(searchMessagesValidator), controller.searchMessages);
router.get('/presence', controller.getPresence);

module.exports = router;
