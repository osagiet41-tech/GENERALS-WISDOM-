import { h, mount, icon } from '../core/dom.js';
import { requireRole, homeFor } from '../core/session.js';
import { aiApi, AI_FEATURES } from '../api/ai.js';
import { createToolBar } from '../ui/shell.js';
import { buildForm } from '../ui/form.js';
import { errorState, empty } from '../ui/states.js';
import { toast } from '../ui/toast.js';

const user = await requireRole('student', 'teacher', 'admin'); const role = user.role === 'student' ? 'student' : 'teacher'; const features = AI_FEATURES[role];
const q = new URLSearchParams(location.search); const ctx = { ...(q.get('course') && { courseId: q.get('course') }), ...(q.get('lesson') && { lessonId: q.get('lesson') }) };
const out = h('section', { class: 'card', 'aria-live': 'polite' }, empty({ title: 'Your answer will appear here', message: 'Pick a tool on the left, fill in the details and press Generate.', iconName: 'bot' }));
const formBox = h('div'); const usage = h('span', { class: 'small muted' }); let active = null;
const picker = h('div', { class: 'feature-grid' }, features.map((f) => h('button', { type: 'button', 'aria-pressed': 'false', 'data-key': f.key, onclick: () => select(f) }, f.label)));
function select(f) {
  active = f; [...picker.children].forEach((b) => b.setAttribute('aria-pressed', b.dataset.key === f.key));
  const fields = f.fields.map((x) => ({ ...x, type: x.type === 'select' ? 'select' : x.type, options: x.options?.map((o) => (typeof o === 'string' ? { value: o, label: o } : o)), value: x.name === 'lessonId' ? ctx.lessonId : undefined, full: x.type === 'textarea' }));
  mount(formBox, h('h2', { style: 'font-size:1.1rem' }, f.label), buildForm({ grid: false, submitLabel: 'Generate', fields, onSubmit: async (v) => {
    const body = { ...ctx, ...v }; if (body.topics) body.topics = String(body.topics).split(',').map((s) => s.trim()).filter(Boolean);
    mount(out, h('p', { class: 'muted', role: 'status' }, h('span', { class: 'spinner' }), ' Thinking… this can take up to a minute.'));
    try { const { data } = await aiApi.generate(role, f.key, body); mount(out, renderResult(data), h('div', { class: 'row', style: 'margin-top:16px' }, h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: () => navigator.clipboard.writeText(toText(data)).then(() => toast.success('Copied.')) }, 'Copy'))); loadUsage(); }
    catch (e) { mount(out, errorState(e)); if (e.status === 429) toast.error('You have reached your AI limit for now.'); }
  } }));
}
const toText = (d) => (typeof d === 'string' ? d : d?.text || d?.content || JSON.stringify(d, null, 2));
function renderResult(d) {
  if (typeof d === 'string') return h('div', { class: 'ai-output' }, d);
  if (d && typeof d === 'object') return h('div', { class: 'ai-output' }, Object.entries(d).map(([k, v]) => h('div', null, h('h4', null, k.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase())), typeof v === 'string' ? v : Array.isArray(v) ? h('ol', null, v.map((it) => h('li', null, typeof it === 'string' ? it : h('pre', { style: 'white-space:pre-wrap;margin:0;font:inherit' }, JSON.stringify(it, null, 2))))) : h('pre', { style: 'white-space:pre-wrap;margin:0;font:inherit' }, JSON.stringify(v, null, 2)))));
  return h('div', { class: 'ai-output' }, String(d));
}
async function loadUsage() { try { const { data } = await aiApi.usage(); const used = data.used ?? data.requestsToday ?? data.count, limit = data.limit ?? data.dailyLimit ?? data.quota; usage.textContent = used != null && limit != null ? `${used} of ${limit} requests used` : ''; } catch { /* optional */ } }
document.body.append(h('div', { class: 'tool' }, createToolBar({ title: role === 'student' ? 'AI study assistant' : 'AI teaching assistant', backHref: homeFor(user.role), backLabel: 'Dashboard', extra: [usage] }),
  h('main', { class: 'ai-layout', id: 'main' }, h('div', { class: 'stack' }, h('section', { class: 'card stack-sm' }, h('h2', { style: 'font-size:1.05rem;margin:0' }, 'What do you need?'), picker), h('section', { class: 'card' }, formBox)), out)));
mount(formBox, h('p', { class: 'muted' }, 'Choose a tool above.')); select(features[0]); loadUsage();
