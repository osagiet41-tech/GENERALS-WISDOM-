const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const authService = require('../services/authService');

// POST /api/auth/register
const register = asyncHandler(async (req, res) => {
  const { name, email, password, role } = req.body;
  const user = await authService.register({ name, email, password, role });
  return ApiResponse.created(res, user, 'Registration successful. Please check your email to verify your account.');
});

// GET /api/auth/verify-email?token=...
const verifyEmail = asyncHandler(async (req, res) => {
  const { token } = req.query;
  const user = await authService.verifyEmail(token);
  return ApiResponse.ok(res, user, 'Email verified successfully');
});

// POST /api/auth/login
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const { user, accessToken, refreshToken } = await authService.login({ email, password });
  return ApiResponse.ok(res, { user, accessToken, refreshToken }, 'Login successful');
});

// POST /api/auth/refresh
const refresh = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  const tokens = await authService.refreshAccessToken(refreshToken);
  return ApiResponse.ok(res, tokens, 'Token refreshed');
});

// POST /api/auth/logout
const logout = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  await authService.logout(req.user.id, refreshToken);
  return ApiResponse.ok(res, null, 'Logged out successfully');
});

// POST /api/auth/forgot-password
const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  await authService.forgotPassword(email);
  return ApiResponse.ok(res, null, 'If that email exists, a password reset link has been sent.');
});

// POST /api/auth/reset-password
const resetPassword = asyncHandler(async (req, res) => {
  const { token, password } = req.body;
  await authService.resetPassword(token, password);
  return ApiResponse.ok(res, null, 'Password reset successfully. Please log in with your new password.');
});

// PUT /api/auth/change-password
const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  await authService.changePassword(req.user.id, currentPassword, newPassword);
  return ApiResponse.ok(res, null, 'Password changed successfully. Please log in again.');
});

// GET /api/auth/me
const me = asyncHandler(async (req, res) => {
  return ApiResponse.ok(res, req.user, 'Current user');
});

// PUT /api/auth/profile
const updateProfile = asyncHandler(async (req, res) => {
  const { name, phone, bio } = req.body;
  const user = await authService.updateProfile(req.user.id, { name, phone, bio });
  return ApiResponse.ok(res, user, 'Profile updated successfully');
});

// POST /api/auth/profile/picture
const uploadProfilePicture = asyncHandler(async (req, res) => {
  const user = await authService.updateProfilePicture(req.user.id, req.file);
  return ApiResponse.ok(res, user, 'Profile picture updated successfully');
});

module.exports = {
  register,
  verifyEmail,
  login,
  refresh,
  logout,
  forgotPassword,
  resetPassword,
  changePassword,
  me,
  updateProfile,
  uploadProfilePicture
};
