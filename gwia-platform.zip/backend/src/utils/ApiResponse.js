class ApiResponse {
  constructor(statusCode, data = null, message = 'Success', meta = null) {
    this.success = statusCode < 400;
    this.statusCode = statusCode;
    this.message = message;
    this.data = data;
    if (meta) this.meta = meta;
  }

  send(res) {
    return res.status(this.statusCode).json({
      success: this.success,
      message: this.message,
      data: this.data,
      ...(this.meta ? { meta: this.meta } : {})
    });
  }

  static ok(res, data, message = 'Success', meta = null) {
    return new ApiResponse(200, data, message, meta).send(res);
  }

  static created(res, data, message = 'Created') {
    return new ApiResponse(201, data, message).send(res);
  }

  static noContent(res, message = 'No content') {
    return new ApiResponse(204, null, message).send(res);
  }
}

module.exports = ApiResponse;
