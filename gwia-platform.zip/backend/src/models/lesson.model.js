const mongoose = require('mongoose');
const { Schema } = mongoose;

const imageSchema = new Schema(
  { url: { type: String, required: true }, caption: { type: String, default: '' }, uploadedAt: { type: Date, default: Date.now } },
  { _id: true }
);

const fileBlockSchema = new Schema(
  {
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true },
    mimeType: { type: String, required: true },
    size: { type: Number, required: true },
    uploadedAt: { type: Date, default: Date.now }
  },
  { _id: true }
);

const audioBlockSchema = new Schema(
  {
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true },
    mimeType: { type: String, required: true },
    size: { type: Number, required: true },
    duration: { type: Number, default: null },
    uploadedAt: { type: Date, default: Date.now }
  },
  { _id: true }
);

const externalResourceSchema = new Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 200 },
    url: { type: String, required: true, trim: true },
    description: { type: String, trim: true, maxlength: 1000, default: '' }
  },
  { _id: true }
);

const lessonSchema = new Schema(
  {
    // Denormalized ancestry (Course -> Subject -> Module) so ownership/enrollment
    // checks and listing queries don't need to walk the chain on every request.
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    subjectId: { type: Schema.Types.ObjectId, ref: 'Subject', required: true, index: true },
    moduleId: { type: Schema.Types.ObjectId, ref: 'CourseModule', required: true, index: true },

    title: { type: String, required: [true, 'Lesson title is required'], trim: true, maxlength: 200 },

    // --- Content types ---
    text: { type: String, default: '' }, // rich text / markdown body
    images: { type: [imageSchema], default: [] },
    pdfs: { type: [fileBlockSchema], default: [] },
    audio: { type: [audioBlockSchema], default: [] },
    video: {
      fileUrl: { type: String, default: null },
      mimeType: { type: String, default: null },
      size: { type: Number, default: null },
      duration: { type: Number, default: null } // seconds
    },
    externalResources: { type: [externalResourceSchema], default: [] },
    attachments: { type: [fileBlockSchema], default: [] }, // generic downloadable files (docs, slides, zips, etc.)

    // Lessons that must be completed before a student may access this one.
    prerequisiteLessonIds: [{ type: Schema.Types.ObjectId, ref: 'Lesson' }],

    order: { type: Number, default: 0 },
    status: { type: String, enum: ['draft', 'published'], default: 'draft' },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true }
  },
  { timestamps: true }
);

lessonSchema.index({ moduleId: 1, order: 1 });
lessonSchema.index({ courseId: 1, order: 1 });

module.exports = mongoose.model('Lesson', lessonSchema);
