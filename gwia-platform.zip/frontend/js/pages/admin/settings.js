import { h, icon } from '../../core/dom.js';
import { adminApi } from '../../api/admin.js';
import { pageHead, items, idOf, card } from '../../ui/page.js';
import { buildForm } from '../../ui/form.js';
import { withState, empty, busy } from '../../ui/states.js';
import { dataTable } from '../../ui/table.js';
import { confirmDialog } from '../../ui/modal.js';
import { toast } from '../../ui/toast.js';
import { fmtDateTime } from '../../core/format.js';

export default async function render() {
  const { data: s } = await adminApi.settings(); const backups = h('div');
  const load = () => withState(backups, () => adminApi.backups().then((r) => items(r.data)), (rows) => dataTable({ rows, caption: 'Backups', emptyState: empty({ title: 'No backups yet', iconName: 'shield' }), columns: [{ label: 'Created', render: (b) => fmtDateTime(b.createdAt) }, { label: 'File', render: (b) => b.fileName || b.filename || idOf(b) }, { label: 'Size', render: (b) => (b.size ? `${(b.size / 1048576).toFixed(1)} MB` : '—') }],
    actions: (b) => h('button', { class: 'btn btn-danger btn-sm', type: 'button', onclick: async () => { if (await confirmDialog({ title: 'Restore this backup?', message: 'Current data will be REPLACED by this backup. This cannot be undone.', confirmLabel: 'Restore backup', danger: true })) { try { await adminApi.restoreBackup(idOf(b)); toast.success('Backup restored.'); } catch (e) { toast.error(e.message); } } } }, 'Restore') }), { rows: 3 });
  load();
  return h('div', { class: 'stack' }, pageHead('Settings & backups'), h('div', { class: 'grid grid-2' },
    card('Platform settings', h('div', { style: 'padding:18px' }, buildForm({ submitLabel: 'Save settings', fields: [{ name: 'siteName', label: 'Site name', value: s.siteName, required: true }, { name: 'supportEmail', label: 'Support email', type: 'email', value: s.supportEmail }, { name: 'defaultCurrency', label: 'Default currency', value: s.defaultCurrency, maxlength: 3 },
      { name: 'maxUploadSizeMB', label: 'Max upload (MB)', type: 'number', min: 1, value: s.maxUploadSizeMB }, { name: 'registrationOpen', label: 'Registration open', type: 'checkbox', value: s.registrationOpen }, { name: 'maintenanceMode', label: 'Maintenance mode (blocks non-admins)', type: 'checkbox', value: s.maintenanceMode }],
      onSubmit: async (v) => { await adminApi.saveSettings({ ...v, ...(v.defaultCurrency && { defaultCurrency: v.defaultCurrency.toUpperCase() }) }); toast.success('Settings saved.'); } }))),
    card('Backups', backups, h('button', { class: 'btn btn-sm', type: 'button', onclick: async (e) => { try { await busy(e.currentTarget, () => adminApi.createBackup()); toast.success('Backup created.'); load(); } catch (err) { toast.error(err.message); } } }, icon('plus'), 'Create backup'))));
}
