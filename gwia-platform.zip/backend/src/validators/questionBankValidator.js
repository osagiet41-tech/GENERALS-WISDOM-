const { body } = require('express-validator');

const questionValidator = [
  body('type').isIn(['mcq', 'true_false', 'short_answer', 'essay']).withMessage('Invalid question type'),
  body('text').trim().notEmpty().withMessage('Question text is required'),
  body('options').optional().isArray().withMessage('options must be an array'),
  body('correctAnswer').exists().withMessage('correctAnswer is required'),
  body('marks').optional().isFloat({ min: 1 }),
  body('difficulty').optional().isIn(['easy', 'medium', 'hard']),
  body('tags').optional().isArray()
];

module.exports = { questionValidator };
