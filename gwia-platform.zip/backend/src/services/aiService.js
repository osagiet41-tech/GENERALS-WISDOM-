const env = require('../config/env');
const ApiError = require('../utils/ApiError');
const logger = require('../utils/logger');

// ---------------------------------------------------------------------
// Core provider call. The API key lives ONLY here, read from env at
// call time — never returned in any response, never sent to the
// frontend. If it's not configured, AI endpoints fail with a clear
// error rather than the whole app refusing to boot.
// ---------------------------------------------------------------------
async function callAI({ system, userPrompt, maxTokens }) {
  if (!env.ai.apiKey) {
    throw ApiError.internal('The AI teaching assistant is not configured on this server (missing AI_API_KEY).');
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), env.ai.timeoutMs);

  let response;
  try {
    response = await fetch(env.ai.apiUrl, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': env.ai.apiKey,
        'anthropic-version': env.ai.apiVersion
      },
      body: JSON.stringify({
        model: env.ai.model,
        max_tokens: maxTokens || env.ai.maxTokens,
        system,
        messages: [{ role: 'user', content: userPrompt }]
      }),
      signal: controller.signal
    });
  } catch (err) {
    if (err.name === 'AbortError') {
      throw ApiError.internal('The AI service took too long to respond. Please try again.');
    }
    logger.error(`AI provider request failed: ${err.message}`);
    throw ApiError.internal('Could not reach the AI service. Please try again shortly.');
  } finally {
    clearTimeout(timeout);
  }

  if (!response.ok) {
    const errorBody = await response.text().catch(() => '');
    logger.error(`AI provider returned ${response.status}: ${errorBody}`);
    throw ApiError.internal('The AI service returned an error. Please try again shortly.');
  }

  const data = await response.json();
  const text = (data.content || [])
    .filter((block) => block.type === 'text')
    .map((block) => block.text)
    .join('\n')
    .trim();

  return {
    text,
    usage: {
      inputTokens: data.usage?.input_tokens ?? null,
      outputTokens: data.usage?.output_tokens ?? null
    }
  };
}

function parseJsonResponse(text) {
  const cleaned = text.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '').trim();
  try {
    return JSON.parse(cleaned);
  } catch (err) {
    logger.error(`AI JSON response failed to parse: ${err.message}`);
    throw ApiError.internal('The AI returned a response in an unexpected format. Please try again.');
  }
}

// ---------------------------------------------------------------------
// Shared prompt-building blocks
// ---------------------------------------------------------------------

const BASE_SYSTEM = (contextBlock, audience) =>
  [
    `You are an AI teaching assistant embedded in an online learning platform, helping a ${audience}.`,
    contextBlock ? `Context the ${audience} is currently working in:\n${contextBlock}` : '',
    'Use this context to tailor your response appropriately (correct level of difficulty, relevant terminology, consistent with the subject/course) whenever it is relevant. If the request is unrelated to the context, just answer it directly.',
    'Be accurate. If you are not confident about a fact, say so rather than inventing one.'
  ]
    .filter(Boolean)
    .join('\n\n');

function explainPrompt({ concept }, contextBlock, audience) {
  return {
    system:
      BASE_SYSTEM(contextBlock, audience) +
      `\n\nExplain clearly and accurately, building from foundational ideas to the full concept. Use a concrete example or analogy where it helps. Keep it well-organized (short paragraphs or a few labeled steps), and match the depth to the class level given in the context, if any.`,
    userPrompt: `Explain this concept: ${concept}`
  };
}

function flashcardsPrompt({ topic, count }, contextBlock, audience) {
  const n = Math.min(Math.max(count || 10, 1), 30);
  return {
    system:
      BASE_SYSTEM(contextBlock, audience) +
      `\n\nGenerate exactly ${n} flashcards on the given topic. Respond with ONLY a JSON array, no markdown fences, no commentary, in this exact shape: [{"front": "...", "back": "..."}]. Each "front" is a short question or term; each "back" is a concise, accurate answer or definition.`,
    userPrompt: `Topic: ${topic}`,
    jsonMode: true
  };
}

function summarizePrompt({ text, length }, contextBlock, audience) {
  const targetLength = length || 'medium (roughly 150-250 words)';
  return {
    system:
      BASE_SYSTEM(contextBlock, audience) +
      `\n\nSummarize the given material faithfully — do not add facts that aren't present. Target length: ${targetLength}. Use short paragraphs or bullet points, whichever fits the content better.`,
    userPrompt: `Summarize the following:\n\n${text}`
  };
}

function questionSetPrompt({ topic, numQuestions, difficulty, questionTypes, marksPerQuestion }, contextBlock, audience) {
  const n = Math.min(Math.max(numQuestions || 5, 1), 30);
  const types = questionTypes && questionTypes.length > 0 ? questionTypes : ['mcq'];
  return {
    system:
      BASE_SYSTEM(contextBlock, audience) +
      `\n\nGenerate exactly ${n} questions on the given topic at ${difficulty || 'medium'} difficulty, using only these question types: ${types.join(', ')}. Respond with ONLY a JSON array, no markdown fences, no commentary, in this exact shape, matching the platform's question bank format:
[{
  "type": "mcq" | "true_false" | "short_answer" | "essay",
  "text": "the question text",
  "options": ["option A", "option B", ...],
  "correctAnswer": "the exact text of the correct option (for mcq/true_false) or a model answer (for short_answer/essay)",
  "marks": ${marksPerQuestion || 1},
  "difficulty": "easy" | "medium" | "hard"
}]
For "mcq", "correctAnswer" must exactly match one of the strings in "options" (not an index or letter) — this platform grades by comparing text values, not positions. For non-mcq types, "options" should be [] (or ["true","false"] for true_false).`,
    userPrompt: `Topic: ${topic}`,
    jsonMode: true
  };
}

// ---------------------------------------------------------------------
// Teacher feature registry
// ---------------------------------------------------------------------

const TEACHER_BUILDERS = {
  lessonPlan: ({ topic, durationMinutes, objectives }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'teacher') +
      `\n\nProduce a complete, classroom-ready lesson plan. Include: learning objectives, required materials, a warm-up/hook, a structured sequence of teaching activities with approximate timings that add up to the given duration, a formative check for understanding, and a closing/wrap-up. Use clear headings.`,
    userPrompt: `Topic: ${topic}\nDuration: ${durationMinutes || 45} minutes${objectives ? `\nDesired learning objectives: ${objectives}` : ''}`
  }),

  lessonNotes: ({ topic, depth }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'teacher') +
      `\n\nWrite lesson notes suitable for a teacher to teach from or a student to study from. Depth: ${depth || 'standard, covering all key points with brief explanations'}. Use headings and bullet points for scannability, and include a short worked example if the topic is procedural (e.g. a formula or method).`,
    userPrompt: `Topic: ${topic}`
  }),

  quiz: (params, contextBlock) => questionSetPrompt(params, contextBlock, 'teacher'),
  examQuestions: (params, contextBlock) => questionSetPrompt(params, contextBlock, 'teacher'),
  assessmentQuestions: (params, contextBlock) => questionSetPrompt(params, contextBlock, 'teacher'),

  assignment: ({ topic, instructions, totalMarks }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'teacher') +
      `\n\nDraft a complete student assignment: a clear title, detailed instructions for what the student must produce, any constraints (format/length), and a short note on what a strong submission looks like. Total marks available: ${totalMarks || 100}.`,
    userPrompt: `Topic: ${topic}${instructions ? `\nAdditional requirements from the teacher: ${instructions}` : ''}`
  }),

  markingGuide: ({ questionText, totalMarks }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'teacher') +
      `\n\nProduce a marking guide/rubric for grading student answers to the given question, worth ${totalMarks || 10} marks total. Break the marks down by what a correct/complete answer must contain (a mark scheme), and include guidance on partial credit for partially correct answers.`,
    userPrompt: `Question: ${questionText}`
  }),

  explainConcept: (params, contextBlock) => explainPrompt(params, contextBlock, 'teacher'),

  revisionMaterials: ({ topic, format }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'teacher') +
      `\n\nCreate revision material for students on the given topic, in this format: ${format || 'a concise revision sheet with key points, definitions, and common mistakes to avoid'}.`,
    userPrompt: `Topic: ${topic}`
  }),

  summary: (params, contextBlock) => summarizePrompt(params, contextBlock, 'teacher'),
  flashcards: (params, contextBlock) => flashcardsPrompt(params, contextBlock, 'teacher'),

  teachingActivities: ({ topic, classLevel, duration }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'teacher') +
      `\n\nSuggest 3-5 engaging classroom teaching activities for the given topic, suitable for class level: ${classLevel || 'as given in context, or general'}, each fitting within about ${duration || 15} minutes. For each activity, give: a name, a one-line description, materials needed, and the learning benefit.`,
    userPrompt: `Topic: ${topic}`
  }),

  learningObjectives: ({ topic, count }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'teacher') +
      `\n\nWrite ${count || 4} clear, measurable learning objectives for the given topic, each starting with an action verb (e.g. "Explain", "Calculate", "Compare") per standard learning-objective conventions (Bloom's taxonomy). Return them as a numbered list, nothing else.`,
    userPrompt: `Topic: ${topic}`
  })
};

// ---------------------------------------------------------------------
// Student feature registry
// ---------------------------------------------------------------------

const STUDENT_BUILDERS = {
  explainConcept: (params, contextBlock) => explainPrompt(params, contextBlock, 'student'),

  answerQuestion: ({ question }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'student') +
      `\n\nAnswer the student's question directly and clearly. If the question is ambiguous, answer the most likely interpretation and briefly note the assumption.`,
    userPrompt: question
  }),

  stepByStep: ({ problem }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'student') +
      `\n\nSolve the given problem with a full step-by-step walkthrough. Number each step, show the reasoning (not just the calculation), and state the final answer clearly at the end.`,
    userPrompt: `Problem: ${problem}`
  }),

  practiceQuestions: (params, contextBlock) => questionSetPrompt(params, contextBlock, 'student'),

  revisionPlan: ({ topics, daysAvailable, examDate }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'student') +
      `\n\nCreate a day-by-day revision plan across ${daysAvailable || 7} days${examDate ? ` leading up to ${examDate}` : ''}, covering all the listed topics with a sensible balance (more time on harder/larger topics), including short review/practice sessions and at least one full practice/mock session near the end.`,
    userPrompt: `Topics to cover: ${Array.isArray(topics) ? topics.join(', ') : topics}`
  }),

  summarizeLesson: (params, contextBlock) => {
    const built = summarizePrompt(params, contextBlock, 'student');
    return { ...built, userPrompt: 'Summarize the current lesson (see the lesson content excerpt in the context above).' };
  },

  flashcards: (params, contextBlock) => flashcardsPrompt(params, contextBlock, 'student'),

  hint: ({ question, studentAttempt }, contextBlock) => ({
    system:
      BASE_SYSTEM(contextBlock, 'student') +
      `\n\nYou must NOT reveal the final answer or solve the problem for the student, even if asked directly. Give ONE helpful hint that nudges their thinking in the right direction — point at the relevant concept, the next step to consider, or a mistake in their current approach. Keep it short (1-3 sentences). If they ask you to just give the answer, gently decline and offer another hint instead.`,
    userPrompt: `Question: ${question}${studentAttempt ? `\n\nThe student's attempt so far: ${studentAttempt}` : '\n\n(The student has not attempted it yet.)'}`
  })
};

async function generate(builders, featureKey, params, contextBlock) {
  const builder = builders[featureKey];
  if (!builder) {
    throw ApiError.badRequest(`Unknown AI feature: ${featureKey}`);
  }

  const { system, userPrompt, jsonMode, maxTokens } = builder(params, contextBlock);
  const { text, usage } = await callAI({ system, userPrompt, maxTokens });

  const result = jsonMode ? parseJsonResponse(text) : text;
  return { result, usage };
}

async function generateForTeacher(featureKey, params, contextBlock) {
  return generate(TEACHER_BUILDERS, featureKey, params, contextBlock);
}

async function generateForStudent(featureKey, params, contextBlock) {
  return generate(STUDENT_BUILDERS, featureKey, params, contextBlock);
}

module.exports = {
  TEACHER_BUILDERS,
  STUDENT_BUILDERS,
  generateForTeacher,
  generateForStudent
};
