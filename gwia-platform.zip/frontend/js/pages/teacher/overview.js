import { h } from '../../core/dom.js';
import { teacherApi } from '../../api/teacher.js';
import { pageHead, statCard, card, items, idOf } from '../../ui/page.js';
import { empty } from '../../ui/states.js';
import { dataTable, statusBadge } from '../../ui/table.js';
import { fmtPercent } from '../../core/format.js';

export default async function render({ user }) {
  const { data } = await teacherApi.courses(); const courses = items(data);
  const stats = await Promise.all(courses.slice(0, 12).map((c) => teacherApi.analytics(idOf(c)).then((r) => ({ c, a: r.data })).catch(() => ({ c, a: null }))));
  const sum = (f) => stats.reduce((n, s) => n + (f(s.a) || 0), 0);
  return h('div', { class: 'stack' }, pageHead(`Welcome, ${user.name.split(' ')[0]}`, 'Your courses at a glance.'),
    h('div', { class: 'grid grid-stats' }, statCard('Courses', courses.length), statCard('Students', sum((a) => a?.enrolledStudentCount)), statCard('Waiting for grading', sum((a) => a?.submissions?.pendingGrading), 'submissions'), statCard('Published', courses.filter((c) => c.status === 'published').length)),
    card('Course performance', dataTable({ rows: stats, rowKey: (r) => idOf(r.c), caption: 'Per course', emptyState: empty({ title: 'No courses yet', message: 'Create your first course to begin.', iconName: 'book', action: h('a', { class: 'btn', href: '#/courses' }, 'Create a course') }),
      columns: [{ label: 'Course', render: (r) => h('strong', null, r.c.title) }, { label: 'Status', render: (r) => statusBadge(r.c.status) }, { label: 'Students', render: (r) => r.a?.enrolledStudentCount ?? '—' },
        { label: 'Content', render: (r) => (r.a ? `${r.a.content.assignmentCount} assignments · ${r.a.content.quizCount} quizzes · ${r.a.content.examCount} exams` : '—') },
        { label: 'Pending grading', render: (r) => r.a?.submissions?.pendingGrading ?? '—' }, { label: 'Class average', render: (r) => fmtPercent(r.a?.classAverageScorePercent) }] })));
}
