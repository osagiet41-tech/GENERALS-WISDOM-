/**
 * NoSQL-injection defence.
 *
 * MongoDB operators arrive as object keys (`{"$ne": null}`, `?token[$ne]=x`). No legitimate request to
 * this API ever sends a key that starts with "$" or contains ".", so those keys are removed from
 * body, query and params before any controller sees them. express-validator `isString()` checks on
 * the sensitive fields (tokens, e-mail, password) are a second layer.
 *
 * Also normalises pagination parameters so `?limit=1000000` cannot be used to dump or stall the DB.
 */
const MAX_DEPTH = 10;

function clean(value, depth = 0) {
  if (depth > MAX_DEPTH) return undefined;
  if (Array.isArray(value)) return value.map((v) => clean(v, depth + 1));
  if (value && typeof value === 'object' && !(value instanceof Date) && !Buffer.isBuffer(value)) {
    const out = {};
    for (const key of Object.keys(value)) {
      if (key.startsWith('$') || key.includes('.') || key === '__proto__' || key === 'constructor' || key === 'prototype') continue;
      out[key] = clean(value[key], depth + 1);
    }
    return out;
  }
  return value;
}

function sanitizeRequest(req, res, next) {
  for (const part of ['body', 'query', 'params']) {
    if (req[part] && typeof req[part] === 'object') {
      const cleaned = clean(req[part]);
      // Mutate in place: in Express 4 req.query is a plain writable property, but in-place keeps references valid.
      for (const k of Object.keys(req[part])) delete req[part][k];
      Object.assign(req[part], cleaned);
    }
  }
  next();
}

const MAX_PAGE_SIZE = 100;

function normalizePagination(req, res, next) {
  const q = req.query || {};
  if (q.limit !== undefined) {
    const n = parseInt(q.limit, 10);
    q.limit = String(Number.isFinite(n) && n > 0 ? Math.min(n, MAX_PAGE_SIZE) : 20);
  }
  if (q.page !== undefined) {
    const n = parseInt(q.page, 10);
    q.page = String(Number.isFinite(n) && n > 0 ? Math.min(n, 100000) : 1);
  }
  next();
}

/** API responses can contain personal data and tokens: never let browsers or proxies cache them. */
function noStore(req, res, next) {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Pragma', 'no-cache');
  next();
}

module.exports = { sanitizeRequest, normalizePagination, noStore, clean, MAX_PAGE_SIZE };
