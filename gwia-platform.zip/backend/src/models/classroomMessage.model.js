const mongoose = require('mongoose');
const { Schema } = mongoose;

const classroomMessageSchema = new Schema(
  {
    liveClassId: { type: Schema.Types.ObjectId, ref: 'LiveClass', required: true, index: true },
    senderId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    senderRole: { type: String, enum: ['teacher', 'student'], required: true },

    type: { type: String, enum: ['chat', 'announcement', 'system'], default: 'chat' },
    text: { type: String, required: true, trim: true, maxlength: 2000 }
  },
  { timestamps: true }
);

classroomMessageSchema.index({ liveClassId: 1, createdAt: 1 });

module.exports = mongoose.model('ClassroomMessage', classroomMessageSchema);
