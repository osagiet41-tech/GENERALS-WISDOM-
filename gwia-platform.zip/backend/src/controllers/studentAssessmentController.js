const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const studentAssessmentService = require('../services/studentAssessmentService');
const examAttemptService = require('../services/examAttemptService');
const examResultService = require('../services/examResultService');

function makeControllers(kind) {
  // GET /api/student/courses/:courseId/quizzes|exams
  const list = asyncHandler(async (req, res) => {
    const items = await studentAssessmentService.listAssessments(kind, req.course._id, req.user.id);
    return ApiResponse.ok(res, items, `${kind === 'quiz' ? 'Quizzes' : 'Exams'} retrieved`);
  });

  // POST /api/student/quizzes|exams/:id/start — starts a new attempt or resumes an in-progress one
  const start = asyncHandler(async (req, res) => {
    const { attempt, resumed } = await examAttemptService.startOrResumeAttempt(req.resource, req.user);
    const view = await examAttemptService.getAttemptView(attempt);
    return ApiResponse.ok(res, view, resumed ? 'Resumed in-progress attempt' : 'Attempt started');
  });

  // GET /api/student/quizzes|exams/:id/attempt — current attempt state (for reload/resume, palette, timer)
  const getAttemptState = asyncHandler(async (req, res) => {
    const attempt = await examAttemptService.getInProgressAttempt(req.resource._id, req.user.id);
    if (!attempt) {
      throw ApiError.notFound('No in-progress attempt found. Start one first.');
    }
    const view = await examAttemptService.getAttemptView(attempt);
    return ApiResponse.ok(res, view, 'Attempt state retrieved');
  });

  // PUT /api/student/quizzes|exams/:id/attempt/save — auto-save / manual save of in-progress answers
  const saveProgress = asyncHandler(async (req, res) => {
    if (!Array.isArray(req.body.answers) || req.body.answers.length === 0) {
      throw ApiError.badRequest('answers must be a non-empty array');
    }

    const attempt = await examAttemptService.getInProgressAttempt(req.resource._id, req.user.id);
    if (!attempt) {
      throw ApiError.notFound('No in-progress attempt found. Start one first.');
    }

    const saved = await examAttemptService.saveProgress(attempt, req.resource, req.body.answers);
    const remainingSeconds = Math.floor(Math.max(0, saved.expiresAt.getTime() - Date.now()) / 1000);
    return ApiResponse.ok(res, { lastSavedAt: saved.lastSavedAt, remainingSeconds }, 'Progress saved');
  });

  // POST /api/student/quizzes|exams/:id/attempt/submit — final submission; locks the attempt against further edits
  const submit = asyncHandler(async (req, res) => {
    const attempt = await examAttemptService.getInProgressAttempt(req.resource._id, req.user.id);
    if (!attempt) {
      throw ApiError.notFound('No in-progress attempt found. Start one first.');
    }

    // Apply any final answer changes sent along with the submit call, same as a save.
    if (Array.isArray(req.body.answers) && req.body.answers.length > 0) {
      await examAttemptService.saveProgress(attempt, req.resource, req.body.answers);
    }

    const { submission } = await examAttemptService.finalizeAttempt(attempt, req.resource, { auto: false });
    const result = examResultService.buildResult(submission, req.resource);
    return ApiResponse.created(res, result, 'Submitted successfully');
  });

  // GET /api/student/quizzes|exams/:id/result/:submissionId
  const getResult = asyncHandler(async (req, res) => {
    const result = await examResultService.getResult(req.resource, req.user.id, req.params.submissionId);
    return ApiResponse.ok(res, result, 'Result retrieved');
  });

  // GET /api/student/quizzes|exams/:id/history — complete examination history for this student
  const getHistory = asyncHandler(async (req, res) => {
    const history = await examResultService.getHistory(req.resource, req.user.id);
    return ApiResponse.ok(res, history, 'Examination history retrieved');
  });

  return { list, start, getAttemptState, saveProgress, submit, getResult, getHistory };
}

module.exports = {
  quiz: makeControllers('quiz'),
  exam: makeControllers('exam')
};
