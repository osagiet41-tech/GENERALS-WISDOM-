const { body } = require('express-validator');

const createCourseValidator = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 200 }),
  body('description').optional().trim().isLength({ max: 5000 }),
  body('category').optional().trim(),
  body('price').optional().isFloat({ min: 0 }).withMessage('Price must be a non-negative number'),
  body('currency').optional({ nullable: true }).isLength({ min: 3, max: 3 }).withMessage('currency must be a 3-letter code'),
  body('prices').optional().isArray(),
  body('prices.*.currency').optional().isLength({ min: 3, max: 3 }),
  body('prices.*.amount').optional().isFloat({ min: 0 }),
  body('includedInSubscription').optional().isBoolean(),
  body('certificate').optional().isObject(),
  body('certificate.enabled').optional().isBoolean(),
  body('certificate.minLessonCompletionPercent').optional().isInt({ min: 1, max: 100 }),
  body('certificate.minAverageScorePercent').optional({ nullable: true }).isInt({ min: 0, max: 100 }),
  body('certificate.requireAllAssessments').optional().isBoolean(),
  body('certificate.minAttendancePercent').optional({ nullable: true }).isInt({ min: 0, max: 100 }),
  body('certificate.showScore').optional().isBoolean(),
  body('durationHours').optional().isFloat({ min: 0 }).withMessage('durationHours must be a non-negative number'),
  body('level').optional().isIn(['beginner', 'intermediate', 'advanced']),
  body('learningObjectives').optional().isArray().withMessage('learningObjectives must be an array'),
  body('learningObjectives.*').optional().isString().isLength({ max: 500 }),
  body('prerequisites').optional().isArray().withMessage('prerequisites must be an array'),
  body('prerequisites.*').optional().isString().isLength({ max: 500 })
];

const updateCourseValidator = [
  body('title').optional().trim().isLength({ min: 1, max: 200 }),
  body('description').optional().trim().isLength({ max: 5000 }),
  body('price').optional().isFloat({ min: 0 }),
  body('currency').optional({ nullable: true }).isLength({ min: 3, max: 3 }).withMessage('currency must be a 3-letter code'),
  body('prices').optional().isArray(),
  body('prices.*.currency').optional().isLength({ min: 3, max: 3 }),
  body('prices.*.amount').optional().isFloat({ min: 0 }),
  body('includedInSubscription').optional().isBoolean(),
  body('certificate').optional().isObject(),
  body('certificate.enabled').optional().isBoolean(),
  body('certificate.minLessonCompletionPercent').optional().isInt({ min: 1, max: 100 }),
  body('certificate.minAverageScorePercent').optional({ nullable: true }).isInt({ min: 0, max: 100 }),
  body('certificate.requireAllAssessments').optional().isBoolean(),
  body('certificate.minAttendancePercent').optional({ nullable: true }).isInt({ min: 0, max: 100 }),
  body('certificate.showScore').optional().isBoolean(),
  body('durationHours').optional().isFloat({ min: 0 }),
  body('level').optional().isIn(['beginner', 'intermediate', 'advanced']),
  body('learningObjectives').optional().isArray(),
  body('learningObjectives.*').optional().isString().isLength({ max: 500 }),
  body('prerequisites').optional().isArray(),
  body('prerequisites.*').optional().isString().isLength({ max: 500 }),
  body('status').optional().isIn(['draft', 'published', 'archived'])
];

const subjectValidator = [
  body('title').trim().notEmpty().withMessage('Subject title is required').isLength({ max: 200 }),
  body('description').optional().trim().isLength({ max: 2000 }),
  body('order').optional().isInt({ min: 0 })
];

const addCoTeacherValidator = [
  body('teacherId').isMongoId().withMessage('A valid teacherId is required')
];

module.exports = {
  createCourseValidator,
  updateCourseValidator,
  subjectValidator,
  addCoTeacherValidator
};
