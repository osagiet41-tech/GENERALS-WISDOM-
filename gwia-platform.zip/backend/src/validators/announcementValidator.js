const { body } = require('express-validator');

const announcementValidator = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 200 }),
  body('content').trim().notEmpty().withMessage('Content is required'),
  body('pinned').optional().isBoolean()
];

module.exports = { announcementValidator };
