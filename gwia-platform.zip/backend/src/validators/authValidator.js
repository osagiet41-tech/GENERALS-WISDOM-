const { body, query } = require('express-validator');
const { ROLES } = require('../models/User');

// Secure password policy: min 8 chars, at least one uppercase, one
// lowercase, one number, and one special character.
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
const PASSWORD_MESSAGE =
  'Password must be at least 8 characters and include an uppercase letter, a lowercase letter, a number, and a special character';

// bcrypt only reads the first 72 BYTES; anything longer is silently ignored, and unbounded input is a CPU-DoS vector.
const withinBcryptLimit = (value) => typeof value === 'string' && Buffer.byteLength(value, 'utf8') <= 72;
const PASSWORD_LIMIT_MESSAGE = 'Password must be at most 72 bytes long';
const COMMON_PASSWORDS = new Set(['password1!', 'password123!', 'qwerty123!', 'welcome123!', 'admin123!', 'passw0rd!', 'p@ssw0rd', 'p@ssword1', 'abc12345!', 'letmein123!']);
const notCommon = (value) => !COMMON_PASSWORDS.has(String(value).toLowerCase());
const passwordRules = (chain) =>
  chain
    .isString().withMessage('Password must be text')
    .bail()
    .matches(PASSWORD_REGEX).withMessage(PASSWORD_MESSAGE)
    .bail()
    .custom(withinBcryptLimit).withMessage(PASSWORD_LIMIT_MESSAGE)
    .bail()
    .custom(notCommon).withMessage('That password is too common. Choose a different one');

const registerValidator = [
  body('name')
    .isString().withMessage('Name must be text')
    .bail()
    .trim()
    .notEmpty()
    .withMessage('Name is required')
    .isLength({ max: 120 })
    .withMessage('Name must be under 120 characters'),
  body('email').trim().isEmail().withMessage('A valid email is required').normalizeEmail(),
  passwordRules(body('password')),
  body('role')
    .optional()
    .isIn(['teacher', 'student'])
    .withMessage('Role must be teacher or student at registration') // admin accounts are provisioned separately, never via public registration
];

const loginValidator = [
  body('email').isString().trim().isEmail().withMessage('A valid email is required').normalizeEmail(),
  body('password').isString().withMessage('Password is required').bail().notEmpty().withMessage('Password is required').bail().custom(withinBcryptLimit).withMessage('Invalid email or password')
];

const forgotPasswordValidator = [
  body('email').isString().trim().isEmail().withMessage('A valid email is required').normalizeEmail()
];

const resetPasswordValidator = [
  body('token').isString().withMessage('Reset token is required').bail().isLength({ min: 20, max: 200 }).withMessage('Reset token is invalid'),
  passwordRules(body('password'))
];

const changePasswordValidator = [
  body('currentPassword').isString().withMessage('Current password is required').bail().notEmpty().withMessage('Current password is required').bail().custom(withinBcryptLimit).withMessage('Current password is incorrect'),
  passwordRules(body('newPassword'))
];

// Tokens must be plain strings: an object here is a NoSQL-injection attempt ({"$ne": null}).
const verifyEmailValidator = [
  query('token').isString().withMessage('Verification token is required').bail().isLength({ min: 20, max: 200 }).withMessage('Verification token is invalid')
];

const refreshValidator = [
  body('refreshToken').isString().withMessage('refreshToken is required').bail().isLength({ min: 20, max: 4096 }).withMessage('refreshToken is invalid')
];

const logoutValidator = [body('refreshToken').optional({ nullable: true }).isString().isLength({ max: 4096 })];

const updateProfileValidator = [
  body('name').optional().isString().trim().isLength({ min: 1, max: 120 }).withMessage('Name must be 1-120 characters'),
  body('phone').optional().isString().trim().isLength({ max: 30 }).withMessage('Phone must be under 30 characters'),
  body('bio').optional().isString().trim().isLength({ max: 500 }).withMessage('Bio must be under 500 characters')
];

module.exports = {
  registerValidator,
  loginValidator,
  forgotPasswordValidator,
  resetPasswordValidator,
  changePasswordValidator,
  updateProfileValidator,
  verifyEmailValidator,
  refreshValidator,
  logoutValidator,
  PASSWORD_REGEX
};
