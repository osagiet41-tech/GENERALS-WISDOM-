const Attendance = require('../models/attendance.model');
const ApiError = require('../utils/ApiError');
const certificateService = require('./certificateService');

async function createOrUpdateSession(course, teacherId, data) {
  // One attendance document per course + session date; upsert so a
  // teacher can mark attendance incrementally without duplicating rows.
  const sessionDate = new Date(data.sessionDate);

  const enrolledIds = new Set(course.enrolledStudentIds.map((id) => id.toString()));
  const invalidStudent = data.records.find((r) => !enrolledIds.has(r.studentId));
  if (invalidStudent) {
    throw ApiError.badRequest(`Student ${invalidStudent.studentId} is not enrolled in this course`);
  }

  let attendance = await Attendance.findOne({
    courseId: course._id,
    liveClassId: data.liveClassId || null,
    sessionDate
  });

  if (!attendance) {
    attendance = new Attendance({
      courseId: course._id,
      liveClassId: data.liveClassId || null,
      sessionDate,
      teacherId,
      records: []
    });
  }

  for (const record of data.records) {
    const existing = attendance.records.find((r) => r.studentId.toString() === record.studentId);
    if (existing) {
      existing.status = record.status;
      existing.note = record.note || null;
      existing.markedAt = new Date();
    } else {
      attendance.records.push({
        studentId: record.studentId,
        status: record.status,
        note: record.note || null,
        markedAt: new Date()
      });
    }
  }

  await attendance.save();
  // Attendance can be a certificate requirement: re-check the affected students in the background.
  data.records.forEach((r) => certificateService.queueEvaluation(r.studentId, course._id));
  return attendance;
}

async function updateSingleRecord(attendance, studentId, status, note) {
  const record = attendance.records.find((r) => r.studentId.toString() === studentId);
  if (!record) {
    throw ApiError.notFound('No attendance record found for this student in this session');
  }
  record.status = status;
  record.note = note || null;
  record.markedAt = new Date();
  await attendance.save();
  certificateService.queueEvaluation(studentId, attendance.courseId);
  return attendance;
}

async function listSessions(courseId, { from, to } = {}) {
  const filter = { courseId };
  if (from || to) {
    filter.sessionDate = {};
    if (from) filter.sessionDate.$gte = new Date(from);
    if (to) filter.sessionDate.$lte = new Date(to);
  }
  return Attendance.find(filter).sort({ sessionDate: -1 });
}

async function getStudentAttendanceSummary(courseId, studentId) {
  const sessions = await Attendance.find({ courseId, 'records.studentId': studentId });

  const summary = { present: 0, absent: 0, late: 0, excused: 0, total: sessions.length };
  for (const session of sessions) {
    const record = session.records.find((r) => r.studentId.toString() === studentId);
    if (record) summary[record.status] += 1;
  }
  summary.attendanceRate =
    summary.total > 0 ? Math.round(((summary.present + summary.late) / summary.total) * 100) : 0;

  return summary;
}

module.exports = { createOrUpdateSession, updateSingleRecord, listSessions, getStudentAttendanceSummary };
