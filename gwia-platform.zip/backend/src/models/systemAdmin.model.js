const mongoose = require('mongoose');
const { Schema } = mongoose;

const auditLogSchema = new Schema(
  {
    actorId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    action: { type: String, required: true, trim: true, index: true },
    targetType: { type: String, required: true, trim: true },
    targetId: { type: Schema.Types.ObjectId, default: null },

    meta: { type: Schema.Types.Mixed, default: {} },
    ipAddress: { type: String, default: null }
  },
  { timestamps: true }
);

auditLogSchema.index({ createdAt: -1 });
auditLogSchema.index({ actorId: 1, createdAt: -1 });

const settingsSchema = new Schema(
  {
    siteName: { type: String, default: 'Online Learning Platform', trim: true, maxlength: 200 },
    registrationOpen: { type: Boolean, default: true },
    maintenanceMode: { type: Boolean, default: false },
    defaultCurrency: { type: String, default: 'USD', uppercase: true, trim: true, maxlength: 3 },
    supportEmail: { type: String, default: null, trim: true },
    maxUploadSizeMB: { type: Number, default: 50, min: 1 },
    updatedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
  },
  { timestamps: true }
);

const backupSchema = new Schema(
  {
    fileName: { type: String, required: true },
    filePath: { type: String, required: true },
    sizeBytes: { type: Number, default: null },

    status: {
      type: String,
      enum: ['in_progress', 'completed', 'failed'],
      default: 'in_progress',
      index: true
    },
    errorMessage: { type: String, default: null },

    triggeredBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    completedAt: { type: Date, default: null },

    restoredAt: { type: Date, default: null },
    restoredBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
  },
  { timestamps: true }
);

backupSchema.index({ createdAt: -1 });

module.exports = {
  AuditLog: mongoose.model('AuditLog', auditLogSchema),
  Settings: mongoose.model('Settings', settingsSchema),
  Backup: mongoose.model('Backup', backupSchema)
};
