const mongoose = require('mongoose');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { Course } = require('../models/course.model');
const { ForumPost, ForumReport } = require('../models/forum.model');

function computeAccess(user, course) {
  const isEnrolled = course.enrolledStudentIds.some((id) => id.toString() === user.id);
  const isTeacherOfCourse = course.teacherIds.some((id) => id.toString() === user.id);
  const isAdmin = user.role === 'admin';

  const canParticipate = isAdmin || isTeacherOfCourse || isEnrolled;
  const isModerator = isAdmin || isTeacherOfCourse;

  return { canParticipate, isModerator };
}

function verifyCourseForumAccess() {
  return asyncHandler(async (req, res, next) => {
    const { courseId } = req.params;
    if (!courseId || !mongoose.Types.ObjectId.isValid(courseId)) {
      throw ApiError.badRequest('A valid courseId is required');
    }

    const course = await Course.findById(courseId);
    if (!course) {
      throw ApiError.notFound('Course not found');
    }

    const { canParticipate, isModerator } = computeAccess(req.user, course);
    if (!canParticipate) {
      throw ApiError.forbidden("You do not have access to this course's discussion forum");
    }

    req.course = course;
    req.isForumModerator = isModerator;
    next();
  });
}

function verifyPostAccess(paramName = 'id') {
  return asyncHandler(async (req, res, next) => {
    const postId = req.params[paramName];
    if (!postId || !mongoose.Types.ObjectId.isValid(postId)) {
      throw ApiError.badRequest(`A valid ${paramName} is required`);
    }

    const post = await ForumPost.findById(postId);
    if (!post) {
      throw ApiError.notFound('Post not found');
    }

    const course = await Course.findById(post.courseId);
    if (!course) {
      throw ApiError.notFound('Parent course not found');
    }

    const { canParticipate, isModerator } = computeAccess(req.user, course);
    if (!canParticipate) {
      throw ApiError.forbidden("You do not have access to this course's discussion forum");
    }

    req.post = post;
    req.course = course;
    req.isForumModerator = isModerator;
    next();
  });
}

/**
 * For /api/forum-reports/:reportId/review — loads the report by id,
 * resolves its course, and applies the same moderator check so only a
 * teacher of that course (or an admin) can act on it.
 */
function verifyReportAccess(paramName = 'reportId') {
  return asyncHandler(async (req, res, next) => {
    const reportId = req.params[paramName];
    if (!reportId || !mongoose.Types.ObjectId.isValid(reportId)) {
      throw ApiError.badRequest(`A valid ${paramName} is required`);
    }

    const report = await ForumReport.findById(reportId);
    if (!report) {
      throw ApiError.notFound('Report not found');
    }

    const course = await Course.findById(report.courseId);
    if (!course) {
      throw ApiError.notFound('Parent course not found');
    }

    const { isModerator } = computeAccess(req.user, course);

    req.report = report;
    req.course = course;
    req.isForumModerator = isModerator;
    next();
  });
}

module.exports = { verifyCourseForumAccess, verifyPostAccess, verifyReportAccess };
