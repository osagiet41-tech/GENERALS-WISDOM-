import { h, icon } from '../core/dom.js';
let region;
function getRegion() { return region ||= document.body.appendChild(h('div', { class: 'toasts', role: 'region', 'aria-label': 'Notifications' })); }
function show(type, message, ms = 5000) {
  const el = h('div', { class: `toast ${type}`, role: type === 'error' ? 'alert' : 'status' },
    icon(type === 'success' ? 'check' : type === 'error' ? 'alert' : 'bell'), h('div', { class: 'msg' }, message),
    h('button', { class: 'btn btn-ghost btn-sm btn-icon', 'aria-label': 'Dismiss', onclick: () => el.remove() }, icon('x')));
  getRegion().append(el); if (ms) setTimeout(() => el.remove(), ms);
}
export const toast = { success: (m) => show('success', m), error: (m) => show('error', m, 8000), info: (m) => show('info', m) };
