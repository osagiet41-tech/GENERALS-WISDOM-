const express = require('express');
const controller = require('../controllers/attendanceController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership, verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { markAttendanceValidator, updateRecordValidator } = require('../validators/attendanceValidator');
const Attendance = require('../models/attendance.model');

const nestedRouter = express.Router({ mergeParams: true });
nestedRouter.use(authMiddleware, requireTeacherOrAdmin);
nestedRouter.get('/', verifyCourseOwnership(), controller.listSessions);
nestedRouter.post('/', verifyCourseOwnership(), validate(markAttendanceValidator), controller.markAttendance);
nestedRouter.get('/students/:studentId', verifyCourseOwnership(), controller.getStudentSummary);

const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);
itemRouter.put(
  '/:id/students/:studentId',
  verifyResourceOwnership(Attendance, 'id'),
  validate(updateRecordValidator),
  controller.updateRecord
);

module.exports = { nestedRouter, itemRouter };
