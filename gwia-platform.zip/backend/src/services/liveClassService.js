const LiveClass = require('../models/liveClass.model');
const ApiError = require('../utils/ApiError');

async function scheduleLiveClass(courseId, teacherId, data) {
  return LiveClass.create({
    courseId,
    subjectId: data.subjectId || null,
    title: data.title,
    description: data.description || '',
    teacherId,
    scheduledAt: data.scheduledAt,
    durationMinutes: data.durationMinutes,
    meetingUrl: data.meetingUrl || null,
    settings: {
      chatEnabled: data.chatEnabled !== undefined ? data.chatEnabled : true,
      studentMicEnabledByDefault: !!data.studentMicEnabledByDefault,
      studentCameraEnabledByDefault: !!data.studentCameraEnabledByDefault,
      studentScreenShareAllowed: !!data.studentScreenShareAllowed
    }
  });
}

async function updateLiveClass(liveClass, updates) {
  if (liveClass.status === 'completed' || liveClass.status === 'cancelled') {
    throw ApiError.badRequest(`Cannot modify a ${liveClass.status} live class`);
  }

  const allowed = ['title', 'description', 'scheduledAt', 'durationMinutes', 'meetingUrl', 'subjectId'];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      liveClass[field] = updates[field];
    }
  }
  await liveClass.save();
  return liveClass;
}

async function cancelLiveClass(liveClass) {
  liveClass.status = 'cancelled';
  await liveClass.save();
  return liveClass;
}

async function startLiveClass(liveClass) {
  liveClass.status = 'live';
  liveClass.timer.actualStartedAt = new Date();
  await liveClass.save();
  return liveClass;
}

async function endLiveClass(liveClass, recordingRef) {
  liveClass.status = 'completed';
  liveClass.timer.actualEndedAt = new Date();
  if (recordingRef) liveClass.recordingRef = recordingRef;
  await liveClass.save();
  return liveClass;
}

async function listLiveClasses(courseId, { upcoming } = {}) {
  const filter = { courseId };
  if (upcoming) filter.scheduledAt = { $gte: new Date() };
  return LiveClass.find(filter, '-roomId').sort({ scheduledAt: 1 });
}

module.exports = {
  scheduleLiveClass,
  updateLiveClass,
  cancelLiveClass,
  startLiveClass,
  endLiveClass,
  listLiveClasses
};
