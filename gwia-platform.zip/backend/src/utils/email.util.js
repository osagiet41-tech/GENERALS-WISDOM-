const nodemailer = require('nodemailer');
const env = require('../config/env');
const logger = require('./logger');

const transporter = nodemailer.createTransport({
  host: env.email.host,
  port: env.email.port,
  secure: env.email.port === 465,
  auth: {
    user: env.email.user,
    pass: env.email.password
  }
});

async function verifyEmailTransport() {
  try {
    await transporter.verify();
    logger.info('Email transporter verified and ready');
  } catch (err) {
    logger.error(`Email transporter verification failed: ${err.message}`);
  }
}

async function sendEmail({ to, subject, html, text, attachments }) {
  try {
    const info = await transporter.sendMail({
      from: env.email.from,
      to,
      subject,
      text,
      html,
      attachments
    });
    logger.info(`Email sent to ${to} (messageId: ${info.messageId})`);
    return info;
  } catch (err) {
    logger.error(`Failed to send email to ${to}: ${err.message}`);
    throw err;
  }
}

module.exports = { transporter, sendEmail, verifyEmailTransport };
