import { api, download } from '../core/http.js';
export const adminApi = {
  overview: () => api.get('/admin/dashboard/overview'), revenue: (q) => api.get('/admin/dashboard/revenue-trend', q), engagement: () => api.get('/admin/dashboard/engagement'), coursePerformance: () => api.get('/admin/dashboard/course-performance'),
  users: (q) => api.get('/admin/users', q), createUser: (b) => api.post('/admin/users', b), setRole: (id, role) => api.put(`/admin/users/${id}/role`, { role }), user: (id) => api.get(`/admin/users/${id}`), suspend: (id, reason) => api.post(`/admin/users/${id}/suspend`, { reason }), restore: (id) => api.post(`/admin/users/${id}/restore`),
  courses: (q) => api.get('/admin/courses', q), setCourseStatus: (id, status) => api.put(`/admin/courses/${id}/status`, { status }),
  payments: (q) => api.get('/admin/payments', q), setPaymentStatus: (id, status) => api.put(`/admin/payments/${id}/status`, { status }), verifyPayment: (id) => api.post(`/admin/payments/${id}/verify`), receiptPdf: (id) => download(`/admin/payments/${id}/receipt.pdf`, `receipt-${id}.pdf`),
  plans: () => api.get('/admin/plans'), createPlan: (b) => api.post('/admin/plans', b), updatePlan: (id, b) => api.put(`/admin/plans/${id}`, b),
  discounts: (q) => api.get('/admin/discount-codes', q), createDiscount: (b) => api.post('/admin/discount-codes', b), updateDiscount: (id, b) => api.put(`/admin/discount-codes/${id}`, b),
  subscriptions: (q) => api.get('/admin/subscriptions', q), cancelSubscription: (id) => api.post(`/admin/subscriptions/${id}/cancel`), extendSubscription: (id, endDate) => api.put(`/admin/subscriptions/${id}/extend`, { endDate }),
  report: (type, q) => api.get(`/admin/reports/${type}`, q), exportReport: (type, q) => download(`/admin/reports/${type}/export`, `${type}-report.xlsx`, q),
  auditLogs: (q) => api.get('/admin/audit-logs', q), settings: () => api.get('/admin/settings'), saveSettings: (b) => api.put('/admin/settings', b),
  backups: () => api.get('/admin/backups'), createBackup: () => api.post('/admin/backups'), restoreBackup: (id) => api.post(`/admin/backups/${id}/restore`, { confirm: true })
};
