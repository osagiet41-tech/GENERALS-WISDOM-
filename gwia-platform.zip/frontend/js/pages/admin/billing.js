import { h, icon } from '../../core/dom.js';
import { adminApi } from '../../api/admin.js';
import { pageHead, items, idOf } from '../../ui/page.js';
import { tabs } from '../../ui/tabs.js';
import { withState, empty } from '../../ui/states.js';
import { dataTable, statusBadge } from '../../ui/table.js';
import { listView } from '../shared/listView.js';
import { openModal } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { ApiError } from '../../core/http.js';
import { fmtMoney, fmtDate } from '../../core/format.js';

const parsePrices = (txt) => (txt || '').split('\n').map((l) => l.trim()).filter(Boolean).map((l) => { const [c, a] = l.split(/[\s:=,]+/); if (!/^[A-Za-z]{3}$/.test(c) || !(Number(a) >= 0)) throw new ApiError(400, `Bad price line “${l}”. Use e.g. NGN 5000`, [{ field: 'prices', message: 'Format: CODE amount, one per line' }]); return { currency: c.toUpperCase(), amountMinor: Math.round(Number(a) * 100) }; });
const priceText = (arr = [], key = 'amountMinor') => arr.map((p) => `${p.currency} ${p[key] / 100}`).join('\n');

export default async function render() {
  return h('div', { class: 'stack' }, pageHead('Plans & discounts'), tabs([{ id: 'p', label: 'Plans', render: plans }, { id: 'd', label: 'Discount codes', render: discounts }]));
}
function plans(panel) {
  let reload;
  const edit = (p) => { const m = openModal({ title: p ? `Edit ${p.name}` : 'New plan', size: 'lg', body: buildForm({ submitLabel: 'Save plan', onCancel: () => m.close(), fields: [
    { name: 'code', label: 'Code', required: true, value: p?.code, hint: 'Letters, digits, hyphens. Cannot change later.' }, { name: 'name', label: 'Name', required: true, value: p?.name },
    { name: 'billingCycle', label: 'Billing cycle', type: 'select', value: p?.billingCycle || 'monthly', options: ['monthly', 'annual'].map((v) => ({ value: v, label: v })) }, { name: 'trialDays', label: 'Free trial days', type: 'number', min: 0, max: 90, value: p?.trialDays ?? 0 },
    { name: 'prices', label: 'Prices (one per line: CURRENCY amount)', type: 'textarea', rows: 3, required: true, full: true, value: priceText(p?.prices), hint: 'Example: NGN 5000 and USD 10. Stored in kobo/cents.' },
    { name: 'features', label: 'Features (one per line)', type: 'textarea', rows: 4, full: true, value: (p?.features || []).join('\n') }, { name: 'description', label: 'Description', full: true, value: p?.description }, { name: 'active', label: 'Active (visible to buyers)', type: 'checkbox', value: p?.active ?? true }],
    onSubmit: async (v) => { const body = { ...v, prices: parsePrices(v.prices), features: (v.features || '').split('\n').map((s) => s.trim()).filter(Boolean), trialDays: v.trialDays ?? 0 }; if (p) { delete body.code; delete body.billingCycle; } p ? await adminApi.updatePlan(idOf(p), body) : await adminApi.createPlan(body); m.close(); toast.success('Plan saved.'); reload(); } }) }); };
  reload = withState(panel, () => adminApi.plans().then((r) => items(r.data)), (rows) => h('div', { class: 'stack' }, h('div', null, h('button', { class: 'btn', type: 'button', onclick: () => edit(null) }, icon('plus'), 'New plan')),
    h('div', { class: 'card card-flush' }, dataTable({ rows, caption: 'Plans', emptyState: empty({ title: 'No plans yet', iconName: 'card' }), columns: [{ label: 'Plan', render: (p) => h('div', null, h('strong', null, p.name), h('div', { class: 'small muted' }, p.code)) }, { label: 'Cycle', key: 'billingCycle' },
      { label: 'Prices', render: (p) => (p.prices || []).map((x) => fmtMoney(x.amountMinor, x.currency, { minor: true })).join(' · ') }, { label: 'Trial', render: (p) => (p.trialDays ? `${p.trialDays} days` : '—') }, { label: 'Status', render: (p) => statusBadge(p.active ? 'active' : 'archived') }],
      actions: (p) => h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: () => edit(p) }, 'Edit') }))), { rows: 3 });
}
function discounts(panel) {
  let lv;
  const create = () => { const m = openModal({ title: 'New discount code', size: 'lg', body: buildForm({ submitLabel: 'Create code', onCancel: () => m.close(), fields: [
    { name: 'code', label: 'Code', required: true, hint: '3–40 letters, digits, - or _' }, { name: 'type', label: 'Type', type: 'select', options: [{ value: 'percent', label: 'Percentage off' }, { value: 'fixed', label: 'Fixed amount off' }] },
    { name: 'percentOff', label: 'Percent off (1–100)', type: 'number', min: 1, max: 100 }, { name: 'fixedAmounts', label: 'Fixed amounts (CURRENCY amount per line)', type: 'textarea', rows: 2 },
    { name: 'appliesTo', label: 'Applies to', type: 'select', options: ['all', 'course', 'subscription'].map((v) => ({ value: v, label: v })) }, { name: 'maxRedemptions', label: 'Total uses (blank = unlimited)', type: 'number', min: 1 },
    { name: 'perUserLimit', label: 'Uses per user', type: 'number', min: 1, value: 1 }, { name: 'validUntil', label: 'Valid until', type: 'datetime-local' }, { name: 'description', label: 'Description', full: true, maxlength: 300 }],
    onSubmit: async (v) => { const body = { ...v }; if (v.type === 'fixed') body.fixedAmounts = parsePrices(v.fixedAmounts); else delete body.fixedAmounts; if (v.type !== 'percent') delete body.percentOff; if (v.validUntil) body.validUntil = new Date(v.validUntil).toISOString(); await adminApi.createDiscount(body); m.close(); toast.success('Code created.'); lv.reload(); } }) }); };
  lv = listView({ caption: 'Discount codes', search: false, fetcher: (q) => adminApi.discounts(q), extraTools: [h('button', { class: 'btn', type: 'button', onclick: create }, icon('plus'), 'New code')],
    columns: [{ label: 'Code', render: (d) => h('code', null, d.code) }, { label: 'Discount', render: (d) => (d.type === 'percent' ? `${d.percentOff}%` : (d.fixedAmounts || []).map((x) => fmtMoney(x.amountMinor, x.currency, { minor: true })).join(' · ')) }, { label: 'Applies to', key: 'appliesTo' },
      { label: 'Used', render: (d) => `${d.redemptionCount ?? 0}${d.maxRedemptions ? ' / ' + d.maxRedemptions : ''}` }, { label: 'Expires', render: (d) => fmtDate(d.validUntil) }, { label: 'Status', render: (d) => statusBadge(d.active ? 'active' : 'archived') }],
    actions: (d) => h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: async () => { try { await adminApi.updateDiscount(idOf(d), { active: !d.active }); toast.success(d.active ? 'Code disabled.' : 'Code enabled.'); lv.reload(); } catch (e) { toast.error(e.message); } } }, d.active ? 'Disable' : 'Enable') });
  panel.append(lv.el);
}
