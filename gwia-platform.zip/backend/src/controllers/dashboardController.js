const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const dashboardService = require('../services/dashboardService');

// GET /api/student/dashboard
const getDashboard = asyncHandler(async (req, res) => {
  const dashboard = await dashboardService.getDashboard(req.user.id);
  return ApiResponse.ok(res, dashboard, 'Dashboard retrieved');
});

module.exports = { getDashboard };
