const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const backupService = require('../services/backupService');
const auditLogService = require('../services/auditLogService');

const createBackup = asyncHandler(async (req, res) => {
  const backup = await backupService.createBackup(req.user.id);
  await auditLogService.record(req.user.id, 'database.backup', 'Backup', backup._id, { fileName: backup.fileName }, req.ip);
  return ApiResponse.created(res, backup, 'Database backup created successfully');
});

const listBackups = asyncHandler(async (req, res) => {
  const { page, limit } = req.query;
  const result = await backupService.listBackups({ page, limit });
  return ApiResponse.ok(res, result.items, 'Backups retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

const restoreBackup = asyncHandler(async (req, res) => {
  if (req.body.confirm !== true) {
    throw ApiError.badRequest(
      'This will overwrite the current database with the backup contents. Resend with { "confirm": true } to proceed.'
    );
  }

  const backup = await backupService.restoreBackup(req.params.id, req.user.id);
  await auditLogService.record(
    req.user.id,
    'database.restore',
    'Backup',
    req.params.id,
    { fileName: backup.fileName },
    req.ip
  );
  return ApiResponse.ok(res, backup, 'Database restored successfully');
});

module.exports = { createBackup, listBackups, restoreBackup };
