/* Service worker for the GWIA PWA. Generated into sw.js by `node tools/build-pwa.js` (it fills in VERSION and PRECACHE).
 *
 * Strategy (designed for low-RAM phones and slow / flaky connections):
 *  - App shell (HTML, CSS, JS, icons) is precached under a versioned cache: instant start, works offline.
 *  - Navigations: network first with a short timeout, then the cached page, then offline.html.
 *  - Static assets: cache first (versioned) with background refresh for anything not precached; runtime cache is size-capped.
 *  - NEVER cached: API calls, uploads, Socket.IO, anything cross-origin, any non-GET. Personal data, signed file links and
 *    payment pages therefore never end up in a cache on a shared phone.
 */
const VERSION = 'c036aa656d26';
const SHELL_CACHE = `gwia-shell-${VERSION}`;
const RUNTIME_CACHE = 'gwia-runtime-v1';
const RUNTIME_MAX_ENTRIES = 60;
const NAV_TIMEOUT_MS = 4000;
const PRECACHE = [
  "./",
  "./admin.html",
  "./ai.html",
  "./auth.html",
  "./classroom.html",
  "./css/base.css",
  "./css/components.css",
  "./css/layout.css",
  "./exam.html",
  "./icons/apple-touch-icon.png",
  "./icons/favicon-64.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/maskable-512.png",
  "./js/api/admin.js",
  "./js/api/ai.js",
  "./js/api/auth.js",
  "./js/api/billing.js",
  "./js/api/certificates.js",
  "./js/api/messages.js",
  "./js/api/student.js",
  "./js/api/teacher.js",
  "./js/core/config.js",
  "./js/core/dom.js",
  "./js/core/files.js",
  "./js/core/format.js",
  "./js/core/http.js",
  "./js/core/session.js",
  "./js/core/store.js",
  "./js/core/theme.js",
  "./js/pages/admin.js",
  "./js/pages/admin/audit.js",
  "./js/pages/admin/billing.js",
  "./js/pages/admin/certificates.js",
  "./js/pages/admin/courses.js",
  "./js/pages/admin/overview.js",
  "./js/pages/admin/payments.js",
  "./js/pages/admin/reports.js",
  "./js/pages/admin/settings.js",
  "./js/pages/admin/subscriptions.js",
  "./js/pages/admin/users.js",
  "./js/pages/ai.js",
  "./js/pages/auth.js",
  "./js/pages/classroom.js",
  "./js/pages/exam.js",
  "./js/pages/learn.js",
  "./js/pages/messages.js",
  "./js/pages/paymentCallback.js",
  "./js/pages/public.js",
  "./js/pages/shared/courseSelect.js",
  "./js/pages/shared/listView.js",
  "./js/pages/shared/profile.js",
  "./js/pages/student.js",
  "./js/pages/student/billing.js",
  "./js/pages/student/certificates.js",
  "./js/pages/student/courses.js",
  "./js/pages/student/live.js",
  "./js/pages/student/overview.js",
  "./js/pages/student/progress.js",
  "./js/pages/student/work.js",
  "./js/pages/teacher.js",
  "./js/pages/teacher/announcements.js",
  "./js/pages/teacher/courses.js",
  "./js/pages/teacher/live.js",
  "./js/pages/teacher/overview.js",
  "./js/pages/teacher/questions.js",
  "./js/pages/teacher/signature.js",
  "./js/pages/teacher/work.js",
  "./js/pages/verify.js",
  "./js/pwa.js",
  "./js/ui/certResult.js",
  "./js/ui/form.js",
  "./js/ui/markdown.js",
  "./js/ui/modal.js",
  "./js/ui/page.js",
  "./js/ui/pagination.js",
  "./js/ui/plans.js",
  "./js/ui/router.js",
  "./js/ui/search.js",
  "./js/ui/shell.js",
  "./js/ui/socket.js",
  "./js/ui/states.js",
  "./js/ui/table.js",
  "./js/ui/tabs.js",
  "./js/ui/toast.js",
  "./learn.html",
  "./manifest.json",
  "./messages.html",
  "./offline.html",
  "./payment-callback.html",
  "./student.html",
  "./teacher.html",
  "./theme-init.js",
  "./verify.html",
  "./index.html"
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) =>
      // One missing file must not abort the whole install.
      Promise.all(PRECACHE.map((url) => cache.add(new Request(url, { cache: 'reload' })).catch(() => null)))
    )
  );
  // The new version waits until the page asks for it (see js/pwa.js), so users are never switched mid-exam.
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k.startsWith('gwia-shell-') && k !== SHELL_CACHE).map((k) => caches.delete(k)));
      if (self.registration.navigationPreload) await self.registration.navigationPreload.enable().catch(() => {});
      await self.clients.claim();
    })()
  );
});

const BYPASS_PATH = /^\/(api|uploads|socket\.io|health|verify)(\/|$)/;

async function trim(cacheName, max) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length > max) await Promise.all(keys.slice(0, keys.length - max).map((k) => cache.delete(k)));
}

function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout')), ms);
    promise.then((r) => { clearTimeout(timer); resolve(r); }, (e) => { clearTimeout(timer); reject(e); });
  });
}

async function navigate(event) {
  const cache = await caches.open(SHELL_CACHE);
  try {
    const preload = event.preloadResponse ? await event.preloadResponse : null;
    const response = preload || (await withTimeout(fetch(event.request), NAV_TIMEOUT_MS));
    if (response && response.ok) cache.put(event.request, response.clone()).catch(() => {});
    return response;
  } catch (err) {
    const cached = (await cache.match(event.request, { ignoreSearch: true })) || (await caches.match(event.request, { ignoreSearch: true }));
    return cached || (await cache.match('offline.html')) || Response.error();
  }
}

async function staticAsset(event) {
  const shell = await caches.open(SHELL_CACHE);
  const hit = await shell.match(event.request, { ignoreSearch: true });
  if (hit) return hit; // precached and versioned with the service worker
  const runtime = await caches.open(RUNTIME_CACHE);
  const cached = await runtime.match(event.request);
  const refresh = fetch(event.request)
    .then((res) => {
      if (res && res.ok && res.type === 'basic') { runtime.put(event.request, res.clone()).then(() => trim(RUNTIME_CACHE, RUNTIME_MAX_ENTRIES)).catch(() => {}); }
      return res;
    })
    .catch(() => null);
  return cached || (await refresh) || Response.error();
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return; // API and CDN requests go straight to the network
  if (BYPASS_PATH.test(url.pathname)) return;
  if (request.headers.has('range')) return; // media streaming

  if (request.mode === 'navigate') {
    event.respondWith(navigate(event));
    return;
  }
  if (['style', 'script', 'image', 'font', 'manifest'].includes(request.destination)) {
    event.respondWith(staticAsset(event));
  }
});

/* ---------- Push notifications (see docs/PUSH.md) ---------- */
self.addEventListener('push', (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (e) { data = { title: 'Notification', body: event.data ? event.data.text() : '' }; }
  const title = data.title || 'Generals Wisdom International Academy';
  event.waitUntil(
    self.registration.showNotification(title, {
      body: data.body || '',
      icon: 'icons/icon-192.png',
      badge: 'icons/favicon-64.png',
      tag: data.tag || 'gwia',
      renotify: Boolean(data.tag),
      data: { url: data.url || './' }
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = new URL((event.notification.data && event.notification.data.url) || './', self.registration.scope).href;
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((wins) => {
      for (const w of wins) if ('focus' in w) { w.navigate(target).catch(() => {}); return w.focus(); }
      return self.clients.openWindow(target);
    })
  );
});
