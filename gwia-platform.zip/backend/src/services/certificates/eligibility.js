/**
 * Pure certificate-eligibility rules (no DB). The service gathers the numbers; this decides.
 * Keeping it pure means every rule is unit-tested and the "why not yet?" answer shown to students
 * comes from exactly the same code that gates issuance.
 */

function num(v, fallback) {
  return v === undefined || v === null || Number.isNaN(Number(v)) ? fallback : Number(v);
}

/** Fills defaults for courses created before certificate settings existed. */
function resolveRequirements(c = {}) {
  return {
    enabled: c.enabled !== false,
    minLessonCompletionPercent: num(c.minLessonCompletionPercent, 100),
    // undefined (never set) => default 50; explicit null => teacher switched the check off
    minAverageScorePercent: c.minAverageScorePercent === undefined ? 50 : c.minAverageScorePercent,
    requireAllAssessments: Boolean(c.requireAllAssessments),
    minAttendancePercent: c.minAttendancePercent === undefined ? null : c.minAttendancePercent,
    showScore: Boolean(c.showScore)
  };
}

/**
 * stats = {
 *   lessons:     { completed, total },                    // PUBLISHED lessons only
 *   assessments: { total, graded, averagePercent|null },  // published/closed assignments+quizzes+exams
 *   attendance:  { counted, present }                     // sessions that count (excused ones excluded)
 * }
 */
function evaluateEligibility(requirements, stats) {
  const checks = [];
  const { lessons, assessments, attendance } = stats;

  const lessonPct = lessons.total > 0 ? Math.round((lessons.completed / lessons.total) * 100) : 0;
  checks.push({
    key: 'lessons',
    label: 'Complete the course lessons',
    required: `${requirements.minLessonCompletionPercent}%`,
    actual: lessons.total > 0 ? `${lessonPct}% (${lessons.completed}/${lessons.total})` : 'No published lessons',
    // integer arithmetic: no rounding surprises at the boundary
    met: lessons.total > 0 && lessons.completed * 100 >= requirements.minLessonCompletionPercent * lessons.total
  });

  if (requirements.minAverageScorePercent !== null && assessments.total > 0) {
    checks.push({
      key: 'averageScore',
      label: 'Reach the minimum average score',
      required: `${requirements.minAverageScorePercent}%`,
      actual: assessments.graded > 0 ? `${assessments.averagePercent}%` : 'No graded work yet',
      met: assessments.graded > 0 && assessments.averagePercent >= requirements.minAverageScorePercent
    });
  }

  if (requirements.requireAllAssessments && assessments.total > 0) {
    checks.push({
      key: 'allAssessments',
      label: 'Have every assignment, quiz and exam graded',
      required: `${assessments.total} of ${assessments.total}`,
      actual: `${assessments.graded} of ${assessments.total}`,
      met: assessments.graded >= assessments.total
    });
  }

  if (requirements.minAttendancePercent !== null && attendance.counted > 0) {
    const rate = Math.round((attendance.present / attendance.counted) * 100);
    checks.push({
      key: 'attendance',
      label: 'Meet the minimum attendance',
      required: `${requirements.minAttendancePercent}%`,
      actual: `${rate}% (${attendance.present}/${attendance.counted})`,
      met: attendance.present * 100 >= requirements.minAttendancePercent * attendance.counted
    });
  }

  return {
    eligible: requirements.enabled && checks.every((c) => c.met),
    enabled: requirements.enabled,
    checks,
    finalScorePercent: assessments.graded > 0 ? assessments.averagePercent : null,
    lessonCompletionPercent: lessonPct
  };
}

module.exports = { resolveRequirements, evaluateEligibility };
