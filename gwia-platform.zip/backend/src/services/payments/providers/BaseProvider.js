const ApiError = require('../../../utils/ApiError');

/**
 * Gateway adapter contract. Every provider normalizes its API to this shape so
 * paymentService never contains provider-specific logic.
 *
 *  initialize({ reference, amountMinor, currency, email, name, phone, callbackUrl, description, metadata })
 *      -> { checkoutUrl, accessCode? }
 *
 *  verify({ reference, transactionIdHint? })       // ALWAYS a server-to-server call
 *      -> { state: 'success'|'failed'|'pending'|'not_found',
 *           reference, amountMinor, currency, providerTransactionId, channel, paidAt, customerEmail, raw }
 *
 *  verifyWebhook({ rawBody: Buffer, headers })     -> boolean (authenticity of the HTTP request)
 *  parseWebhook(parsedBody)                        -> { eventType, eventKey, reference, transactionId, kind }
 *      kind: 'payment' (re-verify via API) | 'refund' | 'ignore'
 */
class BaseProvider {
  constructor(name, config, http) {
    this.name = name;
    this.config = config;
    this.http = http;
  }

  isConfigured() {
    return Boolean(this.config.secretKey);
  }

  supportsCurrency(currency) {
    return this.config.currencies.includes(String(currency).toUpperCase());
  }

  assertConfigured() {
    if (!this.isConfigured()) {
      throw new ApiError(503, `${this.name} is not configured on this server`);
    }
  }
}

module.exports = BaseProvider;
