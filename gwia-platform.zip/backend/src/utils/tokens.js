const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const env = require('../config/env');
const ApiError = require('./ApiError');

/**
 * Single place that signs and verifies JWTs, so every consumer (REST middleware, Socket.IO,
 * refresh flow) applies the same rules:
 *   - the algorithm is pinned (never trust the token header, blocks alg-confusion / "none")
 *   - every token carries a `type` claim and is only accepted for that purpose, so a refresh
 *     token or a classroom token can never be replayed as an access token
 *   - issuer / audience are set and checked
 */
const ALGORITHM = 'HS256';
const ISSUER = 'gwia-api';

const TYPES = Object.freeze({ ACCESS: 'access', REFRESH: 'refresh', CLASSROOM: 'classroom_join' });

function secretFor(type) {
  return type === TYPES.REFRESH ? env.jwtRefreshSecret : env.jwtSecret;
}

function sign(type, claims, expiresIn) {
  return jwt.sign({ ...claims, type }, secretFor(type), {
    algorithm: ALGORITHM,
    expiresIn,
    issuer: ISSUER,
    audience: type,
    jwtid: crypto.randomBytes(12).toString('hex')
  });
}

function verify(type, token) {
  if (typeof token !== 'string' || token.length === 0 || token.length > 4096) {
    throw ApiError.unauthorized('Invalid authentication token');
  }
  const payload = jwt.verify(token, secretFor(type), { algorithms: [ALGORITHM], issuer: ISSUER, audience: type });
  if (payload.type !== type) throw ApiError.unauthorized('Invalid token type');
  return payload;
}

const signAccessToken = (user) => sign(TYPES.ACCESS, { sub: user._id.toString(), role: user.role }, env.jwtExpiresIn);
const signRefreshToken = (user) => sign(TYPES.REFRESH, { sub: user._id.toString() }, env.jwtRefreshExpiresIn);
const verifyAccessToken = (token) => verify(TYPES.ACCESS, token);
const verifyRefreshToken = (token) => verify(TYPES.REFRESH, token);

module.exports = { TYPES, sign, verify, signAccessToken, signRefreshToken, verifyAccessToken, verifyRefreshToken, ALGORITHM, ISSUER };
