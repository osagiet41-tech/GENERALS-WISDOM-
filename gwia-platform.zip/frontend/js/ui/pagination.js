import { h } from '../core/dom.js';
/* pagination({ page, pages, total, limit, onChange }) — works with the backend meta { page, limit, total, pages } */
export function pagination({ page = 1, pages = 1, total = 0, limit = 20, onChange }) {
  if (!total) return null;
  const from = (page - 1) * limit + 1, to = Math.min(total, page * limit);
  const win = []; for (let p = Math.max(1, page - 2); p <= Math.min(pages, page + 2); p++) win.push(p);
  const btn = (label, p, extra = {}) => h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: () => onChange(p), ...extra }, label);
  return h('nav', { class: 'pager', 'aria-label': 'Pagination' },
    h('span', { role: 'status' }, `Showing ${from}–${to} of ${total}`),
    pages > 1 && h('div', { class: 'pages' }, btn('Prev', page - 1, { disabled: page <= 1, 'aria-label': 'Previous page' }),
      win.map((p) => btn(String(p), p, p === page ? { 'aria-current': 'page' } : {})), btn('Next', page + 1, { disabled: page >= pages, 'aria-label': 'Next page' })));
}
