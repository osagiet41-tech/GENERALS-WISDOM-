const { execFile } = require('child_process');
const util = require('util');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { Backup } = require('../models/systemAdmin.model');
const ApiError = require('../utils/ApiError');
const env = require('../config/env');
const logger = require('../utils/logger');

const execFileAsync = util.promisify(execFile);

const BACKUP_DIR = path.join(__dirname, '..', '..', 'backups');

function ensureBackupDir() {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }
}

async function createBackup(adminId) {
  ensureBackupDir();

  const fileName = `backup-${new Date().toISOString().replace(/[:.]/g, '-')}-${crypto.randomBytes(4).toString('hex')}.archive.gz`;
  const filePath = path.join(BACKUP_DIR, fileName);

  const backup = await Backup.create({
    fileName,
    filePath,
    status: 'in_progress',
    triggeredBy: adminId
  });

  try {
    // execFile (no shell): nothing in these arguments can be interpreted as shell syntax.
    await execFileAsync('mongodump', [`--uri=${env.mongodbUri}`, `--archive=${filePath}`, '--gzip'], {
      maxBuffer: 1024 * 1024 * 50
    });

    const stats = fs.statSync(filePath);
    backup.status = 'completed';
    backup.sizeBytes = stats.size;
    backup.completedAt = new Date();
    await backup.save();

    logger.info(`Database backup completed: ${fileName} (${stats.size} bytes)`);
  } catch (err) {
    backup.status = 'failed';
    backup.errorMessage = err.message;
    await backup.save();
    logger.error(`Database backup failed: ${err.message}`);
    throw ApiError.internal(`Backup failed: ${err.message}`);
  }

  return backup;
}

async function listBackups({ page = 1, limit = 20 } = {}) {
  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    Backup.find({}).populate('triggeredBy', 'name email').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Backup.countDocuments({})
  ]);
  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function restoreBackup(backupId, adminId) {
  const backup = await Backup.findById(backupId);
  if (!backup) {
    throw ApiError.notFound('Backup not found');
  }
  if (backup.status !== 'completed') {
    throw ApiError.badRequest('Only a completed backup can be restored');
  }
  // A tampered DB record must not be able to point the restore at an arbitrary file.
  if (path.dirname(path.resolve(backup.filePath)) !== path.resolve(BACKUP_DIR)) {
    throw ApiError.badRequest('Backup file is outside the backup directory');
  }
  if (!fs.existsSync(backup.filePath)) {
    throw ApiError.notFound('Backup archive file is missing from disk');
  }

  try {
    await execFileAsync('mongorestore', [`--uri=${env.mongodbUri}`, `--archive=${backup.filePath}`, '--gzip', '--drop'], {
      maxBuffer: 1024 * 1024 * 50
    });

    backup.restoredAt = new Date();
    backup.restoredBy = adminId;
    await backup.save();

    logger.warn(`Database RESTORED from backup ${backup.fileName} by admin ${adminId}`);
  } catch (err) {
    logger.error(`Database restore failed: ${err.message}`);
    throw ApiError.internal(`Restore failed: ${err.message}`);
  }

  return backup;
}

module.exports = { createBackup, listBackups, restoreBackup, BACKUP_DIR };
