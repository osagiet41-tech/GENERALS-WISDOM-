/* Service worker for the GWIA PWA. Generated into sw.js by `node tools/build-pwa.js` (it fills in VERSION and PRECACHE).
 *
 * Strategy (designed for low-RAM phones and slow / flaky connections):
 *  - App shell (HTML, CSS, JS, icons) is precached under a versioned cache: instant start, works offline.
 *  - Navigations: network first with a short timeout, then the cached page, then offline.html.
 *  - Static assets: cache first (versioned) with background refresh for anything not precached; runtime cache is size-capped.
 *  - NEVER cached: API calls, uploads, Socket.IO, anything cross-origin, any non-GET. Personal data, signed file links and
 *    payment pages therefore never end up in a cache on a shared phone.
 */
const VERSION = '__VERSION__';
const SHELL_CACHE = `gwia-shell-${VERSION}`;
const RUNTIME_CACHE = 'gwia-runtime-v1';
const RUNTIME_MAX_ENTRIES = 60;
const NAV_TIMEOUT_MS = 4000;
const PRECACHE = __PRECACHE__;

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) =>
      // One missing file must not abort the whole install.
      Promise.all(PRECACHE.map((url) => cache.add(new Request(url, { cache: 'reload' })).catch(() => null)))
    )
  );
  // The new version waits until the page asks for it (see js/pwa.js), so users are never switched mid-exam.
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k.startsWith('gwia-shell-') && k !== SHELL_CACHE).map((k) => caches.delete(k)));
      if (self.registration.navigationPreload) await self.registration.navigationPreload.enable().catch(() => {});
      await self.clients.claim();
    })()
  );
});

const BYPASS_PATH = /^\/(api|uploads|socket\.io|health|verify)(\/|$)/;

async function trim(cacheName, max) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length > max) await Promise.all(keys.slice(0, keys.length - max).map((k) => cache.delete(k)));
}

function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout')), ms);
    promise.then((r) => { clearTimeout(timer); resolve(r); }, (e) => { clearTimeout(timer); reject(e); });
  });
}

async function navigate(event) {
  const cache = await caches.open(SHELL_CACHE);
  try {
    const preload = event.preloadResponse ? await event.preloadResponse : null;
    const response = preload || (await withTimeout(fetch(event.request), NAV_TIMEOUT_MS));
    if (response && response.ok) cache.put(event.request, response.clone()).catch(() => {});
    return response;
  } catch (err) {
    const cached = (await cache.match(event.request, { ignoreSearch: true })) || (await caches.match(event.request, { ignoreSearch: true }));
    return cached || (await cache.match('offline.html')) || Response.error();
  }
}

async function staticAsset(event) {
  const shell = await caches.open(SHELL_CACHE);
  const hit = await shell.match(event.request, { ignoreSearch: true });
  if (hit) return hit; // precached and versioned with the service worker
  const runtime = await caches.open(RUNTIME_CACHE);
  const cached = await runtime.match(event.request);
  const refresh = fetch(event.request)
    .then((res) => {
      if (res && res.ok && res.type === 'basic') { runtime.put(event.request, res.clone()).then(() => trim(RUNTIME_CACHE, RUNTIME_MAX_ENTRIES)).catch(() => {}); }
      return res;
    })
    .catch(() => null);
  return cached || (await refresh) || Response.error();
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return; // API and CDN requests go straight to the network
  if (BYPASS_PATH.test(url.pathname)) return;
  if (request.headers.has('range')) return; // media streaming

  if (request.mode === 'navigate') {
    event.respondWith(navigate(event));
    return;
  }
  if (['style', 'script', 'image', 'font', 'manifest'].includes(request.destination)) {
    event.respondWith(staticAsset(event));
  }
});

/* ---------- Push notifications (see docs/PUSH.md) ---------- */
self.addEventListener('push', (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (e) { data = { title: 'Notification', body: event.data ? event.data.text() : '' }; }
  const title = data.title || 'Generals Wisdom International Academy';
  event.waitUntil(
    self.registration.showNotification(title, {
      body: data.body || '',
      icon: 'icons/icon-192.png',
      badge: 'icons/favicon-64.png',
      tag: data.tag || 'gwia',
      renotify: Boolean(data.tag),
      data: { url: data.url || './' }
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = new URL((event.notification.data && event.notification.data.url) || './', self.registration.scope).href;
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((wins) => {
      for (const w of wins) if ('focus' in w) { w.navigate(target).catch(() => {}); return w.focus(); }
      return self.clients.openWindow(target);
    })
  );
});
