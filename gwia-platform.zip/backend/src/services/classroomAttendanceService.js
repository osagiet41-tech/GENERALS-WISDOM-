const { Course } = require('../models/course.model');
const attendanceService = require('./attendanceService');
const classroomService = require('./classroomService');

const PRESENCE_THRESHOLD_RATIO = 0.5; // must be present for at least half the scheduled duration to count as 'present'
const LATE_THRESHOLD_SECONDS = 10 * 60; // joined more than 10 minutes after the actual start counts as 'late'

/**
 * Called when a live class ends. Computes each enrolled student's
 * total time connected (from LiveClass.participantLog) and records
 * attendance for the session via the existing attendance system —
 * so classroom presence becomes the source of truth for attendance
 * instead of requiring the teacher to mark it by hand.
 */
async function finalizeAttendance(liveClass) {
  const course = await Course.findById(liveClass.courseId);
  if (!course) return null;

  const summaries = await classroomService.getParticipantLogSummary(liveClass);
  const summaryByStudent = new Map(summaries.filter((s) => s.role === 'student').map((s) => [s.userId.toString(), s]));

  const scheduledSeconds = liveClass.durationMinutes * 60;
  const actualStart = liveClass.timer.actualStartedAt;

  const records = course.enrolledStudentIds.map((studentId) => {
    const key = studentId.toString();
    const summary = summaryByStudent.get(key);

    if (!summary || summary.totalDurationSeconds === 0) {
      return { studentId: key, status: 'absent' };
    }

    const isPresentEnough = summary.totalDurationSeconds >= scheduledSeconds * PRESENCE_THRESHOLD_RATIO;
    if (!isPresentEnough) {
      return { studentId: key, status: 'absent', note: `Connected for ${Math.round(summary.totalDurationSeconds / 60)} min` };
    }

    const firstJoin = liveClass.participantLog.find((e) => e.userId.toString() === key);
    const joinedLate = actualStart && firstJoin && firstJoin.joinedAt.getTime() - actualStart.getTime() > LATE_THRESHOLD_SECONDS * 1000;

    return { studentId: key, status: joinedLate ? 'late' : 'present' };
  });

  if (records.length === 0) return null;

  return attendanceService.createOrUpdateSession(course, liveClass.teacherId, {
    sessionDate: liveClass.scheduledAt,
    liveClassId: liveClass._id,
    records
  });
}

module.exports = { finalizeAttendance };
