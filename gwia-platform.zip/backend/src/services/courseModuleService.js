const CourseModule = require('../models/courseModule.model');
const ApiError = require('../utils/ApiError');

async function createModule(courseId, subjectId, teacherId, data) {
  return CourseModule.create({
    courseId,
    subjectId,
    title: data.title,
    description: data.description || '',
    order: data.order || 0,
    createdBy: teacherId
  });
}

async function updateModule(courseModule, updates) {
  const allowed = ['title', 'description', 'order'];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      courseModule[field] = updates[field];
    }
  }
  await courseModule.save();
  return courseModule;
}

async function deleteModule(courseModule) {
  const Lesson = require('../models/lesson.model');
  const lessonCount = await Lesson.countDocuments({ moduleId: courseModule._id });
  if (lessonCount > 0) {
    throw ApiError.conflict('Cannot delete a module that still has lessons. Delete or move its lessons first.');
  }
  await courseModule.deleteOne();
}

async function listModules(subjectId) {
  return CourseModule.find({ subjectId }).sort({ order: 1 });
}

async function listModulesForCourse(courseId) {
  return CourseModule.find({ courseId }).sort({ order: 1 });
}

module.exports = { createModule, updateModule, deleteModule, listModules, listModulesForCourse };
