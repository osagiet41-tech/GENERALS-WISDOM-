const test = require('node:test');
const assert = require('node:assert/strict');
const { buildInventory } = require('../../scripts/route-inventory');

const routes = buildInventory();

/* The ONLY routes that may be reached without a token. Adding a route here is a deliberate, reviewed decision. */
const PUBLIC_ALLOW_LIST = new Set([
  'POST /api/auth/register',
  'POST /api/auth/login',
  'POST /api/auth/refresh',
  'POST /api/auth/forgot-password',
  'POST /api/auth/reset-password',
  'GET /api/auth/verify-email',
  'GET /api/billing/plans',
  'GET /api/certificates/verify/:certificateId',
  'GET /api/push/public-key',
  'GET /api/health',
  'GET /health',
  'GET /verify/:certificateId',
  // Payment gateways call these server-to-server; they are protected by signature verification instead of a JWT.
  'POST /api/webhooks/paystack',
  'POST /api/webhooks/flutterwave'
]);

test('inventory found a realistic number of routes', () => {
  assert.ok(routes.length > 200, `only ${routes.length} routes found`);
});

test('no route is public unless it is on the allow-list', () => {
  const unexpected = routes.filter((r) => !r.auth && !PUBLIC_ALLOW_LIST.has(`${r.method} ${r.path}`));
  assert.deepEqual(unexpected.map((r) => `${r.method} ${r.path}`), []);
});

test('every allow-listed public route still exists (the list cannot silently rot)', () => {
  const present = new Set(routes.map((r) => `${r.method} ${r.path}`));
  for (const key of PUBLIC_ALLOW_LIST) assert.ok(present.has(key), `${key} is on the allow-list but not registered`);
});

test('all /api/admin routes require the admin role', () => {
  const admin = routes.filter((r) => r.path.startsWith('/api/admin'));
  assert.ok(admin.length > 20);
  const weak = admin.filter((r) => !r.auth || !r.roles || r.roles.join() !== 'admin');
  assert.deepEqual(weak.map((r) => `${r.method} ${r.path}`), []);
});

test('all /api/student routes require the student role', () => {
  const student = routes.filter((r) => r.path.startsWith('/api/student'));
  assert.ok(student.length > 20);
  const weak = student.filter((r) => !r.auth || !r.roles || r.roles.join() !== 'student');
  assert.deepEqual(weak.map((r) => `${r.method} ${r.path}`), []);
});

test('write operations on courses/lessons/assignments/quizzes/exams are never open to students', () => {
  const prefixes = ['/api/courses', '/api/lessons', '/api/assignments', '/api/quizzes', '/api/exams', '/api/modules', '/api/live-classes', '/api/question-bank'];
  // Routes any signed-in user may call must be explicitly reviewed (forum + thumbnail/uploads enforce ownership inside).
  const REVIEWED_ANY_ROLE = /\/forum|\/thumbnail$|\/attachments$|\/audio$|\/images$|\/pdfs$|\/video$|\/materials$|\/import$/;
  const risky = routes.filter(
    (r) => r.method !== 'GET' && prefixes.some((p) => r.path.startsWith(p)) && r.auth && !r.roles && !REVIEWED_ANY_ROLE.test(r.path)
  );
  assert.deepEqual(risky.map((r) => `${r.method} ${r.path}`), []);
});

test('payment-changing endpoints are students-only; AI endpoints are role-scoped', () => {
  const need = ['POST /api/billing/checkout', 'POST /api/billing/trial', 'POST /api/billing/discounts/validate'];
  for (const key of need) {
    const r = routes.find((x) => `${x.method} ${x.path}` === key);
    assert.ok(r && r.auth && r.roles && r.roles.join() === 'student', `${key} must require the student role`);
  }
  for (const r of routes.filter((x) => x.path.startsWith('/api/ai/teacher/'))) assert.deepEqual(r.roles, ['admin', 'teacher'], r.path);
  for (const r of routes.filter((x) => x.path.startsWith('/api/ai/student/'))) assert.deepEqual(r.roles, ['student'], r.path);
});
