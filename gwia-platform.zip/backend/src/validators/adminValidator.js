const { body } = require('express-validator');

const createUserValidator = [
  body('name').isString().trim().notEmpty().isLength({ max: 120 }).withMessage('Name is required (max 120 characters)'),
  body('email').isString().trim().isEmail().withMessage('A valid email is required').normalizeEmail(),
  // Administrator accounts are provisioned with `npm run seed:admin`, never through the API.
  body('role').isIn(['teacher', 'student']).withMessage('role must be teacher or student')
];

const updateUserRoleValidator = [body('role').isIn(['teacher', 'student']).withMessage('role must be teacher or student')];

const suspendUserValidator = [body('reason').optional().trim().isLength({ max: 500 })];

const updateCourseStatusValidator = [
  body('status').isIn(['draft', 'published', 'archived']).withMessage('status must be draft, published, or archived')
];

const createPaymentValidator = [
  body('userId').isMongoId().withMessage('A valid userId is required'),
  body('courseId').optional().isMongoId(),
  body('planCode').optional().isString(),
  body('amount').isFloat({ min: 0 }).withMessage('amount must be a non-negative number'),
  body('currency').optional().isLength({ min: 3, max: 3 }),
  body('providerReference').optional().isString(),
  body('status').optional().isIn(['pending', 'completed', 'failed', 'refunded']),
  body('notes').optional().isString().isLength({ max: 1000 })
];

const updatePaymentStatusValidator = [
  body('status').isIn(['pending', 'completed', 'failed', 'refunded']).withMessage('A valid status is required')
];

const createSubscriptionValidator = [
  body('userId').isMongoId().withMessage('A valid userId is required'),
  body('plan').trim().notEmpty().withMessage('plan is required'),
  body('amount').isFloat({ min: 0 }).withMessage('amount must be a non-negative number'),
  body('currency').optional().isLength({ min: 3, max: 3 }),
  body('startDate').optional().isISO8601(),
  body('endDate').isISO8601().withMessage('A valid endDate is required'),
  body('autoRenew').optional().isBoolean()
];

const extendSubscriptionValidator = [body('endDate').isISO8601().withMessage('A valid endDate is required')];

const updateSettingsValidator = [
  body('siteName').optional().trim().isLength({ min: 1, max: 200 }),
  body('registrationOpen').optional().isBoolean(),
  body('maintenanceMode').optional().isBoolean(),
  body('defaultCurrency').optional().isLength({ min: 3, max: 3 }),
  body('supportEmail').optional().isEmail(),
  body('maxUploadSizeMB').optional().isInt({ min: 1 })
];

const restoreBackupValidator = [body('confirm').isBoolean().withMessage('confirm must be a boolean')];

module.exports = {
  createUserValidator,
  updateUserRoleValidator,
  suspendUserValidator,
  updateCourseStatusValidator,
  createPaymentValidator,
  updatePaymentStatusValidator,
  createSubscriptionValidator,
  extendSubscriptionValidator,
  updateSettingsValidator,
  restoreBackupValidator
};
