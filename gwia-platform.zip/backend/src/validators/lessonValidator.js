const { body } = require('express-validator');

const createLessonValidator = [
  body('title').trim().notEmpty().withMessage('Lesson title is required').isLength({ max: 200 }),
  body('text').optional().isString(),
  body('order').optional().isInt({ min: 0 }),
  body('status').optional().isIn(['draft', 'published']),
  body('prerequisiteLessonIds').optional().isArray(),
  body('prerequisiteLessonIds.*').optional().isMongoId(),
  body('externalResources').optional().isArray(),
  body('externalResources.*.title').optional().isString().notEmpty(),
  body('externalResources.*.url').optional().isURL({ protocols: ['http', 'https'], require_protocol: true })
];

const updateLessonValidator = [
  body('title').optional().trim().isLength({ min: 1, max: 200 }),
  body('text').optional().isString(),
  body('moduleId').optional().isMongoId(),
  body('order').optional().isInt({ min: 0 }),
  body('status').optional().isIn(['draft', 'published']),
  body('prerequisiteLessonIds').optional().isArray(),
  body('prerequisiteLessonIds.*').optional().isMongoId()
];

const updateTextValidator = [body('text').isString().withMessage('text must be a string')];

const externalResourceValidator = [
  body('title').trim().notEmpty().withMessage('Resource title is required').isLength({ max: 200 }),
  body('url').isURL({ protocols: ['http', 'https'], require_protocol: true }).withMessage('A valid http(s) URL is required'),
  body('description').optional().trim().isLength({ max: 1000 })
];

module.exports = { createLessonValidator, updateLessonValidator, updateTextValidator, externalResourceValidator };
