const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');
const { verifyPaystackSignature, verifyFlutterwaveHash } = require('../src/services/payments/signature');
const PaystackProvider = require('../src/services/payments/providers/paystack.provider');
const FlutterwaveProvider = require('../src/services/payments/providers/flutterwave.provider');

const pCfg = { secretKey: 'sk_test_x', baseUrl: 'https://api.paystack.co', currencies: ['NGN', 'USD'] };
const fCfg = { secretKey: 'FLWSECK_TEST-x', secretHash: 'my-hash', baseUrl: 'https://api.flutterwave.com/v3', currencies: ['NGN', 'USD'] };

test('paystack webhook signature: HMAC-SHA512 of the raw bytes', () => {
  const body = Buffer.from('{"event":"charge.success","data":{"reference":"GW-1"}}');
  const sig = crypto.createHmac('sha512', 'sk_test_x').update(body).digest('hex');
  assert.equal(verifyPaystackSignature(body, sig, 'sk_test_x'), true);
  assert.equal(verifyPaystackSignature(body, sig.toUpperCase(), 'sk_test_x'), true);
  assert.equal(verifyPaystackSignature(Buffer.from(body.toString() + ' '), sig, 'sk_test_x'), false); // body tampered
  assert.equal(verifyPaystackSignature(body, sig, 'other-key'), false);
  assert.equal(verifyPaystackSignature(body, undefined, 'sk_test_x'), false);
  assert.equal(verifyPaystackSignature(body, sig, null), false);
  assert.equal(verifyPaystackSignature(JSON.parse(body), sig, 'sk_test_x'), false); // parsed object, not raw bytes
});

test('flutterwave webhook: secret hash header, constant-time, no hash configured = reject all', () => {
  assert.equal(verifyFlutterwaveHash('my-hash', 'my-hash'), true);
  assert.equal(verifyFlutterwaveHash('wrong', 'my-hash'), false);
  assert.equal(verifyFlutterwaveHash('my-hash', null), false);
  assert.equal(verifyFlutterwaveHash(undefined, 'my-hash'), false);
  assert.equal(verifyFlutterwaveHash('', ''), false);
});

test('paystack: initialize sends minor units, our reference, and returns the checkout url', async () => {
  let sent;
  const http = async (url, opts) => {
    sent = { url, opts };
    return { ok: true, status: 200, body: { status: true, data: { authorization_url: 'https://checkout.paystack.com/abc', access_code: 'ac' } } };
  };
  const p = new PaystackProvider(pCfg, http);
  const out = await p.initialize({ reference: 'GW-abc', amountMinor: 500000, currency: 'NGN', email: 'a@b.com', name: 'A', callbackUrl: 'https://app/cb', metadata: {} });
  assert.equal(out.checkoutUrl, 'https://checkout.paystack.com/abc');
  assert.equal(sent.url, 'https://api.paystack.co/transaction/initialize');
  assert.equal(sent.opts.body.amount, 500000);
  assert.equal(sent.opts.body.reference, 'GW-abc');
  assert.equal(sent.opts.headers.Authorization, 'Bearer sk_test_x');
});

test('paystack: verify mapping (success, abandoned, reference mismatch, not found, API error)', async () => {
  const ok = { ok: true, status: 200, body: { status: true, data: { id: 99, status: 'success', reference: 'GW-1', amount: 500000, currency: 'ngn', channel: 'card', paid_at: '2026-10-09T10:00:00Z', customer: { email: 'a@b.com' } } } };
  const r = PaystackProvider.mapVerifyResponse(ok, 'GW-1');
  assert.equal(r.state, 'success');
  assert.equal(r.amountMinor, 500000);
  assert.equal(r.currency, 'NGN');
  assert.equal(r.providerTransactionId, '99');

  const abandoned = { ok: true, status: 200, body: { status: true, data: { id: 1, status: 'abandoned', reference: 'GW-1', amount: 1, currency: 'NGN' } } };
  assert.equal(PaystackProvider.mapVerifyResponse(abandoned, 'GW-1').state, 'pending');
  assert.throws(() => PaystackProvider.mapVerifyResponse(ok, 'GW-OTHER'), /different transaction reference/);
  assert.equal(PaystackProvider.mapVerifyResponse({ ok: false, status: 404, body: { status: false } }, 'GW-1').state, 'not_found');
  assert.throws(() => PaystackProvider.mapVerifyResponse({ ok: false, status: 500, body: null }, 'GW-1'), /verification failed/);
});

test('paystack: webhook parsing', () => {
  const p = new PaystackProvider(pCfg, null);
  const ev = p.parseWebhook({ event: 'charge.success', data: { id: 7, reference: 'GW-1' } });
  assert.deepEqual([ev.kind, ev.reference, ev.eventKey, ev.transactionId], ['payment', 'GW-1', 'charge.success:7', '7']);
  assert.equal(p.parseWebhook({ event: 'refund.processed', data: { id: 3, transaction_reference: 'GW-1' } }).kind, 'refund');
  assert.equal(p.parseWebhook({ event: 'transfer.success', data: {} }).kind, 'ignore');
});

test('flutterwave: initialize sends MAJOR units and tx_ref', async () => {
  let sent;
  const http = async (url, opts) => {
    sent = { url, opts };
    return { ok: true, status: 200, body: { status: 'success', data: { link: 'https://checkout.flutterwave.com/v3/hosted/pay/x' } } };
  };
  const f = new FlutterwaveProvider(fCfg, http);
  const out = await f.initialize({ reference: 'GW-f1', amountMinor: 1999, currency: 'USD', email: 'a@b.com', name: 'A', callbackUrl: 'https://app/cb', description: 'd', metadata: {}, business: { name: 'B' } });
  assert.equal(out.checkoutUrl, 'https://checkout.flutterwave.com/v3/hosted/pay/x');
  assert.equal(sent.opts.body.amount, 19.99);
  assert.equal(sent.opts.body.tx_ref, 'GW-f1');
});

test('flutterwave: verify mapping + a real transaction for ANOTHER order is rejected', () => {
  const body = { status: 'success', data: { id: 5, tx_ref: 'GW-f1', status: 'successful', amount: 19.99, currency: 'USD', payment_type: 'card', created_at: '2026-10-09T10:00:00Z', customer: { email: 'a@b.com' } } };
  const r = FlutterwaveProvider.mapVerifyResponse({ ok: true, status: 200, body }, 'GW-f1');
  assert.equal(r.state, 'success');
  assert.equal(r.amountMinor, 1999);
  assert.throws(() => FlutterwaveProvider.mapVerifyResponse({ ok: true, status: 200, body }, 'GW-victim'), /does not belong/);
  assert.equal(FlutterwaveProvider.mapVerifyResponse({ ok: false, status: 400, body: { status: 'error', message: 'No transaction was found for this id' } }, 'x').state, 'not_found');
  const failed = { ...body, data: { ...body.data, status: 'failed' } };
  assert.equal(FlutterwaveProvider.mapVerifyResponse({ ok: true, status: 200, body: failed }, 'GW-f1').state, 'failed');
});

test('flutterwave: verify uses numeric id hint when valid, otherwise verify_by_reference', async () => {
  const urls = [];
  const http = async (url) => {
    urls.push(url);
    return { ok: false, status: 404, body: null };
  };
  const f = new FlutterwaveProvider(fCfg, http);
  await f.verify({ reference: 'GW-f1', transactionIdHint: '12345' });
  await f.verify({ reference: 'GW-f1', transactionIdHint: '12345/../../evil' });
  await f.verify({ reference: 'GW-f1' });
  assert.equal(urls[0], 'https://api.flutterwave.com/v3/transactions/12345/verify');
  assert.match(urls[1], /verify_by_reference\?tx_ref=GW-f1$/);
  assert.match(urls[2], /verify_by_reference\?tx_ref=GW-f1$/);
});

test('flutterwave: webhook parsing + unconfigured provider refuses to act', async () => {
  const f = new FlutterwaveProvider(fCfg, null);
  const ev = f.parseWebhook({ event: 'charge.completed', data: { id: 11, tx_ref: 'GW-f1', status: 'successful' } });
  assert.deepEqual([ev.kind, ev.reference, ev.eventKey], ['payment', 'GW-f1', 'charge.completed:11']);
  const none = new FlutterwaveProvider({ ...fCfg, secretKey: null }, async () => ({}));
  await assert.rejects(() => none.verify({ reference: 'x' }), /not configured/);
});
