const Submission = require('../models/submission.model');
const Attendance = require('../models/attendance.model');
const { Course } = require('../models/course.model');
const Assignment = require('../models/assignment.model');
const { Assessment } = require('../models/assessment.model');

/**
 * Aggregated performance for a single student within a course: average
 * score across graded submissions, breakdown by assessment type, and
 * attendance rate.
 */
async function getStudentPerformance(courseId, studentId) {
  const submissions = await Submission.find({ courseId, studentId, status: 'graded' });

  const byType = { assignment: [], quiz: [], exam: [] };
  for (const s of submissions) {
    if (s.grade.totalMarks > 0) {
      byType[s.refType].push((s.grade.score / s.grade.totalMarks) * 100);
    }
  }

  const average = (arr) => (arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : null);

  const attendanceSessions = await Attendance.find({ courseId, 'records.studentId': studentId });
  const attendancePresent = attendanceSessions.filter((s) => {
    const rec = s.records.find((r) => r.studentId.toString() === studentId);
    return rec && (rec.status === 'present' || rec.status === 'late');
  }).length;

  return {
    studentId,
    courseId,
    averageScorePercent: {
      overall: average([...byType.assignment, ...byType.quiz, ...byType.exam]),
      assignments: average(byType.assignment),
      quizzes: average(byType.quiz),
      exams: average(byType.exam)
    },
    gradedSubmissionCount: submissions.length,
    attendance: {
      totalSessions: attendanceSessions.length,
      present: attendancePresent,
      attendanceRatePercent:
        attendanceSessions.length > 0 ? Math.round((attendancePresent / attendanceSessions.length) * 100) : null
    }
  };
}

/**
 * Course-wide analytics for a teacher's dashboard: enrollment count,
 * content counts, submission/grading throughput, and the class average.
 */
async function getCourseAnalytics(courseId) {
  const course = await Course.findById(courseId);

  const [assignmentCount, assessmentCounts, totalSubmissions, gradedSubmissions, avgScoreAgg] = await Promise.all([
    Assignment.countDocuments({ courseId }),
    Assessment.aggregate([{ $match: { courseId: course._id } }, { $group: { _id: '$kind', count: { $sum: 1 } } }]),
    Submission.countDocuments({ courseId }),
    Submission.countDocuments({ courseId, status: 'graded' }),
    Submission.aggregate([
      { $match: { courseId: course._id, status: 'graded', 'grade.totalMarks': { $gt: 0 } } },
      {
        $project: {
          percent: { $multiply: [{ $divide: ['$grade.score', '$grade.totalMarks'] }, 100] }
        }
      },
      { $group: { _id: null, avg: { $avg: '$percent' } } }
    ])
  ]);

  const quizCount = assessmentCounts.find((a) => a._id === 'quiz')?.count || 0;
  const examCount = assessmentCounts.find((a) => a._id === 'exam')?.count || 0;

  return {
    courseId,
    enrolledStudentCount: course.enrolledStudentIds.length,
    content: { assignmentCount, quizCount, examCount },
    submissions: {
      total: totalSubmissions,
      graded: gradedSubmissions,
      pendingGrading: totalSubmissions - gradedSubmissions
    },
    classAverageScorePercent: avgScoreAgg.length ? Math.round(avgScoreAgg[0].avg) : null
  };
}

/**
 * Score distribution for a specific assignment/quiz/exam — feeds a
 * Chart.js histogram on the frontend.
 */
async function getResourceScoreDistribution(refType, refId) {
  const submissions = await Submission.find({ refType, refId, status: 'graded' });

  const buckets = { '0-49': 0, '50-59': 0, '60-69': 0, '70-79': 0, '80-89': 0, '90-100': 0 };
  for (const s of submissions) {
    if (!s.grade.totalMarks) continue;
    const pct = (s.grade.score / s.grade.totalMarks) * 100;
    if (pct < 50) buckets['0-49'] += 1;
    else if (pct < 60) buckets['50-59'] += 1;
    else if (pct < 70) buckets['60-69'] += 1;
    else if (pct < 80) buckets['70-79'] += 1;
    else if (pct < 90) buckets['80-89'] += 1;
    else buckets['90-100'] += 1;
  }

  return { refType, refId, totalGraded: submissions.length, distribution: buckets };
}

module.exports = { getStudentPerformance, getCourseAnalytics, getResourceScoreDistribution };
