import { api } from '../core/http.js';
export const teacherApi = {
  courses: () => api.get('/courses/mine'), course: (id) => api.get(`/courses/${id}`),
  createCourse: (b) => api.post('/courses', b), updateCourse: (id, b) => api.put(`/courses/${id}`, b), deleteCourse: (id) => api.del(`/courses/${id}`),
  analytics: (cid) => api.get(`/courses/${cid}/analytics`),
  liveClasses: (cid) => api.get(`/courses/${cid}/live-classes`), scheduleLive: (cid, b) => api.post(`/courses/${cid}/live-classes`, b),
  startLive: (id) => api.post(`/live-classes/${id}/start`), endLive: (id) => api.post(`/live-classes/${id}/end`), cancelLive: (id) => api.post(`/live-classes/${id}/cancel`), joinToken: (id) => api.get(`/live-classes/${id}/join-token`),
  assignments: (cid) => api.get(`/courses/${cid}/assignments`), createAssignment: (cid, b) => api.post(`/courses/${cid}/assignments`, b),
  publishAssignment: (id) => api.post(`/assignments/${id}/publish`), unpublishAssignment: (id) => api.post(`/assignments/${id}/unpublish`),
  quizzes: (cid) => api.get(`/courses/${cid}/quizzes`), exams: (cid) => api.get(`/courses/${cid}/exams`),
  createAssessment: (kind, cid, b) => api.post(`/courses/${cid}/${kind}`, b),
  results: (kind, id) => api.get(`/${kind}/${id}/results`),
  submissions: (kind, id, q) => api.get(`/${kind}/${id}/submissions`, q),
  grade: (sid, body) => api.put(`/submissions/${sid}/grade`, body),
  questions: (cid, q) => api.get(`/courses/${cid}/question-bank`, q), createQuestion: (cid, b) => api.post(`/courses/${cid}/question-bank`, b),
  announcements: (cid) => api.get(`/courses/${cid}/announcements`), announce: (cid, text) => api.post(`/courses/${cid}/announcements`, { text }),
  forum: (cid, q) => api.get(`/courses/${cid}/forum/posts`, q)
};
