const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const cookieParser = require('cookie-parser');

const env = require('./config/env');
const requestLogger = require('./middleware/requestLogger.middleware');
const errorHandler = require('./middleware/errorHandler.middleware');
const notFound = require('./middleware/notFound.middleware');
const { apiLimiter, verifyLimiter, uploadLimiter } = require('./middleware/rateLimiter.middleware');
const { sanitizeRequest, normalizePagination, noStore } = require('./middleware/sanitize.middleware');

const authRoutes = require('./routes/authRoutes');
const courseRoutes = require('./routes/courseRoutes');
const courseModuleRoutes = require('./routes/courseModuleRoutes');
const lessonRoutes = require('./routes/lessonRoutes');
const liveClassRoutes = require('./routes/liveClassRoutes');
const assignmentRoutes = require('./routes/assignmentRoutes');
const quizRoutes = require('./routes/quizRoutes');
const examRoutes = require('./routes/examRoutes');
const questionBankRoutes = require('./routes/questionBankRoutes');
const submissionRoutes = require('./routes/submissionRoutes');
const attendanceRoutes = require('./routes/attendanceRoutes');
const messagingRoutes = require('./routes/messagingRoutes');
const announcementRoutes = require('./routes/announcementRoutes');
const analyticsRoutes = require('./routes/analyticsRoutes');
const forumRoutes = require('./routes/forumRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const adminRoutes = require('./routes/adminRoutes');
const studentRoutes = require('./routes/studentRoutes');
const aiRoutes = require('./routes/aiRoutes');
const billingRoutes = require('./routes/billingRoutes');
const webhookRoutes = require('./routes/webhookRoutes');
const certificateController = require('./controllers/certificateController');
const certificateRoutes = require('./routes/certificateRoutes');
const fileRoutes = require('./routes/fileRoutes');
const pushRoutes = require('./routes/pushRoutes');

const app = express();

// Behind Nginx / a PaaS load balancer, set TRUST_PROXY=1 so req.ip (rate limiting, audit logs) is the real client.
if (env.trustProxy !== false) app.set('trust proxy', env.trustProxy);
app.disable('x-powered-by');

// --- Security & core middleware ---
app.use(helmet());

// CORS allow-list (CLIENT_URL + CORS_ORIGINS). Requests with no Origin header (mobile apps, curl, server-to-server) are not browser
// cross-site requests, so they pass; every browser origin that is not listed is refused.
const corsOptions = {
  origin(origin, cb) {
    if (!origin || env.corsOrigins.includes(origin)) return cb(null, true);
    return cb(null, false);
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Accept'],
  maxAge: 600
};

// --- Payment gateway webhooks ---
// Mounted BEFORE cors, the rate limiter and express.json(): signature checks need the raw request bytes,
// and gateway servers must never be throttled or rejected by browser-oriented middleware.
app.use('/api/webhooks', webhookRoutes);

app.use(cors(corsOptions));
app.use(compression());
app.use(express.json({ limit: env.security.jsonLimit }));
// extended:false => no nested objects from form posts (blocks `a[$ne]=1` style operator injection at the parser)
app.use(express.urlencoded({ extended: false, limit: '100kb', parameterLimit: 200 }));
app.use(cookieParser());
app.use(sanitizeRequest); // strips $-operators / dotted keys from body, query and params
app.use(requestLogger);
app.use('/api', noStore, normalizePagination, apiLimiter);
// One stricter budget for every multipart upload, wherever the route lives.
app.use('/api', (req, res, next) => (req.is('multipart/form-data') ? uploadLimiter(req, res, next) : next()));

// --- Health check ---
const health = (req, res) => {
  res.status(200).json({ success: true, message: 'OK', timestamp: new Date().toISOString() });
};
app.get('/health', health);
app.get('/api/health', health);

// --- Auth routes ---
app.use('/api/auth', authRoutes);

// --- Courses & Subjects (create/edit/delete courses, create subjects) ---
app.use('/api/courses', courseRoutes);

// --- Modules (Course -> Subject -> Module) ---
app.use('/api/courses/:courseId/subjects/:subjectId/modules', courseModuleRoutes.nestedRouter);
app.use('/api/courses/:courseId/modules', courseModuleRoutes.courseWideRouter);
app.use('/api/modules', courseModuleRoutes.itemRouter);

// --- Lessons (create lessons, upload text/images/pdfs/audio/video/external-resources/attachments) ---
app.use(
  '/api/courses/:courseId/subjects/:subjectId/modules/:moduleId/lessons',
  lessonRoutes.nestedRouter
);
app.use('/api/courses/:courseId/lessons', lessonRoutes.courseListRouter);
app.use('/api/lessons', lessonRoutes.itemRouter);

// --- Live classes (schedule live classes) ---
app.use('/api/courses/:courseId/live-classes', liveClassRoutes.nestedRouter);
app.use('/api/live-classes', liveClassRoutes.itemRouter);

// --- Assignments ---
app.use('/api/courses/:courseId/assignments', assignmentRoutes.nestedRouter);
app.use('/api/assignments', assignmentRoutes.itemRouter);

// --- Quizzes & Exams (separate endpoints, shared underlying assessment model) ---
app.use('/api/courses/:courseId/quizzes', quizRoutes.nestedRouter);
app.use('/api/quizzes', quizRoutes.itemRouter);
app.use('/api/courses/:courseId/exams', examRoutes.nestedRouter);
app.use('/api/exams', examRoutes.itemRouter);

// --- Question bank ---
app.use('/api/courses/:courseId/question-bank', questionBankRoutes.nestedRouter);
app.use('/api/question-bank', questionBankRoutes.itemRouter);

// --- Submissions & grading ---
app.use('/api/assignments', submissionRoutes.assignmentSubmissionsRouter); // GET /:id/submissions
app.use('/api/quizzes', submissionRoutes.assessmentSubmissionsRouter); // GET /:id/submissions
app.use('/api/exams', submissionRoutes.assessmentSubmissionsRouter); // GET /:id/submissions
app.use('/api/submissions', submissionRoutes.itemRouter);

// --- Attendance ---
app.use('/api/courses/:courseId/attendance', attendanceRoutes.nestedRouter);
app.use('/api/attendance', attendanceRoutes.itemRouter);

// --- Messaging (teacher-student communication) ---
app.use('/api/messages', messagingRoutes);

// --- Announcements ---
app.use('/api/courses/:courseId/announcements', announcementRoutes.nestedRouter);
app.use('/api/announcements', announcementRoutes.itemRouter);

// --- Analytics (student performance + course analytics) ---
app.use('/api/courses/:courseId/analytics', analyticsRoutes.courseAnalyticsRouter);
app.use('/api/assignments', analyticsRoutes.assignmentAnalyticsRouter); // GET /:id/analytics
app.use('/api/quizzes', analyticsRoutes.assessmentAnalyticsRouter); // GET /:id/analytics
app.use('/api/exams', analyticsRoutes.assessmentAnalyticsRouter); // GET /:id/analytics

// --- Discussion forum (shared by teachers and students; moderation restricted to a course's own teachers/admins) ---
app.use('/api/courses/:courseId/forum', forumRoutes.courseRouter);
app.use('/api/forum-posts', forumRoutes.postRouter);
app.use('/api/forum-reports', forumRoutes.reportRouter);

// --- Notifications (shared inbox for every role) ---
app.use('/api/notifications', notificationRoutes);

// --- Administrator dashboard (stats, user/course/billing management, audit logs, settings, backups) ---
app.use('/api/admin', adminRoutes);

// --- Student learning module (dashboard, enrollment, lessons, live classes,
//     assignments, quizzes, exams, progress, notifications, certificates, forums) ---
app.use('/api/student', studentRoutes);

// --- AI teaching assistant (rate-limited and quota-tracked; API key never leaves the server) ---
app.use('/api/ai', aiRoutes);

// --- Billing: plans, checkout, payment verification, history, receipts, trials ---
app.use('/api/billing', billingRoutes);

// --- Certificates: public verification (GET /api/certificates/verify/:certificateId) + instructor signature ---
app.use('/api/certificates', certificateRoutes);

// --- Signed file URLs (needed because <img>/<video>/<iframe> cannot send an Authorization header) ---
app.use('/api/files', fileRoutes.apiRouter);

// --- Web Push subscriptions (PWA / Android) ---
app.use('/api/push', pushRoutes);

// Human-readable verification page: this is what the QR code on a certificate opens.
app.get('/verify/:certificateId', verifyLimiter, certificateController.verifyPage);

// --- Static file serving for uploaded assets ---
// Certificates are rendered on demand and never served from disk. Older versions wrote PDFs into
// uploads/certificates, which this static handler would have exposed publicly; block that folder explicitly.
app.use('/uploads/certificates', (req, res) => res.status(404).json({ success: false, message: 'Not found' }));
// Avatars/thumbnails are public; every other upload needs a short-lived signed URL (see routes/fileRoutes.js).
app.use('/uploads', fileRoutes.uploadsRouter);

// --- 404 + centralized error handling (must be last) ---
app.use(notFound);
app.use(errorHandler);

module.exports = app;
