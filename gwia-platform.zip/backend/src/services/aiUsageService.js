const mongoose = require('mongoose');
const AiUsageLog = require('../models/aiUsageLog.model');
const ApiError = require('../utils/ApiError');
const env = require('../config/env');

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

async function getTodayUsageCount(userId) {
  return AiUsageLog.countDocuments({ userId, createdAt: { $gte: startOfToday() } });
}

/**
 * Throws if the user has already hit their daily AI request quota.
 * Called before making the (costly) AI API call, not just at logging
 * time, so an over-quota user is stopped before we spend money on
 * their behalf.
 */
async function enforceQuota(userId) {
  const count = await getTodayUsageCount(userId);
  if (count >= env.ai.dailyQuota) {
    throw ApiError.forbidden(
      `Daily AI usage limit reached (${env.ai.dailyQuota} requests/day). Please try again tomorrow.`
    );
  }
}

async function recordUsage({
  userId,
  role,
  feature,
  courseId,
  subjectId,
  lessonId,
  inputTokens,
  outputTokens,
  durationMs,
  success,
  errorMessage
}) {
  try {
    await AiUsageLog.create({
      userId,
      role,
      feature,
      courseId: courseId || null,
      subjectId: subjectId || null,
      lessonId: lessonId || null,
      inputTokens: inputTokens ?? null,
      outputTokens: outputTokens ?? null,
      durationMs: durationMs ?? null,
      success,
      errorMessage: errorMessage || null
    });
  } catch (err) {
    // Usage logging must never break the actual AI response the user is waiting on.
    // eslint-disable-next-line no-console
    console.error('Failed to record AI usage log:', err.message);
  }
}

async function getMyUsageSummary(userId) {
  const todayCount = await getTodayUsageCount(userId);
  const userObjectId = typeof userId === 'string' ? new mongoose.Types.ObjectId(userId) : userId;

  const byFeature = await AiUsageLog.aggregate([
    { $match: { userId: userObjectId } },
    { $group: { _id: '$feature', count: { $sum: 1 } } },
    { $sort: { count: -1 } }
  ]);

  return {
    todayCount,
    dailyQuota: env.ai.dailyQuota,
    remainingToday: Math.max(0, env.ai.dailyQuota - todayCount),
    usageByFeature: byFeature.map((f) => ({ feature: f._id, count: f.count }))
  };
}

module.exports = { getTodayUsageCount, enforceQuota, recordUsage, getMyUsageSummary };
