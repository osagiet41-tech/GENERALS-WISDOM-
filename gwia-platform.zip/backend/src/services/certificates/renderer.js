const fs = require('fs');
const path = require('path');

const FONT_DIR = path.join(__dirname, '..', '..', '..', 'assets', 'fonts');
const FONT_FILES = {
  'Cert-Serif-Bold': 'DejaVuSerif-Bold.ttf',
  'Cert-Serif-BoldItalic': 'DejaVuSerif-BoldItalic.ttf',
  'Cert-Serif-Italic': 'DejaVuSerif-Italic.ttf',
  'Cert-Sans': 'DejaVuSans.ttf',
  'Cert-Sans-Bold': 'DejaVuSans-Bold.ttf'
};

const COLORS = {
  navy: '#1B3358',
  gold: '#B08D3C',
  ink: '#1F2430',
  gray: '#5B6270',
  lightGray: '#C9CDD4',
  white: '#FFFFFF'
};

/**
 * Registers the bundled fonts (DejaVu: covers Yoruba/Igbo/Hausa letters such as ọ ẹ ṣ, which the built-in
 * PDF fonts cannot draw). If the files are missing, falls back to the built-in fonts so rendering never fails.
 */
function registerFonts(doc) {
  const allPresent = Object.values(FONT_FILES).every((f) => fs.existsSync(path.join(FONT_DIR, f)));
  if (!allPresent) {
    return { title: 'Times-Bold', name: 'Times-BoldItalic', script: 'Times-Italic', body: 'Helvetica', bodyBold: 'Helvetica-Bold', custom: false };
  }
  for (const [name, file] of Object.entries(FONT_FILES)) doc.registerFont(name, path.join(FONT_DIR, file));
  return { title: 'Cert-Serif-Bold', name: 'Cert-Serif-BoldItalic', script: 'Cert-Serif-Italic', body: 'Cert-Sans', bodyBold: 'Cert-Sans-Bold', custom: true };
}

function formatDate(date) {
  return new Date(date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
}

/** Width of a string, including letter-spacing, at the doc's current font and size. */
function measure(doc, text, cs = 0) {
  return doc.widthOfString(text) + cs * text.length;
}

/** Largest font size (down to minSize) at which `text` fits in maxWidth. */
function fitSize(doc, text, font, maxSize, minSize, maxWidth, cs = 0) {
  let size = maxSize;
  doc.font(font);
  for (; size > minSize; size -= 0.5) {
    doc.fontSize(size);
    if (measure(doc, text, cs) <= maxWidth) break;
  }
  return size;
}

/** Splits at the space nearest the middle so two lines come out balanced. */
function splitInTwo(text) {
  const words = text.split(/\s+/);
  if (words.length < 2) return [text];
  let best = 1;
  let bestDiff = Infinity;
  for (let i = 1; i < words.length; i += 1) {
    const diff = Math.abs(words.slice(0, i).join(' ').length - words.slice(i).join(' ').length);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = i;
    }
  }
  return [words.slice(0, best).join(' '), words.slice(best).join(' ')];
}

/**
 * Fits text into maxWidth: one line if possible (shrinking down to minSize), otherwise two balanced lines
 * (allowed to shrink further), and as a last resort a smaller size, so text can never run off the page.
 */
function fitLines(doc, text, font, maxSize, minSize, maxWidth) {
  const fits = (t, size) => {
    doc.font(font).fontSize(size);
    return measure(doc, t) <= maxWidth;
  };
  let size = maxSize;
  while (size > minSize && !fits(text, size)) size -= 0.5;
  if (fits(text, size)) return { lines: [text], size };

  const lines = splitInTwo(text);
  const floor = Math.max(8, minSize * 0.65);
  for (size = maxSize; size > floor; size -= 0.5) {
    if (lines.every((l) => fits(l, size))) return { lines, size };
  }
  size = floor;
  while (size > 5 && !lines.every((l) => fits(l, size))) size -= 0.5;
  return { lines, size };
}

/** Single line of text centred on cx. Positioned manually (no pdfkit wrapping, so it can never spill onto a new page). */
function centered(doc, text, cx, y, { font, size, color, cs = 0 }) {
  doc.font(font).fontSize(size).fillColor(color);
  const w = measure(doc, text, cs);
  doc.text(text, cx - w / 2, y, { lineBreak: false, characterSpacing: cs });
  return w;
}

function hLine(doc, x1, x2, y, color, width) {
  doc.strokeColor(color).lineWidth(width).moveTo(x1, y).lineTo(x2, y).stroke();
}

function drawBorders(doc, W, H) {
  doc.strokeColor(COLORS.navy).lineWidth(3).rect(20, 20, W - 40, H - 40).stroke();
  doc.strokeColor(COLORS.gold).lineWidth(1).rect(30, 30, W - 60, H - 60).stroke();
  for (const [x, y] of [[30, 30], [W - 30, 30], [30, H - 30], [W - 30, H - 30]]) {
    doc.circle(x, y, 5).fill(COLORS.gold);
  }
}

function drawSeal(doc, cx, cy, f) {
  doc.circle(cx, cy, 36).fill(COLORS.gold);
  doc.strokeColor(COLORS.white).lineWidth(1.2).circle(cx, cy, 31).stroke();
  doc.circle(cx, cy, 28).fill(COLORS.navy);
  centered(doc, 'OFFICIAL', cx, cy - 15, { font: f.bodyBold, size: 7.5, color: COLORS.white, cs: 0.8 });
  // five-point star drawn as a polygon (a text glyph would not exist in the built-in fallback fonts)
  const star = [];
  for (let i = 0; i < 10; i += 1) {
    const r = i % 2 === 0 ? 6 : 2.6;
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    star.push([cx + r * Math.cos(a), cy + 0.5 + r * Math.sin(a)]);
  }
  doc.polygon(...star).fill(COLORS.gold);
  centered(doc, 'SEAL', cx, cy + 7, { font: f.bodyBold, size: 7.5, color: COLORS.white, cs: 0.8 });
}

/** One signature block: image (or a typed-name fallback) over a rule, then name and role underneath. */
function drawSigner(doc, cx, lineY, { name, role, image }, f) {
  const half = 95;
  if (image) {
    doc.image(image, cx - 80, lineY - 56, { fit: [160, 52], align: 'center', valign: 'bottom' });
  } else {
    // No uploaded signature: print the name in italic script-style type so the block never looks empty.
    const size = fitSize(doc, name, f.script, 24, 12, half * 2 - 10);
    centered(doc, name, cx, lineY - size * 1.25, { font: f.script, size, color: COLORS.navy });
  }
  hLine(doc, cx - half, cx + half, lineY, COLORS.ink, 0.8);
  const nameSize = fitSize(doc, name, f.bodyBold, 11.5, 8, half * 2);
  centered(doc, name, cx, lineY + 6, { font: f.bodyBold, size: nameSize, color: COLORS.ink });
  const roleSize = fitSize(doc, role, f.body, 9.5, 7, half * 2);
  centered(doc, role, cx, lineY + 6 + nameSize * 1.35, { font: f.body, size: roleSize, color: COLORS.gray });
}

function drawQr(doc, qr, x, y, size) {
  if (!qr) return;
  const quiet = 2;
  const cell = size / (qr.size + quiet * 2);
  doc.rect(x, y, size, size).fill(COLORS.white);
  for (let r = 0; r < qr.size; r += 1) {
    for (let c = 0; c < qr.size; c += 1) {
      if (qr.get(r, c)) doc.rect(x + (c + quiet) * cell, y + (r + quiet) * cell, cell + 0.15, cell + 0.15);
    }
  }
  doc.fill(COLORS.ink);
}

/**
 * Draws the certificate. `data`:
 *   studentName, courseTitle, institutionName, completionDate, certificateId, verifyUrl,
 *   instructors: [{ name }], signatory: { name, title } | null, finalScorePercent|null
 * `assets`: { fonts, qr: {size,get}|null, instructorImages: [Buffer|null], signatoryImage: Buffer|null }
 */
function drawCertificate(doc, data, assets) {
  const W = doc.page.width;
  const H = doc.page.height;
  const cx = W / 2;
  const f = assets.fonts;
  const contentW = W - 170;

  drawBorders(doc, W, H);

  // Institution + title
  const inst = String(data.institutionName || '').toUpperCase();
  const instSize = fitSize(doc, inst, f.bodyBold, 12, 8, contentW, 2);
  centered(doc, inst, cx, 58, { font: f.bodyBold, size: instSize, color: COLORS.navy, cs: 2 });
  hLine(doc, cx - 30, cx + 30, 82, COLORS.gold, 1.5);

  const title = 'CERTIFICATE OF COMPLETION';
  const titleSize = fitSize(doc, title, f.title, 34, 20, contentW, 2);
  centered(doc, title, cx, 96, { font: f.title, size: titleSize, color: COLORS.navy, cs: 2 });

  // --- Plan the recipient/course block first, so it can be centred between the title and the signatures ---
  const nameFit = fitLines(doc, data.studentName, f.name, 38, 22, contentW - 40);
  const courseFit = fitLines(doc, data.courseTitle, f.bodyBold, 22, 14, contentW);
  const nameLineH = nameFit.size * 1.2;
  const courseLineH = courseFit.size * 1.3;
  const hasScore = data.finalScorePercent !== null && data.finalScorePercent !== undefined;
  const blockH =
    24 + nameFit.lines.length * nameLineH + 2 + 16 + 26 + courseFit.lines.length * courseLineH + 8 + 16;
  const windowTop = 156;
  const windowBottom = 392; // signature images start just below this
  const shift = Math.max(0, Math.min((windowBottom - windowTop - blockH) / 2, 26));

  let y = windowTop + shift;
  centered(doc, 'This is to certify that', cx, y, { font: f.body, size: 12.5, color: COLORS.gray });
  y += 24;
  let widest = 0;
  for (const line of nameFit.lines) {
    widest = Math.max(widest, centered(doc, line, cx, y, { font: f.name, size: nameFit.size, color: COLORS.ink }));
    y += nameLineH;
  }
  const ruleY = y + 2;
  const ruleHalf = Math.min(Math.max(widest / 2 + 40, 150), contentW / 2);
  hLine(doc, cx - ruleHalf, cx + ruleHalf, ruleY, COLORS.gold, 1);

  y = ruleY + 16;
  centered(doc, 'has successfully completed the course', cx, y, { font: f.body, size: 12.5, color: COLORS.gray });
  y += 26;
  for (const line of courseFit.lines) {
    centered(doc, line, cx, y, { font: f.bodyBold, size: courseFit.size, color: COLORS.navy });
    y += courseLineH;
  }

  y += 8;
  let completion = `Completed on ${formatDate(data.completionDate)}`;
  if (hasScore) completion += `   \u2022   Final score ${data.finalScorePercent}%`;
  centered(doc, completion, cx, y, { font: f.body, size: 12, color: COLORS.ink });

  // Signatures
  const signLineY = 450;
  const first = (data.instructors || [])[0];
  const second = (data.instructors || [])[1];
  const signers = [];
  if (first) signers.push({ name: first.name, role: 'Course Instructor', image: assets.instructorImages?.[0] || null });
  if (data.signatory && data.signatory.name) {
    signers.push({ name: data.signatory.name, role: data.signatory.title || 'Authorised Signatory', image: assets.signatoryImage || null });
  } else if (second) {
    signers.push({ name: second.name, role: 'Course Instructor', image: assets.instructorImages?.[1] || null });
  }
  const leftX = W * 0.22;
  const rightX = W * 0.78;
  if (signers[0]) drawSigner(doc, leftX, signLineY, signers[0], f);
  if (signers[1]) {
    drawSigner(doc, rightX, signLineY, signers[1], f);
  } else {
    // Single signer: mirror the layout with the issue date so the page stays balanced.
    centered(doc, formatDate(data.issuedAt || data.completionDate), rightX, signLineY - 18, { font: f.script, size: 15, color: COLORS.navy });
    hLine(doc, rightX - 95, rightX + 95, signLineY, COLORS.ink, 0.8);
    centered(doc, 'Date of issue', rightX, signLineY + 6, { font: f.bodyBold, size: 11.5, color: COLORS.ink });
  }
  drawSeal(doc, cx, signLineY - 28, f);

  // Verification footer
  hLine(doc, 60, W - 60, 494, COLORS.lightGray, 0.6);
  const left = 62;
  doc.font(f.body).fontSize(8).fillColor(COLORS.gray).text('CERTIFICATE ID', left, 501, { lineBreak: false, characterSpacing: 1 });
  doc.font(f.bodyBold).fontSize(14).fillColor(COLORS.navy).text(data.certificateId, left, 512, { lineBreak: false, characterSpacing: 1 });
  const verifyText = `Verify this certificate: ${data.verifyUrl}`;
  const verifyMax = W - 60 - left - 90;
  const vSize = fitSize(doc, verifyText, f.body, 9, 6, verifyMax);
  doc.font(f.body).fontSize(vSize).fillColor(COLORS.gray).text(verifyText, left, 534, { lineBreak: false });
  doc.font(f.body).fontSize(7.5).fillColor(COLORS.gray).text(
    'Anyone can confirm this certificate is genuine at the address above using the Certificate ID.',
    left,
    546,
    { lineBreak: false }
  );
  drawQr(doc, assets.qr, W - 62 - 56, 499, 56);
}

/** Renders to a Buffer with the real pdfkit. `PDFDocument` is injected so tests/preview can use a fake. */
function renderToBuffer(PDFDocument, data, assets) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      layout: 'landscape',
      margin: 0,
      info: {
        Title: `Certificate ${data.certificateId}`,
        Author: data.institutionName,
        Subject: `Certificate of completion: ${data.courseTitle}`,
        Keywords: data.certificateId
      }
    });
    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
    try {
      const fonts = registerFonts(doc);
      drawCertificate(doc, data, { ...assets, fonts });
      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = { drawCertificate, renderToBuffer, registerFonts, formatDate, COLORS };
