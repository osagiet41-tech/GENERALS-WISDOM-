import { h, mount, icon } from '../core/dom.js';
import { authApi } from '../api/auth.js';
import { session, homeFor } from '../core/session.js';
import { buildForm } from '../ui/form.js';
import { toast } from '../ui/toast.js';
import { toggleTheme } from '../core/theme.js';
import { spinner } from '../ui/states.js';

const q = new URLSearchParams(location.search);
const mode = q.get('mode') || 'login', root = h('div');
const safeNext = (n) => (n && /^[\w-]+\.html([?#].*)?$/.test(n) ? n : null);   // same-site pages only: no open redirect

const links = (...a) => h('p', { class: 'small', style: 'margin-top:16px' }, a.flatMap(([text, href], i) => [i ? ' · ' : null, h('a', { href }, text)]));
const email = { name: 'email', label: 'Email address', type: 'email', required: true, autocomplete: 'email' };
const password = (name = 'password', label = 'Password', ac = 'current-password') => ({ name, label, type: 'password', required: true, autocomplete: ac, minlength: ac === 'new-password' ? 8 : undefined, hint: ac === 'new-password' ? 'At least 8 characters.' : undefined });

const screens = {
  login: () => ({ title: 'Sign in', body: [buildForm({ grid: false, submitLabel: 'Sign in', fields: [email, password()],
    onSubmit: async (v) => { const u = await authApi.login(v.email, v.password); location.replace(safeNext(q.get('next')) || homeFor(u.role)); } }),
    links(['Forgot password?', 'auth.html?mode=forgot'], ['Create an account', 'auth.html?mode=register'])] }),
  register: () => ({ title: 'Create your account', body: [buildForm({ grid: false, submitLabel: 'Create account', fields: [
      { name: 'name', label: 'Full name', required: true, autocomplete: 'name' }, email, password('password', 'Password', 'new-password'),
      { name: 'role', label: 'I am a', type: 'select', options: [{ value: 'student', label: 'Student' }, { value: 'teacher', label: 'Teacher' }], value: 'student' }],
    onSubmit: async (v) => { await authApi.register(v); mount(root, card('Check your email', h('p', null, `We sent a verification link to ${v.email}. Open it to activate your account, then sign in.`), links(['Go to sign in', 'auth.html?mode=login']))); } }),
    links(['Already registered? Sign in', 'auth.html?mode=login'])] }),
  forgot: () => ({ title: 'Reset your password', body: [buildForm({ grid: false, submitLabel: 'Send reset link', fields: [email],
    onSubmit: async (v) => { await authApi.forgot(v.email); toast.success('If that email exists, a reset link is on its way.'); } }), links(['Back to sign in', 'auth.html?mode=login'])] }),
  reset: () => ({ title: 'Choose a new password', body: q.get('token') ? [buildForm({ grid: false, submitLabel: 'Save password', fields: [password('password', 'New password', 'new-password')],
    onSubmit: async (v) => { await authApi.reset(q.get('token'), v.password); toast.success('Password updated. Please sign in.'); setTimeout(() => location.replace('auth.html?mode=login'), 1200); } })] : [h('p', { class: 'form-error' }, 'This reset link is missing its token. Request a new one.'), links(['Request a new link', 'auth.html?mode=forgot'])] }),
  'verify-email': () => {
    const body = h('div', null, spinner(), ' Verifying your email…');
    authApi.verifyEmail(q.get('token')).then(() => mount(body, h('p', { class: 'banner ok' }, 'Email verified. You can sign in now.'), links(['Sign in', 'auth.html?mode=login'])))
      .catch((e) => mount(body, h('p', { class: 'form-error', role: 'alert' }, e.message), links(['Back to sign in', 'auth.html?mode=login'])));
    return { title: 'Email verification', body: [body] };
  }
};
const card = (title, ...body) => h('div', { class: 'auth-wrap' }, h('main', { class: 'auth-card' }, h('a', { class: 'small', href: 'index.html' }, '← Back to the academy'), h('h1', { style: 'margin-top:12px' }, title), ...body));
const s = (screens[mode] || screens.login)();
if (session.user && mode === 'login') location.replace(homeFor(session.user.role));
document.title = `${s.title} · Generals Wisdom International Academy`;
mount(root, card(s.title, ...s.body)); document.body.append(root);
document.body.append(h('button', { class: 'btn btn-secondary btn-icon', type: 'button', 'aria-label': 'Toggle dark mode', onclick: toggleTheme, style: 'position:fixed;right:12px;top:12px' }, icon('moon')));
