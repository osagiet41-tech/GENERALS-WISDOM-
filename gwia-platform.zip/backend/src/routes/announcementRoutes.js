const express = require('express');
const controller = require('../controllers/announcementController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership, verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { announcementValidator } = require('../validators/announcementValidator');
const Announcement = require('../models/announcement.model');

const nestedRouter = express.Router({ mergeParams: true });
nestedRouter.use(authMiddleware, requireTeacherOrAdmin);
nestedRouter.get('/', verifyCourseOwnership(), controller.listAnnouncements);
nestedRouter.post('/', verifyCourseOwnership(), validate(announcementValidator), controller.createAnnouncement);

const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);
itemRouter.put(
  '/:id',
  verifyResourceOwnership(Announcement, 'id'),
  validate(announcementValidator),
  controller.updateAnnouncement
);
itemRouter.delete('/:id', verifyResourceOwnership(Announcement, 'id'), controller.deleteAnnouncement);

module.exports = { nestedRouter, itemRouter };
