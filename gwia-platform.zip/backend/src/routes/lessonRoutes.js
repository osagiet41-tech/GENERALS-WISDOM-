const express = require('express');
const controller = require('../controllers/lessonController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership, verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { uploadImage, uploadPdf, uploadAudio, uploadVideo, uploadMaterial } = require('../config/multer');
const {
  createLessonValidator,
  updateLessonValidator,
  updateTextValidator,
  externalResourceValidator
} = require('../validators/lessonValidator');
const Lesson = require('../models/lesson.model');

// Nested under /api/courses/:courseId/subjects/:subjectId/modules/:moduleId/lessons
const nestedRouter = express.Router({ mergeParams: true });
nestedRouter.use(authMiddleware, requireTeacherOrAdmin);
nestedRouter.post('/', verifyCourseOwnership(), validate(createLessonValidator), controller.createLesson);

// Nested under /api/courses/:courseId/lessons — flat listing, optional ?subjectId=/?moduleId= filters
const courseListRouter = express.Router({ mergeParams: true });
courseListRouter.use(authMiddleware, requireTeacherOrAdmin);
courseListRouter.get('/', verifyCourseOwnership(), controller.listLessons);

// Top-level /api/lessons/:id for item-scoped operations
const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);

itemRouter.put('/:id', verifyResourceOwnership(Lesson, 'id'), validate(updateLessonValidator), controller.updateLesson);
itemRouter.delete('/:id', verifyResourceOwnership(Lesson, 'id'), controller.deleteLesson);

// Text
itemRouter.put(
  '/:id/text',
  verifyResourceOwnership(Lesson, 'id'),
  validate(updateTextValidator),
  controller.updateText
);

// Images
itemRouter.post(
  '/:id/images',
  verifyResourceOwnership(Lesson, 'id'),
  uploadImage.single('image'),
  controller.addImage
);
itemRouter.delete('/:id/images/:imageId', verifyResourceOwnership(Lesson, 'id'), controller.removeImage);

// PDFs
itemRouter.post('/:id/pdfs', verifyResourceOwnership(Lesson, 'id'), uploadPdf.single('pdf'), controller.addPdf);
itemRouter.delete('/:id/pdfs/:pdfId', verifyResourceOwnership(Lesson, 'id'), controller.removePdf);

// Audio
itemRouter.post(
  '/:id/audio',
  verifyResourceOwnership(Lesson, 'id'),
  uploadAudio.single('audio'),
  controller.addAudio
);
itemRouter.delete('/:id/audio/:audioId', verifyResourceOwnership(Lesson, 'id'), controller.removeAudio);

// Video (single per lesson)
itemRouter.post(
  '/:id/video',
  verifyResourceOwnership(Lesson, 'id'),
  uploadVideo.single('video'),
  controller.setVideo
);
itemRouter.delete('/:id/video', verifyResourceOwnership(Lesson, 'id'), controller.removeVideo);

// External resources (links, no upload)
itemRouter.post(
  '/:id/external-resources',
  verifyResourceOwnership(Lesson, 'id'),
  validate(externalResourceValidator),
  controller.addExternalResource
);
itemRouter.delete(
  '/:id/external-resources/:resourceId',
  verifyResourceOwnership(Lesson, 'id'),
  controller.removeExternalResource
);

// Attachments (generic downloadable files)
itemRouter.post(
  '/:id/attachments',
  verifyResourceOwnership(Lesson, 'id'),
  uploadMaterial.single('file'),
  controller.addAttachment
);
itemRouter.delete('/:id/attachments/:attachmentId', verifyResourceOwnership(Lesson, 'id'), controller.removeAttachment);

module.exports = { nestedRouter, courseListRouter, itemRouter };
