const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const assessmentService = require('../services/assessmentService');
const examResultService = require('../services/examResultService');

const KIND = 'quiz';

// POST /api/courses/:courseId/quizzes
const createQuiz = asyncHandler(async (req, res) => {
  const quiz = await assessmentService.createAssessment(KIND, req.course._id, req.user.id, req.body);
  return ApiResponse.created(res, quiz, 'Quiz created successfully');
});

// GET /api/courses/:courseId/quizzes
const listQuizzes = asyncHandler(async (req, res) => {
  const quizzes = await assessmentService.listAssessments(KIND, req.course._id, req.query.status);
  return ApiResponse.ok(res, quizzes, 'Quizzes retrieved');
});

// GET /api/quizzes/:id
const getQuiz = asyncHandler(async (req, res) => {
  const quiz = await assessmentService.getAssessmentWithAnswerKey(req.resource);
  return ApiResponse.ok(res, quiz, 'Quiz retrieved');
});

// PUT /api/quizzes/:id
const updateQuiz = asyncHandler(async (req, res) => {
  const quiz = await assessmentService.updateAssessment(req.resource, req.body);
  return ApiResponse.ok(res, quiz, 'Quiz updated successfully');
});

// DELETE /api/quizzes/:id
const deleteQuiz = asyncHandler(async (req, res) => {
  await assessmentService.deleteAssessment(req.resource);
  return ApiResponse.ok(res, null, 'Quiz deleted successfully');
});

// GET /api/quizzes/:id/results — every student's attempt(s) for this quiz (gradebook view)
const getResults = asyncHandler(async (req, res) => {
  const results = await examResultService.getAllResultsForAssessment(req.resource);
  return ApiResponse.ok(res, results, 'Quiz results retrieved');
});

module.exports = { createQuiz, listQuizzes, getQuiz, updateQuiz, deleteQuiz, getResults };
