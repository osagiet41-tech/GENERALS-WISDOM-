const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const announcementService = require('../services/announcementService');
const notificationService = require('../services/notificationService');

// POST /api/courses/:courseId/announcements
const createAnnouncement = asyncHandler(async (req, res) => {
  const announcement = await announcementService.createAnnouncement(req.course._id, req.user.id, req.body);

  const io = req.app.get('io');
  if (io) {
    for (const studentId of req.course.enrolledStudentIds) {
      io.to(`user:${studentId}`).emit('announcement:new', {
        announcementId: announcement._id,
        courseId: req.course._id,
        title: announcement.title
      });
    }
  }

  await notificationService.createNotificationsForMany(
    req.course.enrolledStudentIds,
    'announcement',
    announcement.title,
    `New announcement in ${req.course.title}`,
    { announcementId: announcement._id, courseId: req.course._id }
  );

  return ApiResponse.created(res, announcement, 'Announcement published successfully');
});

// GET /api/courses/:courseId/announcements
const listAnnouncements = asyncHandler(async (req, res) => {
  const announcements = await announcementService.listAnnouncements(req.course._id);
  return ApiResponse.ok(res, announcements, 'Announcements retrieved');
});

// PUT /api/announcements/:id
const updateAnnouncement = asyncHandler(async (req, res) => {
  const announcement = await announcementService.updateAnnouncement(req.resource, req.body);
  return ApiResponse.ok(res, announcement, 'Announcement updated successfully');
});

// DELETE /api/announcements/:id
const deleteAnnouncement = asyncHandler(async (req, res) => {
  await announcementService.deleteAnnouncement(req.resource);
  return ApiResponse.ok(res, null, 'Announcement deleted successfully');
});

module.exports = { createAnnouncement, listAnnouncements, updateAnnouncement, deleteAnnouncement };
