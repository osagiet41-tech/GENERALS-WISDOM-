import { config } from './config.js';
const loc = config.locale;
export const fmtDate = (d) => d ? new Intl.DateTimeFormat(loc, { dateStyle: 'medium' }).format(new Date(d)) : '—';
export const fmtDateTime = (d) => d ? new Intl.DateTimeFormat(loc, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(d)) : '—';
export const fmtTime = (d) => d ? new Intl.DateTimeFormat(loc, { timeStyle: 'short' }).format(new Date(d)) : '';
export function fmtMoney(amount, currency = config.defaultCurrency, { minor = false } = {}) {
  if (amount == null || Number.isNaN(Number(amount))) return '—';
  const value = minor ? Number(amount) / 100 : Number(amount);
  try { return new Intl.NumberFormat(loc, { style: 'currency', currency }).format(value); } catch { return `${currency} ${value.toFixed(2)}`; }
}
export const fmtPercent = (n) => (n == null ? '—' : `${Math.round(n)}%`);
export const initials = (name = '') => name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('') || '?';
export function debounce(fn, ms = 350) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
export function relTime(d) {
  const s = Math.round((new Date(d) - Date.now()) / 1000), abs = Math.abs(s);
  const rtf = new Intl.RelativeTimeFormat(loc, { numeric: 'auto' });
  if (abs < 60) return rtf.format(s, 'second'); if (abs < 3600) return rtf.format(Math.round(s / 60), 'minute');
  if (abs < 86400) return rtf.format(Math.round(s / 3600), 'hour'); return rtf.format(Math.round(s / 86400), 'day');
}
export const fmtClock = (sec) => { const s = Math.max(0, Math.floor(sec)); const hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60; return (hh ? `${hh}:` : '') + `${String(mm).padStart(hh ? 2 : 1, '0')}:${String(ss).padStart(2, '0')}`; };
export const toLocalInput = (d) => { const x = new Date(d); x.setMinutes(x.getMinutes() - x.getTimezoneOffset()); return x.toISOString().slice(0, 16); };
export const cap = (s = '') => s.charAt(0).toUpperCase() + s.slice(1).replace(/[_-]/g, ' ');
export const assetUrl = (u, base) => (!u ? '' : /^https?:/.test(u) ? u : `${base}${u}`);
