const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(__dirname, '..', '..', 'logs');
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

const LOG_FILE = path.join(LOG_DIR, 'app.log');
const ERROR_LOG_FILE = path.join(LOG_DIR, 'error.log');

const LEVELS = { error: 0, warn: 1, info: 2, debug: 3 };
const currentLevel = LEVELS[process.env.LOG_LEVEL] ?? LEVELS.info;

function timestamp() {
  return new Date().toISOString();
}

function writeToFile(filePath, line) {
  fs.appendFile(filePath, line + '\n', (err) => {
    if (err) {
      // eslint-disable-next-line no-console
      console.error('Failed to write log file:', err.message);
    }
  });
}

function formatLine(level, message) {
  return `[${timestamp()}] [${level.toUpperCase()}] ${message}`;
}

function log(level, message) {
  if (LEVELS[level] > currentLevel) return;

  const line = formatLine(level, message);

  // eslint-disable-next-line no-console
  const consoleMethod = level === 'error' ? console.error : level === 'warn' ? console.warn : console.log;
  consoleMethod(line);

  writeToFile(LOG_FILE, line);
  if (level === 'error') {
    writeToFile(ERROR_LOG_FILE, line);
  }
}

module.exports = {
  error: (msg) => log('error', msg),
  warn: (msg) => log('warn', msg),
  info: (msg) => log('info', msg),
  debug: (msg) => log('debug', msg)
};
