const Submission = require('../models/submission.model');
const Assignment = require('../models/assignment.model');
const { Assessment } = require('../models/assessment.model');
const ApiError = require('../utils/ApiError');
const certificateService = require('./certificateService');

async function listSubmissionsForResource(refType, refId, status) {
  const filter = { refType, refId };
  if (status) filter.status = status;
  return Submission.find(filter).populate('studentId', 'name email profile.avatarUrl').sort({ submittedAt: -1 });
}

async function getSubmission(submissionId) {
  const submission = await Submission.findById(submissionId).populate('studentId', 'name email');
  if (!submission) {
    throw ApiError.notFound('Submission not found');
  }
  return submission;
}

/**
 * Resolves the parent course id for a submission regardless of whether
 * it points at an Assignment or an Assessment (quiz/exam) — used by the
 * ownership middleware to confirm the grading teacher owns the course.
 */
async function resolveCourseIdForSubmission(submission) {
  return submission.courseId; // denormalized directly onto the submission for exactly this purpose
}

async function gradeAssignmentSubmission(submission, teacherId, { score, feedback }) {
  const assignment = await Assignment.findById(submission.refId);
  if (!assignment) {
    throw ApiError.notFound('Parent assignment no longer exists');
  }
  if (score < 0 || score > assignment.totalMarks) {
    throw ApiError.badRequest(`Score must be between 0 and ${assignment.totalMarks}`);
  }

  submission.grade = {
    score,
    totalMarks: assignment.totalMarks,
    feedback: feedback || null,
    gradedBy: teacherId,
    gradedAt: new Date()
  };
  submission.status = 'graded';
  await submission.save();
  certificateService.queueEvaluation(submission.studentId, submission.courseId);
  return submission;
}

/**
 * For quiz/exam submissions, grades objective (mcq/true_false) answers
 * automatically against the answer key, and lets the teacher assign
 * marks manually for subjective (short_answer/essay) ones.
 */
async function gradeAssessmentSubmission(submission, teacherId, manualMarks = {}) {
  const assessment = await Assessment.findById(submission.refId).populate('questions.questionId');
  if (!assessment) {
    throw ApiError.notFound('Parent quiz/exam no longer exists');
  }

  let totalAwarded = 0;
  let attemptTotalMarks = 0; // sum of marks for only the questions actually presented in THIS submission —
  // not assessment.totalMarks, which is the full question-bank pool and would be
  // wrong whenever random question selection drew a subset for this attempt.

  for (const answer of submission.answers) {
    const questionRef = assessment.questions.find((q) => q.questionId._id.toString() === answer.questionId.toString());
    if (!questionRef) continue;

    attemptTotalMarks += questionRef.marks;
    const question = questionRef.questionId;

    if (question.type === 'mcq' || question.type === 'true_false') {
      const isCorrect = String(answer.response) === String(question.correctAnswer);
      answer.marksAwarded = isCorrect ? questionRef.marks : 0;
    } else if (manualMarks[answer.questionId.toString()] !== undefined) {
      const awarded = Number(manualMarks[answer.questionId.toString()]);
      if (awarded < 0 || awarded > questionRef.marks) {
        throw ApiError.badRequest(`Marks for question ${answer.questionId} must be between 0 and ${questionRef.marks}`);
      }
      answer.marksAwarded = awarded;
    }

    totalAwarded += answer.marksAwarded || 0;
  }

  submission.grade = {
    score: totalAwarded,
    totalMarks: attemptTotalMarks,
    feedback: manualMarks.feedback || null,
    gradedBy: teacherId,
    gradedAt: new Date()
  };
  submission.status = 'graded';
  await submission.save();
  certificateService.queueEvaluation(submission.studentId, submission.courseId);
  return submission;
}

async function returnToStudent(submission) {
  submission.status = 'returned';
  await submission.save();
  return submission;
}

module.exports = {
  listSubmissionsForResource,
  getSubmission,
  resolveCourseIdForSubmission,
  gradeAssignmentSubmission,
  gradeAssessmentSubmission,
  returnToStudent
};
