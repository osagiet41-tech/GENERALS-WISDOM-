const express = require('express');
const controller = require('../controllers/examController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership, verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { createAssessmentValidator, updateAssessmentValidator } = require('../validators/assessmentValidator');
const { Assessment } = require('../models/assessment.model');
const ApiError = require('../utils/ApiError');

function requireKindExam(req, res, next) {
  if (req.resource.kind !== 'exam') return next(ApiError.notFound('Exam not found'));
  next();
}

const nestedRouter = express.Router({ mergeParams: true });
nestedRouter.use(authMiddleware, requireTeacherOrAdmin);
nestedRouter.get('/', verifyCourseOwnership(), controller.listExams);
nestedRouter.post('/', verifyCourseOwnership(), validate(createAssessmentValidator), controller.createExam);

const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);

itemRouter.get('/:id', verifyResourceOwnership(Assessment, 'id'), requireKindExam, controller.getExam);
itemRouter.put(
  '/:id',
  verifyResourceOwnership(Assessment, 'id'),
  requireKindExam,
  validate(updateAssessmentValidator),
  controller.updateExam
);
itemRouter.delete('/:id', verifyResourceOwnership(Assessment, 'id'), requireKindExam, controller.deleteExam);
itemRouter.get('/:id/results', verifyResourceOwnership(Assessment, 'id'), requireKindExam, controller.getResults);

module.exports = { nestedRouter, itemRouter };
