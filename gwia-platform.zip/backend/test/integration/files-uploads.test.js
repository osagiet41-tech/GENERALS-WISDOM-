const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { boot, itest, missing } = require('./helpers');

let t, owner, student, other, teacher, course, lesson;
const oid = () => new (require('mongoose').Types.ObjectId)();
const UP = path.join(__dirname, '..', '..', 'uploads');
const PNG = Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000001e221bc330000000049454e44ae426082', 'hex');

before(async () => {
  if (missing) return;
  t = await boot();
  [owner, student, other, teacher] = [await t.actor('student'), await t.actor('student'), await t.actor('student'), await t.actor('teacher')];
  const { Course } = require('../../src/models/course.model');
  const Lesson = require('../../src/models/lesson.model');
  const tid = teacher.user.id || teacher.user._id;
  course = await Course.create({ title: 'Files', teacherIds: [tid], createdBy: tid, status: 'published', enrolledStudentIds: [student.user.id || student.user._id] });
  fs.mkdirSync(path.join(UP, 'pdfs'), { recursive: true });
  fs.writeFileSync(path.join(UP, 'pdfs', 'test-notes.pdf'), '%PDF-1.4 test');
  lesson = await Lesson.create({ courseId: course._id, subjectId: oid(), moduleId: oid(), title: 'L', status: 'published', createdBy: tid, pdfs: [{ fileName: 'n.pdf', fileUrl: '/uploads/pdfs/test-notes.pdf', mimeType: 'application/pdf', size: 10 }] });
});
after(async () => { try { fs.unlinkSync(path.join(UP, 'pdfs', 'test-notes.pdf')); } catch (e) {} if (t) await t.close(); });

itest(test, 'private uploads are NOT publicly readable (no token, no signature)', async () => {
  assert.equal((await t.request.get('/uploads/pdfs/test-notes.pdf')).status, 403);
});

itest(test, 'a forged or tampered signature is refused', async () => {
  const exp = Math.floor(Date.now() / 1000) + 600;
  assert.equal((await t.request.get(`/uploads/pdfs/test-notes.pdf?u=${student.user.id}&exp=${exp}&sig=${'a'.repeat(64)}`)).status, 403);
});

itest(test, 'enrolled student gets a signed URL that works; the link cannot be reused for another file', async () => {
  const sign = await student.api.post('/api/files/sign').send({ paths: ['/uploads/pdfs/test-notes.pdf'] });
  assert.equal(sign.status, 200);
  const signed = sign.body.data.urls['/uploads/pdfs/test-notes.pdf'];
  assert.ok(signed);
  const ok = await t.request.get(signed);
  assert.equal(ok.status, 200);
  assert.equal(ok.headers['x-content-type-options'], 'nosniff');
  const swapped = signed.replace('test-notes.pdf', 'other.pdf');
  assert.notEqual((await t.request.get(swapped)).status, 200);
});

itest(test, 'IDOR: a student who is not enrolled receives NO signed URL for course files', async () => {
  const sign = await other.api.post('/api/files/sign').send({ paths: ['/uploads/pdfs/test-notes.pdf'] });
  assert.equal(sign.status, 200);
  assert.deepEqual(sign.body.data.urls, {});
});

itest(test, 'path traversal and non-upload paths are never signed or served', async () => {
  const sign = await student.api.post('/api/files/sign').send({ paths: ['/uploads/../.env', '/uploads/pdfs/../../package.json', '/etc/passwd', '/uploads/certificates/x.pdf'] });
  assert.deepEqual(sign.body.data.urls, {});
  assert.equal((await t.request.get('/uploads/..%2f..%2fpackage.json')).status, 404);
  assert.equal((await t.request.get('/uploads/certificates/anything.pdf')).status, 404);
});

itest(test, 'uploads: an HTML file disguised as a PNG is rejected and nothing is stored', async () => {
  const before = fs.existsSync(path.join(UP, 'avatars')) ? fs.readdirSync(path.join(UP, 'avatars')).length : 0;
  const res = await owner.api.post('/api/auth/profile/picture').attach('avatar', Buffer.from('<html><script>alert(1)</script></html>'), { filename: 'evil.png', contentType: 'image/png' });
  assert.equal(res.status, 400);
  const after = fs.existsSync(path.join(UP, 'avatars')) ? fs.readdirSync(path.join(UP, 'avatars')).length : 0;
  assert.equal(after, before);
});

itest(test, 'uploads: disallowed MIME types (svg, html, exe) are rejected', async () => {
  for (const [name, type] of [['x.svg', 'image/svg+xml'], ['x.html', 'text/html'], ['x.exe', 'application/x-msdownload']]) {
    const res = await owner.api.post('/api/auth/profile/picture').attach('avatar', Buffer.from('data'), { filename: name, contentType: type });
    assert.equal(res.status, 400, name);
  }
});

itest(test, 'uploads: a real PNG is accepted and stored with a server-chosen name and .png extension', async () => {
  const res = await owner.api.post('/api/auth/profile/picture').attach('avatar', PNG, { filename: '../../evil.php.png', contentType: 'image/png' });
  assert.equal(res.status, 200);
  assert.match(res.body.data.profile.avatarUrl, /^\/uploads\/avatars\/avatar-[\w-]+\.png$/);
  const pub = await t.request.get(res.body.data.profile.avatarUrl);
  assert.equal(pub.status, 200, 'avatars are public');
});

itest(test, 'uploads: oversized avatars are rejected', async () => {
  const big = Buffer.concat([PNG, Buffer.alloc(6 * 1024 * 1024)]);
  const res = await owner.api.post('/api/auth/profile/picture').attach('avatar', big, { filename: 'big.png', contentType: 'image/png' });
  assert.equal(res.status, 400);
});

itest(test, 'students cannot upload lesson content', async () => {
  const res = await student.api.post(`/api/lessons/${lesson._id}/pdfs`).attach('files', Buffer.from('%PDF-1.4'), { filename: 'a.pdf', contentType: 'application/pdf' });
  assert.equal(res.status, 403);
});
