import { h } from '../../core/dom.js';
import { items, idOf } from '../../ui/page.js';
/* A labelled <select> of courses that remembers the last choice per page. onChange(courseId). */
export function courseSelect(courses, { storageKey, onChange, label = 'Course' }) {
  const list = items(courses); const saved = sessionStorage.getItem(storageKey);
  const sel = h('select', { class: 'input', id: `cs-${storageKey}`, style: 'width:auto;max-width:100%' }, list.map((c) => h('option', { value: idOf(c), selected: idOf(c) === saved }, c.title)));
  sel.addEventListener('change', () => { sessionStorage.setItem(storageKey, sel.value); onChange(sel.value); });
  return { el: h('div', { class: 'row' }, h('label', { for: sel.id, class: 'muted small' }, label), sel), get value() { return sel.value; }, count: list.length };
}
