const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const liveClassService = require('../services/liveClassService');
const classroomService = require('../services/classroomService');
const classroomAuthService = require('../services/classroomAuthService');
const classroomAttendanceService = require('../services/classroomAttendanceService');
const notificationService = require('../services/notificationService');
const { Course } = require('../models/course.model');

// POST /api/courses/:courseId/live-classes
const scheduleLiveClass = asyncHandler(async (req, res) => {
  const liveClass = await liveClassService.scheduleLiveClass(req.course._id, req.user.id, req.body);
  return ApiResponse.created(res, liveClass.toSafeObject(), 'Live class scheduled successfully');
});

// GET /api/courses/:courseId/live-classes
const listLiveClasses = asyncHandler(async (req, res) => {
  const liveClasses = await liveClassService.listLiveClasses(req.course._id, {
    upcoming: req.query.upcoming === 'true'
  });
  return ApiResponse.ok(res, liveClasses, 'Live classes retrieved');
});

// PUT /api/live-classes/:id
const updateLiveClass = asyncHandler(async (req, res) => {
  const liveClass = await liveClassService.updateLiveClass(req.resource, req.body);
  return ApiResponse.ok(res, liveClass.toSafeObject(), 'Live class updated successfully');
});

// POST /api/live-classes/:id/cancel
const cancelLiveClass = asyncHandler(async (req, res) => {
  const liveClass = await liveClassService.cancelLiveClass(req.resource);
  return ApiResponse.ok(res, liveClass.toSafeObject(), 'Live class cancelled');
});

// POST /api/live-classes/:id/start
const startLiveClass = asyncHandler(async (req, res) => {
  const liveClass = await liveClassService.startLiveClass(req.resource);
  const course = await Course.findById(liveClass.courseId);

  // Notify students that the class has started WITHOUT the room credential —
  // students retrieve their own scoped join token from a separate, gated
  // endpoint (getJoinToken below) only after this event tells them to.
  const io = req.app.get('io');
  if (io) {
    for (const studentId of course.enrolledStudentIds) {
      io.to(`user:${studentId}`).emit('liveClass:started', {
        liveClassId: liveClass._id,
        courseId: liveClass.courseId
      });
    }
  }

  await notificationService.createNotificationsForMany(
    course.enrolledStudentIds,
    'live_class_starting',
    `${liveClass.title} is starting now`,
    `Your live class in ${course.title} has started`,
    { liveClassId: liveClass._id, courseId: liveClass.courseId }
  );

  return ApiResponse.ok(res, liveClass.toSafeObject(), 'Live class started');
});

// POST /api/live-classes/:id/end
const endLiveClass = asyncHandler(async (req, res) => {
  const liveClass = await liveClassService.endLiveClass(req.resource, req.body.recordingRef);
  await classroomAttendanceService.finalizeAttendance(liveClass);
  return ApiResponse.ok(res, liveClass.toSafeObject(), 'Live class ended and attendance recorded');
});

// GET /api/live-classes/:id/join-token
// Issues a short-lived, classroom-scoped Socket.IO join token. This is the
// ONLY way the room credential is ever reachable, and only to the teacher
// who owns the class (enforced by verifyResourceOwnership upstream).
const getJoinToken = asyncHandler(async (req, res) => {
  const token = classroomAuthService.issueJoinToken(req.resource, { id: req.user.id, role: 'teacher', name: req.user.name });
  return ApiResponse.ok(res, { token }, 'Join token issued');
});

// PUT /api/live-classes/:id/settings
const updateSettings = asyncHandler(async (req, res) => {
  const liveClass = await classroomService.updateSettings(req.resource, req.body);
  return ApiResponse.ok(res, liveClass.toSafeObject(), 'Classroom settings updated');
});

// POST /api/live-classes/:id/recording/start
const startRecording = asyncHandler(async (req, res) => {
  const liveClass = await classroomService.startRecording(req.resource);
  return ApiResponse.ok(res, liveClass.toSafeObject(), 'Recording started');
});

// POST /api/live-classes/:id/recording/stop
const stopRecording = asyncHandler(async (req, res) => {
  const liveClass = await classroomService.stopRecording(req.resource);
  return ApiResponse.ok(res, liveClass.toSafeObject(), 'Recording stopped');
});

// POST /api/live-classes/:id/materials
const addSharedMaterial = asyncHandler(async (req, res) => {
  const liveClass = await classroomService.addSharedMaterial(req.resource, req.user.id, req.file, req.body.title);
  const material = liveClass.sharedMaterials[liveClass.sharedMaterials.length - 1];

  const io = req.app.get('io');
  if (io) {
    io.of('/classroom').to(`classroom:${liveClass._id}`).emit('classroom:material-shared', material);
  }

  return ApiResponse.ok(res, liveClass.toSafeObject(), 'Material shared successfully');
});

// DELETE /api/live-classes/:id/materials/:materialId
const removeSharedMaterial = asyncHandler(async (req, res) => {
  const liveClass = await classroomService.removeSharedMaterial(req.resource, req.params.materialId);
  return ApiResponse.ok(res, liveClass.toSafeObject(), 'Material removed successfully');
});

// POST /api/live-classes/:id/announcements
const postAnnouncement = asyncHandler(async (req, res) => {
  if (!req.body.text || !req.body.text.trim()) {
    throw ApiError.badRequest('Announcement text is required');
  }
  const message = await classroomService.postAnnouncement(req.resource, req.user.id, req.body.text.trim());

  const io = req.app.get('io');
  if (io) {
    io.of('/classroom').to(`classroom:${req.resource._id}`).emit('classroom:announcement', {
      id: message._id,
      text: message.text,
      createdAt: message.createdAt
    });
  }

  return ApiResponse.created(res, message, 'Announcement posted');
});

// GET /api/live-classes/:id/chat
const getChatHistory = asyncHandler(async (req, res) => {
  const messages = await classroomService.getChatHistory(req.resource._id, req.query);
  return ApiResponse.ok(res, messages, 'Chat history retrieved');
});

// GET /api/live-classes/:id/attendance-summary
const getParticipantSummary = asyncHandler(async (req, res) => {
  const summary = await classroomService.getParticipantLogSummary(req.resource);
  return ApiResponse.ok(res, summary, 'Participant summary retrieved');
});

module.exports = {
  scheduleLiveClass,
  listLiveClasses,
  updateLiveClass,
  cancelLiveClass,
  startLiveClass,
  endLiveClass,
  getJoinToken,
  updateSettings,
  startRecording,
  stopRecording,
  addSharedMaterial,
  removeSharedMaterial,
  postAnnouncement,
  getChatHistory,
  getParticipantSummary
};
