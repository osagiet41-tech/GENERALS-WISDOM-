import { h } from '../../core/dom.js';
import { teacherApi } from '../../api/teacher.js';
import { pageHead, items } from '../../ui/page.js';
import { courseSelect } from '../shared/courseSelect.js';
import { withState, empty } from '../../ui/states.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { fmtDateTime } from '../../core/format.js';

export default async function render() {
  const { data: courses } = await teacherApi.courses(); const feed = h('div', { class: 'stack' }); let reload;
  const cs = courseSelect(courses, { storageKey: 'teacher.ann.course', onChange: () => load() });
  if (!cs.count) return h('div', null, pageHead('Announcements'), empty({ title: 'Create a course first', iconName: 'bell' }));
  const load = () => { reload = withState(feed, () => teacherApi.announcements(cs.value).then((r) => items(r.data)), (rows) => rows.length ? h('ul', { class: 'list card card-flush' }, rows.map((a) => h('li', null, h('div', null, h('p', { style: 'margin:0;white-space:pre-wrap' }, a.text), h('span', { class: 'small muted' }, fmtDateTime(a.createdAt)))))) : empty({ title: 'No announcements yet', iconName: 'bell' }), { rows: 3 }); };
  load();
  return h('div', { class: 'stack' }, pageHead('Announcements', 'Students are notified when you post.'), cs.el,
    h('section', { class: 'card' }, buildForm({ grid: false, submitLabel: 'Post announcement', fields: [{ name: 'text', label: 'Message', type: 'textarea', required: true, maxlength: 2000 }],
      onSubmit: async (v) => { await teacherApi.announce(cs.value, v.text); toast.success('Posted.'); reload(); } })), feed);
}
