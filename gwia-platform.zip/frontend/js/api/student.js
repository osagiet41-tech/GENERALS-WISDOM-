import { api } from '../core/http.js';
export const studentApi = {
  dashboard: () => api.get('/student/dashboard'),
  courses: () => api.get('/student/courses'),
  enroll: (courseId) => api.post('/student/enrollments', { courseId }),
  unenroll: (courseId) => api.del(`/student/enrollments/${courseId}`),
  modules: (cid) => api.get(`/student/courses/${cid}/modules`),
  lessons: (cid, q) => api.get(`/student/courses/${cid}/lessons`, q),
  lesson: (id) => api.get(`/student/lessons/${id}`),
  completeLesson: (id) => api.post(`/student/lessons/${id}/complete`),
  videoProgress: (id, watchedSeconds, completed) => api.post(`/student/lessons/${id}/video-progress`, { watchedSeconds, completed }),
  liveClasses: (cid) => api.get(`/student/courses/${cid}/live-classes`),
  joinLive: (id) => api.get(`/student/live-classes/${id}/join`),
  leaveLive: (id) => api.post(`/student/live-classes/${id}/leave`),
  liveChat: (id) => api.get(`/student/live-classes/${id}/chat`),
  assignments: (cid) => api.get(`/student/courses/${cid}/assignments`),
  assignment: (id) => api.get(`/student/assignments/${id}`),
  submitAssignment(id, { textAnswer, files }) { const fd = new FormData(); if (textAnswer) fd.append('textAnswer', textAnswer); [...(files || [])].forEach((f) => fd.append('files', f)); return api.post(`/student/assignments/${id}/submit`, fd); },
  progress: () => api.get('/student/progress'),
  courseProgress: (cid) => api.get(`/student/courses/${cid}/progress`),
  /* quizzes and exams share one contract: kind = 'quizzes' | 'exams' */
  assessments: (kind, cid) => api.get(`/student/courses/${cid}/${kind}`),
  start: (kind, id) => api.post(`/student/${kind}/${id}/start`),
  attempt: (kind, id) => api.get(`/student/${kind}/${id}/attempt`),
  save: (kind, id, answers) => api.put(`/student/${kind}/${id}/attempt/save`, { answers }),
  submit: (kind, id, answers) => api.post(`/student/${kind}/${id}/attempt/submit`, answers ? { answers } : {}),
  result: (kind, id, submissionId) => api.get(`/student/${kind}/${id}/result/${submissionId}`),
  history: (kind, id) => api.get(`/student/${kind}/${id}/history`)
};
