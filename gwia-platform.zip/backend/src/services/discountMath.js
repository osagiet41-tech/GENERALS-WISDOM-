/**
 * Pure discount arithmetic (no DB). All amounts are integer minor units.
 * Returns { discountMinor, finalMinor } or null if the code cannot apply in `currency`.
 */
function computeDiscount(code, originalMinor, currency) {
  const cur = String(currency).toUpperCase();
  let discount = 0;

  if (code.type === 'percent') {
    discount = Math.round((originalMinor * code.percentOff) / 100);
    if (code.maxDiscountMinor != null) discount = Math.min(discount, code.maxDiscountMinor);
  } else if (code.type === 'fixed') {
    const entry = (code.fixedAmounts || []).find((f) => String(f.currency).toUpperCase() === cur);
    if (!entry) return null; // fixed codes only apply in currencies they define
    discount = entry.amountMinor;
  } else {
    return null;
  }

  discount = Math.max(0, Math.min(discount, originalMinor));
  return { discountMinor: discount, finalMinor: originalMinor - discount };
}

module.exports = { computeDiscount };
