const { verifyAccessToken } = require('../utils/tokens');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const User = require('../models/User');

/**
 * Validates the JWT access token from the Authorization header
 * ("Bearer <token>"), confirms the user still exists and is active,
 * and attaches a minimal, safe user object to req.user for downstream
 * middleware/controllers to use.
 */
const authMiddleware = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    throw ApiError.unauthorized('Authentication token missing');
  }

  // Throws JsonWebTokenError / TokenExpiredError, normalized by the
  // centralized error handler into clean 401 responses.
  // Pinned algorithm + must be an *access* token (refresh / classroom tokens are rejected).
  const payload = verifyAccessToken(token);

  const user = await User.findById(payload.sub);
  if (!user) {
    throw ApiError.unauthorized('User no longer exists');
  }
  // Tokens issued before the last password change/reset are dead immediately, not after they expire.
  if (user.passwordChangedAt && payload.iat * 1000 < user.passwordChangedAt.getTime() - 1000) {
    throw ApiError.unauthorized('Session expired, please sign in again');
  }
  if (user.status === 'suspended') {
    throw ApiError.forbidden('Account is suspended');
  }
  if (user.status !== 'active') {
    throw ApiError.forbidden('Account is not active');
  }

  req.user = {
    id: user._id.toString(),
    name: user.name,
    email: user.email,
    role: user.role,
    institutionId: user.institutionId ? user.institutionId.toString() : null,
    profile: user.profile,
    status: user.status
  };

  next();
});

/**
 * Attaches req.user if a valid token is present, but never rejects
 * the request — useful for routes that behave differently for
 * logged-in vs anonymous users without requiring auth.
 */
const optionalAuthMiddleware = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) return next();

  try {
    const payload = verifyAccessToken(token);
    const user = await User.findById(payload.sub);
    const stale = user && user.passwordChangedAt && payload.iat * 1000 < user.passwordChangedAt.getTime() - 1000;
    if (user && user.status === 'active' && !stale) {
      req.user = {
        id: user._id.toString(),
        name: user.name,
        email: user.email,
        role: user.role,
        institutionId: user.institutionId ? user.institutionId.toString() : null
      };
    }
  } catch (err) {
    // Invalid/expired token on an optional route: proceed as anonymous.
  }

  next();
});

module.exports = { authMiddleware, optionalAuthMiddleware };
