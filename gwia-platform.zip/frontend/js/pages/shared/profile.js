import { h, mount } from '../../core/dom.js';
import { authApi } from '../../api/auth.js';
import { session } from '../../core/session.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { pageHead, card } from '../../ui/page.js';
import { logout } from '../../ui/shell.js';

export default async function render() {
  const { data: me } = await authApi.me();
  const picture = h('input', { type: 'file', accept: 'image/*', 'aria-label': 'Upload profile picture', class: 'input' });
  picture.addEventListener('change', async () => { if (!picture.files[0]) return; try { const { data } = await authApi.uploadPicture(picture.files[0]); session.set({ user: { ...session.user, ...data } }); toast.success('Profile picture updated.'); } catch (e) { toast.error(e.message); } });
  return h('div', { class: 'stack' }, pageHead('Profile & security', `Signed in as ${me.email} (${me.role}).`),
    h('div', { class: 'grid grid-2' },
      card('Your details', h('div', { style: 'padding:18px' }, buildForm({ submitLabel: 'Save changes', fields: [
        { name: 'name', label: 'Full name', value: me.name, required: true }, { name: 'phone', label: 'Phone', value: me.phone || me.profile?.phone, type: 'tel' }, { name: 'bio', label: 'About you', type: 'textarea', value: me.bio || me.profile?.bio, full: true, maxlength: 500 }],
        onSubmit: async (v) => { const { data } = await authApi.updateProfile(v); session.set({ user: { ...session.user, ...data } }); toast.success('Profile saved.'); } }),
        h('div', { class: 'field', style: 'margin-top:16px' }, h('label', null, 'Profile picture'), picture))),
      card('Change password', h('div', { style: 'padding:18px' }, buildForm({ grid: false, submitLabel: 'Change password', fields: [
        { name: 'currentPassword', label: 'Current password', type: 'password', required: true, autocomplete: 'current-password' },
        { name: 'newPassword', label: 'New password', type: 'password', required: true, minlength: 8, autocomplete: 'new-password', hint: 'At least 8 characters. You will be signed out afterwards.' }],
        onSubmit: async (v) => { await authApi.changePassword(v.currentPassword, v.newPassword); toast.success('Password changed. Please sign in again.'); setTimeout(logout, 1200); } })))));
}
