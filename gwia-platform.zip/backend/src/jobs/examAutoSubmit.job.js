const ExamAttempt = require('../models/examAttempt.model');
const { Assessment } = require('../models/assessment.model');
const examAttemptService = require('../services/examAttemptService');
const logger = require('../utils/logger');

const SWEEP_INTERVAL_MS = 60 * 1000; // check every minute

async function sweepExpiredAttempts() {
  const expired = await ExamAttempt.find({ status: 'in_progress', expiresAt: { $lte: new Date() } });

  for (const attempt of expired) {
    try {
      const assessment = await Assessment.findById(attempt.assessmentId);
      if (!assessment) {
        logger.warn(`Skipping auto-submit for attempt ${attempt._id}: parent assessment no longer exists`);
        continue;
      }
      await examAttemptService.finalizeAttempt(attempt, assessment, { auto: true });
    } catch (err) {
      logger.error(`Failed to auto-submit exam attempt ${attempt._id}: ${err.message}`);
    }
  }
}

let intervalHandle = null;

function startExamAutoSubmitJob() {
  if (intervalHandle) return; // already running
  intervalHandle = setInterval(() => {
    sweepExpiredAttempts().catch((err) => logger.error(`Exam auto-submit sweep failed: ${err.message}`));
  }, SWEEP_INTERVAL_MS);
  intervalHandle.unref?.();
  logger.info('Exam auto-submit background job started (checking every 60s)');
}

function stopExamAutoSubmitJob() {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
  }
}

module.exports = { startExamAutoSubmitJob, stopExamAutoSubmitJob, sweepExpiredAttempts };
