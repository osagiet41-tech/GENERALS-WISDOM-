const { DiscountCode, DiscountRedemption } = require('../models/billing.model');
const ApiError = require('../utils/ApiError');
const { computeDiscount } = require('./discountMath');

/**
 * Validates a code for this user/target and returns the code doc + computed amounts.
 * Read-only: nothing is reserved. Throws a 400 with a user-safe reason.
 */
async function validate({ code, userId, purpose, courseId, planCode, originalMinor, currency }) {
  const doc = await DiscountCode.findOne({ code: String(code || '').trim().toUpperCase() });
  const invalid = (msg) => ApiError.badRequest(msg);
  if (!doc || !doc.active) throw invalid('This discount code is not valid');

  const now = new Date();
  if (doc.validFrom && doc.validFrom > now) throw invalid('This discount code is not active yet');
  if (doc.validUntil && doc.validUntil < now) throw invalid('This discount code has expired');
  if (doc.maxRedemptions != null && doc.redeemedCount >= doc.maxRedemptions) {
    throw invalid('This discount code has been fully redeemed');
  }
  if (doc.appliesTo !== 'all' && doc.appliesTo !== purpose) {
    throw invalid(`This discount code only applies to ${doc.appliesTo === 'course' ? 'course purchases' : 'subscriptions'}`);
  }
  if (purpose === 'course' && doc.courseIds.length && !doc.courseIds.some((id) => id.toString() === String(courseId))) {
    throw invalid('This discount code does not apply to this course');
  }
  if (purpose === 'subscription' && doc.planCodes.length && !doc.planCodes.includes(planCode)) {
    throw invalid('This discount code does not apply to this plan');
  }

  const used = await DiscountRedemption.countDocuments({
    codeId: doc._id,
    userId,
    status: { $in: ['reserved', 'redeemed'] }
  });
  if (used >= doc.perUserLimit) throw invalid('You have already used this discount code');

  const result = computeDiscount(doc, originalMinor, currency);
  if (!result) throw invalid(`This discount code cannot be used with ${String(currency).toUpperCase()} prices`);

  return { doc, ...result };
}

/**
 * Atomically reserves one redemption. The $expr guard makes "maxRedemptions" safe under
 * concurrency: two buyers racing for the last slot cannot both win.
 * Must be followed by attachToPayment(); call release() if checkout fails.
 */
async function reserve(codeId) {
  const updated = await DiscountCode.findOneAndUpdate(
    {
      _id: codeId,
      active: true,
      $or: [{ maxRedemptions: null }, { $expr: { $lt: ['$redeemedCount', '$maxRedemptions'] } }]
    },
    { $inc: { redeemedCount: 1 } },
    { new: true }
  );
  if (!updated) throw ApiError.badRequest('This discount code has been fully redeemed');
  return updated;
}

async function attachToPayment({ codeId, userId, paymentId, amountMinor, currency }) {
  return DiscountRedemption.create({ codeId, userId, paymentId, amountMinor, currency, status: 'reserved' });
}

/** Releases a reservation exactly once (the status guard prevents double-decrement). */
async function release(paymentId) {
  const red = await DiscountRedemption.findOneAndUpdate(
    { paymentId, status: 'reserved' },
    { $set: { status: 'released' } }
  );
  if (red) await DiscountCode.updateOne({ _id: red.codeId, redeemedCount: { $gt: 0 } }, { $inc: { redeemedCount: -1 } });
}

async function markRedeemed(paymentId) {
  await DiscountRedemption.updateOne({ paymentId, status: 'reserved' }, { $set: { status: 'redeemed' } });
}

module.exports = { validate, reserve, attachToPayment, release, markRedeemed };
