const mongoose = require('mongoose');
const { Schema } = mongoose;

const answerSchema = new Schema(
  {
    questionId: { type: Schema.Types.ObjectId, ref: 'Question' },
    response: { type: Schema.Types.Mixed }, // selected option / text answer
    marksAwarded: { type: Number, default: null }
  },
  { _id: false }
);

const fileAnswerSchema = new Schema(
  {
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true },
    mimeType: { type: String, required: true },
    size: { type: Number, required: true }
  },
  { _id: true }
);

const submissionSchema = new Schema(
  {
    refType: { type: String, enum: ['assignment', 'quiz', 'exam'], required: true, index: true },
    refId: { type: Schema.Types.ObjectId, required: true, index: true }, // Assignment._id or Assessment._id

    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    studentId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },

    // Assignment-style submissions
    files: { type: [fileAnswerSchema], default: [] },
    textAnswer: { type: String, default: null },

    // Quiz/exam-style submissions
    answers: { type: [answerSchema], default: [] },
    attemptNumber: { type: Number, default: 1 },

    submittedAt: { type: Date, default: Date.now },
    isLate: { type: Boolean, default: false },

    status: {
      type: String,
      enum: ['submitted', 'graded', 'returned'],
      default: 'submitted',
      index: true
    },

    // Embedded grading — avoids a separate Grade collection for a 1:1 relationship.
    grade: {
      score: { type: Number, default: null },
      totalMarks: { type: Number, default: null },
      feedback: { type: String, default: null },
      gradedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null },
      gradedAt: { type: Date, default: null }
    }
  },
  { timestamps: true }
);

submissionSchema.index({ refType: 1, refId: 1, studentId: 1, attemptNumber: 1 }, { unique: true });
submissionSchema.index({ courseId: 1, studentId: 1 });

module.exports = mongoose.model('Submission', submissionSchema);
