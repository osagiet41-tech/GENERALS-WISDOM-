/**
 * Exercises certificateService against in-memory fakes of the Mongoose models (no database needed).
 * The fakes enforce the same unique constraints as the real indexes, and yield between "check" and "insert"
 * so concurrent requests really interleave. What this does NOT prove is the behaviour of MongoDB itself.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const Module = require('module');
const path = require('path');

const SRC = path.join(__dirname, '..', 'src');
let seq = 0;
const newId = () => (++seq).toString(16).padStart(24, '0');
const tick = () => new Promise((r) => setImmediate(r));

class Q {
  constructor(fn) { this.fn = fn; }
  populate() { return this; }
  select() { return this; }
  sort() { return this; }
  skip() { return this; }
  limit() { return this; }
  lean() { return this; }
  then(res, rej) { return Promise.resolve().then(this.fn).then(res, rej); }
}

const matches = (doc, f) =>
  Object.entries(f).every(([k, v]) => {
    if (k === 'status' && v && v.$in) return v.$in.includes(doc.status);
    if (v && typeof v === 'object' && v.$in) return v.$in.map(String).includes(String(doc[k]));
    if (v === null) return doc[k] == null;
    return String(doc[k]) === String(v);
  });

// ---------- fake collections ----------
const db = { certs: [], users: [], courses: [], progress: [], lessons: [], submissions: [], assignments: [], assessments: [], attendance: [] };
const spy = { notified: 0, emails: 0 };
const dup = () => Object.assign(new Error('E11000 duplicate key'), { code: 11000 });

const Certificate = {
  findOne: (f) => new Q(() => db.certs.find((c) => matches(c, f)) || null),
  findById: (id) => new Q(() => db.certs.find((c) => c._id === String(id)) || null),
  async create(doc) {
    await tick(); // let concurrent callers pass their own "already exists?" check first
    if (db.certs.some((c) => c.studentId === String(doc.studentId) && c.courseId === String(doc.courseId))) throw dup();
    if (db.certs.some((c) => c.certificateId === doc.certificateId || c.verificationCode === doc.verificationCode)) throw dup();
    const rec = { status: 'valid', emailedAt: null, ...doc, studentId: String(doc.studentId), courseId: String(doc.courseId), _id: newId() };
    db.certs.push(rec);
    return rec;
  },
  findOneAndUpdate: async (f, u) => {
    const c = db.certs.find((x) => matches(x, f));
    if (!c) return null;
    Object.assign(c, u.$set);
    return c;
  },
  updateOne: async (f, u) => { const c = db.certs.find((x) => matches(x, f)); if (c) Object.assign(c, u.$set); },
  exists: async (f) => db.certs.some((c) => matches(c, f)),
  countDocuments: async () => db.certs.length,
  find: (f) => new Q(() => db.certs.filter((c) => matches(c, f)))
};
const col = (name) => ({
  find: (f = {}) => new Q(() => db[name].filter((d) => matches(d, f))),
  findOne: (f) => new Q(() => db[name].find((d) => matches(d, f)) || null),
  findById: (id) => new Q(() => db[name].find((d) => d._id === String(id)) || null)
});

const stubs = {
  'models/certificate.model': Certificate,
  'models/course.model': { Course: { findById: (id) => new Q(() => db.courses.find((c) => c._id === String(id)) || null) } },
  'models/User': { findById: (id) => new Q(() => db.users.find((u) => u._id === String(id)) || null), find: (f) => new Q(() => db.users.filter((u) => String(f._id.$in.map(String)).includes(u._id))) },
  'models/progress.model': col('progress'),
  'models/lesson.model': col('lessons'),
  'models/submission.model': col('submissions'),
  'models/attendance.model': col('attendance'),
  'models/assignment.model': col('assignments'),
  'models/assessment.model': { Assessment: col('assessments') },
  'config/env': { certificates: { institutionName: 'Test Academy', verifyBaseUrl: 'https://x.test/verify', signatory: { name: '', title: '', imageFile: '' } } },
  'utils/logger': { info() {}, warn() {}, error() {} },
  'utils/email.util': { sendEmail: async () => { spy.emails += 1; } },
  'services/notificationService': { notifyCertificateAvailable: async () => { spy.notified += 1; } },
  'services/certificates/renderer': { renderToBuffer: async () => Buffer.from('%PDF-fake') }
};
const bare = { mongoose: { isValidObjectId: (v) => /^[a-f0-9]{24}$/i.test(String(v)) }, pdfkit: class {} };

const origLoad = Module._load;
Module._load = function load(request, parent, isMain) {
  if (bare[request]) return bare[request];
  if (request.startsWith('.')) {
    const abs = path.resolve(path.dirname(parent.filename), request).replace(/\.js$/, '');
    for (const [k, v] of Object.entries(stubs)) if (abs === path.join(SRC, k)) return v;
  }
  return origLoad.apply(this, arguments);
};
const service = require('../src/services/certificateService');

// ---------- scenario data ----------
const S = 'a'.repeat(23) + '1'; // student
const T = 'b'.repeat(23) + '1'; // teacher
const C = 'c'.repeat(23) + '1'; // course

function reset({ lessonsDone = 3, score = 80, certificate = {} } = {}) {
  Object.keys(db).forEach((k) => { db[k].length = 0; });
  spy.notified = 0; spy.emails = 0;
  db.users.push({ _id: S, name: 'Adaeze Okonkwo', email: 'adaeze@example.com', role: 'student' });
  db.users.push({ _id: T, name: 'Mr. Osagie Thomas', role: 'teacher', profile: { signatureFile: null } });
  db.courses.push({ _id: C, title: 'Intro to Python', teacherIds: [T], enrolledStudentIds: [S], certificate, toObject() { return { certificate: this.certificate }; } });
  for (let i = 1; i <= 3; i += 1) db.lessons.push({ _id: `L${i}`, courseId: C, status: 'published' });
  db.progress.push({ studentId: S, courseId: C, completedLessonIds: ['L1', 'L2', 'L3'].slice(0, lessonsDone) });
  db.assignments.push({ _id: 'A1', courseId: C, status: 'published' });
  if (score !== null) db.submissions.push({ studentId: S, courseId: C, refId: 'A1', status: 'graded', grade: { score, totalMarks: 100 } });
}

test('8 simultaneous requests produce exactly ONE certificate, one notification', async () => {
  reset();
  const results = await Promise.all(Array.from({ length: 8 }, () => service.evaluateAndIssue(S, C)));
  assert.equal(db.certs.length, 1);
  assert.equal(results.filter((r) => r.issued).length, 1);
  assert.equal(new Set(results.map((r) => r.certificate.certificateId)).size, 1);
  await tick(); await tick(); await tick();
  assert.equal(spy.notified, 1);
  assert.match(db.certs[0].certificateId, /^CERT-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}$/);
});

test('snapshot captures name, course, institution, instructor, date', async () => {
  reset();
  const { certificate } = await service.evaluateAndIssue(S, C);
  assert.equal(certificate.snapshot.studentName, 'Adaeze Okonkwo');
  assert.equal(certificate.snapshot.courseTitle, 'Intro to Python');
  assert.equal(certificate.snapshot.institutionName, 'Test Academy');
  assert.deepEqual(certificate.snapshot.instructors.map((i) => i.name), ['Mr. Osagie Thomas']);
  assert.ok(certificate.completionDate instanceof Date);
});

test('not eligible: no certificate, and the result says exactly what is missing', async () => {
  reset({ lessonsDone: 2 });
  const r = await service.evaluateAndIssue(S, C);
  assert.equal(r.certificate, null);
  assert.equal(db.certs.length, 0);
  assert.equal(r.evaluation.checks.find((c) => c.key === 'lessons').met, false);
  await assert.rejects(() => service.issueCertificateIfEligible(S, C), (e) => e.statusCode === 400 && e.details?.code === 'CERTIFICATE_REQUIREMENTS_NOT_MET');
});

test('all lessons done but failing score: no certificate; once grading lifts the average, it is issued', async () => {
  reset({ score: 30 });
  assert.equal((await service.evaluateAndIssue(S, C)).certificate, null);
  db.submissions[0].grade.score = 65; // teacher regrades
  const r = await service.evaluateAndIssue(S, C);
  assert.equal(r.issued, true);
});

test('best attempt per assessment counts (retakes)', async () => {
  reset({ score: 20 });
  db.submissions.push({ studentId: S, courseId: C, refId: 'A1', status: 'graded', grade: { score: 90, totalMarks: 100 } });
  assert.equal((await service.evaluateAndIssue(S, C)).issued, true);
});

test('unpublished or deleted lessons do not count toward completion', async () => {
  // Student finished 2 of 3 published lessons, plus a lesson that is now a draft and one that no longer exists.
  reset({ lessonsDone: 2 });
  db.lessons.push({ _id: 'L4', courseId: C, status: 'draft' });
  db.progress[0].completedLessonIds.push('L4', 'GHOST');
  const report = await service.getEligibilityReport(S, C);
  assert.equal(report.eligible, false);
  assert.match(report.checks.find((c) => c.key === 'lessons').actual, /67% \(2\/3\)/);
  assert.equal((await service.evaluateAndIssue(S, C)).certificate, null);

  // Unpublishing the lesson they have NOT done makes them complete: 2 of 2.
  db.lessons.find((l) => l._id === 'L3').status = 'draft';
  assert.equal((await service.getEligibilityReport(S, C)).eligible, true);
});

test('disabled course, non-enrolled student, non-student: nothing issued', async () => {
  reset({ certificate: { enabled: false } });
  assert.equal((await service.evaluateAndIssue(S, C)).certificate, null);
  reset();
  db.courses[0].enrolledStudentIds = [];
  assert.equal((await service.evaluateAndIssue(S, C)).certificate, null);
  reset();
  db.users[0].role = 'teacher';
  assert.equal((await service.evaluateAndIssue(S, C)).certificate, null);
  assert.equal(db.certs.length, 0);
});

test('queueEvaluation de-duplicates a burst of triggers', async () => {
  reset();
  for (let i = 0; i < 25; i += 1) service.queueEvaluation(S, C);
  for (let i = 0; i < 10; i += 1) await tick();
  assert.equal(db.certs.length, 1);
});

test('public verification: valid shape leaks nothing private; messy input still resolves', async () => {
  reset();
  const { certificate } = await service.evaluateAndIssue(S, C);
  const id = certificate.certificateId;
  const v = await service.verifyCertificate(id.toLowerCase().replace(/-/g, ' '));
  assert.equal(v.valid, true);
  assert.deepEqual(Object.keys(v).sort(), ['certificateId', 'completionDate', 'courseTitle', 'institutionName', 'instructors', 'issuedAt', 'status', 'studentName', 'valid']);
  assert.equal(v.studentName, 'Adaeze Okonkwo');
  assert.ok(!JSON.stringify(v).includes('adaeze@example.com'));
});

test('verification rejects junk, unknown IDs and injection-shaped input', async () => {
  reset();
  await service.evaluateAndIssue(S, C);
  for (const bad of ['CERT-AAAA-BBBB-CCCC', 'nonsense', '', null, undefined, { $ne: null }, ['CERT-AAAA-BBBB-CCCC'], '../../etc/passwd']) {
    assert.equal(await service.verifyCertificate(bad), null, `should not match: ${JSON.stringify(bad)}`);
  }
});

test('legacy 16-character codes still verify; revoked certificates verify as invalid', async () => {
  reset();
  db.certs.push({ _id: newId(), studentId: S, courseId: C, status: 'valid', issuedAt: new Date('2025-01-01'), verificationCode: 'A1B2C3D4E5F60718', title: 'Old', snapshot: {} });
  const legacy = await service.verifyCertificate('a1b2c3d4e5f60718');
  assert.equal(legacy.valid, true);
  assert.equal(legacy.studentName, 'Adaeze Okonkwo'); // legacy rows fall back to live data
  db.certs[0].status = 'revoked'; db.certs[0].revokedAt = new Date();
  const revoked = await service.verifyCertificate('A1B2C3D4E5F60718');
  assert.deepEqual([revoked.valid, revoked.status], [false, 'revoked']);
  assert.equal(revoked.studentName, undefined); // revoked: no personal details
});

test('an issued certificate does not change when the student or course is renamed later', async () => {
  reset();
  const { certificate } = await service.evaluateAndIssue(S, C);
  db.users[0].name = 'Someone Else';
  db.courses[0].title = 'Renamed Course';
  const v = await service.verifyCertificate(certificate.certificateId);
  assert.equal(v.studentName, 'Adaeze Okonkwo');
  assert.equal(v.courseTitle, 'Intro to Python');
});

test('score is only snapshotted for printing when the course opts in', async () => {
  reset({ certificate: { showScore: true } });
  const { certificate } = await service.evaluateAndIssue(S, C);
  assert.equal(certificate.snapshot.showScore, true);
  assert.equal(certificate.snapshot.finalScorePercent, 80);
  reset();
  assert.equal((await service.evaluateAndIssue(S, C)).certificate.snapshot.showScore, false);
});

test('students can only fetch their own certificates', async () => {
  reset();
  const { certificate } = await service.evaluateAndIssue(S, C);
  const mine = await service.getCertificate(certificate.certificateId, S);
  assert.equal(mine._id, certificate._id);
  await assert.rejects(() => service.getCertificate(certificate.certificateId, 'd'.repeat(24)), /not found/i);
});

test('renderPdf produces a PDF buffer through the renderer', async () => {
  reset();
  const { certificate } = await service.evaluateAndIssue(S, C);
  const pdf = await service.renderPdf(certificate);
  assert.ok(Buffer.isBuffer(pdf));
});
