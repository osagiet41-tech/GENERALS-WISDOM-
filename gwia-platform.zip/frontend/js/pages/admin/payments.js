import { h } from '../../core/dom.js';
import { adminApi } from '../../api/admin.js';
import { pageHead, idOf } from '../../ui/page.js';
import { listView } from '../shared/listView.js';
import { statusBadge } from '../../ui/table.js';
import { toast } from '../../ui/toast.js';
import { busy } from '../../ui/states.js';
import { fmtMoney, fmtDateTime } from '../../core/format.js';

export default async function render() {
  const lv = listView({ searchPlaceholder: 'Search reference…', caption: 'Payments', fetcher: (q) => adminApi.payments(q), filters: [{ name: 'status', label: 'All statuses', options: ['pending', 'completed', 'failed', 'refunded'].map((v) => ({ value: v, label: v })) }],
    columns: [{ label: 'Date', render: (p) => fmtDateTime(p.createdAt) }, { label: 'Reference', render: (p) => h('code', { class: 'small' }, p.reference || p.providerReference || '—') }, { label: 'Provider', render: (p) => p.provider || '—' },
      { label: 'Amount', align: 'right', render: (p) => (p.amountMinor != null ? fmtMoney(p.amountMinor, p.currency, { minor: true }) : fmtMoney(p.amount, p.currency)) }, { label: 'Status', render: (p) => statusBadge(p.status) }],
    actions: (p) => h('div', { class: 'row', style: 'justify-content:flex-end' },
      p.status === 'pending' && h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: async (e) => { try { const r = await busy(e.currentTarget, () => adminApi.verifyPayment(idOf(p))); toast.info(r.message || 'Checked with provider.'); lv.reload(); } catch (err) { toast.error(err.message); } } }, 'Verify with provider'),
      p.status === 'completed' && h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: async (e) => { try { await busy(e.currentTarget, () => adminApi.receiptPdf(idOf(p))); } catch (err) { toast.error(err.message); } } }, 'Receipt')) });
  return h('div', { class: 'stack' }, pageHead('Payments', 'Statuses are confirmed by the payment provider, never by the browser.'), lv.el);
}
