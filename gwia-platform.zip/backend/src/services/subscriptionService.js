const { Subscription, Plan } = require('../models/billing.model');
const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const notificationService = require('./notificationService');
const logger = require('../utils/logger');
const { addMonths, addDays } = require('../utils/periods');

const LIVE = ['active', 'trialing'];

/**
 * Applies one paid period to the user's subscription. Idempotent per payment id and safe under
 * concurrency (compare-and-swap on endDate), so a webhook + a browser verify + a retry job can all
 * call it for the same payment and the user gets exactly one period.
 */
async function applyPaidPeriod(payment) {
  const existingForPayment = await Subscription.findOne({ paymentIds: payment._id });
  if (existingForPayment) return existingForPayment;

  const plan = payment.planId ? await Plan.findById(payment.planId) : null;
  const months = payment.periodMonths || plan?.periodMonths;
  if (!months) throw new Error(`Payment ${payment._id} has no subscription period`);

  const common = {
    plan: payment.planCode || plan?.code || 'subscription',
    planId: payment.planId,
    billingCycle: payment.billingCycle || plan?.billingCycle || null,
    amount: payment.amount,
    currency: payment.currency,
    lastPaymentId: payment._id,
    source: 'payment',
    cancelledAt: null,
    reminder3dSentAt: null,
    reminder1dSentAt: null,
    expiredNotifiedAt: null
  };

  for (let attempt = 0; attempt < 6; attempt += 1) {
    const now = new Date();
    const live = await Subscription.findOne({ userId: payment.userId, status: { $in: LIVE } }).sort({ endDate: -1 });

    if (live) {
      // Stack on top of remaining PAID time; a trial's leftover days are replaced, not added.
      const base = live.status === 'active' && live.endDate > now ? live.endDate : now;
      const updated = await Subscription.findOneAndUpdate(
        { _id: live._id, endDate: live.endDate, status: live.status, paymentIds: { $ne: payment._id } },
        {
          $set: {
            ...common,
            status: 'active',
            endDate: addMonths(base, months),
            startDate: live.status === 'trialing' ? now : live.startDate
          },
          $push: { paymentIds: payment._id }
        },
        { new: true }
      );
      if (updated) return updated;
      continue; // lost the race: re-read and retry
    }

    try {
      return await Subscription.create({
        userId: payment.userId,
        ...common,
        status: 'active',
        startDate: now,
        endDate: addMonths(now, months),
        paymentIds: [payment._id]
      });
    } catch (err) {
      if (err.code === 11000) continue; // someone created the active sub first: loop will extend it
      throw err;
    }
  }
  throw new Error(`Could not apply subscription period for payment ${payment._id} (contention)`);
}

/** Undo a refunded payment's period: remove its months, or end the subscription if nothing is left. */
async function revokePeriod(payment) {
  const sub = await Subscription.findOne({ paymentIds: payment._id });
  if (!sub || !['active', 'trialing'].includes(sub.status)) return;
  const months = payment.periodMonths || 1;
  const reduced = addMonths(sub.endDate, -months);
  const now = new Date();
  if (reduced <= now) {
    sub.status = 'cancelled';
    sub.cancelledAt = now;
    sub.endDate = now;
  } else {
    sub.endDate = reduced;
  }
  sub.paymentIds = sub.paymentIds.filter((id) => id.toString() !== payment._id.toString());
  await sub.save();
}

async function startTrial(userId, planCode) {
  const plan = await Plan.findOne({ code: String(planCode || '').toLowerCase(), active: true });
  if (!plan) throw ApiError.notFound('Subscription plan not found');
  if (!plan.trialDays) throw ApiError.badRequest('This plan does not offer a free trial');

  const user = await User.findById(userId);
  if (!user) throw ApiError.notFound('User not found');
  // Cheap abuse control: a trial needs a verified email. (Multi-account abuse needs more, e.g. card-on-file.)
  if (!user.isEmailVerified) throw ApiError.forbidden('Verify your email address to start a free trial');

  if (await Subscription.exists({ userId, status: { $in: LIVE } })) {
    throw ApiError.conflict('You already have an active subscription');
  }
  if (await Subscription.exists({ userId, trialStartedAt: { $type: 'date' } })) {
    throw ApiError.conflict('You have already used your free trial');
  }

  const now = new Date();
  try {
    return await Subscription.create({
      userId,
      plan: plan.code,
      planId: plan._id,
      billingCycle: plan.billingCycle,
      amount: 0,
      currency: 'USD',
      status: 'trialing',
      source: 'trial',
      startDate: now,
      endDate: addDays(now, plan.trialDays),
      trialStartedAt: now,
      trialMarker: 'trial'
    });
  } catch (err) {
    if (err.code === 11000) throw ApiError.conflict('You have already used your free trial or have a live subscription');
    throw err;
  }
}

async function trialEligibility(userId, plan) {
  if (!plan.trialDays) return { eligible: false, reason: 'no_trial_offered' };
  const used = await Subscription.exists({ userId, trialStartedAt: { $type: 'date' } });
  if (used) return { eligible: false, reason: 'trial_used' };
  if (await Subscription.exists({ userId, status: { $in: LIVE }, endDate: { $gt: new Date() } })) {
    return { eligible: false, reason: 'has_subscription' };
  }
  return { eligible: true, trialDays: plan.trialDays };
}

/**
 * Flips overdue subscriptions to "expired". Per-document atomic update, so running this on several
 * server instances (or twice) notifies each user once.
 */
async function expireOverdueSubscriptions() {
  const now = new Date();
  const overdue = await Subscription.find({ status: { $in: LIVE }, endDate: { $lte: now } }).select('_id');
  let count = 0;
  for (const { _id } of overdue) {
    const sub = await Subscription.findOneAndUpdate(
      { _id, status: { $in: LIVE }, endDate: { $lte: now } },
      { $set: { status: 'expired', expiredNotifiedAt: now } },
      { new: true }
    );
    if (!sub) continue;
    count += 1;
    try {
      await notificationService.notifySubscriptionExpiration(sub.userId, {
        subscriptionId: sub._id,
        expiresAt: sub.endDate,
        daysRemaining: 0
      });
    } catch (err) {
      logger.error(`Expiry notification failed for subscription ${sub._id}: ${err.message}`);
    }
  }
  return count;
}

/** 3-day and 1-day expiry warnings, each sent once per period (flag set atomically before sending). */
async function sendExpiryReminders() {
  const now = new Date();
  let sent = 0;
  for (const [days, field] of [[3, 'reminder3dSentAt'], [1, 'reminder1dSentAt']]) {
    const due = await Subscription.find({
      status: { $in: LIVE },
      endDate: { $gt: now, $lte: addDays(now, days) },
      [field]: null
    }).select('_id');
    for (const { _id } of due) {
      const sub = await Subscription.findOneAndUpdate(
        { _id, [field]: null, status: { $in: LIVE }, endDate: { $gt: now } },
        { $set: { [field]: now } },
        { new: true }
      );
      if (!sub) continue;
      // A subscription already inside its last day only gets the 1-day notice, not both at once.
      if (days === 3 && sub.endDate <= addDays(now, 1)) continue;
      sent += 1;
      try {
        await notificationService.notifySubscriptionExpiration(sub.userId, {
          subscriptionId: sub._id,
          expiresAt: sub.endDate,
          daysRemaining: Math.max(1, Math.ceil((sub.endDate - now) / 86400000))
        });
      } catch (err) {
        logger.error(`Expiry reminder failed for subscription ${sub._id}: ${err.message}`);
      }
    }
  }
  return sent;
}

module.exports = {
  applyPaidPeriod,
  revokePeriod,
  startTrial,
  trialEligibility,
  expireOverdueSubscriptions,
  sendExpiryReminders
};
