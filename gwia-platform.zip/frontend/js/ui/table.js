import { h } from '../core/dom.js';
import { empty } from './states.js';
/* dataTable({ columns:[{key,label,render(row),align,class}], rows, caption, onRowClick, emptyState, actions(row)->Node }) */
export function dataTable({ columns, rows, caption, onRowClick, emptyState, actions, rowKey = (r) => r._id || r.id }) {
  if (!rows || !rows.length) return emptyState || empty({ title: 'No records found', message: 'Try changing your search or filters.' });
  const head = h('tr', null, columns.map((c) => h('th', { scope: 'col', class: c.align === 'right' ? 'right' : '' }, c.label)), actions && h('th', { scope: 'col' }, h('span', { class: 'sr-only' }, 'Actions')));
  const body = rows.map((r) => {
    const tr = h('tr', { 'data-key': rowKey(r), ...(onRowClick && { 'data-clickable': '', tabindex: '0', onclick: () => onRowClick(r), onkeydown: (e) => { if (e.key === 'Enter') onRowClick(r); } }) },
      columns.map((c) => h('td', { 'data-label': c.label, class: c.align === 'right' ? 'right' : '' }, c.render ? c.render(r) : (r[c.key] ?? '—'))),
      actions && h('td', { class: 'actions', onclick: (e) => e.stopPropagation() }, actions(r)));
    return tr;
  });
  return h('div', { class: 'table-wrap' }, h('table', { class: 'table' }, caption && h('caption', null, caption), h('thead', null, head), h('tbody', null, body)));
}
export const badge = (text, kind = '') => h('span', { class: `badge ${kind}` }, text);
const KINDS = { active: 'ok', published: 'ok', completed: 'ok', paid: 'ok', graded: 'ok', valid: 'ok', live: 'ok', trialing: 'info', scheduled: 'info', pending: 'warn', draft: 'warn', submitted: 'info', failed: 'err', cancelled: 'err', suspended: 'err', revoked: 'err', expired: 'err', refunded: 'warn', closed: '', archived: '' };
export const statusBadge = (s) => badge(String(s ?? '—').replace(/_/g, ' '), KINDS[String(s).toLowerCase()] || '');
