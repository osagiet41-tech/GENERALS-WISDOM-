const Notification = require('../models/notification.model');
const User = require('../models/User');
const { sendEmail } = require('../utils/email.util');
const { getIO } = require('../utils/socketRegistry');
const { escapeHtml } = require('../utils/security');
const pushService = require('./pushService');
const logger = require('../utils/logger');

const EMAIL_ENABLED_TYPES = new Set([
  'new_assignment',
  'assignment_deadline',
  'grade_posted',
  'live_class_reminder',
  'exam_reminder',
  'announcement',
  'certificate_issued',
  'payment_confirmation',
  'subscription_expiration'
]);

function emitRealtime(userId, notification) {
  const io = getIO();
  if (!io) return;
  io.to(`user:${userId}`).emit('notification:new', notification);
}

async function sendEmailForNotification(userId, title, message) {
  try {
    const user = await User.findById(userId);
    if (!user || !user.email) return;
    await sendEmail({
      to: user.email,
      subject: title,
      html: `<p>Hi ${escapeHtml(user.name || '')},</p><p>${escapeHtml(message)}</p>`
    });
  } catch (err) {
    logger.error(`Failed to send notification email to user ${userId}: ${err.message}`);
  }
}

async function createNotification(userId, type, title, message, data = {}) {
  const notification = await Notification.create({ userId, type, title, message, data });

  emitRealtime(userId, notification);
  pushService.sendToUser(userId, { title, body: message, tag: type }).catch(() => {}); // never blocks or fails the caller
  if (EMAIL_ENABLED_TYPES.has(type)) {
    await sendEmailForNotification(userId, title, message);
  }

  return notification;
}

async function createNotificationsForMany(userIds, type, title, message, data = {}) {
  if (!userIds || userIds.length === 0) return [];

  const docs = userIds.map((userId) => ({ userId, type, title, message, data }));
  const created = await Notification.insertMany(docs);

  for (const notification of created) {
    emitRealtime(notification.userId, notification);
    pushService.sendToUser(notification.userId, { title, body: message, tag: type }).catch(() => {});
  }
  if (EMAIL_ENABLED_TYPES.has(type)) {
    await Promise.all(userIds.map((userId) => sendEmailForNotification(userId, title, message)));
  }

  return created;
}

async function listNotifications(userId, { unreadOnly = false, page = 1, limit = 20 } = {}) {
  const filter = { userId };
  if (unreadOnly) filter.read = false;

  const skip = (page - 1) * limit;
  const [items, total, unreadCount] = await Promise.all([
    Notification.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
    Notification.countDocuments(filter),
    Notification.countDocuments({ userId, read: false })
  ]);

  return { items, total, unreadCount, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function markAsRead(notificationId, userId) {
  return Notification.findOneAndUpdate({ _id: notificationId, userId }, { read: true }, { new: true });
}

async function markAllAsRead(userId) {
  await Notification.updateMany({ userId, read: false }, { read: true });
}

async function notifyNewAssignment(studentIds, { assignmentId, courseId, title, dueDate }) {
  return createNotificationsForMany(
    studentIds,
    'new_assignment',
    'New assignment posted',
    `"${title}" has been posted${dueDate ? `, due ${new Date(dueDate).toDateString()}` : ''}`,
    { assignmentId, courseId }
  );
}

async function notifyAssignmentDeadline(studentIds, { assignmentId, courseId, title, dueDate }) {
  return createNotificationsForMany(
    studentIds,
    'assignment_deadline',
    'Assignment due soon',
    `"${title}" is due ${new Date(dueDate).toDateString()}`,
    { assignmentId, courseId }
  );
}

async function notifyGradePosted(studentId, { submissionId, refType, courseId, score, totalMarks }) {
  return createNotification(
    studentId,
    'grade_posted',
    'New grade posted',
    `You received ${score}/${totalMarks} on a ${refType}`,
    { submissionId, refType, courseId }
  );
}

async function notifyNewLesson(studentIds, { lessonId, courseId, title }) {
  return createNotificationsForMany(studentIds, 'new_lesson', 'New lesson available', `"${title}" has been published`, {
    lessonId,
    courseId
  });
}

async function notifyNewCourse(studentIds, { courseId, title, teacherName }) {
  return createNotificationsForMany(
    studentIds,
    'new_course',
    'New course available',
    `${teacherName ? `${teacherName} published` : 'A new course is available:'} "${title}"`,
    { courseId }
  );
}

async function notifyLiveClassReminder(userIds, { liveClassId, courseId, title, scheduledAt }) {
  return createNotificationsForMany(
    userIds,
    'live_class_reminder',
    'Live class starting soon',
    `"${title}" starts at ${new Date(scheduledAt).toLocaleTimeString()}`,
    { liveClassId, courseId }
  );
}

async function notifyLiveClassStarting(studentIds, { liveClassId, courseId, title }) {
  return createNotificationsForMany(
    studentIds,
    'live_class_starting',
    `${title} is starting now`,
    'Your live class has started',
    { liveClassId, courseId }
  );
}

async function notifyExamReminder(studentIds, { assessmentId, kind, courseId, title, availableUntil }) {
  return createNotificationsForMany(
    studentIds,
    'exam_reminder',
    `${kind === 'exam' ? 'Exam' : 'Quiz'} closing soon`,
    `"${title}" closes ${new Date(availableUntil).toDateString()} — don't forget to complete it`,
    { assessmentId, courseId }
  );
}

async function notifyNewMessage(userIds, { conversationId, messageId, preview }) {
  return createNotificationsForMany(userIds, 'message', 'New message', preview, { conversationId, messageId });
}

async function notifyTeacherAnnouncement(studentIds, { announcementId, courseId, courseTitle, title }) {
  return createNotificationsForMany(studentIds, 'announcement', title, `New announcement in ${courseTitle}`, {
    announcementId,
    courseId
  });
}

async function notifyCertificateAvailable(studentId, { certificateId, courseId, courseTitle }) {
  return createNotification(
    studentId,
    'certificate_issued',
    'Certificate available',
    `Your certificate for "${courseTitle}" is ready to download`,
    { certificateId, courseId }
  );
}

async function notifyPaymentConfirmation(userId, { paymentId, courseId, amount, currency }) {
  return createNotification(
    userId,
    'payment_confirmation',
    'Payment confirmed',
    `Your payment of ${currency || ''} ${amount} was received successfully`,
    { paymentId, courseId, amount, currency }
  );
}

async function notifySubscriptionExpiration(userId, { subscriptionId, expiresAt, daysRemaining }) {
  return createNotification(
    userId,
    'subscription_expiration',
    daysRemaining <= 0 ? 'Subscription expired' : 'Subscription expiring soon',
    daysRemaining <= 0
      ? 'Your subscription has expired. Renew to keep your access.'
      : `Your subscription expires in ${daysRemaining} day(s) (${new Date(expiresAt).toDateString()})`,
    { subscriptionId, expiresAt }
  );
}

async function notifyForumReply(studentId, { postId, replyId, courseId, postTitle, replierRole }) {
  return createNotification(
    studentId,
    'forum_reply',
    'New reply to your question',
    `${replierRole === 'teacher' ? 'A teacher' : 'Someone'} replied to "${postTitle}"`,
    { postId, replyId, courseId }
  );
}

async function notifyEnrollment(studentId, { courseId, courseTitle }) {
  return createNotification(studentId, 'enrollment', 'Enrollment confirmed', `You are now enrolled in ${courseTitle}`, {
    courseId
  });
}

module.exports = {
  createNotification,
  createNotificationsForMany,
  listNotifications,
  markAsRead,
  markAllAsRead,
  notifyNewAssignment,
  notifyAssignmentDeadline,
  notifyGradePosted,
  notifyNewLesson,
  notifyNewCourse,
  notifyLiveClassReminder,
  notifyLiveClassStarting,
  notifyExamReminder,
  notifyNewMessage,
  notifyTeacherAnnouncement,
  notifyCertificateAvailable,
  notifyPaymentConfirmation,
  notifySubscriptionExpiration,
  notifyForumReply,
  notifyEnrollment
};
