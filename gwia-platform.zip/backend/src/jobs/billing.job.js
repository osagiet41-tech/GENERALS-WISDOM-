const subscriptionService = require('../services/subscriptionService');
const paymentService = require('../services/paymentService');
const logger = require('../utils/logger');

const SWEEP_INTERVAL_MS = 5 * 60 * 1000;
let intervalHandle = null;
let running = false;

/**
 * Safe to run on several server instances at once: every step claims its work with an atomic
 * update, so nothing is expired, reminded, verified or fulfilled twice.
 */
async function runBillingSweeps() {
  if (running) return; // don't overlap with a slow previous sweep on this instance
  running = true;
  try {
    const expired = await subscriptionService.expireOverdueSubscriptions();
    const reminded = await subscriptionService.sendExpiryReminders();
    const reconciled = await paymentService.reconcilePendingPayments();
    const retried = await paymentService.retryStuckFulfillments();
    if (expired || reminded || reconciled.settled || retried.fixed) {
      logger.info(
        `Billing sweep: expired=${expired} reminded=${reminded} settledPending=${reconciled.settled} fulfilmentRetried=${retried.fixed}`
      );
    }
  } finally {
    running = false;
  }
}

function startBillingJobs() {
  if (intervalHandle) return;
  const tick = () => runBillingSweeps().catch((err) => logger.error(`Billing sweep failed: ${err.message}`));
  intervalHandle = setInterval(tick, SWEEP_INTERVAL_MS);
  intervalHandle.unref?.();
  tick(); // catch up immediately after a restart
  logger.info('Billing background jobs started (every 5 minutes)');
}

function stopBillingJobs() {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
  }
}

module.exports = { startBillingJobs, stopBillingJobs, runBillingSweeps };
