const { body } = require('express-validator');

const scheduleLiveClassValidator = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 200 }),
  body('description').optional().trim().isLength({ max: 2000 }),
  body('scheduledAt').isISO8601().withMessage('scheduledAt must be a valid date'),
  body('durationMinutes').isInt({ min: 5, max: 480 }).withMessage('durationMinutes must be between 5 and 480'),
  body('subjectId').optional().isMongoId(),
  body('meetingUrl').optional().isURL({ protocols: ['http', 'https'], require_protocol: true }).withMessage('meetingUrl must be a valid http(s) URL'),
  body('chatEnabled').optional().isBoolean(),
  body('studentMicEnabledByDefault').optional().isBoolean(),
  body('studentCameraEnabledByDefault').optional().isBoolean(),
  body('studentScreenShareAllowed').optional().isBoolean()
];

const updateLiveClassValidator = [
  body('title').optional().trim().isLength({ min: 1, max: 200 }),
  body('description').optional().trim().isLength({ max: 2000 }),
  body('scheduledAt').optional().isISO8601(),
  body('durationMinutes').optional().isInt({ min: 5, max: 480 }),
  body('meetingUrl').optional().isURL({ protocols: ['http', 'https'], require_protocol: true })
];

const updateSettingsValidator = [
  body('chatEnabled').optional().isBoolean(),
  body('studentMicEnabledByDefault').optional().isBoolean(),
  body('studentCameraEnabledByDefault').optional().isBoolean(),
  body('studentScreenShareAllowed').optional().isBoolean()
];

const announcementValidator = [
  body('text').trim().notEmpty().withMessage('Announcement text is required').isLength({ max: 2000 })
];

module.exports = {
  scheduleLiveClassValidator,
  updateLiveClassValidator,
  updateSettingsValidator,
  announcementValidator
};
