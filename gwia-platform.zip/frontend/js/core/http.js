import { config } from './config.js';
import { session, redirectToLogin } from './session.js';

export class ApiError extends Error {
  constructor(status, message, details = null) { super(message); this.status = status; this.details = details; }
  /* { fieldName: message } built from the backend's validation error list */
  get fieldErrors() { return Array.isArray(this.details) ? Object.fromEntries(this.details.filter((d) => d && d.field).map((d) => [d.field, d.message])) : {}; }
}

function buildUrl(path, query) {
  const url = new URL(config.apiBase + path, location.href);
  for (const [k, v] of Object.entries(query || {})) if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, v);
  return url;
}

async function toError(res) { const j = await res.json().catch(() => null); return new ApiError(res.status, (j && j.message) || 'Request failed', j && j.details); }

async function raw(path, { method = 'GET', body, query, auth = true, blob = false, signal } = {}) {
  const headers = { Accept: blob ? '*/*' : 'application/json' };
  if (auth && session.accessToken) headers.Authorization = `Bearer ${session.accessToken}`;
  let payload;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  let res;
  try { res = await fetch(buildUrl(path, query), { method, headers, body: payload, signal }); }
  catch (e) { if (e.name === 'AbortError') throw e; throw new ApiError(0, 'Cannot reach the server. Check your connection and try again.'); }
  if (blob) {
    if (!res.ok) throw await toError(res);
    const cd = res.headers.get('Content-Disposition') || '';
    return { blob: await res.blob(), filename: (/filename="?([^";]+)"?/i.exec(cd) || [])[1] };
  }
  const json = await res.json().catch(() => null);
  if (!res.ok) throw new ApiError(res.status, (json && json.message) || res.statusText || 'Request failed', json && json.details);
  return { data: json ? json.data : null, meta: json && json.meta, message: json && json.message };
}

let refreshing = null;
async function refreshTokens() {
  const refreshToken = session.refreshToken;
  if (!refreshToken) throw new ApiError(401, 'Session expired');
  const { data } = await raw('/auth/refresh', { method: 'POST', body: { refreshToken }, auth: false });
  session.set(data);
}

/* Single entry point. One automatic token refresh on 401, then back to the login page. */
export async function request(path, opts = {}) {
  try { return await raw(path, opts); }
  catch (e) {
    if (e.status !== 401 || opts.auth === false || !session.refreshToken) throw e;
    try { await (refreshing ||= refreshTokens().finally(() => { refreshing = null; })); return await raw(path, opts); }
    catch { session.clear(); redirectToLogin(); throw e; }
  }
}
export const api = {
  get: (p, query, o) => request(p, { ...o, query }), post: (p, body, o) => request(p, { ...o, method: 'POST', body }),
  put: (p, body, o) => request(p, { ...o, method: 'PUT', body }), del: (p, o) => request(p, { ...o, method: 'DELETE' })
};
/* Authenticated file download (a plain <a href> cannot send the Bearer token). */
export async function download(path, fallbackName = 'download', query) {
  const { blob, filename } = await request(path, { blob: true, query });
  const url = URL.createObjectURL(blob); const a = document.createElement('a');
  a.href = url; a.download = filename || fallbackName; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000);
}
export async function openBlob(path, query) {
  const { blob } = await request(path, { blob: true, query });
  window.open(URL.createObjectURL(blob), '_blank', 'noopener');
}
