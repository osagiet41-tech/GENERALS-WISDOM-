const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const studentLessonService = require('../services/studentLessonService');
const certificateService = require('../services/certificateService');

// GET /api/student/courses/:courseId/lessons
const listLessons = asyncHandler(async (req, res) => {
  const lessons = await studentLessonService.listPublishedLessons(req.user.id, req.course._id, {
    subjectId: req.query.subjectId,
    moduleId: req.query.moduleId
  });
  return ApiResponse.ok(res, lessons, 'Lessons retrieved');
});

// GET /api/student/lessons/:id  (req.resource set by verifyResourceAccess)
const getLesson = asyncHandler(async (req, res) => {
  return ApiResponse.ok(res, req.resource, 'Lesson retrieved');
});

// POST /api/student/lessons/:id/complete
const markComplete = asyncHandler(async (req, res) => {
  const progress = await studentLessonService.markLessonComplete(req.user.id, req.course._id, req.resource._id);

  // Re-check certificate eligibility in the background (this completion may have satisfied the requirements).
  certificateService.queueEvaluation(req.user.id, req.course._id);

  return ApiResponse.ok(res, progress, 'Lesson marked as complete');
});

// POST /api/student/lessons/:id/video-progress  { watchedSeconds, completed }
const trackVideoProgress = asyncHandler(async (req, res) => {
  const progress = await studentLessonService.trackVideoProgress(
    req.user.id,
    req.course._id,
    req.resource._id,
    req.body.watchedSeconds,
    req.body.completed
  );
  // Finishing a video can complete the lesson too.
  if (req.body.completed) certificateService.queueEvaluation(req.user.id, req.course._id);
  return ApiResponse.ok(res, progress, 'Video progress recorded');
});

module.exports = { listLessons, getLesson, markComplete, trackVideoProgress };
