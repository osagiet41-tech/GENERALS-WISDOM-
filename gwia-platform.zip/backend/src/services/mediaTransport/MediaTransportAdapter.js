/**
 * MediaTransportAdapter — the contract between the classroom Socket.IO
 * layer and however audio/video actually gets from one participant to
 * another. Today, `MeshSignalingAdapter` implements this by relaying
 * raw WebRTC offer/answer/ICE messages peer-to-peer (fine for small
 * classes). To move to a scalable SFU (LiveKit, mediasoup, etc.)
 * later, implement this same interface in a new adapter and swap it
 * in via `MEDIA_MODE` — nothing in classroom.socket.js, the REST
 * controllers, or the client's event names has to change, because
 * they only ever talk to this interface, never to raw peer connections
 * or a specific SFU SDK directly.
 *
 * Methods a concrete adapter must implement:
 *
 * - async getConnectionInfo(liveClass, participant)
 *     Returns whatever the client needs to establish media for this
 *     session under this transport. For mesh: { mode: 'mesh' } (the
 *     client discovers peers via Socket.IO presence events and does
 *     its own RTCPeerConnection setup). For an SFU: would return
 *     { mode: 'sfu', url, token } for that SFU's client SDK to connect
 *     directly to the media server.
 *
 * - relaySignal(nsp, liveClassId, fromUserId, toUserId, payload)
 *     Delivers a signaling message (offer/answer/ICE candidate) from
 *     one participant to another. For mesh, this is a direct relay
 *     over Socket.IO. An SFU adapter would typically no-op this (or
 *     use it only for a fallback data channel), since the SFU server
 *     handles media routing itself rather than peers signaling each
 *     other directly. `nsp` is the Socket.IO `/classroom` namespace.
 *
 * - onParticipantJoined(nsp, liveClassId, participant) / onParticipantLeft(...)
 *     Hook for transport-specific bookkeeping (e.g. an SFU adapter
 *     might need to create/destroy a server-side participant session).
 *     Mesh does nothing beyond what classroom.socket.js already does.
 */
class MediaTransportAdapter {
  async getConnectionInfo(liveClass, participant) {
    throw new Error('getConnectionInfo not implemented');
  }

  relaySignal(nsp, liveClassId, fromUserId, toUserId, payload) {
    throw new Error('relaySignal not implemented');
  }

  onParticipantJoined(nsp, liveClassId, participant) {}

  onParticipantLeft(nsp, liveClassId, participant) {}
}

module.exports = MediaTransportAdapter;
