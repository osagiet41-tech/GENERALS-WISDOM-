const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const ApiError = require('../utils/ApiError');
const { extensionFor, fileMatchesMime } = require('../utils/fileSignature');

const UPLOAD_ROOT = path.join(__dirname, '..', '..', 'uploads');

const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/gif',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'video/mp4',
  'video/webm',
  'audio/mpeg',
  'text/plain',
  'application/zip'
]);

const MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024; // 50MB

/**
 * Wraps multer's disk storage: after the bytes are written, the file's magic number must match the declared MIME
 * type, otherwise the file is deleted and the request fails with 400. This is what stops "malware.html renamed to
 * photo.png" style uploads; the extension is also derived from the MIME type, not from the client's file name.
 */
function diskStorage(options) {
  const inner = multer.diskStorage(options);
  return {
    _handleFile(req, file, cb) {
      inner._handleFile(req, file, (err, info) => {
        if (err) return cb(err);
        fileMatchesMime(info.path, file.mimetype)
          .then((ok) => {
            if (ok) return cb(null, info);
            fs.unlink(info.path, () => cb(new ApiError(400, 'The file content does not match its declared type')));
          })
          .catch((e) => fs.unlink(info.path, () => cb(e)));
      });
    },
    _removeFile(req, file, cb) {
      inner._removeFile(req, file, cb);
    }
  };
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

const storage = diskStorage({
  destination: (req, file, cb) => {
    const subfolder = req.uploadSubfolder || 'misc';
    const dest = path.join(UPLOAD_ROOT, subfolder);
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = extensionFor(file.mimetype);
    cb(null, `${Date.now()}-${uniqueSuffix}${ext}`);
  }
});

function fileFilter(req, file, cb) {
  if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
    return cb(new ApiError(400, `File type not allowed: ${file.mimetype}`));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_FILE_SIZE_BYTES, files: 10 }
});

// --- Dedicated avatar upload: images only, smaller size cap, fixed subfolder ---
const AVATAR_MAX_SIZE_BYTES = 5 * 1024 * 1024; // 5MB
const AVATAR_MIME_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

const avatarStorage = diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(UPLOAD_ROOT, 'avatars');
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = extensionFor(file.mimetype);
    cb(null, `avatar-${req.user ? req.user.id : 'anon'}-${Date.now()}-${uniqueSuffix}${ext}`);
  }
});

function avatarFileFilter(req, file, cb) {
  if (!AVATAR_MIME_TYPES.has(file.mimetype)) {
    return cb(new ApiError(400, `Profile picture must be an image (jpeg, png, webp, gif). Got: ${file.mimetype}`));
  }
  cb(null, true);
}

const uploadAvatar = multer({
  storage: avatarStorage,
  fileFilter: avatarFileFilter,
  limits: { fileSize: AVATAR_MAX_SIZE_BYTES, files: 1 }
});

// --- Lesson materials: documents/slides/etc., fixed subfolder ---
const materialStorage = diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(UPLOAD_ROOT, 'materials');
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = extensionFor(file.mimetype);
    cb(null, `material-${Date.now()}-${uniqueSuffix}${ext}`);
  }
});

const uploadMaterial = multer({
  storage: materialStorage,
  fileFilter,
  limits: { fileSize: MAX_FILE_SIZE_BYTES, files: 5 }
});

// --- Lesson videos: larger size cap, video MIME types only ---
const VIDEO_MAX_SIZE_BYTES = 500 * 1024 * 1024; // 500MB
const VIDEO_MIME_TYPES = new Set(['video/mp4', 'video/webm', 'video/quicktime']);

const videoStorage = diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(UPLOAD_ROOT, 'videos');
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = extensionFor(file.mimetype);
    cb(null, `video-${Date.now()}-${uniqueSuffix}${ext}`);
  }
});

function videoFileFilter(req, file, cb) {
  if (!VIDEO_MIME_TYPES.has(file.mimetype)) {
    return cb(new ApiError(400, `File must be a video (mp4, webm, mov). Got: ${file.mimetype}`));
  }
  cb(null, true);
}

const uploadVideo = multer({
  storage: videoStorage,
  fileFilter: videoFileFilter,
  limits: { fileSize: VIDEO_MAX_SIZE_BYTES, files: 1 }
});

// --- Lesson images: image types only, fixed subfolder, multiple per lesson ---
const IMAGE_MIME_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);
const IMAGE_MAX_SIZE_BYTES = 10 * 1024 * 1024; // 10MB

const imageStorage = diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(UPLOAD_ROOT, 'images');
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = extensionFor(file.mimetype);
    cb(null, `image-${Date.now()}-${uniqueSuffix}${ext}`);
  }
});

function imageFileFilter(req, file, cb) {
  if (!IMAGE_MIME_TYPES.has(file.mimetype)) {
    return cb(new ApiError(400, `File must be an image (jpeg, png, webp, gif). Got: ${file.mimetype}`));
  }
  cb(null, true);
}

const uploadImage = multer({
  storage: imageStorage,
  fileFilter: imageFileFilter,
  limits: { fileSize: IMAGE_MAX_SIZE_BYTES, files: 10 }
});

// --- Lesson PDFs: PDF only, fixed subfolder ---
const PDF_MAX_SIZE_BYTES = 50 * 1024 * 1024; // 50MB

const pdfStorage = diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(UPLOAD_ROOT, 'pdfs');
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    cb(null, `pdf-${Date.now()}-${uniqueSuffix}.pdf`);
  }
});

function pdfFileFilter(req, file, cb) {
  if (file.mimetype !== 'application/pdf') {
    return cb(new ApiError(400, `File must be a PDF. Got: ${file.mimetype}`));
  }
  cb(null, true);
}

const uploadPdf = multer({
  storage: pdfStorage,
  fileFilter: pdfFileFilter,
  limits: { fileSize: PDF_MAX_SIZE_BYTES, files: 5 }
});

// --- Lesson audio: audio types only, fixed subfolder ---
const AUDIO_MIME_TYPES = new Set(['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/mp4']);
const AUDIO_MAX_SIZE_BYTES = 100 * 1024 * 1024; // 100MB

const audioStorage = diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(UPLOAD_ROOT, 'audio');
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = extensionFor(file.mimetype);
    cb(null, `audio-${Date.now()}-${uniqueSuffix}${ext}`);
  }
});

function audioFileFilter(req, file, cb) {
  if (!AUDIO_MIME_TYPES.has(file.mimetype)) {
    return cb(new ApiError(400, `File must be audio (mp3, wav, ogg). Got: ${file.mimetype}`));
  }
  cb(null, true);
}

const uploadAudio = multer({
  storage: audioStorage,
  fileFilter: audioFileFilter,
  limits: { fileSize: AUDIO_MAX_SIZE_BYTES, files: 5 }
});

// --- Course thumbnails: image only, small size cap ---
const THUMBNAIL_MAX_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

const thumbnailStorage = diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(UPLOAD_ROOT, 'thumbnails');
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = extensionFor(file.mimetype);
    cb(null, `thumbnail-${Date.now()}-${uniqueSuffix}${ext}`);
  }
});

const uploadThumbnail = multer({
  storage: thumbnailStorage,
  fileFilter: imageFileFilter,
  limits: { fileSize: THUMBNAIL_MAX_SIZE_BYTES, files: 1 }
});

// --- Assignment submissions: PDF, DOC/DOCX, images, and ZIP only (per the assignment
// system spec — deliberately narrower than the generic uploadMaterial config, which
// also allows slides/spreadsheets/audio/video that aren't valid assignment deliverables) ---
const SUBMISSION_MIME_TYPES = new Set([
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/gif',
  'application/zip',
  'application/x-zip-compressed'
]);
const SUBMISSION_MAX_SIZE_BYTES = 25 * 1024 * 1024; // 25MB

const submissionStorage = diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(UPLOAD_ROOT, 'submissions');
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = extensionFor(file.mimetype);
    cb(null, `submission-${Date.now()}-${uniqueSuffix}${ext}`);
  }
});

function submissionFileFilter(req, file, cb) {
  if (!SUBMISSION_MIME_TYPES.has(file.mimetype)) {
    return cb(
      new ApiError(400, `File type not allowed for submissions (PDF, DOC/DOCX, images, or ZIP only). Got: ${file.mimetype}`)
    );
  }
  cb(null, true);
}

const uploadSubmission = multer({
  storage: submissionStorage,
  fileFilter: submissionFileFilter,
  limits: { fileSize: SUBMISSION_MAX_SIZE_BYTES, files: 5 }
});

// --- Chat attachments: images or documents (PDF/DOC/DOCX), tagged with which kind for the message model ---
const CHAT_IMAGE_MIME_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);
const CHAT_DOCUMENT_MIME_TYPES = new Set([
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
]);
const CHAT_ATTACHMENT_MAX_SIZE_BYTES = 15 * 1024 * 1024; // 15MB

const chatAttachmentStorage = diskStorage({
  destination: (req, file, cb) => {
    const dest = path.join(UPLOAD_ROOT, 'chat');
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = crypto.randomBytes(16).toString('hex');
    const ext = extensionFor(file.mimetype);
    cb(null, `chat-${Date.now()}-${uniqueSuffix}${ext}`);
  }
});

function chatAttachmentFileFilter(req, file, cb) {
  if (!CHAT_IMAGE_MIME_TYPES.has(file.mimetype) && !CHAT_DOCUMENT_MIME_TYPES.has(file.mimetype)) {
    return cb(new ApiError(400, `File type not allowed in chat (images or PDF/DOC/DOCX only). Got: ${file.mimetype}`));
  }
  cb(null, true);
}

const uploadChatAttachment = multer({
  storage: chatAttachmentStorage,
  fileFilter: chatAttachmentFileFilter,
  limits: { fileSize: CHAT_ATTACHMENT_MAX_SIZE_BYTES, files: 5 }
});

function chatAttachmentKind(mimeType) {
  return CHAT_IMAGE_MIME_TYPES.has(mimeType) ? 'image' : 'document';
}

module.exports = {
  upload,
  uploadAvatar,
  uploadMaterial,
  uploadVideo,
  uploadImage,
  uploadPdf,
  uploadAudio,
  uploadThumbnail,
  uploadSubmission,
  uploadChatAttachment,
  chatAttachmentKind,
  UPLOAD_ROOT,
  ALLOWED_MIME_TYPES,
  MAX_FILE_SIZE_BYTES,
  AVATAR_MAX_SIZE_BYTES,
  VIDEO_MAX_SIZE_BYTES,
  IMAGE_MAX_SIZE_BYTES,
  PDF_MAX_SIZE_BYTES,
  AUDIO_MAX_SIZE_BYTES,
  THUMBNAIL_MAX_SIZE_BYTES,
  SUBMISSION_MAX_SIZE_BYTES,
  CHAT_ATTACHMENT_MAX_SIZE_BYTES
};
