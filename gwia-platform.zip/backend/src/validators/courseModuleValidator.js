const { body } = require('express-validator');

const courseModuleValidator = [
  body('title').trim().notEmpty().withMessage('Module title is required').isLength({ max: 200 }),
  body('description').optional().trim().isLength({ max: 2000 }),
  body('order').optional().isInt({ min: 0 })
];

module.exports = { courseModuleValidator };
