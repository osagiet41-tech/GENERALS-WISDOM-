import { config } from '../core/config.js';
/* Loads the Socket.IO client the backend itself serves at /socket.io/socket.io.js (no CDN). */
let loader;
export function loadSocketIO() {
  if (window.io) return Promise.resolve(window.io);
  return (loader ||= new Promise((resolve, reject) => {
    const s = document.createElement('script'); s.src = `${config.socketUrl}/socket.io/socket.io.js`;
    s.onload = () => resolve(window.io); s.onerror = () => reject(new Error('Could not load the real-time client. Is the server running?'));
    document.head.append(s);
  }));
}
export async function connect(namespace, token, opts = {}) {
  const io = await loadSocketIO();
  return io(`${config.socketUrl}${namespace}`, { auth: { token }, transports: ['websocket', 'polling'], ...opts });
}
