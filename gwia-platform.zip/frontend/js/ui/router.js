import { mount } from '../core/dom.js';
import { loading, errorState } from './states.js';
/* startRouter({ shell, routes: { id: () => import('./page.js') }, fallback, ctx })
   Page modules export default async function render(ctx) -> Node. ctx.args = path segments after the route id, ctx.query = ?k=v inside the hash. */
export function startRouter({ shell, routes, fallback, ctx }) {
  let token = 0;
  async function go() {
    const raw = location.hash.replace(/^#\/?/, ''), [pathPart, qs] = raw.split('?'), [id = fallback, ...args] = pathPart.split('/').filter(Boolean);
    const key = routes[id] ? id : fallback, mine = ++token;
    shell.setActive(key); mount(shell.main, loading(5)); document.title = `${key[0].toUpperCase() + key.slice(1)} · ${document.title.split('·').pop().trim()}`;
    try {
      const mod = await routes[key](); if (mine !== token) return;
      const node = await mod.default({ ...ctx, args, query: Object.fromEntries(new URLSearchParams(qs || '')), shell, navigate: (h) => { location.hash = h; } });
      if (mine !== token) return; mount(shell.main, node); shell.main.focus({ preventScroll: true }); window.scrollTo(0, 0);
    } catch (e) { if (mine === token) mount(shell.main, errorState(e, go)); }
  }
  addEventListener('hashchange', go); go();
}
