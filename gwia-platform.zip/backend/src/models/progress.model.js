const mongoose = require('mongoose');
const { Schema } = mongoose;

const progressSchema = new Schema(
  {
    studentId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },

    completedLessonIds: [{ type: Schema.Types.ObjectId, ref: 'Lesson' }],

    videoProgress: [
      {
        lessonId: { type: Schema.Types.ObjectId, ref: 'Lesson' },
        watchedSeconds: { type: Number, default: 0 },
        completed: { type: Boolean, default: false },
        lastWatchedAt: { type: Date, default: Date.now }
      }
    ],

    lastAccessedAt: { type: Date, default: Date.now },
    enrolledAt: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

progressSchema.index({ studentId: 1, courseId: 1 }, { unique: true });

module.exports = mongoose.model('Progress', progressSchema);
