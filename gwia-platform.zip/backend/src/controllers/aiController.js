const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const aiService = require('../services/aiService');
const aiContextService = require('../services/aiContextService');
const aiUsageService = require('../services/aiUsageService');

/**
 * Builds an Express handler for one AI feature. Shared by every
 * teacher/student route so the request lifecycle (context loading,
 * quota check, provider call, usage logging, response) is identical
 * and defined exactly once — avoiding 21 hand-written copies that
 * could drift out of sync with each other.
 */
function createAiHandler(role, featureKey) {
  const generate = role === 'teacher' ? aiService.generateForTeacher : aiService.generateForStudent;

  return asyncHandler(async (req, res) => {
    const { courseId, subjectId, lessonId, ...params } = req.body;

    await aiUsageService.enforceQuota(req.user.id);

    const { contextBlock } = await aiContextService.buildContext(req.user, { courseId, subjectId, lessonId });

    const startedAt = Date.now();

    try {
      const outcome = await generate(featureKey, params, contextBlock);

      await aiUsageService.recordUsage({
        userId: req.user.id,
        role: req.user.role,
        feature: featureKey,
        courseId,
        subjectId,
        lessonId,
        inputTokens: outcome.usage?.inputTokens,
        outputTokens: outcome.usage?.outputTokens,
        durationMs: Date.now() - startedAt,
        success: true
      });

      return ApiResponse.ok(res, outcome.result, 'Generated successfully');
    } catch (err) {
      await aiUsageService.recordUsage({
        userId: req.user.id,
        role: req.user.role,
        feature: featureKey,
        courseId,
        subjectId,
        lessonId,
        durationMs: Date.now() - startedAt,
        success: false,
        errorMessage: err.message
      });
      throw err;
    }
  });
}

// GET /api/ai/usage — the authenticated user's own AI usage summary and remaining quota.
const getMyUsage = asyncHandler(async (req, res) => {
  const summary = await aiUsageService.getMyUsageSummary(req.user.id);
  return ApiResponse.ok(res, summary, 'Usage summary retrieved');
});

module.exports = { createAiHandler, getMyUsage };
