const KEY = 'gwia.theme';
export function currentTheme() { return document.documentElement.dataset.theme || 'light'; }
export function applyTheme(t) { document.documentElement.dataset.theme = t; localStorage.setItem(KEY, t); document.dispatchEvent(new CustomEvent('themechange', { detail: t })); }
export function toggleTheme() { applyTheme(currentTheme() === 'dark' ? 'light' : 'dark'); }
