import { h, icon } from '../../core/dom.js';
import { studentApi } from '../../api/student.js';
import { pageHead, items, idOf } from '../../ui/page.js';
import { courseSelect } from '../shared/courseSelect.js';
import { withState, empty } from '../../ui/states.js';
import { dataTable, statusBadge } from '../../ui/table.js';
import { fmtDateTime } from '../../core/format.js';
import { toast } from '../../ui/toast.js';
import { mount } from '../../core/dom.js';

export default async function render() {
  const { data: courses } = await studentApi.courses(); const panel = h('div', { class: 'card card-flush' });
  const cs = courseSelect(courses, { storageKey: 'student.live.course', onChange: (id) => load(id) });
  if (!cs.count) return h('div', null, pageHead('Live classes'), empty({ title: 'No courses yet', message: 'Live classes appear here once you enrol.', iconName: 'video' }));
  const load = (id) => withState(panel, () => studentApi.liveClasses(id).then((r) => items(r.data)), (rows, reload) => dataTable({ rows, caption: 'Live classes', emptyState: empty({ title: 'No live classes scheduled', iconName: 'video' }),
    columns: [{ label: 'Class', render: (r) => h('strong', null, r.title) }, { label: 'When', render: (r) => fmtDateTime(r.scheduledAt) }, { label: 'Length', render: (r) => `${r.durationMinutes} min` }, { label: 'Status', render: (r) => statusBadge(r.status) }],
    actions: (r) => r.status === 'live' ? h('a', { class: 'btn btn-sm', href: `classroom.html?id=${idOf(r)}&course=${cs.value}` }, icon('video'), 'Join now')
      : r.status === 'completed' ? h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: async (e) => { try { const { data } = await studentApi.joinLive(idOf(r)); data.recordingUrl ? window.open(data.recordingUrl, '_blank', 'noopener') : toast.info(data.message || 'No recording is available.'); } catch (err) { toast.error(err.message); } } }, 'Recording')
      : h('span', { class: 'small muted' }, 'Not started') }), { rows: 3 });
  load(cs.value);
  return h('div', { class: 'stack' }, pageHead('Live classes', 'Join when your teacher starts the class.'), cs.el, panel);
}
