const mongoose = require('mongoose');
const { Schema } = mongoose;

/**
 * One row per browser/device registered for push notifications.
 *  - kind 'webpush': a W3C PushSubscription (endpoint + keys). Works for the installed PWA on Android Chrome.
 *  - kind 'fcm'    : a Firebase Cloud Messaging device token (native Capacitor app). Sender not bundled; see docs/PUSH.md.
 */
const pushSubscriptionSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    kind: { type: String, enum: ['webpush', 'fcm'], default: 'webpush' },
    endpoint: { type: String, required: true, maxlength: 1000 }, // webpush endpoint URL, or the FCM token
    keys: {
      p256dh: { type: String, default: null },
      auth: { type: String, default: null }
    },
    userAgent: { type: String, default: null, maxlength: 300 },
    lastSuccessAt: { type: Date, default: null },
    failureCount: { type: Number, default: 0 }
  },
  { timestamps: true }
);

pushSubscriptionSchema.index({ endpoint: 1 }, { unique: true });

module.exports = mongoose.model('PushSubscription', pushSubscriptionSchema);
