const BaseProvider = require('./BaseProvider');
const ApiError = require('../../../utils/ApiError');
const { verifyFlutterwaveHash } = require('../signature');
const { toMinor, fromMinor } = require('../../../utils/money');

class FlutterwaveProvider extends BaseProvider {
  constructor(config, http, { timeoutMs } = {}) {
    super('flutterwave', config, http);
    this.timeoutMs = timeoutMs;
  }

  _headers() {
    return { Authorization: `Bearer ${this.config.secretKey}` };
  }

  async initialize({ reference, amountMinor, currency, email, name, phone, callbackUrl, description, metadata, business }) {
    this.assertConfigured();
    // Flutterwave takes MAJOR units (e.g. 5000.00), unlike Paystack.
    const res = await this.http(`${this.config.baseUrl}/payments`, {
      method: 'POST',
      headers: this._headers(),
      timeoutMs: this.timeoutMs,
      body: {
        tx_ref: reference,
        amount: fromMinor(amountMinor, currency),
        currency,
        redirect_url: callbackUrl,
        customer: { email, name, ...(phone ? { phonenumber: phone } : {}) },
        customizations: { title: business?.name, description },
        meta: metadata
      }
    });
    if (!res.ok || !res.body || res.body.status !== 'success' || !res.body.data?.link) {
      throw new ApiError(502, `Flutterwave could not start the payment: ${res.body?.message || res.status}`);
    }
    return { checkoutUrl: res.body.data.link };
  }

  async verify({ reference, transactionIdHint }) {
    this.assertConfigured();
    // transactionIdHint comes from a webhook or the browser redirect. It is only a LOOKUP KEY:
    // every field that matters (tx_ref, amount, currency, status) is checked from the API response.
    const useId = transactionIdHint && /^\d+$/.test(String(transactionIdHint));
    const url = useId
      ? `${this.config.baseUrl}/transactions/${transactionIdHint}/verify`
      : `${this.config.baseUrl}/transactions/verify_by_reference?tx_ref=${encodeURIComponent(reference)}`;
    const res = await this.http(url, { headers: this._headers(), timeoutMs: this.timeoutMs });
    return FlutterwaveProvider.mapVerifyResponse(res, reference);
  }

  static mapVerifyResponse(res, reference) {
    if (res.status === 404 || (res.body && res.body.status === 'error' && /no transaction/i.test(res.body.message || ''))) {
      return { state: 'not_found', raw: res.body };
    }
    if (!res.ok || !res.body || res.body.status !== 'success' || !res.body.data) {
      throw new ApiError(502, `Flutterwave verification failed: ${res.body?.message || res.status}`);
    }
    const d = res.body.data;
    if (d.tx_ref !== reference) {
      // A real, successful transaction — but for a different order. Never fulfil this one.
      throw new ApiError(502, 'Flutterwave transaction does not belong to this payment reference');
    }
    const currency = String(d.currency || '').toUpperCase();
    const stateMap = { successful: 'success', failed: 'failed', pending: 'pending' };
    return {
      state: stateMap[String(d.status).toLowerCase()] || 'pending',
      reference: d.tx_ref,
      amountMinor: toMinor(d.amount, currency),
      currency,
      providerTransactionId: d.id != null ? String(d.id) : null,
      channel: d.payment_type || null,
      paidAt: d.created_at ? new Date(d.created_at) : null,
      customerEmail: d.customer?.email || null,
      raw: { status: d.status, processor_response: d.processor_response, id: d.id, flw_ref: d.flw_ref }
    };
  }

  verifyWebhook({ headers }) {
    return verifyFlutterwaveHash(headers['verif-hash'], this.config.secretHash);
  }

  parseWebhook(body) {
    const event = body?.event;
    const data = body?.data || {};
    if (event === 'charge.completed') {
      return {
        kind: 'payment',
        eventType: event,
        eventKey: `${event}:${data.id ?? data.tx_ref}`,
        reference: data.tx_ref,
        transactionId: data.id != null ? String(data.id) : null
      };
    }
    return { kind: 'ignore', eventType: event || 'unknown', eventKey: `${event}:${data.id ?? data.tx_ref ?? 'n/a'}`, reference: null };
  }
}

module.exports = FlutterwaveProvider;
