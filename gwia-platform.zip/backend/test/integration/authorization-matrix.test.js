const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { boot, itest, missing } = require('./helpers');
const { buildInventory } = require('../../scripts/route-inventory');

/**
 * Generated from the live route table, so new endpoints are covered automatically:
 *   - every authenticated route must answer 401 without a token
 *   - every role-restricted route must answer 403 to a user with the wrong role
 */
const OID = '64b7f0f0f0f0f0f0f0f0f0f0';
const fill = (p) => p.replace(/:[A-Za-z]+/g, (m) => (/reference/i.test(m) ? 'GW-aaaaaaaaaaaa' : /certificateId/i.test(m) ? 'CERT-AAAA-BBBB-CCCC' : OID));
const routes = buildInventory().filter((r) => r.auth && !r.path.startsWith('/api/webhooks'));

let t;
let actors;
before(async () => {
  if (missing) return;
  t = await boot();
  actors = { student: await t.actor('student'), teacher: await t.actor('teacher'), admin: await t.actor('admin') };
});
after(async () => { if (t) await t.close(); });

const send = (req, method, url) => ({ GET: req.get, POST: req.post, PUT: req.put, PATCH: req.patch, DELETE: req.delete })[method].call(req, url);

itest(test, 'unauthenticated requests are refused (401) on every protected route', async () => {
  const failures = [];
  for (const r of routes) {
    const url = fill(r.path);
    const res = await (r.method === 'GET' ? t.request.get(url) : r.method === 'POST' ? t.request.post(url).send({}) : r.method === 'PUT' ? t.request.put(url).send({}) : r.method === 'PATCH' ? t.request.patch(url).send({}) : t.request.delete(url));
    if (res.status !== 401) failures.push(`${r.method} ${r.path} -> ${res.status}`);
  }
  assert.deepEqual(failures, []);
});

itest(test, 'a signed-in user with the wrong role is refused (403) on every role-restricted route', async () => {
  const failures = [];
  for (const r of routes.filter((x) => x.roles)) {
    const wrong = ['student', 'teacher', 'admin'].find((role) => !r.roles.includes(role));
    if (!wrong) continue;
    const url = fill(r.path);
    const api = actors[wrong].api;
    const res = await (r.method === 'GET' ? api.get(url) : r.method === 'POST' ? api.post(url).send({}) : r.method === 'PUT' ? api.put(url).send({}) : r.method === 'DELETE' ? api.delete(url) : api.put(url).send({}));
    if (res.status !== 403) failures.push(`${wrong} ${r.method} ${r.path} -> ${res.status}`);
  }
  assert.deepEqual(failures, []);
});
