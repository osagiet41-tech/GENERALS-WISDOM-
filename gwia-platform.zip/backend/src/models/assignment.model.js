const mongoose = require('mongoose');
const { Schema } = mongoose;

const attachmentSchema = new Schema(
  {
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true },
    mimeType: { type: String, required: true },
    size: { type: Number, required: true }
  },
  { _id: true }
);

const assignmentSchema = new Schema(
  {
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    subjectId: { type: Schema.Types.ObjectId, ref: 'Subject', default: null },
    moduleId: { type: Schema.Types.ObjectId, ref: 'CourseModule', default: null, index: true },
    lessonId: { type: Schema.Types.ObjectId, ref: 'Lesson', default: null },

    title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 200 },
    instructions: { type: String, default: '' },
    attachments: { type: [attachmentSchema], default: [] },

    totalMarks: { type: Number, required: true, min: 1 },
    dueDate: { type: Date, required: [true, 'Due date is required'] },
    allowLateSubmission: { type: Boolean, default: false },
    allowResubmission: { type: Boolean, default: true }, // whether a student may replace an ungraded submission

    // Set once the "due soon" reminder has gone out, so the reminder sweep
    // never sends it twice for the same assignment.
    deadlineReminderSentAt: { type: Date, default: null },

    status: { type: String, enum: ['draft', 'published', 'closed'], default: 'draft', index: true },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true }
  },
  { timestamps: true }
);

assignmentSchema.index({ courseId: 1, dueDate: 1 });

module.exports = mongoose.model('Assignment', assignmentSchema);
