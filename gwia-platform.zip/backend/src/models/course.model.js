const mongoose = require('mongoose');
const { Schema } = mongoose;

const courseSchema = new Schema(
  {
    title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 200 },
    description: { type: String, trim: true, maxlength: 5000, default: '' },
    category: { type: String, trim: true, default: 'general' },
    institutionId: { type: Schema.Types.ObjectId, ref: 'Institution', default: null, index: true },

    // A course can have multiple co-teachers; ownership checks allow any of them to manage it.
    teacherIds: [{ type: Schema.Types.ObjectId, ref: 'User', required: true, index: true }],
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },

    enrolledStudentIds: [{ type: Schema.Types.ObjectId, ref: 'User', index: true }],

    price: { type: Number, default: 0, min: 0 }, // major units, in `currency` (0 and no overrides = free course)
    currency: { type: String, default: null, uppercase: true, trim: true, maxlength: 3 }, // null = platform default currency
    // Optional per-currency prices for international buyers (major units). No automatic FX conversion.
    prices: [
      {
        _id: false,
        currency: { type: String, required: true, uppercase: true, trim: true, maxlength: 3 },
        amount: { type: Number, required: true, min: 0 }
      }
    ],
    // When true, an active subscription (or trial) unlocks this course without a separate purchase.
    includedInSubscription: { type: Boolean, default: true },

    // What a student must achieve to be issued a completion certificate (evaluated automatically).
    certificate: {
      enabled: { type: Boolean, default: true },
      minLessonCompletionPercent: { type: Number, default: 100, min: 1, max: 100 },
      // Average of the student's best graded result per published assignment/quiz/exam. null = don't check.
      minAverageScorePercent: { type: Number, default: 50, min: 0, max: 100 },
      requireAllAssessments: { type: Boolean, default: false },
      minAttendancePercent: { type: Number, default: null, min: 0, max: 100 },
      showScore: { type: Boolean, default: false }
    },
    durationHours: { type: Number, default: null, min: 0 }, // total estimated learning time

    level: {
      type: String,
      enum: ['beginner', 'intermediate', 'advanced'],
      default: 'beginner'
    },

    learningObjectives: { type: [String], default: [] }, // "By the end of this course, you will be able to..."
    prerequisites: { type: [String], default: [] }, // descriptive, informational (e.g. "Basic algebra")

    thumbnailUrl: { type: String, default: null },

    // 'published' / 'draft' (unpublished) — 'archived' additionally supports retiring old courses.
    status: {
      type: String,
      enum: ['draft', 'published', 'archived'],
      default: 'draft',
      index: true
    }
  },
  { timestamps: true }
);

courseSchema.index({ title: 'text', description: 'text' });
courseSchema.index({ teacherIds: 1, status: 1 });

const subjectSchema = new Schema(
  {
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    title: { type: String, required: [true, 'Subject title is required'], trim: true, maxlength: 200 },
    description: { type: String, trim: true, maxlength: 2000, default: '' },
    order: { type: Number, default: 0 },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true }
  },
  { timestamps: true }
);

subjectSchema.index({ courseId: 1, order: 1 });

module.exports = {
  Course: mongoose.model('Course', courseSchema),
  Subject: mongoose.model('Subject', subjectSchema)
};
