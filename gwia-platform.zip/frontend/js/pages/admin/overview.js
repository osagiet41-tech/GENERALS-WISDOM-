import { h } from '../../core/dom.js';
import { adminApi } from '../../api/admin.js';
import { pageHead, statCard, card, items } from '../../ui/page.js';
import { fmtMoney, fmtPercent } from '../../core/format.js';
import { withState, empty } from '../../ui/states.js';
import { dataTable } from '../../ui/table.js';
import { currentTheme } from '../../core/theme.js';

/* The overview endpoint's exact keys vary by deployment, so numbers are rendered from whatever scalar fields it returns. */
const label = (k) => k.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase());
function bars(rows, xKey, yKey, money) {
  if (!rows.length) return empty({ title: 'No data for this period', iconName: 'chart' });
  const max = Math.max(...rows.map((r) => Number(r[yKey]) || 0), 1);
  return h('div', { role: 'img', 'aria-label': 'Bar chart', style: 'display:flex;align-items:flex-end;gap:6px;height:180px;padding:16px;overflow-x:auto' }, rows.map((r) => h('div', { style: 'flex:1;min-width:28px;display:grid;gap:4px;justify-items:center;align-content:end;height:100%' },
    h('div', { title: `${r[xKey]}: ${money ? fmtMoney(r[yKey]) : r[yKey]}`, style: `width:100%;background:var(--gold);border-radius:4px 4px 0 0;height:${Math.max(3, ((Number(r[yKey]) || 0) / max) * 100)}%` }), h('span', { class: 'small muted', style: 'font-size:.7rem' }, String(r[xKey]).slice(-5)))));
}
export default async function render() {
  const { data } = await adminApi.overview(); const flat = Object.entries(data || {}).filter(([, v]) => ['number', 'string'].includes(typeof v));
  const trend = h('div'), perf = h('div');
  withState(trend, () => adminApi.revenue().then((r) => items(r.data)), (rows) => bars(rows, rows[0] && ('month' in rows[0] ? 'month' : 'date' in rows[0] ? 'date' : Object.keys(rows[0])[0]), rows[0] && ('revenue' in rows[0] ? 'revenue' : 'total' in rows[0] ? 'total' : Object.keys(rows[0])[1]), true), { rows: 3 });
  withState(perf, () => adminApi.coursePerformance().then((r) => items(r.data)), (rows) => dataTable({ rows: rows.slice(0, 10), rowKey: (r) => r.courseId || r.title, caption: 'Top courses', columns: [{ label: 'Course', render: (r) => r.title || r.courseTitle || '—' },
    { label: 'Students', render: (r) => r.enrolled ?? r.enrollments ?? r.students ?? '—' }, { label: 'Completion', render: (r) => fmtPercent(r.completionPercent ?? r.completionRate) }] }), { rows: 3 });
  return h('div', { class: 'stack' }, pageHead('Administrator overview', 'The state of the academy right now.'),
    flat.length ? h('div', { class: 'grid grid-stats' }, flat.map(([k, v]) => statCard(label(k), typeof v === 'number' && /revenue|amount/i.test(k) ? fmtMoney(v) : v))) : empty({ title: 'No summary available' }),
    h('div', { class: 'grid grid-2' }, card('Revenue trend', trend), card('Course performance', perf)));
}
