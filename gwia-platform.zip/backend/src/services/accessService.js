const env = require('../config/env');
const { CourseAccess, Subscription } = require('../models/billing.model');
const ApiError = require('../utils/ApiError');
const { isCourseFree } = require('./pricingService');

/** The subscription (paid or trial) that is valid RIGHT NOW. Checks endDate, not just status,
 *  so access stops at the exact expiry moment even if the expiry job hasn't run yet. */
async function getLiveSubscription(userId, now = new Date()) {
  return Subscription.findOne({ userId, status: { $in: ['active', 'trialing'] }, endDate: { $gt: now } })
    .sort({ endDate: -1 })
    .lean();
}

/**
 * Decides whether `userId` may use the content of `course`.
 * Order: free -> purchased/granted -> subscription/trial.
 */
async function getCourseAccess(userId, course, now = new Date()) {
  if (isCourseFree(course)) return { granted: true, via: 'free' };

  const entitlement = await CourseAccess.findOne({
    userId,
    courseId: course._id,
    status: 'active',
    $or: [{ expiresAt: null }, { expiresAt: { $gt: now } }]
  }).lean();
  if (entitlement) return { granted: true, via: entitlement.source === 'purchase' ? 'purchase' : 'granted', expiresAt: entitlement.expiresAt };

  if (course.includedInSubscription !== false) {
    const sub = await getLiveSubscription(userId, now);
    if (sub) return { granted: true, via: sub.status === 'trialing' ? 'trial' : 'subscription', expiresAt: sub.endDate };
  }

  const hadSubscription = course.includedInSubscription !== false && (await Subscription.exists({ userId }));
  return { granted: false, reason: hadSubscription ? 'subscription_expired' : 'payment_required' };
}

/** Throws 402 (with a machine-readable code the frontend can route on) if access is not granted. */
async function assertCourseAccess(userId, course) {
  if (!env.payments.enforceAccess) return { granted: true, via: 'enforcement_disabled' };
  const access = await getCourseAccess(userId, course);
  if (!access.granted) {
    const message =
      access.reason === 'subscription_expired'
        ? 'Your subscription has expired. Renew it or purchase this course to continue.'
        : 'This course requires payment or an active subscription.';
    throw ApiError.paymentRequired(message, { code: access.reason.toUpperCase(), courseId: String(course._id) });
  }
  return access;
}

module.exports = { getLiveSubscription, getCourseAccess, assertCourseAccess };
