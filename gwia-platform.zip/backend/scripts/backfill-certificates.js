/**
 * Run once when rolling out the new certificate system.
 *
 *  1. Upgrades certificates issued by the old system: gives them a public Certificate ID and a frozen snapshot
 *     (so they keep saying what they said). Their old 16-character verification code keeps working.
 *  2. Issues certificates to students who ALREADY meet their course's requirements but never got one
 *     (the old system only tried when a lesson was completed, and ignored grades).
 *
 *   node scripts/backfill-certificates.js            # dry run: prints what it would do
 *   node scripts/backfill-certificates.js --apply    # does it
 */
require('dotenv').config();
const mongoose = require('mongoose');
const env = require('../src/config/env');
const Certificate = require('../src/models/certificate.model');
const { Course } = require('../src/models/course.model');
const User = require('../src/models/User');
const certificateService = require('../src/services/certificateService');
const { generateCertificateId } = require('../src/utils/certificateId');

(async () => {
  const apply = process.argv.includes('--apply');
  await mongoose.connect(env.mongodbUri);
  await Certificate.createIndexes();

  // 1. upgrade legacy certificates
  const legacy = await Certificate.find({ certificateId: null });
  let upgraded = 0;
  for (const cert of legacy) {
    upgraded += 1;
    if (!apply) continue;
    const [student, course] = await Promise.all([User.findById(cert.studentId).select('name'), Course.findById(cert.courseId)]);
    const instructors = course
      ? (await User.find({ _id: { $in: course.teacherIds } }).select('name profile.signatureFile')).map((u) => ({
          name: u.name,
          signatureFile: u.profile?.signatureFile || null
        }))
      : [];
    cert.certificateId = generateCertificateId();
    cert.completionDate = cert.completionDate || cert.issuedAt;
    cert.snapshot = {
      studentName: student?.name || 'Student',
      courseTitle: course?.title || cert.title,
      institutionName: env.certificates.institutionName,
      instructors,
      signatory: env.certificates.signatory.name
        ? { name: env.certificates.signatory.name, title: env.certificates.signatory.title || null, signatureFile: env.certificates.signatory.imageFile || null }
        : { name: null, title: null, signatureFile: null },
      finalScorePercent: null,
      showScore: false
    };
    await cert.save();
  }
  console.log(`${apply ? 'Upgraded' : 'Would upgrade'} ${upgraded} legacy certificate(s).`);

  // 2. issue certificates that are already earned
  let eligible = 0;
  let issued = 0;
  const courses = await Course.find({ status: { $ne: 'draft' } }).select('_id');
  for (const { _id } of courses) {
    const r = await certificateService.evaluateCourse(_id, { apply });
    eligible += r.eligible;
    issued += r.issued;
  }
  console.log(apply ? `Issued ${issued} new certificate(s).` : `Would issue ${eligible} new certificate(s). Re-run with --apply.`);

  await mongoose.disconnect();
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
