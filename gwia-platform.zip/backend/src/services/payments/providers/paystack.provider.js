const BaseProvider = require('./BaseProvider');
const ApiError = require('../../../utils/ApiError');
const { verifyPaystackSignature } = require('../signature');

class PaystackProvider extends BaseProvider {
  constructor(config, http, { timeoutMs } = {}) {
    super('paystack', config, http);
    this.timeoutMs = timeoutMs;
  }

  _headers() {
    return { Authorization: `Bearer ${this.config.secretKey}` };
  }

  async initialize({ reference, amountMinor, currency, email, name, callbackUrl, metadata }) {
    this.assertConfigured();
    // Paystack amounts are in the subunit (kobo/cents) — exactly our internal unit.
    const res = await this.http(`${this.config.baseUrl}/transaction/initialize`, {
      method: 'POST',
      headers: this._headers(),
      timeoutMs: this.timeoutMs,
      body: {
        email,
        amount: amountMinor,
        currency,
        reference,
        callback_url: callbackUrl,
        metadata: { ...metadata, customerName: name }
      }
    });
    if (!res.ok || !res.body || res.body.status !== true || !res.body.data?.authorization_url) {
      throw new ApiError(502, `Paystack could not start the payment: ${res.body?.message || res.status}`);
    }
    return { checkoutUrl: res.body.data.authorization_url, accessCode: res.body.data.access_code };
  }

  async verify({ reference }) {
    this.assertConfigured();
    const res = await this.http(`${this.config.baseUrl}/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: this._headers(),
      timeoutMs: this.timeoutMs
    });
    return PaystackProvider.mapVerifyResponse(res, reference);
  }

  static mapVerifyResponse(res, reference) {
    if (res.status === 404) return { state: 'not_found', raw: res.body };
    if (!res.ok || !res.body || res.body.status !== true || !res.body.data) {
      // Unknown failure: do NOT treat as paid or failed. Caller retries later.
      throw new ApiError(502, `Paystack verification failed: ${res.body?.message || res.status}`);
    }
    const d = res.body.data;
    if (d.reference !== reference) {
      throw new ApiError(502, 'Paystack returned a different transaction reference than requested');
    }
    const stateMap = {
      success: 'success',
      failed: 'failed',
      reversed: 'failed',
      abandoned: 'pending',
      ongoing: 'pending',
      pending: 'pending',
      processing: 'pending',
      queued: 'pending'
    };
    return {
      state: stateMap[d.status] || 'pending',
      reference: d.reference,
      amountMinor: Number(d.amount),
      currency: String(d.currency || '').toUpperCase(),
      providerTransactionId: d.id != null ? String(d.id) : null,
      channel: d.channel || null,
      paidAt: d.paid_at ? new Date(d.paid_at) : null,
      customerEmail: d.customer?.email || null,
      raw: { status: d.status, gateway_response: d.gateway_response, id: d.id }
    };
  }

  verifyWebhook({ rawBody, headers }) {
    return verifyPaystackSignature(rawBody, headers['x-paystack-signature'], this.config.secretKey);
  }

  parseWebhook(body) {
    const event = body?.event;
    const data = body?.data || {};
    if (event === 'charge.success') {
      return {
        kind: 'payment',
        eventType: event,
        eventKey: `${event}:${data.id ?? data.reference}`,
        reference: data.reference,
        transactionId: data.id != null ? String(data.id) : null
      };
    }
    if (event === 'refund.processed') {
      return {
        kind: 'refund',
        eventType: event,
        eventKey: `${event}:${data.id ?? data.transaction_reference}`,
        reference: data.transaction_reference,
        transactionId: null
      };
    }
    return { kind: 'ignore', eventType: event || 'unknown', eventKey: `${event}:${data.id ?? data.reference ?? 'n/a'}`, reference: null };
  }
}

module.exports = PaystackProvider;
