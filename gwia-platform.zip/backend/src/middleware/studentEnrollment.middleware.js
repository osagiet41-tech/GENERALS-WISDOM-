const mongoose = require('mongoose');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { Course } = require('../models/course.model');
const Progress = require('../models/progress.model');
const Lesson = require('../models/lesson.model');
const accessService = require('../services/accessService');

/**
 * Loads a Course by id and confirms the requesting student is enrolled
 * in it. Attaches the course to req.course.
 */
function verifyEnrollment(resolveCourseId = (req) => req.params.courseId) {
  return asyncHandler(async (req, res, next) => {
    const courseId = resolveCourseId(req);

    if (!courseId || !mongoose.Types.ObjectId.isValid(courseId)) {
      throw ApiError.badRequest('A valid courseId is required');
    }

    const course = await Course.findById(courseId);
    if (!course) {
      throw ApiError.notFound('Course not found');
    }

    const isEnrolled = course.enrolledStudentIds.some((id) => id.toString() === req.user.id);
    if (!isEnrolled) {
      throw ApiError.forbidden('You are not enrolled in this course');
    }

    // Paid content: enrolled is not enough, the student must also currently have access
    // (free course, purchase, or live subscription/trial). Throws 402 otherwise.
    await accessService.assertCourseAccess(req.user.id, course);

    req.course = course;
    next();
  });
}

/**
 * For routes operating on a resource that carries its own courseId (a
 * lesson, assignment, quiz, exam, live class, announcement, etc.) —
 * loads the resource, verifies the requesting student is enrolled in
 * its parent course, and additionally verifies the resource is in a
 * student-visible state (published, not draft) unless the resource
 * has no status field.
 */
function verifyResourceAccess(Model, paramName = 'id', { statusField = 'status', publishedValue = 'published' } = {}) {
  return asyncHandler(async (req, res, next) => {
    const resourceId = req.params[paramName];

    if (!resourceId || !mongoose.Types.ObjectId.isValid(resourceId)) {
      throw ApiError.badRequest(`A valid ${paramName} is required`);
    }

    const resource = await Model.findById(resourceId);
    if (!resource) {
      throw ApiError.notFound('Resource not found');
    }

    if (statusField && resource[statusField] !== undefined && resource[statusField] !== publishedValue) {
      throw ApiError.notFound('Resource not found');
    }

    const course = await Course.findById(resource.courseId);
    if (!course) {
      throw ApiError.notFound('Parent course not found');
    }

    const isEnrolled = course.enrolledStudentIds.some((id) => id.toString() === req.user.id);
    if (!isEnrolled) {
      throw ApiError.forbidden('You are not enrolled in this course');
    }

    await accessService.assertCourseAccess(req.user.id, course);

    req.resource = resource;
    req.course = course;
    next();
  });
}

/**
 * Ensures a student can only view/modify their own submissions,
 * progress, grades, or certificates — never another student's, even
 * within a shared course.
 */
function verifySelfOwnership(resolveOwnerId) {
  return (req, res, next) => {
    const ownerId = resolveOwnerId(req);
    if (ownerId !== req.user.id) {
      return next(ApiError.forbidden('You may only access your own data'));
    }
    next();
  };
}

/**
 * Blocks access to a lesson (req.resource, already loaded by
 * verifyResourceAccess) until every lesson listed in its
 * prerequisiteLessonIds has been marked complete by this student.
 * Must run after verifyResourceAccess(Lesson, ...).
 */
function verifyLessonPrerequisites() {
  return asyncHandler(async (req, res, next) => {
    const lesson = req.resource;
    if (!lesson.prerequisiteLessonIds || lesson.prerequisiteLessonIds.length === 0) {
      return next();
    }

    const progress = await Progress.findOne({ studentId: req.user.id, courseId: lesson.courseId });
    const completedIds = new Set((progress ? progress.completedLessonIds : []).map((id) => id.toString()));

    const missingIds = lesson.prerequisiteLessonIds.filter((id) => !completedIds.has(id.toString()));
    if (missingIds.length > 0) {
      const missingLessons = await Lesson.find({ _id: { $in: missingIds } }, 'title');
      throw ApiError.forbidden(
        `Complete the following lesson(s) first: ${missingLessons.map((l) => l.title).join(', ')}`
      );
    }

    next();
  });
}

module.exports = { verifyEnrollment, verifyResourceAccess, verifySelfOwnership, verifyLessonPrerequisites };
