/**
 * A recording stand-in for pdfkit's document, used to test certificate LAYOUT without the pdfkit package.
 * It measures text with the real TTF metrics (cmap + hmtx), so fit-to-width logic behaves like production,
 * and records every drawing operation so test/preview/replay.py can paint them for a visual check.
 */
const fs = require('fs');

function parseTtf(file) {
  const b = fs.readFileSync(file);
  const numTables = b.readUInt16BE(4);
  const tables = {};
  for (let i = 0; i < numTables; i += 1) {
    const o = 12 + i * 16;
    tables[b.toString('ascii', o, o + 4)] = b.readUInt32BE(o + 8);
  }
  const unitsPerEm = b.readUInt16BE(tables.head + 18);
  const ascent = b.readInt16BE(tables.hhea + 4);
  const numHMetrics = b.readUInt16BE(tables.hhea + 34);

  // cmap: prefer a format-12 (full Unicode) subtable, otherwise format 4 (BMP)
  const cmapOff = tables.cmap;
  const nSub = b.readUInt16BE(cmapOff + 2);
  let sub4 = null;
  let sub12 = null;
  for (let i = 0; i < nSub; i += 1) {
    const rec = cmapOff + 4 + i * 8;
    const off = cmapOff + b.readUInt32BE(rec + 4);
    const format = b.readUInt16BE(off);
    if (format === 12) sub12 = off;
    if (format === 4 && !sub4) sub4 = off;
  }
  const glyphFor = (cp) => {
    if (sub12 !== null) {
      const nGroups = b.readUInt32BE(sub12 + 12);
      for (let g = 0; g < nGroups; g += 1) {
        const o = sub12 + 16 + g * 12;
        const start = b.readUInt32BE(o);
        const end = b.readUInt32BE(o + 4);
        if (cp >= start && cp <= end) return b.readUInt32BE(o + 8) + (cp - start);
      }
      return 0;
    }
    const segX2 = b.readUInt16BE(sub4 + 6);
    const endO = sub4 + 14;
    const startO = endO + segX2 + 2;
    const deltaO = startO + segX2;
    const rangeO = deltaO + segX2;
    for (let s = 0; s < segX2 / 2; s += 1) {
      if (cp <= b.readUInt16BE(endO + s * 2)) {
        const start = b.readUInt16BE(startO + s * 2);
        if (cp < start) return 0;
        const delta = b.readInt16BE(deltaO + s * 2);
        const ro = b.readUInt16BE(rangeO + s * 2);
        if (ro === 0) return (cp + delta) & 0xffff;
        const gi = b.readUInt16BE(rangeO + s * 2 + ro + (cp - start) * 2);
        return gi === 0 ? 0 : (gi + delta) & 0xffff;
      }
    }
    return 0;
  };
  const advance = (gid) => {
    const idx = Math.min(gid, numHMetrics - 1);
    return b.readUInt16BE(tables.hmtx + idx * 4);
  };
  return {
    unitsPerEm,
    ascender: (ascent * 1000) / unitsPerEm,
    width(str, size) {
      let w = 0;
      for (const ch of str) w += advance(glyphFor(ch.codePointAt(0)));
      return (w / unitsPerEm) * size;
    },
    hasGlyph: (cp) => glyphFor(cp) !== 0
  };
}

class FakePdfDoc {
  constructor(opts = {}) {
    // A4 landscape in points, like pdfkit
    this.page = { width: 841.89, height: 595.28 };
    this.fonts = {};
    this.fontPaths = {};
    this.cur = { font: null, size: 12, fill: '#000000', stroke: '#000000', lineWidth: 1 };
    this.path = [];
    this.ops = [];
    this.texts = [];
    this.opts = opts;
  }

  registerFont(name, file) {
    this.fontPaths[name] = file;
    this.fonts[name] = parseTtf(file);
    return this;
  }
  font(name) { this.cur.font = name; return this; }
  fontSize(n) { this.cur.size = n; return this; }
  fillColor(c) { this.cur.fill = c; return this; }
  strokeColor(c) { this.cur.stroke = c; return this; }
  lineWidth(w) { this.cur.lineWidth = w; return this; }
  widthOfString(str) {
    const f = this.fonts[this.cur.font];
    if (!f) throw new Error(`FakePdfDoc: font "${this.cur.font}" is not registered`);
    return f.width(str, this.cur.size);
  }
  rect(x, y, w, h) { this.path.push({ t: 'rect', x, y, w, h }); return this; }
  circle(x, y, r) { this.path.push({ t: 'circle', x, y, r }); return this; }
  polygon(...pts) { this.path.push({ t: 'poly', pts }); return this; }
  moveTo(x, y) { this.path.push({ t: 'move', x, y }); return this; }
  lineTo(x, y) { this.path.push({ t: 'line', x, y }); return this; }
  _flush(kind, fill) {
    this.ops.push({ type: 'path', kind, segs: this.path, fill: fill || this.cur.fill, stroke: this.cur.stroke, lineWidth: this.cur.lineWidth });
    this.path = [];
    return this;
  }
  stroke() { return this._flush('stroke'); }
  fill(color) { return this._flush('fill', color); }
  text(str, x, y, opts = {}) {
    const f = this.fonts[this.cur.font];
    const cs = opts.characterSpacing || 0;
    const width = f.width(str, this.cur.size) + cs * str.length;
    const baseline = y + (f.ascender / 1000) * this.cur.size; // pdfkit places y at the TOP of the line box
    const rec = { str, x, baseline, width, size: this.cur.size, font: this.cur.font, fill: this.cur.fill, cs };
    this.texts.push({ ...rec, top: y, bottom: baseline + 0.25 * this.cur.size });
    this.ops.push({ type: 'text', ...rec });
    return this;
  }
  image(buf, x, y, opts = {}) {
    const fit = opts.fit || [0, 0];
    this.ops.push({ type: 'image', data: Buffer.from(buf).toString('base64'), x, y, w: fit[0], h: fit[1], align: opts.align, valign: opts.valign });
    return this;
  }
}

module.exports = { FakePdfDoc, parseTtf };
