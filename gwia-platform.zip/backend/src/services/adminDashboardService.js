const User = require('../models/User');
const { Course } = require('../models/course.model');
const { Assessment } = require('../models/assessment.model');
const Submission = require('../models/submission.model');
const Progress = require('../models/progress.model');
const { Payment, Subscription } = require('../models/billing.model');

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

async function getOverviewStats() {
  const now = new Date();

  const [
    totalStudents,
    totalTeachers,
    totalCourses,
    activeCourses,
    totalExaminations,
    assignmentSubmissions,
    revenueAgg,
    activeSubscriptions
  ] = await Promise.all([
    User.countDocuments({ role: 'student' }),
    User.countDocuments({ role: 'teacher' }),
    Course.countDocuments({}),
    Course.countDocuments({ status: 'published' }),
    Assessment.countDocuments({ kind: 'exam' }),
    Submission.countDocuments({ refType: 'assignment' }),
    Payment.aggregate([
      { $match: { status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]),
    Subscription.countDocuments({ status: 'active', endDate: { $gte: now } })
  ]);

  return {
    totalStudents,
    totalTeachers,
    totalCourses,
    activeCourses,
    totalExaminations,
    assignmentSubmissions,
    revenue: revenueAgg[0]?.total || 0,
    activeSubscriptions
  };
}

async function getRevenueTrend({ months = 6 } = {}) {
  const start = new Date();
  start.setMonth(start.getMonth() - (months - 1));
  start.setDate(1);
  start.setHours(0, 0, 0, 0);

  const results = await Payment.aggregate([
    { $match: { status: 'completed', createdAt: { $gte: start } } },
    {
      $group: {
        _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
        total: { $sum: '$amount' },
        count: { $sum: 1 }
      }
    },
    { $sort: { '_id.year': 1, '_id.month': 1 } }
  ]);

  return results.map((r) => ({
    label: `${r._id.year}-${String(r._id.month).padStart(2, '0')}`,
    total: r.total,
    count: r.count
  }));
}

async function getStudentEngagement() {
  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - SEVEN_DAYS_MS);
  const thirtyDaysAgo = new Date(now.getTime() - THIRTY_DAYS_MS);

  const [totalStudents, activeLast7Days, activeLast30Days, progressDocs] = await Promise.all([
    User.countDocuments({ role: 'student' }),
    User.countDocuments({ role: 'student', lastLoginAt: { $gte: sevenDaysAgo } }),
    User.countDocuments({ role: 'student', lastLoginAt: { $gte: thirtyDaysAgo } }),
    Progress.find({}, 'completedLessonIds')
  ]);

  const avgLessonsCompletedPerEnrollment =
    progressDocs.length > 0
      ? Math.round(
          (progressDocs.reduce((sum, p) => sum + p.completedLessonIds.length, 0) / progressDocs.length) * 10
        ) / 10
      : 0;

  return {
    totalStudents,
    activeLast7Days,
    activeLast30Days,
    engagementRate7d: totalStudents > 0 ? Math.round((activeLast7Days / totalStudents) * 100) : 0,
    engagementRate30d: totalStudents > 0 ? Math.round((activeLast30Days / totalStudents) * 100) : 0,
    avgLessonsCompletedPerEnrollment
  };
}

async function getCoursePerformance({ limit = 10 } = {}) {
  const courses = await Course.find({ status: { $ne: 'archived' } })
    .sort({ enrolledStudentIds: -1 })
    .limit(Number(limit));

  const results = await Promise.all(
    courses.map(async (course) => {
      const submissions = await Submission.find({ courseId: course._id });
      const graded = submissions.filter((s) => s.status === 'graded' && s.grade.totalMarks > 0);

      const avgPercent =
        graded.length > 0
          ? Math.round(
              (graded.reduce((sum, s) => sum + s.grade.score / s.grade.totalMarks, 0) / graded.length) * 100
            )
          : null;

      return {
        courseId: course._id,
        title: course.title,
        enrolledCount: course.enrolledStudentIds.length,
        totalSubmissions: submissions.length,
        gradedSubmissions: graded.length,
        averageScorePercent: avgPercent
      };
    })
  );

  return results;
}

/**
 * There's no dedicated enrollment-event log in this codebase (enrollment
 * just pushes into Course.enrolledStudentIds), so a true "new enrollments
 * per month" series isn't derivable. This reports new COURSE creation per
 * month instead — the closest trend signal actually available from
 * existing data — and is named accordingly rather than mislabeled as
 * enrollment growth.
 */
async function getCourseCreationTrend({ months = 6 } = {}) {
  const start = new Date();
  start.setMonth(start.getMonth() - (months - 1));
  start.setDate(1);
  start.setHours(0, 0, 0, 0);

  const results = await Course.aggregate([
    { $match: { createdAt: { $gte: start } } },
    {
      $group: {
        _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
        count: { $sum: 1 }
      }
    },
    { $sort: { '_id.year': 1, '_id.month': 1 } }
  ]);

  return results.map((r) => ({ label: `${r._id.year}-${String(r._id.month).padStart(2, '0')}`, count: r.count }));
}

module.exports = {
  getOverviewStats,
  getRevenueTrend,
  getStudentEngagement,
  getCoursePerformance,
  getCourseCreationTrend
};
