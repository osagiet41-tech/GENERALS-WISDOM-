const certificateService = require('../services/certificateService');
const logger = require('../utils/logger');

const SWEEP_INTERVAL_MS = 30 * 60 * 1000;
let intervalHandle = null;

/**
 * Safety net behind the instant triggers (lesson completed, work graded, attendance saved): re-checks every
 * student whose progress, grades or attendance changed recently. Issuing is idempotent (one certificate per
 * student per course, enforced by a unique index), so overlapping runs or several server instances are harmless.
 */
async function runCertificateSweep() {
  const checked = await certificateService.sweepRecentActivity();
  if (checked) logger.info(`Certificate sweep queued ${checked} student/course check(s)`);
}

function startCertificateJobs() {
  if (intervalHandle) return;
  const tick = () => runCertificateSweep().catch((err) => logger.error(`Certificate sweep failed: ${err.message}`));
  intervalHandle = setInterval(tick, SWEEP_INTERVAL_MS);
  intervalHandle.unref?.();
  logger.info('Certificate background job started (every 30 minutes)');
}

function stopCertificateJobs() {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
  }
}

module.exports = { startCertificateJobs, stopCertificateJobs, runCertificateSweep };
