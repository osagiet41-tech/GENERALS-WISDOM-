const mongoose = require('mongoose');
const { Schema } = mongoose;

const conversationSchema = new Schema(
  {
    participantIds: [{ type: Schema.Types.ObjectId, ref: 'User', required: true, index: true }],
    // The exact pairing of roles at creation time (e.g. ['teacher','student']) — stored so it
    // never needs recomputing, and so a later role change doesn't retroactively alter what was
    // an already-valid conversation.
    participantRoles: [{ type: String, enum: ['admin', 'teacher', 'student'] }],
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', default: null },

    lastMessageAt: { type: Date, default: Date.now },
    lastMessagePreview: { type: String, default: null, maxlength: 200 }
  },
  { timestamps: true }
);

conversationSchema.index({ participantIds: 1 });
conversationSchema.index({ participantIds: 1, lastMessageAt: -1 });

const attachmentSchema = new Schema(
  {
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true },
    mimeType: { type: String, required: true },
    size: { type: Number, required: true },
    kind: { type: String, enum: ['image', 'document'], required: true }
  },
  { _id: true }
);

const messageSchema = new Schema(
  {
    conversationId: { type: Schema.Types.ObjectId, ref: 'Conversation', required: true, index: true },
    senderId: { type: Schema.Types.ObjectId, ref: 'User', required: true },

    text: { type: String, trim: true, maxlength: 5000, default: '' },
    attachments: { type: [attachmentSchema], default: [] },

    readBy: [{ type: Schema.Types.ObjectId, ref: 'User' }],

    // Soft delete: "delete for me" hides it only for the deleting user (deletedFor);
    // "delete for everyone" replaces the visible content for all participants but
    // keeps the row (and its position in history) intact.
    deletedFor: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    isDeletedForEveryone: { type: Boolean, default: false },
    deletedAt: { type: Date, default: null }
  },
  { timestamps: true }
);

messageSchema.index({ conversationId: 1, createdAt: -1 });
messageSchema.index({ text: 'text' });

module.exports = {
  Conversation: mongoose.model('Conversation', conversationSchema),
  Message: mongoose.model('Message', messageSchema)
};
