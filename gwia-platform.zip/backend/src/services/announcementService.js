const Announcement = require('../models/announcement.model');

async function createAnnouncement(courseId, teacherId, data) {
  return Announcement.create({
    courseId,
    teacherId,
    title: data.title,
    content: data.content,
    pinned: !!data.pinned
  });
}

async function updateAnnouncement(announcement, updates) {
  const allowed = ['title', 'content', 'pinned'];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      announcement[field] = updates[field];
    }
  }
  await announcement.save();
  return announcement;
}

async function deleteAnnouncement(announcement) {
  await announcement.deleteOne();
}

async function listAnnouncements(courseId) {
  return Announcement.find({ courseId }).sort({ pinned: -1, createdAt: -1 });
}

module.exports = { createAnnouncement, updateAnnouncement, deleteAnnouncement, listAnnouncements };
