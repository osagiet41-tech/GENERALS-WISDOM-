const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const studentAssignmentService = require('../services/studentAssignmentService');
const Submission = require('../models/submission.model');

// GET /api/student/courses/:courseId/assignments
const listAssignments = asyncHandler(async (req, res) => {
  const assignments = await studentAssignmentService.listAssignments(req.course._id);
  return ApiResponse.ok(res, assignments, 'Assignments retrieved');
});

// GET /api/student/assignments/:id  (req.resource set by verifyResourceAccess)
const getAssignment = asyncHandler(async (req, res) => {
  const mySubmission = await Submission.findOne({
    refType: 'assignment',
    refId: req.resource._id,
    studentId: req.user.id
  });
  return ApiResponse.ok(res, { assignment: req.resource, mySubmission }, 'Assignment retrieved');
});

// POST /api/student/assignments/:id/submit
const submitAssignment = asyncHandler(async (req, res) => {
  const files = (req.files || []).map((file) => ({
    fileName: file.originalname,
    fileUrl: `/uploads/submissions/${file.filename}`,
    mimeType: file.mimetype,
    size: file.size
  }));

  if (!req.body.textAnswer && files.length === 0) {
    throw ApiError.badRequest('Provide a text answer, at least one file, or both');
  }

  const submission = await studentAssignmentService.submitAssignment(req.resource, req.user.id, {
    textAnswer: req.body.textAnswer,
    files
  });

  return ApiResponse.created(res, submission, 'Assignment submitted successfully');
});

module.exports = { listAssignments, getAssignment, submitAssignment };
