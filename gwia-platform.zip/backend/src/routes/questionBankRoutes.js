const express = require('express');
const controller = require('../controllers/questionBankController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership, verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { uploadMaterial } = require('../config/multer');
const { questionValidator } = require('../validators/questionBankValidator');
const { Question } = require('../models/assessment.model');

const nestedRouter = express.Router({ mergeParams: true });
nestedRouter.use(authMiddleware, requireTeacherOrAdmin);
nestedRouter.get('/', verifyCourseOwnership(), controller.listQuestions);
nestedRouter.post('/', verifyCourseOwnership(), validate(questionValidator), controller.createQuestion);
nestedRouter.post('/import', verifyCourseOwnership(), uploadMaterial.single('file'), controller.bulkImport);

const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);

itemRouter.put(
  '/:id',
  verifyResourceOwnership(Question, 'id'),
  validate(questionValidator),
  controller.updateQuestion
);
itemRouter.delete('/:id', verifyResourceOwnership(Question, 'id'), controller.deleteQuestion);

module.exports = { nestedRouter, itemRouter };
