const express = require('express');
const controller = require('../controllers/analyticsController');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const {
  verifyCourseOwnership,
  verifyResourceOwnership,
  verifyStudentInCourse
} = require('../middleware/teacherOwnership.middleware');
const Assignment = require('../models/assignment.model');
const { Assessment } = require('../models/assessment.model');

// Nested under /api/courses/:courseId/analytics
const courseAnalyticsRouter = express.Router({ mergeParams: true });
courseAnalyticsRouter.use(authMiddleware, requireTeacherOrAdmin);
courseAnalyticsRouter.get('/', verifyCourseOwnership(), controller.getCourseAnalytics);
courseAnalyticsRouter.get(
  '/students/:studentId',
  verifyCourseOwnership(),
  verifyStudentInCourse(),
  controller.getStudentPerformance
);

// GET /api/assignments/:id/analytics
const assignmentAnalyticsRouter = express.Router();
assignmentAnalyticsRouter.use(authMiddleware, requireTeacherOrAdmin);
assignmentAnalyticsRouter.get(
  '/:id/analytics',
  verifyResourceOwnership(Assignment, 'id'),
  controller.getAssignmentDistribution
);

// GET /api/quizzes/:id/analytics and /api/exams/:id/analytics
const assessmentAnalyticsRouter = express.Router();
assessmentAnalyticsRouter.use(authMiddleware, requireTeacherOrAdmin);
assessmentAnalyticsRouter.get(
  '/:id/analytics',
  verifyResourceOwnership(Assessment, 'id'),
  controller.getAssessmentDistribution
);

module.exports = { courseAnalyticsRouter, assignmentAnalyticsRouter, assessmentAnalyticsRouter };
