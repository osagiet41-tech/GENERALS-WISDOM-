const { jsonToExcelBuffer } = require('../utils/excel.util');
const adminDashboardService = require('./adminDashboardService');
const billingService = require('./billingService');

async function getCoursePerformanceReport({ limit = 100 } = {}) {
  const rows = await adminDashboardService.getCoursePerformance({ limit });
  return rows.map((r) => ({
    Course: r.title,
    Enrolled: r.enrolledCount,
    'Total Submissions': r.totalSubmissions,
    'Graded Submissions': r.gradedSubmissions,
    'Average Score %': r.averageScorePercent ?? 'N/A'
  }));
}

async function getRevenueReport({ months = 12 } = {}) {
  const rows = await adminDashboardService.getRevenueTrend({ months });
  return rows.map((r) => ({ Month: r.label, 'Total Revenue': r.total, 'Payment Count': r.count }));
}

async function getPaymentsReport({ status } = {}) {
  const { items } = await billingService.listPayments({ status, limit: 1000 });
  return items.map((p) => ({
    User: p.userId?.name || 'Unknown',
    Email: p.userId?.email || '',
    Course: p.courseId?.title || '',
    Amount: p.amount,
    Currency: p.currency,
    Status: p.status,
    Provider: p.provider,
    Date: p.createdAt.toISOString().slice(0, 10)
  }));
}

function toExcelBuffer(rows, sheetName = 'Report') {
  return jsonToExcelBuffer(rows, sheetName);
}

module.exports = { getCoursePerformanceReport, getRevenueReport, getPaymentsReport, toExcelBuffer };
