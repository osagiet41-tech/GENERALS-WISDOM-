const crypto = require('crypto');
const path = require('path');
const env = require('../config/env');
const ApiError = require('../utils/ApiError');
const { createSigner } = require('../utils/signedUrl');

const Lesson = require('../models/lesson.model');
const Assignment = require('../models/assignment.model');
const LiveClass = require('../models/liveClass.model');
const Submission = require('../models/submission.model');
const { Message, Conversation } = require('../models/messaging.model');
const { Course } = require('../models/course.model');
const accessService = require('./accessService');

/**
 * Access control for files in /uploads.
 *
 * Before the audit `express.static('uploads')` served every file to anyone who knew (or guessed) the URL:
 * paid lesson videos, students' graded submissions and private chat attachments included. Now:
 *   - avatars and course thumbnails are public (they are shown on public pages);
 *   - everything else needs a short-lived HMAC-signed URL, which the API hands out only after checking the caller
 *     is allowed to see the owning lesson / assignment / submission / conversation.
 * Browsers cannot send an Authorization header from <img>, <video> or <iframe>, hence signed URLs.
 */
const PUBLIC_FOLDERS = new Set(['avatars', 'thumbnails']);
const PRIVATE_FOLDERS = new Set(['materials', 'videos', 'pdfs', 'audio', 'images', 'submissions', 'chat']);
const UPLOAD_PATH = /^\/uploads\/([a-z]+)\/([A-Za-z0-9._-]{1,200})$/;

function parseUploadPath(urlPath) {
  if (typeof urlPath !== 'string' || urlPath.length > 300 || urlPath.includes('..')) return null;
  const m = UPLOAD_PATH.exec(urlPath);
  if (!m) return null;
  const [, folder, file] = m;
  if (!PUBLIC_FOLDERS.has(folder) && !PRIVATE_FOLDERS.has(folder)) return null;
  return { folder, file, urlPath, isPublic: PUBLIC_FOLDERS.has(folder) };
}

const signer = createSigner(() => env.security.fileUrlSecret || crypto.createHmac('sha256', env.jwtSecret).update('file-url-signing-v1').digest('hex'));
const signature = (urlPath, userId, exp) => signer.sign(urlPath, userId, exp);
const buildSignedPath = (urlPath, userId, ttl = env.security.fileUrlTtlSeconds, now) => signer.build(urlPath, userId, ttl, now);
const verifySignature = (urlPath, query, now) => signer.verify(urlPath, query, now);

const isTeacherOf = (course, userId) => course.teacherIds.some((id) => id.toString() === userId);
const isEnrolled = (course, userId) => course.enrolledStudentIds.some((id) => id.toString() === userId);

async function assertCourseFileAccess(user, courseId, { published = true } = {}) {
  const course = await Course.findById(courseId);
  if (!course) throw ApiError.notFound('File not found');
  if (user.role === 'admin' || isTeacherOf(course, user.id)) return;
  if (user.role === 'student' && isEnrolled(course, user.id)) {
    if (!published) throw ApiError.notFound('File not found'); // draft content is invisible to students
    await accessService.assertCourseAccess(user.id, course); // paid content: purchase / subscription still required
    return;
  }
  throw ApiError.forbidden('You do not have access to this file');
}

/** Resolves who may see a private file by finding the document that references it. Throws unless `user` is allowed. */
async function authorize(user, urlPath) {
  const parsed = parseUploadPath(urlPath);
  if (!parsed) throw ApiError.badRequest('Invalid file path');
  if (parsed.isPublic) return parsed;
  if (user.role === 'admin') return parsed;

  const p = urlPath;
  switch (parsed.folder) {
    case 'submissions': {
      const sub = await Submission.findOne({ 'files.fileUrl': p }).select('studentId courseId');
      if (!sub) throw ApiError.notFound('File not found');
      if (sub.studentId.toString() === user.id) return parsed;
      const course = await Course.findById(sub.courseId).select('teacherIds');
      if (course && user.role === 'teacher' && isTeacherOf(course, user.id)) return parsed;
      throw ApiError.forbidden('You do not have access to this file');
    }
    case 'chat': {
      const msg = await Message.findOne({ 'attachments.fileUrl': p }).select('conversationId isDeletedForEveryone');
      if (!msg || msg.isDeletedForEveryone) throw ApiError.notFound('File not found');
      const conv = await Conversation.findById(msg.conversationId).select('participantIds');
      if (!conv || !conv.participantIds.some((id) => id.toString() === user.id)) throw ApiError.forbidden('You do not have access to this file');
      return parsed;
    }
    default: {
      const lesson = await Lesson.findOne({
        $or: [{ 'images.url': p }, { 'pdfs.fileUrl': p }, { 'audio.fileUrl': p }, { 'video.fileUrl': p }, { 'attachments.fileUrl': p }]
      }).select('courseId status');
      if (lesson) {
        await assertCourseFileAccess(user, lesson.courseId, { published: lesson.status === 'published' });
        return parsed;
      }
      const assignment = await Assignment.findOne({ 'attachments.fileUrl': p }).select('courseId status');
      if (assignment) {
        await assertCourseFileAccess(user, assignment.courseId, { published: assignment.status === undefined || assignment.status === 'published' });
        return parsed;
      }
      const live = await LiveClass.findOne({ $or: [{ 'sharedMaterials.fileUrl': p }, { 'recording.fileUrl': p }] }).select('courseId');
      if (live) {
        await assertCourseFileAccess(user, live.courseId);
        return parsed;
      }
      throw ApiError.notFound('File not found');
    }
  }
}

/** Signs up to 50 file paths at once. Paths the user may not access are omitted from the result (never an error). */
async function signMany(user, paths) {
  const out = {};
  for (const p of paths.slice(0, 50)) {
    const parsed = parseUploadPath(p);
    if (!parsed) continue;
    if (parsed.isPublic) {
      out[p] = p;
      continue;
    }
    try {
      await authorize(user, p);
      out[p] = buildSignedPath(p, user.id);
    } catch (e) {
      /* not permitted / not found: leave unsigned */
    }
  }
  return out;
}

module.exports = { parseUploadPath, buildSignedPath, verifySignature, authorize, signMany, PUBLIC_FOLDERS, PRIVATE_FOLDERS, signature };
