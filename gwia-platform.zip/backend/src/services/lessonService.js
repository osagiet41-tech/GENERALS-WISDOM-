const fs = require('fs');
const path = require('path');
const Lesson = require('../models/lesson.model');
const ApiError = require('../utils/ApiError');

function unlinkQuiet(fileUrl) {
  fs.unlink(path.join(__dirname, '..', '..', fileUrl.replace(/^\//, '')), () => {});
}

async function validatePrerequisites(courseId, prerequisiteLessonIds = [], excludeLessonId = null) {
  if (prerequisiteLessonIds.length === 0) return;

  if (excludeLessonId && prerequisiteLessonIds.some((id) => id.toString() === excludeLessonId.toString())) {
    throw ApiError.badRequest('A lesson cannot be its own prerequisite');
  }

  const count = await Lesson.countDocuments({ _id: { $in: prerequisiteLessonIds }, courseId });
  if (count !== prerequisiteLessonIds.length) {
    throw ApiError.badRequest('One or more prerequisite lessons do not belong to this course');
  }
}

async function createLesson(course, subjectId, moduleId, teacherId, data) {
  await validatePrerequisites(course._id, data.prerequisiteLessonIds);

  return Lesson.create({
    courseId: course._id,
    subjectId,
    moduleId,
    title: data.title,
    text: data.text || '',
    externalResources: data.externalResources || [],
    prerequisiteLessonIds: data.prerequisiteLessonIds || [],
    order: data.order || 0,
    status: data.status || 'draft',
    createdBy: teacherId
  });
}

async function updateLesson(lesson, updates) {
  if (updates.prerequisiteLessonIds) {
    await validatePrerequisites(lesson.courseId, updates.prerequisiteLessonIds, lesson._id);
  }

  const allowed = ['title', 'text', 'moduleId', 'order', 'status', 'externalResources', 'prerequisiteLessonIds'];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      lesson[field] = updates[field];
    }
  }
  await lesson.save();
  return lesson;
}

async function deleteLesson(lesson) {
  for (const image of lesson.images) unlinkQuiet(image.url);
  for (const pdf of lesson.pdfs) unlinkQuiet(pdf.fileUrl);
  for (const audioItem of lesson.audio) unlinkQuiet(audioItem.fileUrl);
  for (const attachment of lesson.attachments) unlinkQuiet(attachment.fileUrl);
  if (lesson.video?.fileUrl) unlinkQuiet(lesson.video.fileUrl);

  // Lessons that listed this one as a prerequisite would otherwise point at a dangling id.
  await Lesson.updateMany({ prerequisiteLessonIds: lesson._id }, { $pull: { prerequisiteLessonIds: lesson._id } });

  await lesson.deleteOne();
}

async function listLessons(filter) {
  // filter: { courseId } and optionally { subjectId } and/or { moduleId }
  return Lesson.find(filter).sort({ order: 1 });
}

// --- Text ---
async function updateText(lesson, text) {
  lesson.text = text;
  await lesson.save();
  return lesson;
}

// --- Images ---
async function addImage(lesson, file, caption) {
  if (!file) throw ApiError.badRequest('No image file uploaded');
  lesson.images.push({ url: `/uploads/images/${file.filename}`, caption: caption || '' });
  await lesson.save();
  return lesson;
}

async function removeImage(lesson, imageId) {
  const image = lesson.images.id(imageId);
  if (!image) throw ApiError.notFound('Image not found on this lesson');
  unlinkQuiet(image.url);
  image.deleteOne();
  await lesson.save();
  return lesson;
}

// --- PDFs ---
async function addPdf(lesson, file) {
  if (!file) throw ApiError.badRequest('No PDF file uploaded');
  lesson.pdfs.push({ fileName: file.originalname, fileUrl: `/uploads/pdfs/${file.filename}`, mimeType: file.mimetype, size: file.size });
  await lesson.save();
  return lesson;
}

async function removePdf(lesson, pdfId) {
  const pdf = lesson.pdfs.id(pdfId);
  if (!pdf) throw ApiError.notFound('PDF not found on this lesson');
  unlinkQuiet(pdf.fileUrl);
  pdf.deleteOne();
  await lesson.save();
  return lesson;
}

// --- Audio ---
async function addAudio(lesson, file, duration) {
  if (!file) throw ApiError.badRequest('No audio file uploaded');
  lesson.audio.push({
    fileName: file.originalname,
    fileUrl: `/uploads/audio/${file.filename}`,
    mimeType: file.mimetype,
    size: file.size,
    duration: duration || null
  });
  await lesson.save();
  return lesson;
}

async function removeAudio(lesson, audioId) {
  const audioItem = lesson.audio.id(audioId);
  if (!audioItem) throw ApiError.notFound('Audio not found on this lesson');
  unlinkQuiet(audioItem.fileUrl);
  audioItem.deleteOne();
  await lesson.save();
  return lesson;
}

// --- Video ---
async function setVideo(lesson, file, duration) {
  if (!file) throw ApiError.badRequest('No video file uploaded');
  if (lesson.video?.fileUrl) unlinkQuiet(lesson.video.fileUrl);

  lesson.video = {
    fileUrl: `/uploads/videos/${file.filename}`,
    mimeType: file.mimetype,
    size: file.size,
    duration: duration || null
  };
  await lesson.save();
  return lesson;
}

async function removeVideo(lesson) {
  if (lesson.video?.fileUrl) unlinkQuiet(lesson.video.fileUrl);
  lesson.video = { fileUrl: null, mimeType: null, size: null, duration: null };
  await lesson.save();
  return lesson;
}

// --- External resources (links, no file) ---
async function addExternalResource(lesson, { title, url, description }) {
  lesson.externalResources.push({ title, url, description: description || '' });
  await lesson.save();
  return lesson;
}

async function removeExternalResource(lesson, resourceId) {
  const resource = lesson.externalResources.id(resourceId);
  if (!resource) throw ApiError.notFound('External resource not found on this lesson');
  resource.deleteOne();
  await lesson.save();
  return lesson;
}

// --- Attachments (generic downloadable files) ---
async function addAttachment(lesson, file) {
  if (!file) throw ApiError.badRequest('No file uploaded');
  lesson.attachments.push({
    fileName: file.originalname,
    fileUrl: `/uploads/materials/${file.filename}`,
    mimeType: file.mimetype,
    size: file.size
  });
  await lesson.save();
  return lesson;
}

async function removeAttachment(lesson, attachmentId) {
  const attachment = lesson.attachments.id(attachmentId);
  if (!attachment) throw ApiError.notFound('Attachment not found on this lesson');
  unlinkQuiet(attachment.fileUrl);
  attachment.deleteOne();
  await lesson.save();
  return lesson;
}

module.exports = {
  createLesson,
  updateLesson,
  deleteLesson,
  listLessons,
  updateText,
  addImage,
  removeImage,
  addPdf,
  removePdf,
  addAudio,
  removeAudio,
  setVideo,
  removeVideo,
  addExternalResource,
  removeExternalResource,
  addAttachment,
  removeAttachment
};
