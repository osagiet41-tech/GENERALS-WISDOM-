const { Conversation, Message } = require('../models/messaging.model');
const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const presenceService = require('../services/presenceService');

const DELETED_PLACEHOLDER = 'This message was deleted';

function isAllowedPairing(roleA, roleB) {
  if (roleA === 'student' && roleB === 'student') return false;
  if (roleA === 'admin' && roleB === 'admin') return false;
  return true;
}

async function findOrCreateConversation(userId, recipientId, courseId) {
  if (userId === recipientId) {
    throw ApiError.badRequest('You cannot start a conversation with yourself');
  }

  const [user, recipient] = await Promise.all([User.findById(userId), User.findById(recipientId)]);
  if (!recipient) {
    throw ApiError.notFound('Recipient not found');
  }
  if (!isAllowedPairing(user.role, recipient.role)) {
    throw ApiError.forbidden(`Messaging between two ${user.role}s is not supported`);
  }

  let conversation = await Conversation.findOne({
    participantIds: { $all: [userId, recipientId], $size: 2 },
    courseId: courseId || null
  });

  if (!conversation) {
    conversation = await Conversation.create({
      participantIds: [userId, recipientId],
      participantRoles: [user.role, recipient.role],
      courseId: courseId || null
    });
  }

  return conversation;
}

async function getConversationById(conversationId) {
  const conversation = await Conversation.findById(conversationId);
  if (!conversation) {
    throw ApiError.notFound('Conversation not found');
  }
  return conversation;
}

function assertParticipant(conversation, userId) {
  const isParticipant = conversation.participantIds.some((id) => id.toString() === userId.toString());
  if (!isParticipant) {
    throw ApiError.forbidden('You are not a participant in this conversation');
  }
}

async function sendMessage(conversationId, senderId, { text, attachments }) {
  const conversation = await getConversationById(conversationId);
  assertParticipant(conversation, senderId);

  if ((!text || !text.trim()) && (!attachments || attachments.length === 0)) {
    throw ApiError.badRequest('A message must contain text or at least one attachment');
  }

  const message = await Message.create({
    conversationId,
    senderId,
    text: text ? text.trim() : '',
    attachments: attachments || [],
    readBy: [senderId]
  });

  const preview = message.text || (message.attachments.length > 0 ? `[${message.attachments[0].kind}]` : '');
  conversation.lastMessageAt = new Date();
  conversation.lastMessagePreview = preview.slice(0, 200);
  await conversation.save();

  return message;
}

async function listConversationsForUser(userId) {
  const conversations = await Conversation.find({ participantIds: userId })
    .populate('participantIds', 'name email profile.avatarUrl role')
    .sort({ lastMessageAt: -1 });

  const results = await Promise.all(
    conversations.map(async (conversation) => {
      const partner = conversation.participantIds.find((p) => p._id.toString() !== userId.toString());
      const unreadCount = await Message.countDocuments({
        conversationId: conversation._id,
        readBy: { $ne: userId },
        senderId: { $ne: userId },
        deletedFor: { $ne: userId }
      });

      return {
        conversationId: conversation._id,
        partner: partner
          ? {
              id: partner._id,
              name: partner.name,
              role: partner.role,
              avatarUrl: partner.profile?.avatarUrl || null,
              ...presenceService.getStatus(partner._id)
            }
          : null,
        courseId: conversation.courseId,
        lastMessageAt: conversation.lastMessageAt,
        lastMessagePreview: conversation.lastMessagePreview,
        unreadCount
      };
    })
  );

  return results;
}

function serializeMessage(message, userId) {
  const isDeletedForUser = message.deletedFor.some((id) => id.toString() === userId.toString());
  if (isDeletedForUser) return null;

  const base = {
    id: message._id,
    conversationId: message.conversationId,
    senderId: message.senderId,
    createdAt: message.createdAt,
    readBy: message.readBy,
    isDeletedForEveryone: message.isDeletedForEveryone
  };

  if (message.isDeletedForEveryone) {
    return { ...base, text: DELETED_PLACEHOLDER, attachments: [] };
  }
  return { ...base, text: message.text, attachments: message.attachments };
}

async function listMessages(conversationId, userId, { before, limit = 30 } = {}) {
  const conversation = await getConversationById(conversationId);
  assertParticipant(conversation, userId);

  const filter = { conversationId };
  if (before) {
    const cursorMessage = await Message.findById(before);
    if (cursorMessage) {
      filter.createdAt = { $lt: cursorMessage.createdAt };
    }
  }

  const pageSize = Math.min(Math.max(Number(limit) || 30, 1), 100);
  const page = await Message.find(filter)
    .sort({ createdAt: -1 })
    .limit(pageSize + 1);

  const hasMore = page.length > pageSize;
  const trimmed = page.slice(0, pageSize).reverse();

  return {
    messages: trimmed.map((m) => serializeMessage(m, userId)).filter(Boolean),
    hasMore,
    nextCursor: hasMore ? trimmed[0]._id : null
  };
}

async function markAsRead(conversationId, userId, messageIds) {
  const conversation = await getConversationById(conversationId);
  assertParticipant(conversation, userId);

  const filter = { conversationId, senderId: { $ne: userId }, readBy: { $ne: userId } };
  if (messageIds && messageIds.length > 0) {
    filter._id = { $in: messageIds };
  }

  const result = await Message.updateMany(filter, { $addToSet: { readBy: userId } });
  const idFilter = Object.prototype.hasOwnProperty.call(filter, '_id')
    ? { _id: filter._id }
    : { conversationId, readBy: userId };
  const updatedIds = await Message.find(idFilter, '_id').limit(200);

  return { matched: result.modifiedCount ?? result.nModified ?? 0, messageIds: updatedIds.map((m) => m._id) };
}

async function deleteMessage(messageId, userId, { forEveryone }) {
  const message = await Message.findById(messageId);
  if (!message) {
    throw ApiError.notFound('Message not found');
  }

  const conversation = await getConversationById(message.conversationId);
  assertParticipant(conversation, userId);

  if (forEveryone) {
    if (message.senderId.toString() !== userId.toString()) {
      throw ApiError.forbidden('Only the sender can delete a message for everyone');
    }
    message.isDeletedForEveryone = true;
    message.text = '';
    message.attachments = [];
    message.deletedAt = new Date();
  } else {
    if (!message.deletedFor.some((id) => id.toString() === userId.toString())) {
      message.deletedFor.push(userId);
    }
  }

  await message.save();
  return message;
}

async function searchMessages(userId, { query, conversationId, limit = 50 }) {
  let conversationIds;

  if (conversationId) {
    const conversation = await getConversationById(conversationId);
    assertParticipant(conversation, userId);
    conversationIds = [conversation._id];
  } else {
    const conversations = await Conversation.find({ participantIds: userId }, '_id');
    conversationIds = conversations.map((c) => c._id);
  }

  const results = await Message.find({
    conversationId: { $in: conversationIds },
    deletedFor: { $ne: userId },
    isDeletedForEveryone: false,
    $text: { $search: query }
  })
    .sort({ score: { $meta: 'textScore' } })
    .limit(Math.min(Number(limit) || 50, 100));

  return results.map((m) => serializeMessage(m, userId)).filter(Boolean);
}

module.exports = {
  isAllowedPairing,
  findOrCreateConversation,
  getConversationById,
  assertParticipant,
  sendMessage,
  listConversationsForUser,
  listMessages,
  markAsRead,
  deleteMessage,
  searchMessages
};
