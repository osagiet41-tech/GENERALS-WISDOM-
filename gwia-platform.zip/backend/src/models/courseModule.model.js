const mongoose = require('mongoose');
const { Schema } = mongoose;

const courseModuleSchema = new Schema(
  {
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    subjectId: { type: Schema.Types.ObjectId, ref: 'Subject', required: true, index: true },

    title: { type: String, required: [true, 'Module title is required'], trim: true, maxlength: 200 },
    description: { type: String, trim: true, maxlength: 2000, default: '' },
    order: { type: Number, default: 0 },

    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true }
  },
  { timestamps: true }
);

courseModuleSchema.index({ subjectId: 1, order: 1 });
courseModuleSchema.index({ courseId: 1 });

module.exports = mongoose.model('CourseModule', courseModuleSchema);
