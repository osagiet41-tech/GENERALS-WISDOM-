const ApiError = require('../utils/ApiError');

/**
 * Restricts a route to the given list of roles. Must run after
 * authMiddleware, since it reads req.user.role.
 *
 * This is a strict allow-list, NOT a hierarchy: admins are not
 * automatically granted teacher/student-only routes, and teachers are
 * not automatically granted admin routes. Each route explicitly lists
 * every role permitted to access it, e.g.:
 *
 *   router.get('/admin/users', authMiddleware, roleMiddleware('admin'), ctrl.listUsers);
 *   router.get('/courses', authMiddleware, roleMiddleware('admin', 'teacher'), ctrl.createCourse);
 *   router.get('/submissions/mine', authMiddleware, roleMiddleware('student'), ctrl.mySubmissions);
 *
 * To support additional roles later (e.g. 'parent', 'ta'), simply add
 * them to the allow-list of the routes they should reach — no change
 * needed here.
 */
function roleMiddleware(...allowedRoles) {
  const normalizedAllowedRoles = allowedRoles.map((r) => r.toLowerCase());

  return (req, res, next) => {
    if (!req.user) {
      return next(ApiError.unauthorized('Authentication required'));
    }

    if (!normalizedAllowedRoles.includes(req.user.role)) {
      return next(
        ApiError.forbidden(
          `Access denied: role '${req.user.role}' is not permitted to access this resource`
        )
      );
    }

    next();
  };
}

/** Convenience shorthand for admin-only routes. */
const requireAdmin = roleMiddleware('admin');

/** Convenience shorthand for routes shared by admins and teachers. */
const requireTeacherOrAdmin = roleMiddleware('admin', 'teacher');

/** Convenience shorthand for student-only routes. */
const requireStudent = roleMiddleware('student');

/**
 * Ensures a user can only act on their own resource (e.g. their own
 * profile, their own submission) unless they are an admin. Compares
 * req.user.id against a resource owner id resolved from the request.
 *
 * Usage: router.put('/users/:id', authMiddleware,
 *          requireSelfOrAdmin((req) => req.params.id), ctrl.update);
 */
function requireSelfOrAdmin(resolveOwnerId) {
  return (req, res, next) => {
    if (!req.user) {
      return next(ApiError.unauthorized('Authentication required'));
    }

    if (req.user.role === 'admin') {
      return next();
    }

    const ownerId = resolveOwnerId(req);
    if (ownerId !== req.user.id) {
      return next(ApiError.forbidden('You may only access your own resource'));
    }

    next();
  };
}

module.exports = {
  roleMiddleware,
  requireAdmin,
  requireTeacherOrAdmin,
  requireStudent,
  requireSelfOrAdmin
};
