const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { render, base } = require('./helpers/sampleCertificates');
const { parseTtf } = require('./helpers/fakePdfDoc');
const signatureStore = require('../src/services/certificates/signatureStore');
const { formatDate } = require('../src/services/certificates/renderer');

const cases = {
  standard: {},
  yoruba_long_two_signers: {
    studentName: 'Ọláòkúnṣẹ́ Adébáyọ̀ Ṣọlá-Ẹ̀gbẹ́yẹmí',
    courseTitle: 'Advanced Data Structures, Algorithms and Complexity Analysis for Modern Software Engineers',
    finalScorePercent: 87,
    instructors: [{ name: 'Dr. Ngozi Ọbiọ́ma-Adéwálé' }, { name: 'Mr. Osagie Thomas' }],
    signatory: { name: 'Mrs. Funmilayo Adeyemi', title: 'Principal' }
  },
  extreme_name: {
    studentName: 'Maximilian Oluwaseyi Chukwuebuka Abdulrahman Bello-Nwachukwu Junior',
    institutionName: 'Generals Wisdom International Academy of Science, Technology and Vocational Studies'
  },
  extreme_name_and_title: {
    studentName: 'Maximilian Oluwaseyi Chukwuebuka Abdulrahman Bello-Nwachukwu Junior',
    courseTitle: 'Professional Certificate in Advanced Cybersecurity Operations, Threat Intelligence and Incident Response',
    instructors: [{ name: 'Dr. Ngozi Ọbiọ́ma-Adéwálé' }, { name: 'Mr. Osagie Thomas' }]
  },
  single_unbroken_word: { studentName: 'Pneumonoultramicroscopicsilicovolcanoconiosisaaaaaaaaaaaaaaaa', courseTitle: 'X' },
  no_instructors: { instructors: [] }
};

for (const [name, overrides] of Object.entries(cases)) {
  test(`layout: "${name}" stays inside the border and nothing overlaps`, () => {
    const doc = render(overrides);
    const { width: W, height: H } = doc.page;
    for (const t of doc.texts) {
      assert.ok(t.x >= 40 && t.x + t.width <= W - 40, `"${t.str.slice(0, 30)}…" leaves the page horizontally (x=${t.x.toFixed(1)}, w=${t.width.toFixed(1)})`);
      assert.ok(t.top >= 36 && t.bottom <= H - 36, `"${t.str.slice(0, 30)}…" leaves the page vertically`);
    }
    // No two text boxes may overlap (tiny tolerance for rounding).
    const eps = 1;
    for (let i = 0; i < doc.texts.length; i += 1) {
      for (let j = i + 1; j < doc.texts.length; j += 1) {
        const a = doc.texts[i];
        const b = doc.texts[j];
        const overlap = a.x < b.x + b.width - eps && b.x < a.x + a.width - eps && a.top < b.bottom - eps && b.top < a.bottom - eps;
        assert.ok(!overlap, `"${a.str.slice(0, 25)}…" overlaps "${b.str.slice(0, 25)}…"`);
      }
    }
  });
}

test('certificate carries every required field', () => {
  const doc = render({ finalScorePercent: 91 });
  const all = doc.texts.map((t) => t.str).join('\n');
  for (const needle of [base.studentName, base.courseTitle, base.institutionName.toUpperCase(), 'Completed on 9 October 2026', base.certificateId, base.verifyUrl, 'Mr. Osagie Thomas', 'Course Instructor', 'Final score 91%']) {
    assert.ok(all.includes(needle), `missing on certificate: ${needle}`);
  }
});

test('typed-name signature is the fallback; an uploaded image replaces it', () => {
  const noImg = render({ instructors: [{ name: 'Mr. Osagie Thomas' }] });
  assert.equal(noImg.ops.filter((o) => o.type === 'image').length, 0);
  assert.ok(noImg.texts.filter((t) => t.str === 'Mr. Osagie Thomas').length >= 2); // script-style + printed name
  const withImg = render({ instructors: [{ name: 'Mr. Osagie Thomas' }] }, { instructorImages: [Buffer.from('x')] });
  assert.equal(withImg.ops.filter((o) => o.type === 'image').length, 1);
  assert.equal(withImg.texts.filter((t) => t.str === 'Mr. Osagie Thomas').length, 1);
});

test('score appears only when provided (courses can hide it)', () => {
  assert.ok(!render().texts.some((t) => t.str.includes('Final score')));
});

test('bundled font covers Yoruba, Igbo and Hausa letters', () => {
  const font = parseTtf(path.join(__dirname, '..', 'assets', 'fonts', 'DejaVuSerif-BoldItalic.ttf'));
  for (const ch of 'ẹọṣẸỌṢàáèéìíòóùúńǹẹ́ọ́ɓɗƙŋƴ') assert.ok(font.hasGlyph(ch.codePointAt(0)), `no glyph for ${ch}`);
});

test('date formatting is timezone-stable', () => {
  assert.equal(formatDate(new Date('2026-12-31T23:30:00Z')), '31 December 2026');
});

test('signature store: sniffs real bytes, refuses path tricks', () => {
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(10)]);
  assert.equal(signatureStore.detectType(png), 'png');
  assert.equal(signatureStore.detectType(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0])), 'jpg');
  assert.equal(signatureStore.detectType(Buffer.from('<svg onload=alert(1)>')), null);
  assert.equal(signatureStore.detectType(Buffer.from('GIF89a')), null);
  assert.throws(() => signatureStore.save('u1', Buffer.from('<?php system($_GET[0]);')), /PNG or JPEG/);
  assert.throws(() => signatureStore.save('u1', Buffer.alloc(600 * 1024, 0xff)), /500 KB/);
  for (const bad of ['../../.env', '..\\x.png', '/etc/passwd', 'a/b.png', '', null, undefined]) assert.equal(signatureStore.read(bad), null);
});
