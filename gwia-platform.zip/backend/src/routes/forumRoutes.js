const express = require('express');
const controller = require('../controllers/forumController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { verifyCourseForumAccess, verifyPostAccess, verifyReportAccess } = require('../middleware/forumAccess.middleware');
const {
  createPostValidator,
  editPostValidator,
  createReplyValidator,
  reportPostValidator,
  hidePostValidator,
  reviewReportValidator
} = require('../validators/forumValidator');

const courseRouter = express.Router({ mergeParams: true });
courseRouter.use(authMiddleware, verifyCourseForumAccess());

courseRouter.get('/posts', controller.listPosts);
courseRouter.post('/posts', validate(createPostValidator), controller.createPost);
courseRouter.get('/search', controller.searchPosts);
courseRouter.get('/reports', controller.listReports);

const postRouter = express.Router();
postRouter.use(authMiddleware);

postRouter.get('/:id', verifyPostAccess('id'), controller.getPost);
postRouter.put('/:id', verifyPostAccess('id'), validate(editPostValidator), controller.editPost);
postRouter.delete('/:id', verifyPostAccess('id'), controller.deletePost);

postRouter.get('/:id/replies', verifyPostAccess('id'), controller.listReplies);
postRouter.post('/:id/replies', verifyPostAccess('id'), validate(createReplyValidator), controller.createReply);

postRouter.post('/:id/like', verifyPostAccess('id'), controller.toggleLike);
postRouter.post('/:id/report', verifyPostAccess('id'), validate(reportPostValidator), controller.reportPost);

postRouter.post('/:id/pin', verifyPostAccess('id'), controller.pinPost);
postRouter.post('/:id/unpin', verifyPostAccess('id'), controller.unpinPost);
postRouter.post('/:id/lock', verifyPostAccess('id'), controller.lockPost);
postRouter.post('/:id/unlock', verifyPostAccess('id'), controller.unlockPost);
postRouter.post('/:id/hide', verifyPostAccess('id'), validate(hidePostValidator), controller.hidePost);
postRouter.post('/:id/unhide', verifyPostAccess('id'), controller.unhidePost);

const reportRouter = express.Router();
reportRouter.use(authMiddleware);
reportRouter.put(
  '/:reportId/review',
  verifyReportAccess('reportId'),
  validate(reviewReportValidator),
  controller.reviewReport
);

module.exports = { courseRouter, postRouter, reportRouter };
