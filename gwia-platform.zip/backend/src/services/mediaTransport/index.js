const MeshSignalingAdapter = require('./MeshSignalingAdapter');
const SfuAdapterStub = require('./SfuAdapterStub');

const MEDIA_MODE = process.env.MEDIA_MODE || 'mesh';

const adapters = {
  mesh: () => new MeshSignalingAdapter(),
  sfu: () => new SfuAdapterStub()
};

const activeAdapter = (adapters[MEDIA_MODE] || adapters.mesh)();

module.exports = activeAdapter;
