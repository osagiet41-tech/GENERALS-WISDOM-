/**
 * Integration-test harness: boots the real Express app against an in-memory MongoDB.
 * Requires dev dependencies:  npm i -D supertest mongodb-memory-server   (first run downloads a MongoDB binary).
 * When they are missing, every integration test is skipped with a clear reason instead of failing.
 */
let supertest;
let MongoMemoryServer;
let missing = null;
try {
  supertest = require('supertest');
  ({ MongoMemoryServer } = require('mongodb-memory-server'));
  require('mongoose');
  require('express');
} catch (e) {
  missing = e.message.split('\n')[0];
}

const PASSWORD = 'Str0ng!Passw0rd#1';

async function boot() {
  Object.assign(process.env, {
    NODE_ENV: 'test',
    JWT_SECRET: 'test-access-secret-0123456789-0123456789-abcdef',
    JWT_REFRESH_SECRET: 'test-refresh-secret-0123456789-0123456789-xyz9',
    JWT_EXPIRES_IN: '15m',
    EMAIL_HOST: '127.0.0.1',
    EMAIL_PORT: '1', // connection refused immediately: e-mail sending fails fast and is swallowed by the app
    EMAIL_USER: 'test',
    EMAIL_PASSWORD: 'test',
    CLIENT_URL: 'http://localhost:3000',
    RATE_LIMIT_MAX: '100000',
    LOGIN_RATE_LIMIT_MAX: '100000'
  });
  const mongod = await MongoMemoryServer.create();
  process.env.MONGODB_URI = mongod.getUri('gwia_test');

  const mongoose = require('mongoose');
  await mongoose.connect(process.env.MONGODB_URI);
  const app = require('../../src/app');
  const User = require('../../src/models/User');
  const bcrypt = require('bcryptjs');
  const request = supertest(app);
  let seq = 0;

  async function makeUser(role = 'student', overrides = {}) {
    seq += 1;
    return User.create({
      name: `${role} ${seq}`,
      email: `${role}${seq}-${Date.now()}@example.com`,
      passwordHash: await bcrypt.hash(PASSWORD, 4),
      role,
      status: 'active',
      isEmailVerified: true,
      ...overrides
    });
  }

  async function login(user) {
    const res = await request.post('/api/auth/login').send({ email: user.email, password: PASSWORD });
    if (res.status !== 200) throw new Error(`login failed (${res.status}): ${JSON.stringify(res.body)}`);
    return { accessToken: res.body.data.accessToken, refreshToken: res.body.data.refreshToken, user: res.body.data.user };
  }

  const as = (token) => ({
    get: (url) => request.get(url).set('Authorization', `Bearer ${token}`),
    post: (url) => request.post(url).set('Authorization', `Bearer ${token}`),
    put: (url) => request.put(url).set('Authorization', `Bearer ${token}`),
    delete: (url) => request.delete(url).set('Authorization', `Bearer ${token}`)
  });

  async function actor(role) {
    const user = await makeUser(role);
    const tokens = await login(user);
    return { user, ...tokens, api: as(tokens.accessToken) };
  }

  async function close() {
    await mongoose.disconnect();
    await mongod.stop();
  }

  return { app, request, mongoose, makeUser, login, actor, as, close, PASSWORD };
}

/** `test(name, fn)` wrapper that skips when the integration dependencies are not installed. */
function itest(testFn, name, fn) {
  return testFn(name, { skip: missing ? `integration dependencies not installed (${missing})` : false }, fn);
}

module.exports = { boot, itest, missing, PASSWORD };
