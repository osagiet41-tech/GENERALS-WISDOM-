const { body } = require('express-validator');

const markAttendanceValidator = [
  body('sessionDate').isISO8601().withMessage('sessionDate must be a valid date'),
  body('liveClassId').optional().isMongoId(),
  body('records').isArray({ min: 1 }).withMessage('At least one attendance record is required'),
  body('records.*.studentId').isMongoId().withMessage('Each record must include a valid studentId'),
  body('records.*.status').isIn(['present', 'absent', 'late', 'excused']).withMessage('Invalid attendance status'),
  body('records.*.note').optional().isString().isLength({ max: 500 })
];

const updateRecordValidator = [
  body('status').isIn(['present', 'absent', 'late', 'excused']).withMessage('Invalid attendance status'),
  body('note').optional().isString().isLength({ max: 500 })
];

module.exports = { markAttendanceValidator, updateRecordValidator };
