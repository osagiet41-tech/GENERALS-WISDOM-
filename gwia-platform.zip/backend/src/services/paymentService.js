const crypto = require('crypto');
const env = require('../config/env');
const { Payment, WebhookEvent } = require('../models/billing.model');
const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const logger = require('../utils/logger');
const { fromMinor } = require('../utils/money');
const pricingService = require('./pricingService');
const discountService = require('./discountService');
const accessService = require('./accessService');
const fulfillmentService = require('./fulfillmentService');
const { getProvider, chooseProvider } = require('./payments/providers');

const GATEWAYS = ['paystack', 'flutterwave'];
const REUSE_WINDOW_MS = 30 * 60 * 1000;

function newReference(prefix = 'GW') {
  // Hyphens only: Paystack rejects underscores in references. 96 bits of randomness, not guessable.
  return `${prefix}-${crypto.randomBytes(12).toString('hex')}`;
}

/* ------------------------------------------------------------------ */
/* Checkout                                                            */
/* ------------------------------------------------------------------ */

async function createCheckout({ user, purpose, courseId, planCode, currency, provider: requestedProvider, discountCode, ip }) {
  const q = await pricingService.quote({ userId: user.id, purpose, courseId, planCode, currency, discountCode });

  if (purpose === 'course') {
    const access = await accessService.getCourseAccess(user.id, q.course);
    if (access.granted) {
      throw ApiError.conflict(
        access.via === 'purchase' || access.via === 'granted'
          ? 'You already have access to this course'
          : 'This course is already included in your current subscription'
      );
    }
  }

  const isFree = q.finalMinor === 0;
  const gateway = isFree ? null : chooseProvider(q.currency, requestedProvider);

  // Double-click / retry protection: reuse a recent identical pending checkout instead of creating another.
  if (!isFree) {
    const reusable = await Payment.findOne({
      userId: user.id,
      purpose,
      ...(purpose === 'course' ? { courseId: q.course._id } : { planCode: q.plan.code }),
      currency: q.currency,
      amountMinor: q.finalMinor,
      discountCode: q.discount ? q.discount.code : null,
      provider: gateway.name,
      status: 'pending',
      checkoutUrl: { $ne: null },
      checkoutExpiresAt: { $gt: new Date() }
    });
    if (reusable) return { payment: reusable, reused: true };
  }

  const reference = newReference(isFree ? 'FREE' : 'GW');
  const payment = await Payment.create({
    userId: user.id,
    purpose,
    courseId: purpose === 'course' ? q.course._id : null,
    planId: purpose === 'subscription' ? q.plan._id : null,
    planCode: purpose === 'subscription' ? q.plan.code : null,
    billingCycle: purpose === 'subscription' ? q.plan.billingCycle : null,
    periodMonths: purpose === 'subscription' ? q.plan.periodMonths : null,
    description: q.description,
    amount: fromMinor(q.finalMinor, q.currency),
    amountMinor: q.finalMinor,
    originalAmountMinor: q.originalMinor,
    discountAmountMinor: q.discountMinor,
    discountCode: q.discount ? q.discount.code : null,
    discountCodeId: q.discount ? q.discount._id : null,
    currency: q.currency,
    provider: isFree ? 'free' : gateway.name,
    reference,
    status: 'pending',
    customerEmail: user.email,
    ipAddress: ip || null
  });

  if (q.discount) {
    try {
      await discountService.reserve(q.discount._id);
      await discountService.attachToPayment({
        codeId: q.discount._id,
        userId: user.id,
        paymentId: payment._id,
        amountMinor: q.discountMinor,
        currency: q.currency
      });
    } catch (err) {
      await Payment.updateOne({ _id: payment._id, status: 'pending' }, { $set: { status: 'failed', failureReason: 'discount_unavailable' } });
      throw err;
    }
  }

  if (isFree) {
    // The total was computed on the server (a 100% discount or a zero-price plan): nothing to charge.
    await settleSuccess(payment, { providerTransactionId: null, channel: 'none', paidAt: new Date(), raw: { free: true } }, { skipAmountCheck: true });
    return { payment: await Payment.findById(payment._id), reused: false };
  }

  try {
    const callbackUrl = `${env.clientUrl.replace(/\/$/, '')}${env.payments.callbackPath}`;
    const init = await gateway.initialize({
      reference,
      amountMinor: q.finalMinor,
      currency: q.currency,
      email: user.email,
      name: user.name,
      phone: user.profile?.phone || null,
      callbackUrl,
      description: q.description,
      business: env.payments.business,
      metadata: { paymentId: String(payment._id), userId: user.id, purpose }
    });
    payment.checkoutUrl = init.checkoutUrl;
    payment.checkoutExpiresAt = new Date(Date.now() + REUSE_WINDOW_MS);
    await payment.save();
  } catch (err) {
    await failPayment(payment, 'init_failed');
    throw err;
  }
  return { payment, reused: false };
}

/* ------------------------------------------------------------------ */
/* Settlement (the only code path that turns a payment into "completed")*/
/* ------------------------------------------------------------------ */

async function failPayment(payment, reason, { needsReview = false } = {}) {
  const failed = await Payment.findOneAndUpdate(
    { _id: payment._id, status: 'pending' },
    { $set: { status: 'failed', failureReason: reason, needsReview } },
    { new: true }
  );
  if (failed) await discountService.release(payment._id).catch((e) => logger.error(`Discount release failed: ${e.message}`));
  return failed || Payment.findById(payment._id);
}

/**
 * `verification` MUST come from the gateway's server API (provider.verify) — never from a request body.
 * The atomic claim (status pending|failed -> completed) means concurrent callers settle a payment once.
 */
async function settleSuccess(payment, verification, { skipAmountCheck = false } = {}) {
  if (!skipAmountCheck) {
    if (verification.amountMinor !== payment.amountMinor || verification.currency !== payment.currency) {
      logger.error(
        `Payment ${payment.reference}: amount mismatch (expected ${payment.amountMinor} ${payment.currency}, ` +
          `gateway reported ${verification.amountMinor} ${verification.currency})`
      );
      return failPayment(payment, `amount_mismatch: expected ${payment.amountMinor} ${payment.currency}, got ${verification.amountMinor} ${verification.currency}`, {
        needsReview: true
      });
    }
  }

  let claimed;
  try {
    claimed = await Payment.findOneAndUpdate(
      // 'failed' is allowed so a late success (e.g. marked abandoned, paid afterwards) is never lost;
      // 'refunded' and 'completed' are final.
      { _id: payment._id, status: { $in: ['pending', 'failed'] } },
      {
        $set: {
          status: 'completed',
          paidAt: verification.paidAt || new Date(),
          verifiedAt: new Date(),
          providerReference: verification.providerTransactionId,
          channel: verification.channel || null,
          customerEmail: payment.customerEmail || verification.customerEmail || null,
          failureReason: null,
          needsReview: false,
          providerPayload: verification.raw || null,
          'fulfillment.status': 'pending'
        }
      },
      { new: true }
    );
  } catch (err) {
    if (err.code === 11000) {
      // This gateway transaction id is already attached to a different payment: replay/fraud signal.
      await Payment.updateOne({ _id: payment._id }, { $set: { needsReview: true, failureReason: 'duplicate_provider_transaction' } });
      throw ApiError.conflict('This transaction has already been used');
    }
    throw err;
  }

  await fulfillmentService.ensureFulfilled(payment._id); // idempotent; also runs when we lost the claim
  return claimed || Payment.findById(payment._id);
}

/**
 * Verifies a payment with the gateway (server-to-server) and settles it if — and only if — the gateway
 * confirms success for the exact reference, amount and currency we recorded.
 * Callers: webhook handler, browser "verify" endpoint, admin re-verify, reconciliation job.
 */
async function confirmPayment(reference, { transactionIdHint = null } = {}) {
  const payment = await Payment.findOne({ reference });
  if (!payment) return null;

  if (payment.status === 'completed') {
    await fulfillmentService.ensureFulfilled(payment._id);
    return Payment.findById(payment._id);
  }
  if (!['pending', 'failed'].includes(payment.status)) return payment;
  if (!GATEWAYS.includes(payment.provider)) return payment;

  const provider = getProvider(payment.provider);
  await Payment.updateOne({ _id: payment._id }, { $set: { lastVerifyAttemptAt: new Date() } });
  const v = await provider.verify({ reference, transactionIdHint });

  if (v.state === 'success') return settleSuccess(payment, v);
  if (v.state === 'failed' && payment.status === 'pending') return failPayment(payment, 'declined_by_provider');
  return payment; // pending / not_found: customer hasn't finished yet
}

async function markRefunded(payment) {
  const refunded = await Payment.findOneAndUpdate(
    { _id: payment._id, status: 'completed' },
    { $set: { status: 'refunded', refundedAt: new Date() } },
    { new: true }
  );
  if (refunded) await fulfillmentService.revoke(refunded);
  return refunded;
}

/* ------------------------------------------------------------------ */
/* Webhooks                                                            */
/* ------------------------------------------------------------------ */

/**
 * Authenticates the request (signature), de-duplicates the delivery, then treats the payload only as a
 * TRIGGER: success is decided by confirmPayment() calling the gateway API, not by the webhook body.
 * Returns { outcome }. Throws 401 for a bad signature and re-throws processing errors so the HTTP layer
 * answers 5xx and the gateway retries.
 */
async function handleWebhook(providerName, rawBody, headers) {
  const provider = getProvider(providerName);
  if (!provider.verifyWebhook({ rawBody, headers })) throw ApiError.unauthorized('Invalid webhook signature');

  let body;
  try {
    body = JSON.parse(rawBody.toString('utf8'));
  } catch (e) {
    throw ApiError.badRequest('Webhook body is not valid JSON');
  }

  const evt = provider.parseWebhook(body);
  if (evt.kind === 'ignore' || !evt.reference) return { outcome: 'ignored' };

  let record;
  try {
    record = await WebhookEvent.create({
      provider: provider.name,
      eventKey: evt.eventKey,
      eventType: evt.eventType,
      reference: evt.reference
    });
  } catch (err) {
    if (err.code !== 11000) throw err;
    record = await WebhookEvent.findOneAndUpdate(
      { provider: provider.name, eventKey: evt.eventKey, status: { $in: ['received', 'failed'] } },
      { $inc: { attempts: 1 } },
      { new: true }
    );
    if (!record) return { outcome: 'duplicate' }; // already processed/ignored: acknowledge, do nothing
  }

  try {
    let outcome = 'processed';
    if (evt.kind === 'payment') {
      const payment = await confirmPayment(evt.reference, { transactionIdHint: evt.transactionId });
      if (!payment) outcome = 'ignored'; // not one of our references (e.g. shared gateway account)
    } else if (evt.kind === 'refund') {
      const payment = await Payment.findOne({ reference: evt.reference });
      if (!payment) outcome = 'ignored';
      else if (payment.status === 'completed') await markRefunded(payment);
    }
    await WebhookEvent.updateOne(
      { _id: record._id },
      { $set: { status: outcome === 'ignored' ? 'ignored' : 'processed', processedAt: new Date(), error: null } }
    );
    return { outcome };
  } catch (err) {
    await WebhookEvent.updateOne({ _id: record._id }, { $set: { status: 'failed', error: String(err.message).slice(0, 300) } });
    throw err;
  }
}

/* ------------------------------------------------------------------ */
/* Background reconciliation (missed webhooks, crashes)                */
/* ------------------------------------------------------------------ */

async function reconcilePendingPayments({ limit = 40 } = {}) {
  const now = Date.now();
  const pending = await Payment.find({
    status: 'pending',
    provider: { $in: GATEWAYS },
    createdAt: { $lt: new Date(now - 5 * 60 * 1000), $gt: new Date(now - 14 * 24 * 60 * 60 * 1000) },
    $or: [{ lastVerifyAttemptAt: null }, { lastVerifyAttemptAt: { $lt: new Date(now - 10 * 60 * 1000) } }]
  })
    .sort({ createdAt: 1 })
    .limit(limit);

  let settled = 0;
  for (const p of pending) {
    try {
      const result = await confirmPayment(p.reference);
      if (result?.status === 'completed') settled += 1;
      else if (result?.status === 'pending' && p.createdAt < new Date(now - env.payments.pendingExpiryHours * 3600 * 1000)) {
        await failPayment(result, 'abandoned');
      }
    } catch (err) {
      logger.error(`Reconcile failed for ${p.reference}: ${err.message}`);
    }
  }
  return { checked: pending.length, settled };
}

async function retryStuckFulfillments({ limit = 50 } = {}) {
  const stuck = await Payment.find({
    status: 'completed',
    'fulfillment.status': { $in: ['pending', 'in_progress'] },
    updatedAt: { $lt: new Date(Date.now() - 2 * 60 * 1000) }
  })
    .limit(limit)
    .select('_id');
  let fixed = 0;
  for (const { _id } of stuck) {
    try {
      if (await fulfillmentService.ensureFulfilled(_id)) fixed += 1;
    } catch (err) {
      logger.error(`Fulfilment retry failed for ${_id}: ${err.message}`);
    }
  }
  return { stuck: stuck.length, fixed };
}

/* ------------------------------------------------------------------ */
/* Reads                                                               */
/* ------------------------------------------------------------------ */

const USER_VISIBLE_SELECT = '-providerPayload -ipAddress -notes -lastVerifyAttemptAt -needsReview -fulfillment.lockedAt -fulfillment.lastError';

async function listForUser(userId, { page = 1, limit = 20, status } = {}) {
  const filter = { userId, purpose: { $ne: null } };
  if (status) filter.status = status;
  const skip = (Number(page) - 1) * Number(limit);
  const [items, total] = await Promise.all([
    Payment.find(filter).select(USER_VISIBLE_SELECT).populate('courseId', 'title').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Payment.countDocuments(filter)
  ]);
  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / Number(limit)) };
}

async function getForUser(userId, idOrReference) {
  const isObjectId = /^[a-f\d]{24}$/i.test(idOrReference);
  const payment = await Payment.findOne({ userId, ...(isObjectId ? { _id: idOrReference } : { reference: idOrReference }) })
    .select(USER_VISIBLE_SELECT)
    .populate('courseId', 'title');
  if (!payment) throw ApiError.notFound('Payment not found');
  return payment;
}

/** Admin-recorded offline payment (bank transfer, cash): the admin is the verifier. Gateway payments can't use this. */
async function settleManually(payment) {
  return settleSuccess(
    payment,
    { providerTransactionId: null, channel: 'manual', paidAt: new Date(), raw: { manual: true } },
    { skipAmountCheck: true }
  );
}

module.exports = {
  newReference,
  settleManually,
  createCheckout,
  confirmPayment,
  failPayment,
  markRefunded,
  handleWebhook,
  reconcilePendingPayments,
  retryStuckFulfillments,
  listForUser,
  getForUser
};
