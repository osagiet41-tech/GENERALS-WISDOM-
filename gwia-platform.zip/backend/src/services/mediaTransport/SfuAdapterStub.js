const MediaTransportAdapter = require('./MediaTransportAdapter');
const ApiError = require('../../utils/ApiError');

/**
 * Placeholder for a real SFU integration (LiveKit, mediasoup, Janus,
 * etc.). Not wired to any actual media server — this file exists so
 * the adapter selection point (MEDIA_MODE=sfu) and the shape of the
 * integration are already in place. To make this real:
 *
 * 1. Provision an SFU server/cloud project and add its credentials to
 *    config/env.js (e.g. LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET).
 * 2. In getConnectionInfo(), call that SFU's server SDK to create/get
 *    the room for this liveClass._id and mint a per-participant access
 *    token (usually a signed JWT scoped to that room + role), then
 *    return { mode: 'sfu', url: <sfu ws/https url>, token }.
 * 3. The frontend swaps its RTCPeerConnection logic for that SFU's
 *    client SDK when it sees mode: 'sfu' in the connection info —
 *    classroom.socket.js's webrtc:signal event simply stops being used
 *    for media (relaySignal below no-ops), since the SFU server routes
 *    media itself instead of peers signaling each other.
 * 4. onParticipantJoined/onParticipantLeft are where you'd sync
 *    server-side room membership with the SFU if it needs that
 *    (many SFUs manage this automatically once a client connects with
 *    a valid token, in which case these can stay no-ops too).
 */
class SfuAdapterStub extends MediaTransportAdapter {
  async getConnectionInfo(liveClass, participant) {
    throw ApiError.internal(
      'SFU media mode is configured but no SFU integration has been implemented yet. Set MEDIA_MODE=mesh, or implement SfuAdapterStub.'
    );
  }

  relaySignal() {
    return false; // SFU handles media routing itself; nothing to relay peer-to-peer
  }
}

module.exports = SfuAdapterStub;
