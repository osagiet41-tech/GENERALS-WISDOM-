const XLSX = require('xlsx');

/**
 * Converts an array of plain objects into an XLSX file buffer.
 * Used for exporting reports, grade sheets, attendance sheets, etc.
 */
function jsonToExcelBuffer(rows, sheetName = 'Sheet1') {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}

/**
 * Parses an uploaded XLSX/CSV file (from disk path) into an array of
 * plain row objects, keyed by header row. Used for bulk imports
 * (e.g. bulk student enrollment, bulk question bank upload).
 */
function excelFileToJson(filePath, sheetIndex = 0) {
  // Spreadsheet parsers are a classic attack surface: no formulas/HTML/styles are parsed and the row count is capped.
  const workbook = XLSX.readFile(filePath, { sheetRows: 5001, cellFormula: false, cellHTML: false, cellStyles: false, cellDates: true });
  const sheetName = workbook.SheetNames[sheetIndex];
  const worksheet = workbook.Sheets[sheetName];
  return XLSX.utils.sheet_to_json(worksheet, { defval: null });
}

module.exports = { jsonToExcelBuffer, excelFileToJson };
