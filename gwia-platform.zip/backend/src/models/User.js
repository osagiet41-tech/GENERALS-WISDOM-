const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const { Schema } = mongoose;

const ROLES = ['admin', 'teacher', 'student'];

const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_DURATION_MS = 30 * 60 * 1000; // 30 minutes

const userSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      maxlength: 120
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Invalid email address']
    },
    passwordHash: {
      type: String,
      required: true,
      select: false
    },
    role: {
      type: String,
      enum: ROLES,
      required: true,
      default: 'student',
      index: true
    },
    institutionId: {
      type: Schema.Types.ObjectId,
      ref: 'Institution',
      default: null,
      index: true
    },
    profile: {
      avatarUrl: { type: String, default: null },
      phone: { type: String, default: null },
      bio: { type: String, default: null },
      // Instructor's signature image (file name in storage/signatures/), printed on certificates
      signatureFile: { type: String, default: null }
    },
    status: {
      type: String,
      enum: ['active', 'suspended', 'pending'],
      default: 'pending'
    },
    isEmailVerified: {
      type: Boolean,
      default: false
    },
    emailVerificationToken: { type: String, select: false },
    emailVerificationExpires: { type: Date, select: false },
    passwordResetToken: { type: String, select: false },
    passwordResetExpires: { type: Date, select: false },
    refreshTokens: {
      type: [String],
      default: [],
      select: false
    },

    // --- Login attempt protection ---
    failedLoginAttempts: {
      type: Number,
      default: 0,
      select: false
    },
    lockUntil: {
      type: Date,
      default: null,
      select: false
    },

    // Set whenever the password changes; access tokens issued before this moment are rejected.
    passwordChangedAt: { type: Date, default: null },

    lastLoginAt: { type: Date, default: null }
  },
  { timestamps: true }
);

userSchema.index({ institutionId: 1, role: 1 });

// --- Virtuals ---
userSchema.virtual('isLocked').get(function isLocked() {
  return !!(this.lockUntil && this.lockUntil.getTime() > Date.now());
});

// --- Instance methods ---
userSchema.methods.comparePassword = async function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.passwordHash);
};

userSchema.methods.registerFailedLogin = async function registerFailedLogin() {
  // If a previous lock has expired, start counting fresh.
  if (this.lockUntil && this.lockUntil.getTime() < Date.now()) {
    this.failedLoginAttempts = 0;
    this.lockUntil = null;
  }

  this.failedLoginAttempts += 1;

  if (this.failedLoginAttempts >= MAX_LOGIN_ATTEMPTS) {
    this.lockUntil = new Date(Date.now() + LOCK_DURATION_MS);
  }

  await this.save();
};

userSchema.methods.registerSuccessfulLogin = async function registerSuccessfulLogin() {
  this.failedLoginAttempts = 0;
  this.lockUntil = null;
  this.lastLoginAt = new Date();
  await this.save();
};

// Defence in depth: even if some code path forgets toSafeObject() or .select(), secrets never serialise.
const SECRET_FIELDS = [
  'passwordHash', 'refreshTokens', 'emailVerificationToken', 'emailVerificationExpires',
  'passwordResetToken', 'passwordResetExpires', 'failedLoginAttempts', 'lockUntil', 'passwordChangedAt'
];
function stripSecrets(doc, ret) {
  for (const f of SECRET_FIELDS) delete ret[f];
  delete ret.__v;
  return ret;
}
userSchema.set('toJSON', { transform: stripSecrets });

userSchema.methods.toSafeObject = function toSafeObject() {
  const obj = this.toObject();
  delete obj.passwordHash;
  delete obj.refreshTokens;
  delete obj.emailVerificationToken;
  delete obj.emailVerificationExpires;
  delete obj.passwordResetToken;
  delete obj.passwordResetExpires;
  delete obj.failedLoginAttempts;
  delete obj.lockUntil;
  delete obj.passwordChangedAt;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
module.exports.ROLES = ROLES;
module.exports.MAX_LOGIN_ATTEMPTS = MAX_LOGIN_ATTEMPTS;
module.exports.LOCK_DURATION_MS = LOCK_DURATION_MS;
