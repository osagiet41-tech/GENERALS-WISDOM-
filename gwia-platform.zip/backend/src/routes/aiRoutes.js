const express = require('express');
const controller = require('../controllers/aiController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { roleMiddleware } = require('../middleware/roleMiddleware');
const { aiLimiter } = require('../middleware/rateLimiter.middleware');
const { TEACHER_VALIDATORS, STUDENT_VALIDATORS } = require('../validators/aiValidator');

const router = express.Router();
router.use(authMiddleware, aiLimiter);

const TEACHER_PATHS = {
  lessonPlan: 'lesson-plan',
  lessonNotes: 'lesson-notes',
  quiz: 'quiz',
  examQuestions: 'exam-questions',
  assessmentQuestions: 'assessment-questions',
  assignment: 'assignment',
  markingGuide: 'marking-guide',
  explainConcept: 'explain-concept',
  revisionMaterials: 'revision-materials',
  summary: 'summary',
  flashcards: 'flashcards',
  teachingActivities: 'teaching-activities',
  learningObjectives: 'learning-objectives'
};

const STUDENT_PATHS = {
  explainConcept: 'explain-concept',
  answerQuestion: 'answer-question',
  stepByStep: 'step-by-step',
  practiceQuestions: 'practice-questions',
  revisionPlan: 'revision-plan',
  summarizeLesson: 'summarize-lesson',
  flashcards: 'flashcards',
  hint: 'hint'
};

const teacherRouter = express.Router();
teacherRouter.use(roleMiddleware('admin', 'teacher'));
for (const [featureKey, urlPath] of Object.entries(TEACHER_PATHS)) {
  const validators = TEACHER_VALIDATORS[featureKey];
  if (!validators) {
    throw new Error(`aiRoutes: no validator registered for teacher feature "${featureKey}"`);
  }
  teacherRouter.post(`/${urlPath}`, validate(validators), controller.createAiHandler('teacher', featureKey));
}

const studentRouter = express.Router();
studentRouter.use(roleMiddleware('student'));
for (const [featureKey, urlPath] of Object.entries(STUDENT_PATHS)) {
  const validators = STUDENT_VALIDATORS[featureKey];
  if (!validators) {
    throw new Error(`aiRoutes: no validator registered for student feature "${featureKey}"`);
  }
  studentRouter.post(`/${urlPath}`, validate(validators), controller.createAiHandler('student', featureKey));
}

router.use('/teacher', teacherRouter);
router.use('/student', studentRouter);
router.get('/usage', controller.getMyUsage);

module.exports = router;
