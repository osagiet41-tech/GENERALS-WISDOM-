const rateLimit = require('express-rate-limit');
const env = require('../config/env');

const apiLimiter = rateLimit({
  windowMs: env.rateLimit.windowMs,
  max: env.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests, please try again later.' }
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many authentication attempts, please try again later.' }
});

// Per (IP + e-mail) login limiter: stops one attacker hammering a single victim account from one address,
// without letting a shared school/NAT IP lock out everybody. (authLimiter above caps the IP as a whole.)
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: env.security.loginRateLimitMax,
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  keyGenerator: (req) => `${req.ip}|${String((req.body && req.body.email) || '').toLowerCase().slice(0, 200)}`,
  message: { success: false, message: 'Too many failed sign-in attempts, please try again later.' }
});

const refreshLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many token refresh requests, please try again later.' }
});

// File uploads are the most expensive writes (disk + bandwidth). Applied once, in app.js, to every multipart request.
const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: env.security.uploadRateLimitMax,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => (req.user ? req.user.id : req.ip),
  message: { success: false, message: 'Too many uploads, please try again later.' }
});

// AI endpoints are expensive (real API cost + latency), so they get their
// own, stricter, per-USER limit rather than sharing the general per-IP
// apiLimiter — two students behind the same NAT/IP shouldn't share one
// budget, and one student shouldn't be able to hammer the AI provider by
// itself either.
const aiLimiter = rateLimit({
  windowMs: env.ai.rateLimit.windowMs,
  max: env.ai.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => (req.user ? req.user.id : req.ip),
  message: { success: false, message: 'Too many AI requests, please slow down and try again shortly.' }
});

// Checkout / verify hit external payment APIs, so they get a per-user limit of their own.
const paymentLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 40,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => (req.user ? req.user.id : req.ip),
  message: { success: false, message: 'Too many payment requests, please slow down and try again shortly.' }
});

// Public certificate verification: generous for genuine checks, tight enough to make guessing IDs pointless.
const verifyLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many verification requests, please try again later.' }
});

module.exports = { apiLimiter, authLimiter, loginLimiter, refreshLimiter, uploadLimiter, aiLimiter, paymentLimiter, verifyLimiter };
