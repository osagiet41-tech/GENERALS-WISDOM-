const env = require('../../../config/env');
const ApiError = require('../../../utils/ApiError');
const { requestJson } = require('../http');
const PaystackProvider = require('./paystack.provider');
const FlutterwaveProvider = require('./flutterwave.provider');

const opts = { timeoutMs: env.payments.httpTimeoutMs };
const registry = {
  paystack: new PaystackProvider(env.payments.paystack, requestJson, opts),
  flutterwave: new FlutterwaveProvider(env.payments.flutterwave, requestJson, opts)
};

function getProvider(name) {
  const p = registry[String(name).toLowerCase()];
  if (!p) throw ApiError.badRequest(`Unknown payment provider "${name}"`);
  return p;
}

function listEnabled() {
  return Object.values(registry).filter((p) => p.isConfigured());
}

/** Picks the gateway for a checkout: explicit choice if valid, otherwise the currency default. */
function chooseProvider(currency, requested) {
  const cur = String(currency).toUpperCase();
  if (requested) {
    const p = getProvider(requested);
    if (!p.isConfigured()) throw new ApiError(503, `${p.name} is not available right now`);
    if (!p.supportsCurrency(cur)) throw ApiError.badRequest(`${p.name} does not support ${cur}`);
    return p;
  }
  const preferredName = env.payments.providerByCurrency[cur] || env.payments.defaultProvider;
  const ordered = [registry[preferredName], ...Object.values(registry)].filter(Boolean);
  const found = ordered.find((p) => p.isConfigured() && p.supportsCurrency(cur));
  if (!found) throw new ApiError(503, `No payment provider is available for ${cur}`);
  return found;
}

module.exports = { getProvider, listEnabled, chooseProvider, registry };
