import { h } from '../../core/dom.js';
import { adminApi } from '../../api/admin.js';
import { pageHead } from '../../ui/page.js';
import { listView } from '../shared/listView.js';
import { fmtDateTime } from '../../core/format.js';

export default async function render() {
  const lv = listView({ searchPlaceholder: 'Search action…', caption: 'Audit log', limit: 25, fetcher: (q) => adminApi.auditLogs(q),
    columns: [{ label: 'When', render: (l) => fmtDateTime(l.createdAt) }, { label: 'Who', render: (l) => l.userId?.name || l.actorName || String(l.userId || '—') }, { label: 'Action', render: (l) => h('code', null, l.action) }, { label: 'Target', render: (l) => `${l.targetType || ''} ${l.targetId || ''}`.trim() || '—' }, { label: 'IP', render: (l) => l.ip || '—' }] });
  return h('div', { class: 'stack' }, pageHead('Audit log', 'Every administrative change, newest first.'), lv.el);
}
