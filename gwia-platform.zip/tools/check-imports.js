#!/usr/bin/env node
/**
 * Static import check for the backend (needs no node_modules and no database):
 *   1. every relative require('./x') must resolve to a real file;
 *   2. every destructured name  const { a, b } = require('./x')  must actually be exported by that module.
 * Third-party packages are replaced by stubs, so this runs anywhere. Exit code 1 on any problem.
 */
const Module = require('module');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..', 'backend');
const stub = () => { const f = function () {}; return new Proxy(f, { get: (t, p) => (p === 'then' || (typeof p === 'string' && p.startsWith('__')) ? undefined : stub()), apply: () => stub(), construct: () => stub() }); };
const express = () => ({ use() {}, get() {}, post() {}, put() {}, delete() {}, set() {}, disable() {}, listen() {} });
express.Router = () => ({ use() {}, get() {}, post() {}, put() {}, delete() {}, patch() {}, route() { return this; }, param() {} });
express.json = express.urlencoded = express.raw = express.static = () => () => {};

const load = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === 'express') return express;
  const rel = request.startsWith('.') || path.isAbsolute(request);
  if (!rel && !Module.builtinModules.includes(request) && !request.startsWith('node:')) return stub();
  return load.apply(this, arguments);
};
Object.assign(process.env, { MONGODB_URI: 'mongodb://x/x', JWT_SECRET: 'x'.repeat(48), JWT_EXPIRES_IN: '15m', EMAIL_HOST: 'x', EMAIL_PORT: '587', EMAIL_USER: 'x', EMAIL_PASSWORD: 'x', CLIENT_URL: 'http://localhost:3000', NODE_ENV: 'test' });

function* walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', 'test', 'uploads', 'logs', 'backups', 'storage', 'assets'].includes(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) yield* walk(full); else if (e.name.endsWith('.js')) yield full;
  }
}

const problems = [];
let checked = 0;
for (const file of walk(root)) {
  // Comments are ignored (they contain example code such as `// require('../x')(io)`).
  const src = fs.readFileSync(file, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  const rel = path.relative(root, file);
  // 1 + 2: destructured requires
  for (const m of src.matchAll(/const\s*\{([^}]+)\}\s*=\s*require\(\s*'(\.[^']+)'\s*\)/g)) {
    checked += 1;
    let target;
    try { target = require.resolve(path.resolve(path.dirname(file), m[2])); } catch { problems.push(`${rel}: cannot resolve '${m[2]}'`); continue; }
    let exported;
    try { exported = require(target); } catch (e) { problems.push(`${rel}: '${m[2]}' fails to load (${e.message.split('\n')[0]})`); continue; }
    for (const raw of m[1].split(',')) {
      const name = raw.split(':')[0].trim();
      if (!name) continue;
      if (exported === undefined || exported === null || !(name in Object(exported))) problems.push(`${rel}: '${name}' is not exported by '${m[2]}'`);
    }
  }
  // plain requires
  for (const m of src.matchAll(/require\(\s*'(\.[^']+)'\s*\)/g)) {
    try { require.resolve(path.resolve(path.dirname(file), m[1])); } catch { problems.push(`${rel}: cannot resolve '${m[1]}'`); }
  }
}
if (problems.length) { [...new Set(problems)].forEach((p) => console.log(`IMPORT PROBLEM: ${p}`)); process.exit(1); }
console.log(`Import check OK: ${checked} destructured imports verified across the backend.`);
