#!/usr/bin/env node
/* Cross-version test runner (Node 18/20/22): node scripts/run-tests.js [unit|integration|all] */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const mode = process.argv[2] || 'all';
const testDir = path.join(__dirname, '..', 'test');
const list = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.endsWith('.test.js')).map((f) => path.join(dir, f)) : []);

const legacy = list(testDir); // original certificate / payment unit tests
const unit = [...legacy, ...list(path.join(testDir, 'unit'))];
const integration = list(path.join(testDir, 'integration'));
const files = mode === 'unit' ? unit : mode === 'integration' ? integration : [...unit, ...integration];

if (files.length === 0) { console.error('No test files found'); process.exit(1); }
const res = spawnSync(process.execPath, ['--test', ...(mode === 'integration' ? ['--test-concurrency=1'] : []), ...files], { stdio: 'inherit', env: { ...process.env, NODE_ENV: 'test' } });
process.exit(res.status === null ? 1 : res.status);
