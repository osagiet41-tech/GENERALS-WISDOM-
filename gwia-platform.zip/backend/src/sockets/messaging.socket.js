const { Conversation } = require('../models/messaging.model');
const messagingService = require('../services/messagingService');
const presenceService = require('../services/presenceService');
const logger = require('../utils/logger');
const { createLimiter, isObjectId } = require('./rateLimit');

const MAX_MESSAGE_LENGTH = 5000;
const allowEvent = createLimiter({ capacity: 30, refillPerSec: 5 });
const allowTyping = createLimiter({ capacity: 10, refillPerSec: 2 });
const BAD_REQUEST = { error: 'Invalid request' };

function conversationRoom(conversationId) {
  return `conversation:${conversationId}`;
}

/**
 * Registers messaging-specific behavior on an already-authenticated
 * socket (auth happens once, centrally, in sockets/index.js). Called
 * once per connection.
 */
async function registerMessagingHandlers(io, socket) {
  const { id: userId } = socket.user;

  const conversations = await Conversation.find({ participantIds: userId }, '_id participantIds');
  for (const conversation of conversations) {
    socket.join(conversationRoom(conversation._id));
  }

  const justCameOnline = presenceService.addSocket(userId, socket.id);
  if (justCameOnline) {
    const partnerIds = new Set();
    for (const conversation of conversations) {
      for (const participantId of conversation.participantIds) {
        if (participantId.toString() !== userId) partnerIds.add(participantId.toString());
      }
    }
    for (const partnerId of partnerIds) {
      io.to(`user:${partnerId}`).emit('presence:online', { userId });
    }
  }

  socket.on('conversation:join', async (payload, ack) => {
    try {
      const { conversationId } = payload || {};
      if (!isObjectId(conversationId) || !allowEvent(socket.id, 'join')) return ack?.(BAD_REQUEST);
      const conversation = await messagingService.getConversationById(conversationId);
      messagingService.assertParticipant(conversation, userId);
      socket.join(conversationRoom(conversationId));
      ack?.({ success: true });
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on('conversation:leave', (payload) => {
    if (!isObjectId(payload?.conversationId)) return;
    socket.leave(conversationRoom(payload.conversationId));
  });

  socket.on('message:send', async (payload, ack) => {
    try {
      const { conversationId, text } = payload || {};
      if (!isObjectId(conversationId) || typeof text !== 'string' || text.length > MAX_MESSAGE_LENGTH) return ack?.(BAD_REQUEST);
      if (!allowEvent(socket.id, 'send')) return ack?.({ error: 'You are sending messages too quickly' });
      const message = await messagingService.sendMessage(conversationId, userId, { text });
      io.to(conversationRoom(conversationId)).emit('message:new', message);
      ack?.({ success: true, message });
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on('message:read', async (payload, ack) => {
    try {
      const { conversationId, messageIds } = payload || {};
      if (!isObjectId(conversationId) || (messageIds !== undefined && (!Array.isArray(messageIds) || messageIds.length > 200 || !messageIds.every(isObjectId)))) {
        return ack?.(BAD_REQUEST);
      }
      if (!allowEvent(socket.id, 'read')) return ack?.({ error: 'Too many requests' });
      const { messageIds: updatedIds } = await messagingService.markAsRead(conversationId, userId, messageIds);
      io.to(conversationRoom(conversationId)).emit('message:read-receipt', {
        conversationId,
        readBy: userId,
        messageIds: updatedIds
      });
      ack?.({ success: true });
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  socket.on('message:delete', async (payload, ack) => {
    try {
      const { messageId, forEveryone } = payload || {};
      if (!isObjectId(messageId) || !allowEvent(socket.id, 'delete')) return ack?.(BAD_REQUEST);
      const message = await messagingService.deleteMessage(messageId, userId, { forEveryone: !!forEveryone });
      if (forEveryone) {
        io.to(conversationRoom(message.conversationId)).emit('message:deleted', { messageId, forEveryone: true });
      } else {
        socket.emit('message:deleted', { messageId, forEveryone: false });
      }
      ack?.({ success: true });
    } catch (err) {
      ack?.({ error: err.message });
    }
  });

  // Typing indicators are only relayed for rooms this socket was authorised to join (participants only).
  socket.on('typing:start', (payload) => {
    const conversationId = payload?.conversationId;
    if (!isObjectId(conversationId) || !socket.rooms.has(conversationRoom(conversationId)) || !allowTyping(socket.id, 'typing')) return;
    socket.to(conversationRoom(conversationId)).emit('typing:start', { conversationId, userId });
  });
  socket.on('typing:stop', (payload) => {
    const conversationId = payload?.conversationId;
    if (!isObjectId(conversationId) || !socket.rooms.has(conversationRoom(conversationId))) return;
    socket.to(conversationRoom(conversationId)).emit('typing:stop', { conversationId, userId });
  });

  socket.on('disconnect', async () => {
    const wentOffline = presenceService.removeSocket(userId, socket.id);
    if (!wentOffline) return;

    try {
      const stillConversations = await Conversation.find({ participantIds: userId }, 'participantIds');
      const partnerIds = new Set();
      for (const conversation of stillConversations) {
        for (const participantId of conversation.participantIds) {
          if (participantId.toString() !== userId) partnerIds.add(participantId.toString());
        }
      }
      const status = presenceService.getStatus(userId);
      for (const partnerId of partnerIds) {
        io.to(`user:${partnerId}`).emit('presence:offline', { userId, lastSeenAt: status.lastSeenAt });
      }
    } catch (err) {
      logger.error(`Failed to broadcast offline presence for user ${userId}: ${err.message}`);
    }
  });
}

module.exports = { registerMessagingHandlers };
