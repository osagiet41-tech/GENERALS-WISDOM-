require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const env = require('../src/config/env');
const User = require('../src/models/User');
const logger = require('../src/utils/logger');

const ADMIN_EMAIL = process.env.SEED_ADMIN_EMAIL || 'admin@appname.com';
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD; // must be supplied, never hardcoded
const ADMIN_NAME = process.env.SEED_ADMIN_NAME || 'System Administrator';

async function seedAdmin() {
  if (!ADMIN_PASSWORD) {
    logger.error('SEED_ADMIN_PASSWORD env var is required to seed the admin account. Aborting.');
    process.exit(1);
  }

  await mongoose.connect(env.mongodbUri);

  const existing = await User.findOne({ email: ADMIN_EMAIL });
  if (existing) {
    logger.info(`Admin account already exists for ${ADMIN_EMAIL}. Skipping.`);
    await mongoose.disconnect();
    return;
  }

  const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 12);

  await User.create({
    name: ADMIN_NAME,
    email: ADMIN_EMAIL,
    passwordHash,
    role: 'admin',
    status: 'active',
    isEmailVerified: true
  });

  logger.info(`Admin account created: ${ADMIN_EMAIL}`);
  await mongoose.disconnect();
}

seedAdmin().catch((err) => {
  logger.error(`Admin seeding failed: ${err.message}`);
  process.exit(1);
});
