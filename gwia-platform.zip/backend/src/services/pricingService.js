const env = require('../config/env');
const { Course } = require('../models/course.model');
const { Plan } = require('../models/billing.model');
const ApiError = require('../utils/ApiError');
const { toMinor, formatMoney } = require('../utils/money');
const discountService = require('./discountService');

function platformCurrency() {
  return env.payments.defaultCurrency;
}

/** A course is free only if its base price AND every per-currency override are zero. */
function isCourseFree(course) {
  const base = Number(course.price) > 0;
  const overrides = (course.prices || []).some((p) => Number(p.amount) > 0);
  return !base && !overrides;
}

/** Price of a course in `currency` (minor units), or null if not sold in that currency. */
function courseUnitAmount(course, currency) {
  const cur = String(currency).toUpperCase();
  const override = (course.prices || []).find((p) => String(p.currency).toUpperCase() === cur);
  if (override) return toMinor(override.amount, cur);
  const baseCur = String(course.currency || platformCurrency()).toUpperCase();
  if (baseCur === cur && Number(course.price) > 0) return toMinor(course.price, cur);
  return null;
}

function planUnitAmount(plan, currency) {
  const cur = String(currency).toUpperCase();
  const entry = plan.prices.find((p) => p.currency === cur);
  return entry ? entry.amountMinor : null;
}

function availableCurrenciesForCourse(course) {
  const set = new Set((course.prices || []).filter((p) => p.amount > 0).map((p) => p.currency.toUpperCase()));
  if (Number(course.price) > 0) set.add(String(course.currency || platformCurrency()).toUpperCase());
  return [...set];
}

/**
 * The ONLY place a payable amount is computed. The client sends what it wants to buy (course id or
 * plan code), never an amount. Throws if the target cannot be bought.
 */
async function quote({ userId, purpose, courseId, planCode, currency, discountCode }) {
  let target;
  let unit;
  let description;
  let cur = String(currency || platformCurrency()).toUpperCase();

  if (purpose === 'course') {
    const course = await Course.findById(courseId);
    if (!course || course.status !== 'published') throw ApiError.notFound('Course not found or not open for sale');
    if (isCourseFree(course)) throw ApiError.badRequest('This course is free — enroll directly');
    unit = courseUnitAmount(course, cur);
    if (unit == null && !currency) {
      // No currency requested and the platform default isn't offered: fall back to the only/first one sold.
      const first = availableCurrenciesForCourse(course)[0];
      if (first) {
        cur = first;
        unit = courseUnitAmount(course, cur);
      }
    }
    if (unit == null) {
      throw ApiError.badRequest(
        `This course is not sold in ${cur}. Available: ${availableCurrenciesForCourse(course).join(', ')}`
      );
    }
    target = { course };
    description = `Course: ${course.title}`;
  } else if (purpose === 'subscription') {
    const plan = await Plan.findOne({ code: String(planCode || '').toLowerCase(), active: true });
    if (!plan) throw ApiError.notFound('Subscription plan not found');
    unit = planUnitAmount(plan, cur);
    if (unit == null && !currency && plan.prices.length) {
      cur = plan.prices[0].currency;
      unit = planUnitAmount(plan, cur);
    }
    if (unit == null) {
      throw ApiError.badRequest(`This plan is not sold in ${cur}. Available: ${plan.prices.map((p) => p.currency).join(', ')}`);
    }
    target = { plan };
    description = `${plan.name} subscription (${plan.billingCycle})`;
  } else {
    throw ApiError.badRequest('purpose must be "course" or "subscription"');
  }

  let discount = null;
  let discountMinor = 0;
  if (discountCode) {
    const result = await discountService.validate({
      code: discountCode,
      userId,
      purpose,
      courseId,
      planCode: target.plan?.code,
      originalMinor: unit,
      currency: cur
    });
    discount = result.doc;
    discountMinor = result.discountMinor;
  }

  const finalMinor = unit - discountMinor;
  return {
    purpose,
    ...target,
    currency: cur,
    originalMinor: unit,
    discountMinor,
    finalMinor,
    discount,
    description,
    display: {
      original: formatMoney(unit, cur),
      discount: formatMoney(discountMinor, cur),
      total: formatMoney(finalMinor, cur)
    }
  };
}

module.exports = { quote, isCourseFree, courseUnitAmount, planUnitAmount, availableCurrenciesForCourse, platformCurrency };
