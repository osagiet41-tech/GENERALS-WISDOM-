const express = require('express');
const controller = require('../controllers/liveClassController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership, verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { uploadMaterial } = require('../config/multer');
const {
  scheduleLiveClassValidator,
  updateLiveClassValidator,
  updateSettingsValidator,
  announcementValidator
} = require('../validators/liveClassValidator');
const LiveClass = require('../models/liveClass.model');

const nestedRouter = express.Router({ mergeParams: true });
nestedRouter.use(authMiddleware, requireTeacherOrAdmin);
nestedRouter.get('/', verifyCourseOwnership(), controller.listLiveClasses);
nestedRouter.post('/', verifyCourseOwnership(), validate(scheduleLiveClassValidator), controller.scheduleLiveClass);

const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);

itemRouter.put(
  '/:id',
  verifyResourceOwnership(LiveClass, 'id'),
  validate(updateLiveClassValidator),
  controller.updateLiveClass
);
itemRouter.post('/:id/cancel', verifyResourceOwnership(LiveClass, 'id'), controller.cancelLiveClass);
itemRouter.post('/:id/start', verifyResourceOwnership(LiveClass, 'id'), controller.startLiveClass);
itemRouter.post('/:id/end', verifyResourceOwnership(LiveClass, 'id'), controller.endLiveClass);

// The only way the classroom's real join credential is ever reachable —
// gated by verifyResourceOwnership, same as every other item route.
itemRouter.get('/:id/join-token', verifyResourceOwnership(LiveClass, 'id'), controller.getJoinToken);

itemRouter.put(
  '/:id/settings',
  verifyResourceOwnership(LiveClass, 'id'),
  validate(updateSettingsValidator),
  controller.updateSettings
);

itemRouter.post('/:id/recording/start', verifyResourceOwnership(LiveClass, 'id'), controller.startRecording);
itemRouter.post('/:id/recording/stop', verifyResourceOwnership(LiveClass, 'id'), controller.stopRecording);

itemRouter.post(
  '/:id/materials',
  verifyResourceOwnership(LiveClass, 'id'),
  uploadMaterial.single('file'),
  controller.addSharedMaterial
);
itemRouter.delete(
  '/:id/materials/:materialId',
  verifyResourceOwnership(LiveClass, 'id'),
  controller.removeSharedMaterial
);

itemRouter.post(
  '/:id/announcements',
  verifyResourceOwnership(LiveClass, 'id'),
  validate(announcementValidator),
  controller.postAnnouncement
);

itemRouter.get('/:id/chat', verifyResourceOwnership(LiveClass, 'id'), controller.getChatHistory);
itemRouter.get(
  '/:id/attendance-summary',
  verifyResourceOwnership(LiveClass, 'id'),
  controller.getParticipantSummary
);

module.exports = { nestedRouter, itemRouter };
