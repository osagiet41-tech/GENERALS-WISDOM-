import { h, $, mount } from '../core/dom.js';
import { session, homeFor } from '../core/session.js';
import { toggleTheme, currentTheme } from '../core/theme.js';
import { icon } from '../core/dom.js';
import { billingApi } from '../api/billing.js';
import { withState } from '../ui/states.js';
import { empty } from '../ui/states.js';
import { planCard, planCurrencies, currencySelect, defaultCurrency } from '../ui/plans.js';
import { verifyCertificate } from '../ui/certResult.js';

// Header: theme toggle + guest/member buttons
const tb = $('#theme-toggle'); const paint = () => tb.replaceChildren(icon(currentTheme() === 'dark' ? 'sun' : 'moon'));
tb.addEventListener('click', toggleTheme); document.addEventListener('themechange', paint); paint();
if (session.user && session.accessToken) {
  document.querySelectorAll('[data-guest]').forEach((e) => e.classList.add('hidden'));
  const m = $('[data-member]'); m.href = homeFor(session.user.role); m.classList.remove('hidden');
}
$('#year').textContent = new Date().getFullYear();

// Certificate verification
const form = $('#verify-form'), out = $('#verify-result');
form.addEventListener('submit', async (e) => {
  e.preventDefault(); const id = form.elements.id.value; if (!id.trim()) return form.elements.id.focus();
  const btn = form.querySelector('button'); btn.disabled = true; btn.setAttribute('aria-busy', 'true');
  mount(out, h('p', { class: 'muted' }, 'Checking…'));
  mount(out, await verifyCertificate(id)); btn.disabled = false; btn.removeAttribute('aria-busy');
});

// Plans (public endpoint)
withState($('#plans-mount'), async () => (await billingApi.plans()).data || [], (plans) => {
  const active = plans.filter((p) => p.active !== false);
  if (!active.length) return empty({ title: 'Plans are coming soon', message: 'Individual courses can still be bought one at a time once you sign in.', iconName: 'card' });
  const currencies = planCurrencies(active); let cur = defaultCurrency(currencies); const grid = h('div', { class: 'grid grid-3' });
  const draw = () => mount(grid, active.map((p, i) => planCard(p, { currency: cur, featured: p.billingCycle === 'annual', cta: { label: 'Choose plan', onClick: () => { location.href = `auth.html?mode=register&plan=${encodeURIComponent(p.code)}`; } } })));
  draw();
  return h('div', { class: 'stack' }, currencies.length > 1 && h('div', { class: 'row' }, h('span', { class: 'muted' }, 'Show prices in'), currencySelect(currencies, cur, (c) => { cur = c; draw(); })), grid);
}, { rows: 3 });
