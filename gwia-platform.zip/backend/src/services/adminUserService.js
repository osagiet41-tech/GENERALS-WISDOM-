const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const env = require('../config/env');
const authService = require('./authService');
const { Course } = require('../models/course.model');
const Progress = require('../models/progress.model');
const ApiError = require('../utils/ApiError');
const { escapeRegex } = require('../utils/security');

async function listUsers({ role, status, search, page = 1, limit = 20 } = {}) {
  const filter = {};
  if (role) filter.role = role;
  if (status) filter.status = status;
  if (search) {
    const rx = new RegExp(escapeRegex(String(search).slice(0, 100)), 'i');
    filter.$or = [{ name: rx }, { email: rx }];
  }

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    User.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function getUserDetail(userId) {
  const user = await User.findById(userId);
  if (!user) {
    throw ApiError.notFound('User not found');
  }

  const detail = { user: user.toSafeObject() };

  if (user.role === 'teacher') {
    const courses = await Course.find({ teacherIds: user._id }, 'title status enrolledStudentIds');
    detail.coursesTaught = courses.map((c) => ({
      courseId: c._id,
      title: c.title,
      status: c.status,
      enrolledCount: c.enrolledStudentIds.length
    }));
  }

  if (user.role === 'student') {
    const [courses, progressDocs] = await Promise.all([
      Course.find({ enrolledStudentIds: user._id }, 'title status'),
      Progress.find({ studentId: user._id })
    ]);
    detail.enrolledCourses = courses.map((c) => ({ courseId: c._id, title: c.title, status: c.status }));
    detail.progressSummaries = progressDocs.map((p) => ({
      courseId: p.courseId,
      completedLessons: p.completedLessonIds.length
    }));
  }

  return detail;
}

async function suspendUser(userId, adminId) {
  const user = await User.findById(userId);
  if (!user) {
    throw ApiError.notFound('User not found');
  }
  if (user._id.toString() === adminId) {
    throw ApiError.badRequest('You cannot suspend your own account');
  }
  if (user.role === 'admin') {
    throw ApiError.forbidden('Admin accounts cannot be suspended through this endpoint');
  }

  user.status = 'suspended';
  user.refreshTokens = [];
  await user.save();
  return user.toSafeObject();
}

async function restoreUser(userId) {
  const user = await User.findById(userId);
  if (!user) {
    throw ApiError.notFound('User not found');
  }
  if (user.status !== 'suspended') {
    throw ApiError.badRequest('This account is not currently suspended');
  }

  // An account that was suspended before it ever verified its e-mail goes back to pending, not straight to active.
  user.status = user.isEmailVerified ? 'active' : 'pending';
  await user.save();
  return user.toSafeObject();
}

/**
 * Administrators provision teacher (and student) accounts. The account gets an unusable random password and the new
 * user receives a "set your password" link by e-mail, so no password is ever chosen, typed or sent by the admin.
 */
async function createUser({ name, email, role }) {
  if (!['teacher', 'student'].includes(role)) throw ApiError.badRequest('role must be teacher or student');
  if (await User.findOne({ email })) throw ApiError.conflict('An account with this email already exists');

  const user = await User.create({
    name,
    email,
    role,
    status: 'active',
    isEmailVerified: true,
    passwordHash: await bcrypt.hash(crypto.randomBytes(32).toString('hex'), env.security.bcryptRounds)
  });
  const setupEmailSent = await authService.forgotPassword(user.email);
  return { user: user.toSafeObject(), setupEmailSent };
}

async function changeRole(userId, role, adminId) {
  const user = await User.findById(userId).select('+refreshTokens');
  if (!user) throw ApiError.notFound('User not found');
  if (user._id.toString() === adminId) throw ApiError.badRequest('You cannot change your own role');
  if (user.role === 'admin') throw ApiError.forbidden('Administrator roles cannot be changed through the API');
  user.role = role;
  user.refreshTokens = []; // sign them out everywhere so the new role applies from a clean session
  await user.save();
  return user.toSafeObject();
}

module.exports = { createUser, changeRole, listUsers, getUserDetail, suspendUser, restoreUser };
