const { AuditLog } = require('../models/systemAdmin.model');

async function record(actorId, action, targetType, targetId, meta = {}, ipAddress = null) {
  try {
    await AuditLog.create({ actorId, action, targetType, targetId: targetId || null, meta, ipAddress });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(`Failed to record audit log for action "${action}":`, err.message);
  }
}

async function list({ actorId, action, targetType, page = 1, limit = 50 } = {}) {
  const filter = {};
  if (actorId) filter.actorId = actorId;
  if (action) filter.action = action;
  if (targetType) filter.targetType = targetType;

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    AuditLog.find(filter)
      .populate('actorId', 'name email role')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    AuditLog.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

module.exports = { record, list };
