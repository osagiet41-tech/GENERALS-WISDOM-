const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ApiError = require('../../utils/ApiError');

// Deliberately NOT under /uploads (which app.js serves publicly): signatures are only ever embedded in PDFs.
const DIR = path.join(__dirname, '..', '..', '..', 'storage', 'signatures');
const MAX_BYTES = 512 * 1024;

const PNG_MAGIC = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

function detectType(buf) {
  if (buf.length >= 8 && buf.subarray(0, 8).equals(PNG_MAGIC)) return 'png';
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  return null;
}

/**
 * Stores a signature under a content-addressed name. Old files are never overwritten or deleted, because
 * certificates already issued keep pointing at the signature they were issued with.
 */
function save(userId, buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) throw ApiError.badRequest('No signature file received');
  if (buffer.length > MAX_BYTES) throw ApiError.badRequest('Signature image must be 500 KB or smaller');
  const type = detectType(buffer); // checks the real bytes, not the client-supplied mimetype
  if (!type) throw ApiError.badRequest('Signature must be a PNG or JPEG image');

  fs.mkdirSync(DIR, { recursive: true });
  const hash = crypto.createHash('sha256').update(buffer).digest('hex').slice(0, 12);
  const fileName = `${userId}-${hash}.${type}`;
  const target = path.join(DIR, fileName);
  if (!fs.existsSync(target)) fs.writeFileSync(target, buffer, { mode: 0o640 });
  return fileName;
}

/** Returns the file's bytes, or null if the name is unsafe/missing (rendering then falls back to a typed signature). */
function read(fileName) {
  if (typeof fileName !== 'string' || !/^[A-Za-z0-9._-]+$/.test(fileName) || fileName.includes('..')) return null;
  const full = path.join(DIR, fileName);
  if (!full.startsWith(DIR + path.sep)) return null;
  try {
    return fs.readFileSync(full);
  } catch (e) {
    return null;
  }
}

module.exports = { save, read, detectType, DIR, MAX_BYTES };
