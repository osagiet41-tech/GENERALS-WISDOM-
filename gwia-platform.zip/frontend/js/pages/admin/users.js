import { h } from '../../core/dom.js';
import { adminApi } from '../../api/admin.js';
import { pageHead, idOf } from '../../ui/page.js';
import { listView } from '../shared/listView.js';
import { statusBadge, badge } from '../../ui/table.js';
import { openModal, confirmDialog } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { fmtDate } from '../../core/format.js';
import { initials } from '../../core/format.js';

export default async function render() {
  const lv = listView({ searchPlaceholder: 'Search name or email…', caption: 'Users', fetcher: (q) => adminApi.users(q), filters: [
    { name: 'role', label: 'All roles', options: ['student', 'teacher', 'admin'].map((v) => ({ value: v, label: v })) }, { name: 'status', label: 'All statuses', options: ['active', 'suspended', 'pending'].map((v) => ({ value: v, label: v })) }],
    columns: [{ label: 'User', render: (u) => h('div', { class: 'user-chip' }, h('span', { class: 'avatar', 'aria-hidden': 'true' }, initials(u.name)), h('div', null, h('strong', null, u.name), h('div', { class: 'small muted' }, u.email))) },
      { label: 'Role', render: (u) => badge(u.role, 'info') }, { label: 'Status', render: (u) => statusBadge(u.status) }, { label: 'Joined', render: (u) => fmtDate(u.createdAt) }],
    actions: (u) => h('div', { class: 'row' }, u.role !== 'admin' && roleButton(u, () => lv.reload()), suspendOrRestore(u)) });
  function suspendOrRestore(u) { return u.status === 'suspended'
      ? h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: async () => { try { await adminApi.restore(idOf(u)); toast.success(`${u.name} restored.`); lv.reload(); } catch (e) { toast.error(e.message); } } }, 'Restore')
      : h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => { const m = openModal({ title: `Suspend ${u.name}?`, body: buildForm({ grid: false, submitLabel: 'Suspend user', onCancel: () => m.close(), fields: [{ name: 'reason', label: 'Reason (optional)', type: 'textarea', maxlength: 500 }],
        onSubmit: async (v) => { await adminApi.suspend(idOf(u), v.reason); m.close(); toast.success(`${u.name} suspended.`); lv.reload(); } }) }); } }, 'Suspend'); }
  const addBtn = h('button', { class: 'btn', type: 'button', onclick: () => addUserModal(() => lv.reload()) }, 'Add user');
  return h('div', { class: 'stack' }, pageHead('Users', 'Search, filter and manage accounts. Teachers are created here (public sign-up only creates students).', addBtn), lv.el);
}

function addUserModal(done) {
  const m = openModal({ title: 'Add a user', body: buildForm({ grid: false, submitLabel: 'Create account', onCancel: () => m.close(),
    fields: [{ name: 'name', label: 'Full name', required: true, maxlength: 120 }, { name: 'email', label: 'Email', type: 'email', required: true },
      { name: 'role', label: 'Role', type: 'select', required: true, options: [{ value: 'teacher', label: 'Teacher' }, { value: 'student', label: 'Student' }] }],
    onSubmit: async (v) => { const { data } = await adminApi.createUser(v); m.close(); data.setupEmailSent ? toast.success('Account created. A set-password link was e-mailed.') : toast.info('Account created, but the e-mail could not be sent. Ask them to use Forgot password.'); done(); } }) });
}

function roleButton(u, done) {
  return h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => {
    const m = openModal({ title: `Change role for ${u.name}`, body: buildForm({ grid: false, submitLabel: 'Save role', onCancel: () => m.close(),
      fields: [{ name: 'role', label: 'Role', type: 'select', required: true, value: u.role, options: [{ value: 'teacher', label: 'Teacher' }, { value: 'student', label: 'Student' }] }],
      onSubmit: async (v) => { await adminApi.setRole(idOf(u), v.role); m.close(); toast.success('Role updated. The user must sign in again.'); done(); } }) });
  } }, 'Change role');
}
