/**
 * In-memory presence registry: classroomId -> userId -> participant state.
 *
 * This is per-process state, which is fine for a single Node instance.
 * If the app is ever scaled horizontally (multiple server processes),
 * this needs to move to a shared store (Redis is the usual choice —
 * the Socket.IO Redis adapter for cross-process room broadcast, plus a
 * Redis hash for presence lookups) so relaySignal() and participant
 * lists stay consistent across processes. Isolating all presence
 * access behind this module's functions means that migration only
 * touches this one file.
 */
const rooms = new Map(); // liveClassId (string) -> Map<userId (string), participant>

function getRoom(liveClassId) {
  const key = liveClassId.toString();
  if (!rooms.has(key)) {
    rooms.set(key, new Map());
  }
  return rooms.get(key);
}

function addParticipant(liveClassId, userId, participant) {
  getRoom(liveClassId).set(userId.toString(), participant);
}

function removeParticipant(liveClassId, userId) {
  const room = getRoom(liveClassId);
  room.delete(userId.toString());
  if (room.size === 0) {
    rooms.delete(liveClassId.toString());
  }
}

function getParticipant(liveClassId, userId) {
  return getRoom(liveClassId).get(userId.toString()) || null;
}

function updateParticipant(liveClassId, userId, patch) {
  const room = getRoom(liveClassId);
  const key = userId.toString();
  const existing = room.get(key);
  if (!existing) return null;
  const updated = { ...existing, ...patch };
  room.set(key, updated);
  return updated;
}

function listParticipants(liveClassId) {
  return Array.from(getRoom(liveClassId).values());
}

function findBySocketId(liveClassId, socketId) {
  return listParticipants(liveClassId).find((p) => p.socketId === socketId) || null;
}

module.exports = {
  addParticipant,
  removeParticipant,
  getParticipant,
  updateParticipant,
  listParticipants,
  findBySocketId
};
