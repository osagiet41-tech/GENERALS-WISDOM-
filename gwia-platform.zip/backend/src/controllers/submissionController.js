const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const submissionService = require('../services/submissionService');
const notificationService = require('../services/notificationService');

// GET /api/assignments/:id/submissions  (req.resource = Assignment, set by ownership middleware)
const listAssignmentSubmissions = asyncHandler(async (req, res) => {
  const submissions = await submissionService.listSubmissionsForResource(
    'assignment',
    req.resource._id,
    req.query.status
  );
  return ApiResponse.ok(res, submissions, 'Submissions retrieved');
});

// GET /api/quizzes/:id/submissions and GET /api/exams/:id/submissions (req.resource = Assessment)
const listAssessmentSubmissions = asyncHandler(async (req, res) => {
  const submissions = await submissionService.listSubmissionsForResource(
    req.resource.kind,
    req.resource._id,
    req.query.status
  );
  return ApiResponse.ok(res, submissions, 'Submissions retrieved');
});

// GET /api/submissions/:submissionId  (req.resource = Submission, set by ownership middleware)
const getSubmission = asyncHandler(async (req, res) => {
  return ApiResponse.ok(res, req.resource, 'Submission retrieved');
});

// PUT /api/submissions/:submissionId/grade
const gradeSubmission = asyncHandler(async (req, res) => {
  const submission =
    req.resource.refType === 'assignment'
      ? await submissionService.gradeAssignmentSubmission(req.resource, req.user.id, req.body)
      : await submissionService.gradeAssessmentSubmission(req.resource, req.user.id, req.body);

  const io = req.app.get('io');
  if (io) {
    io.to(`user:${submission.studentId}`).emit('grade:posted', {
      submissionId: submission._id,
      refType: submission.refType,
      score: submission.grade.score,
      totalMarks: submission.grade.totalMarks
    });
  }

  await notificationService.createNotification(
    submission.studentId,
    'grade_posted',
    'New grade posted',
    `You received ${submission.grade.score}/${submission.grade.totalMarks} on a ${submission.refType}`,
    { submissionId: submission._id, refType: submission.refType, courseId: submission.courseId }
  );

  return ApiResponse.ok(res, submission, 'Submission graded successfully');
});

// PUT /api/submissions/:submissionId/return
const returnToStudent = asyncHandler(async (req, res) => {
  const submission = await submissionService.returnToStudent(req.resource);
  return ApiResponse.ok(res, submission, 'Submission returned to student');
});

module.exports = {
  listAssignmentSubmissions,
  listAssessmentSubmissions,
  getSubmission,
  gradeSubmission,
  returnToStudent
};
