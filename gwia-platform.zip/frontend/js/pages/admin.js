import { requireRole } from '../core/session.js';
import { createShell } from '../ui/shell.js';
import { startRouter } from '../ui/router.js';

const user = await requireRole('admin');
const shell = createShell({ user, nav: [
  { id: 'overview', label: 'Overview', icon: 'home' }, { id: 'users', label: 'Users', icon: 'users' }, { id: 'courses', label: 'Courses', icon: 'book' }, { id: 'payments', label: 'Payments', icon: 'card' },
  { id: 'billing', label: 'Plans & discounts', icon: 'award' }, { id: 'subscriptions', label: 'Subscriptions', icon: 'calendar' }, { id: 'certificates', label: 'Certificates', icon: 'shield' },
  { id: 'reports', label: 'Reports', icon: 'chart' }, { id: 'audit', label: 'Audit log', icon: 'file' }, { id: 'settings', label: 'Settings & backups', icon: 'settings' }, { id: 'messages', label: 'Messages', icon: 'message', href: 'messages.html' }, { id: 'profile', label: 'Profile', icon: 'users' }] });
startRouter({ shell, ctx: { user }, fallback: 'overview', routes: {
  overview: () => import('./admin/overview.js'), users: () => import('./admin/users.js'), courses: () => import('./admin/courses.js'), payments: () => import('./admin/payments.js'), billing: () => import('./admin/billing.js'),
  subscriptions: () => import('./admin/subscriptions.js'), certificates: () => import('./admin/certificates.js'), reports: () => import('./admin/reports.js'), audit: () => import('./admin/audit.js'), settings: () => import('./admin/settings.js'), profile: () => import('./shared/profile.js') } });
