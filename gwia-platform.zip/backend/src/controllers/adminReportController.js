const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const adminReportService = require('../services/adminReportService');

const REPORT_BUILDERS = {
  'course-performance': (query) => adminReportService.getCoursePerformanceReport({ limit: query.limit }),
  revenue: (query) => adminReportService.getRevenueReport({ months: query.months }),
  payments: (query) => adminReportService.getPaymentsReport({ status: query.status })
};

const getReport = asyncHandler(async (req, res) => {
  const builder = REPORT_BUILDERS[req.params.type];
  if (!builder) {
    throw ApiError.badRequest(`Unknown report type: ${req.params.type}`);
  }
  const rows = await builder(req.query);
  return ApiResponse.ok(res, rows, 'Report retrieved');
});

const exportReport = asyncHandler(async (req, res) => {
  const builder = REPORT_BUILDERS[req.params.type];
  if (!builder) {
    throw ApiError.badRequest(`Unknown report type: ${req.params.type}`);
  }
  const rows = await builder(req.query);
  const buffer = adminReportService.toExcelBuffer(rows, req.params.type);

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${req.params.type}-report.xlsx"`);
  return res.send(buffer);
});

module.exports = { getReport, exportReport };
