const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const { Plan, Subscription } = require('../models/billing.model');
const { Course } = require('../models/course.model');
const User = require('../models/User');
const paymentService = require('../services/paymentService');
const pricingService = require('../services/pricingService');
const discountService = require('../services/discountService');
const accessService = require('../services/accessService');
const subscriptionService = require('../services/subscriptionService');
const receiptService = require('../services/receiptService');
const providers = require('../services/payments/providers');
const { formatMoney } = require('../utils/money');
const { Payment } = require('../models/billing.model');

function publicPlan(plan, eligibility) {
  return {
    code: plan.code,
    name: plan.name,
    description: plan.description,
    billingCycle: plan.billingCycle,
    features: plan.features,
    trialDays: plan.trialDays,
    prices: plan.prices.map((p) => ({ currency: p.currency, amountMinor: p.amountMinor, display: formatMoney(p.amountMinor, p.currency) })),
    ...(eligibility ? { trial: eligibility } : {})
  };
}

// GET /api/billing/plans  (public)
const listPlans = asyncHandler(async (req, res) => {
  const plans = await Plan.find({ active: true }).sort({ sortOrder: 1, createdAt: 1 });
  const enabled = providers.listEnabled();
  return ApiResponse.ok(
    res,
    {
      plans: plans.map((p) => publicPlan(p)),
      defaultCurrency: pricingService.platformCurrency(),
      providers: enabled.map((p) => ({ name: p.name, currencies: p.config.currencies }))
    },
    'Plans retrieved'
  );
});

// GET /api/billing/courses/:courseId/access
const courseAccess = asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.courseId);
  if (!course || course.status === 'draft') throw ApiError.notFound('Course not found');
  const access = await accessService.getCourseAccess(req.user.id, course);
  const free = pricingService.isCourseFree(course);
  return ApiResponse.ok(res, {
    courseId: course._id,
    free,
    access,
    purchaseOptions: free
      ? []
      : pricingService.availableCurrenciesForCourse(course).map((cur) => {
          const minor = pricingService.courseUnitAmount(course, cur);
          return { currency: cur, amountMinor: minor, display: formatMoney(minor, cur) };
        }),
    includedInSubscription: course.includedInSubscription !== false
  });
});

// POST /api/billing/discounts/validate  — preview only, nothing is reserved
const validateDiscount = asyncHandler(async (req, res) => {
  const { code, purpose, courseId, planCode, currency } = req.body;
  const q = await pricingService.quote({ userId: req.user.id, purpose, courseId, planCode, currency, discountCode: code });
  return ApiResponse.ok(res, { valid: true, code: q.discount.code, currency: q.currency, ...q.display, totalMinor: q.finalMinor }, 'Discount applied');
});

// POST /api/billing/checkout
const checkout = asyncHandler(async (req, res) => {
  const { purpose, courseId, planCode, currency, provider, discountCode } = req.body;
  const { payment, reused } = await paymentService.createCheckout({
    user: req.user,
    purpose,
    courseId,
    planCode,
    currency,
    provider,
    discountCode,
    ip: req.ip
  });

  const free = payment.provider === 'free';
  return ApiResponse.created(
    res,
    {
      paymentId: payment._id,
      reference: payment.reference,
      status: payment.status,
      free,
      reused,
      amountMinor: payment.amountMinor,
      currency: payment.currency,
      total: formatMoney(payment.amountMinor, payment.currency),
      provider: payment.provider,
      checkoutUrl: free ? null : payment.checkoutUrl
    },
    free ? 'Access granted' : 'Checkout created'
  );
});

// POST /api/billing/payments/:reference/verify
// Called by the frontend callback page. The body is only a lookup hint; the outcome is decided by the
// gateway's server API, so nothing the browser sends can mark a payment as paid.
const verifyPayment = asyncHandler(async (req, res) => {
  const mine = await Payment.findOne({ reference: req.params.reference, userId: req.user.id }).select('_id');
  if (!mine) throw ApiError.notFound('Payment not found');
  const payment = await paymentService.confirmPayment(req.params.reference, { transactionIdHint: req.body.transactionId || null });
  const fresh = await paymentService.getForUser(req.user.id, payment._id.toString());
  return ApiResponse.ok(
    res,
    {
      status: fresh.status,
      paid: fresh.status === 'completed',
      accessGranted: fresh.status === 'completed' && fresh.fulfillment?.status === 'done',
      reference: fresh.reference,
      receiptNumber: fresh.receiptNumber
    },
    fresh.status === 'completed' ? 'Payment confirmed' : 'Payment not confirmed yet'
  );
});

// GET /api/billing/payments
const listPayments = asyncHandler(async (req, res) => {
  const { page, limit, status } = req.query;
  const result = await paymentService.listForUser(req.user.id, { page, limit, status });
  return ApiResponse.ok(res, result.items, 'Payment history retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

// GET /api/billing/payments/:id
const getPayment = asyncHandler(async (req, res) => {
  const payment = await paymentService.getForUser(req.user.id, req.params.id);
  return ApiResponse.ok(res, payment, 'Payment retrieved');
});

async function loadReceiptPayment(req) {
  const owned = await paymentService.getForUser(req.user.id, req.params.id);
  const payment = await Payment.findById(owned._id);
  if (!['completed', 'refunded'].includes(payment.status)) throw ApiError.badRequest('No receipt: this payment was not completed');
  if (!payment.receiptNumber) throw ApiError.conflict('Your receipt is being prepared, please retry in a moment');
  return payment;
}

// GET /api/billing/payments/:id/receipt
const getReceipt = asyncHandler(async (req, res) => {
  const payment = await loadReceiptPayment(req);
  const user = await User.findById(req.user.id);
  return ApiResponse.ok(res, receiptService.buildReceipt(payment, user), 'Receipt retrieved');
});

// GET /api/billing/payments/:id/receipt.pdf
const downloadReceipt = asyncHandler(async (req, res) => {
  const payment = await loadReceiptPayment(req);
  const user = await User.findById(req.user.id);
  const pdf = await receiptService.renderReceiptPdf(receiptService.buildReceipt(payment, user));
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${payment.receiptNumber}.pdf"`);
  return res.send(pdf);
});

// GET /api/billing/subscription
const mySubscription = asyncHandler(async (req, res) => {
  const live = await accessService.getLiveSubscription(req.user.id);
  const latest = live || (await Subscription.findOne({ userId: req.user.id }).sort({ endDate: -1 }).lean());
  const plans = await Plan.find({ active: true }).sort({ sortOrder: 1 });
  const trials = {};
  for (const p of plans) trials[p.code] = await subscriptionService.trialEligibility(req.user.id, p);
  return ApiResponse.ok(res, {
    active: Boolean(live),
    subscription: latest
      ? {
          plan: latest.plan,
          billingCycle: latest.billingCycle,
          status: live ? latest.status : 'expired',
          trial: latest.status === 'trialing' && Boolean(live),
          startDate: latest.startDate,
          endDate: latest.endDate
        }
      : null,
    trialEligibility: trials
  });
});

// POST /api/billing/trial
const startTrial = asyncHandler(async (req, res) => {
  const sub = await subscriptionService.startTrial(req.user.id, req.body.planCode);
  return ApiResponse.created(res, { status: sub.status, endDate: sub.endDate, plan: sub.plan }, 'Free trial started');
});

module.exports = {
  listPlans,
  courseAccess,
  validateDiscount,
  checkout,
  verifyPayment,
  listPayments,
  getPayment,
  getReceipt,
  downloadReceipt,
  mySubscription,
  startTrial
};
