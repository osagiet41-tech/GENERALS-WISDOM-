import { h, mount, icon } from '../core/dom.js';
import { requireRole } from '../core/session.js';
import { studentApi } from '../api/student.js';
import { createToolBar } from '../ui/shell.js';
import { errorState, loading, busy } from '../ui/states.js';
import { openModal } from '../ui/modal.js';
import { toast } from '../ui/toast.js';
import { fmtClock, fmtDateTime } from '../core/format.js';

await requireRole('student');
const q = new URLSearchParams(location.search), kind = q.get('kind') === 'quizzes' ? 'quizzes' : 'exams', id = q.get('id'), back = `student.html#/work`;
const label = kind === 'exams' ? 'Exam' : 'Quiz';
const root = h('main', { id: 'main', tabindex: '-1' }); const timer = h('span', { class: 'timer', role: 'timer', 'aria-label': 'Time remaining' }, '--:--'); timer.hidden = true; const saveState = h('span', { class: 'small muted', role: 'status' }, '');
document.body.append(h('div', { class: 'tool' }, createToolBar({ title: label, backHref: back, backLabel: 'Leave', extra: [saveState, timer] }), root));
if (!id) mount(root, errorState({ message: 'No exam selected.' })); else intro();

let attempt = null, current = 0, dirty = new Map(), deadline = 0, tick = null, autosave = null, finished = false;

async function intro() {
  mount(root, loading(4));
  try {
    const { data } = await studentApi.attempt(kind, id).catch((e) => { if (e.status === 404) return { data: null }; throw e; });
    if (data && data.status === 'in_progress') return run(data);
  } catch (e) { return mount(root, errorState(e, intro)); }
  mount(root, h('div', { class: 'exam', style: 'grid-template-columns:1fr;max-width:640px' }, h('section', { class: 'card stack' }, h('h1', null, `Before you begin`), h('ul', null,
    h('li', null, 'The timer starts as soon as you press Begin and does not pause if you close the page.'), h('li', null, 'Answers are saved automatically every few seconds. If your connection drops, keep the page open; saving resumes when you are back online.'),
    h('li', null, 'When time runs out the attempt is submitted for you.'), h('li', null, 'Do not switch devices mid-attempt.')),
    h('div', { class: 'row' }, h('button', { class: 'btn btn-lg', type: 'button', id: 'begin', onclick: begin }, icon('play'), `Begin ${label.toLowerCase()}`), h('a', { class: 'btn btn-secondary btn-lg', href: back }, 'Not now')))));
}
async function begin(e) { try { const { data } = await busy(e.currentTarget, () => studentApi.start(kind, id)); run(data); } catch (err) { toast.error(err.message); } }

function run(view) {
  attempt = view; deadline = Date.now() + view.remainingSeconds * 1000; current = Math.max(0, view.questions.findIndex((x) => !x.visited)); dirty.clear(); finished = false;
  timer.hidden = false; clearInterval(tick); clearInterval(autosave);
  tick = setInterval(() => { const left = Math.max(0, Math.round((deadline - Date.now()) / 1000)); timer.textContent = fmtClock(left); timer.classList.toggle('low', left <= 300); if (left === 0 && !finished) finish(true); }, 500);
  autosave = setInterval(flush, 15000); addEventListener('online', flush);
  addEventListener('beforeunload', (ev) => { if (!finished) { ev.preventDefault(); ev.returnValue = ''; } }); draw();
}
const answered = (x) => x.response !== null && x.response !== undefined && x.response !== '' && !(Array.isArray(x.response) && !x.response.length);
function mark(x, patch) { Object.assign(x, patch, { visited: true }); dirty.set(x.questionId, { questionId: x.questionId, response: x.response ?? null, markedForReview: !!x.markedForReview, visited: true }); saveState.textContent = 'Unsaved changes'; drawPalette(); }
async function flush() {
  if (!dirty.size || finished) return; const batch = [...dirty.values()]; saveState.textContent = 'Saving…';
  try { const { data } = await studentApi.save(kind, id, batch); batch.forEach((b) => { const cur = dirty.get(b.questionId); if (cur && cur.response === b.response && cur.markedForReview === b.markedForReview) dirty.delete(b.questionId); });
    deadline = Date.now() + data.remainingSeconds * 1000; saveState.textContent = `Saved ${new Date(data.lastSavedAt).toLocaleTimeString()}`; }
  catch (e) { if (e.status === 0) saveState.textContent = 'Offline: will retry'; else if (e.status === 400 || e.status === 404) { finished = true; await ended(); } else saveState.textContent = 'Save failed: will retry'; }
}
let palette = h('div', { class: 'palette', role: 'group', 'aria-label': 'Question navigator' }), qbox = h('section', { class: 'card stack' });
function drawPalette() { mount(palette, attempt.questions.map((x, i) => h('button', { type: 'button', class: `${x.markedForReview ? 'review' : answered(x) ? 'answered' : ''}`, 'aria-current': i === current ? 'true' : null, 'aria-label': `Question ${i + 1}${answered(x) ? ', answered' : ''}${x.markedForReview ? ', marked for review' : ''}`, onclick: () => go(i) }, String(i + 1)))); }
function go(i) { current = i; attempt.questions[i].visited = true; if (!dirty.has(attempt.questions[i].questionId)) dirty.set(attempt.questions[i].questionId, { questionId: attempt.questions[i].questionId, response: attempt.questions[i].response ?? null, markedForReview: !!attempt.questions[i].markedForReview, visited: true }); drawQuestion(); drawPalette(); }
function drawQuestion() {
  const x = attempt.questions[current], name = `q-${x.questionId}`; let input;
  if (x.type === 'mcq' || (x.type === 'true_false' && x.options?.length)) input = h('div', { role: 'radiogroup', 'aria-label': 'Answer options' }, x.options.map((o) => h('label', { class: 'option' }, h('input', { type: 'radio', name, checked: x.response === o, onchange: () => mark(x, { response: o }) }), h('span', null, String(o)))));
  else if (x.type === 'true_false') input = h('div', { role: 'radiogroup' }, [[true, 'True'], [false, 'False']].map(([v, l]) => h('label', { class: 'option' }, h('input', { type: 'radio', name, checked: x.response === v, onchange: () => mark(x, { response: v }) }), h('span', null, l))));
  else if (x.type === 'short_answer') input = h('input', { class: 'input', value: x.response || '', 'aria-label': 'Your answer', oninput: (e) => mark(x, { response: e.target.value }) });
  else input = h('textarea', { class: 'input', rows: 10, 'aria-label': 'Your answer', oninput: (e) => mark(x, { response: e.target.value }) }, x.response || '');
  mount(qbox, h('div', { class: 'spread' }, h('strong', null, `Question ${current + 1} of ${attempt.questions.length}`), h('span', { class: 'badge' }, `${x.marks} mark${x.marks === 1 ? '' : 's'}`)), h('p', { style: 'font-size:1.1rem;white-space:pre-wrap' }, x.text), input,
    h('div', { class: 'spread' }, h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!x.markedForReview, onchange: (e) => mark(x, { markedForReview: e.target.checked }) }), 'Mark for review'),
      h('div', { class: 'row' }, h('button', { class: 'btn btn-secondary', type: 'button', disabled: current === 0, onclick: () => go(current - 1) }, 'Previous'), current < attempt.questions.length - 1 ? h('button', { class: 'btn', type: 'button', onclick: () => go(current + 1) }, 'Next') : h('button', { class: 'btn', type: 'button', onclick: confirmSubmit }, 'Review & submit'))));
}
function draw() { drawPalette(); drawQuestion(); mount(root, h('div', { class: 'exam' }, qbox, h('aside', { class: 'card stack' }, h('h2', { style: 'margin:0;font-size:1rem' }, 'Questions'), palette,
  h('p', { class: 'small muted', style: 'margin:0' }, 'Green = answered · Amber = marked for review'), h('button', { class: 'btn btn-secondary', type: 'button', onclick: confirmSubmit }, 'Submit now')))); root.focus({ preventScroll: true }); }
function confirmSubmit() {
  const left = attempt.questions.filter((x) => !answered(x)).length, review = attempt.questions.filter((x) => x.markedForReview).length;
  const m = openModal({ title: `Submit ${label.toLowerCase()}?`, body: h('div', { class: 'stack' }, h('p', null, left ? `${left} question${left > 1 ? 's are' : ' is'} unanswered.` : 'All questions are answered.'), review ? h('p', null, `${review} marked for review.`) : null, h('p', { class: 'muted small' }, 'You cannot change answers after submitting.')),
    actions: [{ label: 'Keep working', variant: 'secondary' }, { label: 'Submit', onClick: async () => { await finish(false); } }] });
}
async function finish(auto) {
  if (finished && !auto) return; finished = true; clearInterval(tick); clearInterval(autosave);
  try { const answers = attempt.questions.map((x) => ({ questionId: x.questionId, response: x.response ?? null, markedForReview: !!x.markedForReview, visited: !!x.visited })); const { data } = await studentApi.submit(kind, id, answers); result(data, auto); }
  catch (e) { if (e.status === 400 || e.status === 404) return ended(); finished = false; toast.error(`Could not submit: ${e.message}. Your answers are still here, try again.`); if (!auto) return false; setTimeout(() => finish(true), 5000); }
}
async function ended() { timer.hidden = true; try { const { data } = await studentApi.history(kind, id); const list = Array.isArray(data) ? data : data?.items || []; const last = list[list.length - 1]; if (last) return result({ title: label, status: last.status, submittedAt: last.submittedAt, score: last.grade?.score, totalMarks: last.grade?.totalMarks }, true); } catch { /* fall through */ }
  mount(root, h('div', { class: 'exam', style: 'grid-template-columns:1fr;max-width:640px' }, h('div', { class: 'card stack' }, h('h1', null, 'This attempt has ended'), h('p', null, 'Your answers were submitted.'), h('a', { class: 'btn', href: back }, 'Back to assessments')))); }
function result(r, auto) {
  timer.hidden = true; saveState.textContent = ''; const graded = r.status === 'graded' && r.score != null;
  mount(root, h('div', { class: 'exam', style: 'grid-template-columns:1fr;max-width:640px' }, h('section', { class: 'card stack' }, h('h1', null, auto ? 'Time is up. Your answers were submitted.' : 'Submitted'),
    graded ? h('div', { class: 'stat card' }, h('div', { class: 'value' }, `${r.score} / ${r.totalMarks}`), h('div', { class: 'label' }, r.percentage != null ? `${r.percentage}%${r.passed === true ? ' · Passed' : r.passed === false ? ' · Not passed' : ''}` : '')) : h('div', { class: 'banner info' }, 'Your teacher will mark the written answers. You will be notified when results are ready.'),
    r.feedback && h('p', null, r.feedback), r.submittedAt && h('p', { class: 'muted small' }, `Submitted ${fmtDateTime(r.submittedAt)}`), h('a', { class: 'btn', href: back }, 'Back to assessments'))));
}
