const { Payment, Subscription, Plan, DiscountCode } = require('../models/billing.model');
const { Course } = require('../models/course.model');
const subscriptionService = require('./subscriptionService');
const paymentService = require('./paymentService');
const pricingService = require('./pricingService');
const ApiError = require('../utils/ApiError');
const { toMinor, fromMinor } = require('../utils/money');

const GATEWAYS = ['paystack', 'flutterwave'];

function paginate(items, total, page, limit) {
  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

/* ------------------------------ payments ------------------------------ */

async function listPayments({ status, userId, provider, purpose, needsReview, page = 1, limit = 20 } = {}) {
  const filter = {};
  if (status) filter.status = status;
  if (userId) filter.userId = userId;
  if (provider) filter.provider = provider;
  if (purpose) filter.purpose = purpose;
  if (needsReview === 'true' || needsReview === true) filter.needsReview = true;

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    Payment.find(filter)
      .populate('userId', 'name email')
      .populate('courseId', 'title')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    Payment.countDocuments(filter)
  ]);
  return paginate(items, total, page, limit);
}

/**
 * Records an offline payment (bank transfer etc.). If it is `completed` and tied to a course or plan,
 * access is granted through the same idempotent fulfilment used for gateway payments.
 */
async function createManualPayment({ userId, courseId, planCode, amount, currency, providerReference, status, notes }) {
  const cur = String(currency || pricingService.platformCurrency()).toUpperCase();
  let purpose = null;
  let description = notes || 'Manual payment';
  const extra = {};

  if (courseId) {
    const course = await Course.findById(courseId);
    if (!course) throw ApiError.notFound('Course not found');
    purpose = 'course';
    description = `Course: ${course.title}`;
  } else if (planCode) {
    const plan = await Plan.findOne({ code: String(planCode).toLowerCase() });
    if (!plan) throw ApiError.notFound('Plan not found');
    purpose = 'subscription';
    description = `${plan.name} subscription (${plan.billingCycle})`;
    Object.assign(extra, { planId: plan._id, planCode: plan.code, billingCycle: plan.billingCycle, periodMonths: plan.periodMonths });
  }

  const minor = toMinor(amount, cur);
  const payment = await Payment.create({
    userId,
    courseId: courseId || null,
    purpose,
    ...extra,
    description,
    amount: fromMinor(minor, cur),
    amountMinor: minor,
    originalAmountMinor: minor,
    currency: cur,
    provider: 'manual',
    reference: paymentService.newReference('MAN'),
    providerReference: providerReference || null,
    status: 'pending',
    notes: notes || ''
  });

  const wanted = status || 'completed';
  if (wanted === 'completed') return paymentService.settleManually(payment);
  if (wanted === 'failed') return paymentService.failPayment(payment, 'recorded_as_failed');
  if (wanted === 'refunded') throw ApiError.badRequest('Create the payment as completed first, then refund it');
  return payment;
}

async function updatePaymentStatus(payment, status) {
  const validTransitions = {
    pending: ['completed', 'failed'],
    completed: ['refunded'],
    failed: [],
    refunded: []
  };
  if (!validTransitions[payment.status].includes(status)) {
    throw ApiError.badRequest(`Cannot transition a payment from "${payment.status}" to "${status}"`);
  }
  // Gateway money is only ever confirmed by the gateway's API. An admin click must not be able to
  // mark a card payment as paid (or failed): use "re-verify" instead.
  if (GATEWAYS.includes(payment.provider) && status !== 'refunded') {
    throw ApiError.badRequest('Gateway payments cannot be changed manually. Use "Verify" to re-check with the provider.');
  }

  if (status === 'completed') return paymentService.settleManually(payment);
  if (status === 'failed') return paymentService.failPayment(payment, 'marked_failed_by_admin');
  // refunded: record + revoke access. (This does not move money; refund through the gateway dashboard.)
  return paymentService.markRefunded(payment);
}

async function adminVerifyPayment(payment) {
  if (!GATEWAYS.includes(payment.provider)) throw ApiError.badRequest('Only gateway payments can be verified with a provider');
  const result = await paymentService.confirmPayment(payment.reference);
  return result || payment;
}

/* ---------------------------- subscriptions ---------------------------- */

async function listSubscriptions({ status, userId, page = 1, limit = 20 } = {}) {
  const filter = {};
  if (status) filter.status = status;
  if (userId) filter.userId = userId;

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    Subscription.find(filter).populate('userId', 'name email').sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Subscription.countDocuments(filter)
  ]);
  return paginate(items, total, page, limit);
}

async function createSubscription({ userId, plan, amount, currency, startDate, endDate, autoRenew }) {
  try {
    return await Subscription.create({
      userId,
      plan,
      amount,
      currency: currency || 'USD',
      source: 'admin',
      startDate: startDate || new Date(),
      endDate,
      autoRenew: !!autoRenew
    });
  } catch (err) {
    if (err.code === 11000) throw ApiError.conflict('This user already has an active subscription. Extend it instead.');
    throw err;
  }
}

async function cancelSubscription(subscription) {
  if (!['active', 'trialing'].includes(subscription.status)) {
    throw ApiError.badRequest('Only an active or trialing subscription can be cancelled');
  }
  subscription.status = 'cancelled';
  subscription.cancelledAt = new Date();
  subscription.autoRenew = false;
  await subscription.save();
  return subscription;
}

async function extendSubscription(subscription, newEndDate) {
  if (new Date(newEndDate) <= subscription.endDate) {
    throw ApiError.badRequest('New end date must be after the current end date');
  }
  subscription.endDate = newEndDate;
  if (subscription.status === 'expired') subscription.status = 'active';
  subscription.reminder3dSentAt = null;
  subscription.reminder1dSentAt = null;
  try {
    await subscription.save();
  } catch (err) {
    if (err.code === 11000) throw ApiError.conflict('This user already has another active subscription');
    throw err;
  }
  return subscription;
}

const expireOverdueSubscriptions = () => subscriptionService.expireOverdueSubscriptions();

/* -------------------------------- plans -------------------------------- */

async function listPlans({ activeOnly = false } = {}) {
  return Plan.find(activeOnly ? { active: true } : {}).sort({ sortOrder: 1, createdAt: 1 });
}

async function createPlan(data) {
  const periodMonths = data.billingCycle === 'annual' ? 12 : 1;
  try {
    return await Plan.create({
      code: data.code,
      name: data.name,
      description: data.description || '',
      billingCycle: data.billingCycle,
      periodMonths,
      prices: data.prices.map((p) => ({ currency: p.currency, amountMinor: p.amountMinor })),
      trialDays: data.trialDays || 0,
      features: data.features || [],
      active: data.active !== false,
      sortOrder: data.sortOrder || 0
    });
  } catch (err) {
    if (err.code === 11000) throw ApiError.conflict('A plan with this code already exists');
    throw err;
  }
}

async function updatePlan(id, updates) {
  const plan = await Plan.findById(id);
  if (!plan) throw ApiError.notFound('Plan not found');
  // Code and billing cycle are fixed: existing payments and subscriptions refer to them. Prices can change
  // (past payments keep their own snapshot), or retire the plan with active=false.
  for (const f of ['name', 'description', 'prices', 'trialDays', 'features', 'active', 'sortOrder']) {
    if (updates[f] !== undefined) plan[f] = updates[f];
  }
  await plan.save();
  return plan;
}

/* ---------------------------- discount codes ---------------------------- */

async function listDiscountCodes({ page = 1, limit = 20 } = {}) {
  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    DiscountCode.find({}).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    DiscountCode.countDocuments({})
  ]);
  return paginate(items, total, page, limit);
}

async function createDiscountCode(data, adminId) {
  if (data.type === 'percent' && !data.percentOff) throw ApiError.badRequest('percentOff is required for percent codes');
  if (data.type === 'fixed' && !(data.fixedAmounts || []).length) throw ApiError.badRequest('fixedAmounts is required for fixed codes');
  try {
    return await DiscountCode.create({ ...data, createdBy: adminId });
  } catch (err) {
    if (err.code === 11000) throw ApiError.conflict('A discount code with this name already exists');
    throw err;
  }
}

async function updateDiscountCode(id, updates) {
  const code = await DiscountCode.findById(id);
  if (!code) throw ApiError.notFound('Discount code not found');
  // type / percentOff / fixedAmounts are immutable once created: issue a new code instead, so redemption
  // history always matches what the customer was promised.
  for (const f of ['description', 'active', 'validFrom', 'validUntil', 'maxRedemptions', 'perUserLimit', 'courseIds', 'planCodes', 'appliesTo', 'maxDiscountMinor']) {
    if (updates[f] !== undefined) code[f] = updates[f];
  }
  await code.save();
  return code;
}

module.exports = {
  listPayments,
  createManualPayment,
  updatePaymentStatus,
  adminVerifyPayment,
  listSubscriptions,
  createSubscription,
  cancelSubscription,
  extendSubscription,
  expireOverdueSubscriptions,
  listPlans,
  createPlan,
  updatePlan,
  listDiscountCodes,
  createDiscountCode,
  updateDiscountCode
};
