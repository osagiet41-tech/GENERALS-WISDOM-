#!/usr/bin/env node
/* Static PWA validation: manifest fields, icons on disk, every page linked to the manifest + registering the service worker,
   precache list complete and pointing at real files, sw.js up to date with the sources. Exit code 1 on any problem. */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = path.join(__dirname, '..', 'frontend');
const problems = [];
const need = (cond, msg) => { if (!cond) problems.push(msg); };

const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
for (const k of ['name', 'short_name', 'start_url', 'display', 'background_color', 'theme_color', 'icons']) need(manifest[k], `manifest.json is missing "${k}"`);
need(manifest.display === 'standalone', 'manifest display should be standalone (installable)');
const sizes = new Set((manifest.icons || []).map((i) => i.sizes));
need(sizes.has('192x192') && sizes.has('512x512'), 'manifest needs 192x192 and 512x512 icons');
need((manifest.icons || []).some((i) => /maskable/.test(i.purpose || '')), 'manifest needs a maskable icon');
for (const i of manifest.icons || []) need(fs.existsSync(path.join(root, i.src)), `icon file missing: ${i.src}`);

for (const page of fs.readdirSync(root).filter((f) => f.endsWith('.html') && f !== 'offline.html')) {
  const html = fs.readFileSync(path.join(root, page), 'utf8');
  need(html.includes('rel="manifest"'), `${page}: no <link rel="manifest">`);
  need(html.includes('js/pwa.js'), `${page}: does not load js/pwa.js (service worker registration)`);
  need(/name="viewport"[^>]*viewport-fit=cover/.test(html), `${page}: viewport meta missing viewport-fit=cover`);
  need(html.includes('name="theme-color"'), `${page}: no theme-color`);
}
need(fs.existsSync(path.join(root, 'offline.html')), 'offline.html missing');

const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
const list = JSON.parse(/const PRECACHE = (\[[\s\S]*?\]);/.exec(sw)[1]);
for (const u of list) need(u === './' || fs.existsSync(path.join(root, u.replace(/^\.\//, ''))), `precache entry does not exist: ${u}`);
for (const must of ['./offline.html', './manifest.json', './index.html', './js/pwa.js', './css/base.css']) need(list.includes(must), `precache is missing ${must}`);
need(!list.includes('./config.js'), 'config.js must not be precached (it is edited per deployment)');
need(!/__VERSION__|__PRECACHE__/.test(sw), 'sw.js still contains template placeholders: run `npm run build`');

// sw.js must be current: regenerate into memory and compare versions
const before = /const VERSION = '([a-f0-9]+)'/.exec(sw)[1];
execFileSync(process.execPath, [path.join(__dirname, 'build-pwa.js')], { stdio: 'pipe' });
const after = /const VERSION = '([a-f0-9]+)'/.exec(fs.readFileSync(path.join(root, 'sw.js'), 'utf8'))[1];
need(before === after, `sw.js was stale (${before} -> ${after}); it has been regenerated, commit the new file`);

if (problems.length) { problems.forEach((p) => console.log(`PWA problem: ${p}`)); process.exit(1); }
console.log(`PWA check passed: ${list.length} precached files, manifest valid, ${fs.readdirSync(root).filter((f) => f.endsWith('.html')).length} pages wired.`);
