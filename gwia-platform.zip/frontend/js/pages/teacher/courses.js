import { h, icon } from '../../core/dom.js';
import { teacherApi } from '../../api/teacher.js';
import { pageHead, items, idOf } from '../../ui/page.js';
import { empty } from '../../ui/states.js';
import { dataTable, statusBadge } from '../../ui/table.js';
import { openModal, confirmDialog } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { searchBox } from '../../ui/search.js';
import { toast } from '../../ui/toast.js';
import { fmtMoney } from '../../core/format.js';

export default async function render({ navigate }) {
  const { data } = await teacherApi.courses(); const all = items(data); let term = ''; const holder = h('div', { class: 'card card-flush' });
  const reload = () => navigate('#/courses?r=' + Date.now());
  const draw = () => holder.replaceChildren(dataTable({ rows: all.filter((c) => c.title.toLowerCase().includes(term.toLowerCase())), caption: 'My courses', emptyState: empty({ title: all.length ? 'No match' : 'No courses yet', message: all.length ? '' : 'Use “New course” to create one.', iconName: 'book' }),
    columns: [{ label: 'Title', render: (r) => h('div', null, h('strong', null, r.title), h('div', { class: 'small muted' }, `ID ${idOf(r)}`)) }, { label: 'Status', render: (r) => statusBadge(r.status) }, { label: 'Price', render: (r) => (r.price ? fmtMoney(r.price, r.currency || undefined) : 'Free') }, { label: 'Students', render: (r) => r.enrolledStudentIds?.length ?? 0 }],
    actions: (r) => h('div', { class: 'row', style: 'justify-content:flex-end' }, h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: () => edit(r) }, icon('edit'), 'Edit'),
      h('button', { class: 'btn btn-ghost btn-sm btn-icon', type: 'button', 'aria-label': `Delete ${r.title}`, onclick: async () => { if (await confirmDialog({ title: 'Delete course?', message: `“${r.title}” and its content will be removed.`, confirmLabel: 'Delete', danger: true })) { try { await teacherApi.deleteCourse(idOf(r)); toast.success('Course deleted.'); reload(); } catch (e) { toast.error(e.message); } } } }, icon('trash'))) }));
  const edit = (c) => {
    const cert = c?.certificate || {};
    const form = buildForm({ submitLabel: c ? 'Save course' : 'Create course', onCancel: () => m.close(), fields: [
      { name: 'title', label: 'Title', required: true, value: c?.title, maxlength: 200, full: true }, { name: 'description', label: 'Description', type: 'textarea', value: c?.description, full: true, maxlength: 5000 },
      { name: 'category', label: 'Category', value: c?.category }, { name: 'level', label: 'Level', type: 'select', value: c?.level || 'beginner', options: ['beginner', 'intermediate', 'advanced'].map((v) => ({ value: v, label: v })) },
      { name: 'price', label: 'Price (0 = free)', type: 'number', min: 0, step: '0.01', value: c?.price ?? 0 }, { name: 'currency', label: 'Currency (3 letters, blank = platform default)', value: c?.currency, maxlength: 3 },
      { name: 'durationHours', label: 'Duration (hours)', type: 'number', min: 0, step: '0.5', value: c?.durationHours }, ...(c ? [{ name: 'status', label: 'Status', type: 'select', value: c.status, options: ['draft', 'published', 'archived'].map((v) => ({ value: v, label: v })) }] : []),
      { name: 'includedInSubscription', label: 'Included in subscription plans', type: 'checkbox', value: c?.includedInSubscription ?? true, full: true },
      { name: 'certEnabled', label: 'Issue certificates', type: 'checkbox', value: cert.enabled ?? true }, { name: 'certLessons', label: 'Min lessons completed (%)', type: 'number', min: 1, max: 100, value: cert.minLessonCompletionPercent ?? 100 },
      { name: 'certScore', label: 'Min average score (%)', type: 'number', min: 0, max: 100, value: cert.minAverageScorePercent ?? 50, hint: 'Leave blank to ignore scores.' }, { name: 'certAttendance', label: 'Min attendance (%)', type: 'number', min: 0, max: 100, value: cert.minAttendancePercent, hint: 'Blank = not required.' },
      { name: 'certAll', label: 'Require every assessment graded', type: 'checkbox', value: cert.requireAllAssessments }, { name: 'certShow', label: 'Print final score on certificate', type: 'checkbox', value: cert.showScore }],
      onSubmit: async (v) => {
        const body = { title: v.title, description: v.description, category: v.category, level: v.level, price: v.price ?? 0, durationHours: v.durationHours, status: v.status, includedInSubscription: v.includedInSubscription,
          ...(v.currency ? { currency: v.currency.toUpperCase() } : {}), certificate: { enabled: v.certEnabled, minLessonCompletionPercent: v.certLessons ?? 100, minAverageScorePercent: v.certScore ?? null, minAttendancePercent: v.certAttendance ?? null, requireAllAssessments: v.certAll, showScore: v.certShow } };
        Object.keys(body).forEach((k) => body[k] === undefined && delete body[k]);
        c ? await teacherApi.updateCourse(idOf(c), body) : await teacherApi.createCourse(body); m.close(); toast.success(c ? 'Course saved.' : 'Course created.'); reload();
      } });
    const m = openModal({ title: c ? 'Edit course' : 'New course', size: 'lg', body: form });
  };
  draw();
  return h('div', { class: 'stack' }, pageHead('My courses', `${all.length} course${all.length === 1 ? '' : 's'}`, h('button', { class: 'btn', type: 'button', onclick: () => edit(null) }, icon('plus'), 'New course')), searchBox({ placeholder: 'Search courses…', onSearch: (t) => { term = t; draw(); } }), holder);
}
