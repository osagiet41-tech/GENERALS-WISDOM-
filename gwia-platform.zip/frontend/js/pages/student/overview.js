import { h } from '../../core/dom.js';
import { studentApi } from '../../api/student.js';
import { pageHead, statCard, card } from '../../ui/page.js';
import { fmtDateTime, fmtDate, fmtPercent } from '../../core/format.js';
import { empty } from '../../ui/states.js';
import { statusBadge } from '../../ui/table.js';

const linkTo = (text, href) => h('a', { href }, text);
export default async function render({ shell }) {
  const { data: d } = await studentApi.dashboard();
  shell.setBadge('live', d.upcomingLiveClasses?.length || 0);
  const list = (rows, row, emptyTitle) => rows?.length ? h('ul', { class: 'list' }, rows.map(row)) : empty({ title: emptyTitle });
  return h('div', { class: 'stack' },
    pageHead(d.welcome.message, 'Here is what needs your attention.'),
    h('div', { class: 'grid grid-stats' }, statCard('Courses enrolled', d.learningProgress.enrolledCourseCount), statCard('Overall progress', fmtPercent(d.learningProgress.completionPercent), `${d.learningProgress.lessonsCompleted} of ${d.learningProgress.lessonsTotal} lessons`),
      statCard('Attendance', fmtPercent(d.attendance.ratePercent), `${d.attendance.present} of ${d.attendance.totalSessions} sessions`), statCard('Certificates', d.certificates?.length || 0), statCard('Unread messages', d.messages?.unreadConversationCount || 0)),
    h('div', { class: 'grid grid-2' },
      card('Continue learning', list(d.currentLessons, (c) => h('li', null, h('div', null, h('strong', null, c.lesson.title), h('div', { class: 'small muted' }, c.courseTitle)), h('a', { class: 'btn btn-sm', href: `learn.html?course=${c.courseId}&lesson=${c.lesson._id}` }, 'Resume')), 'No unfinished lessons. Enrol in a course to begin.')),
      card('Live classes this week', list(d.upcomingLiveClasses, (c) => h('li', null, h('div', null, h('strong', null, c.title), h('div', { class: 'small muted' }, fmtDateTime(c.scheduledAt))), linkTo('Open', '#/live')), 'No live classes scheduled.')),
      card('Open assignments', list(d.assignments, (a) => h('li', null, h('div', null, h('strong', null, a.title), h('div', { class: 'small muted' }, `Due ${fmtDateTime(a.dueDate)}`)), linkTo('Go', '#/work')), 'Nothing due. Nice.')),
      card('Quizzes & exams open', list([...(d.quizzes || []).map((x) => ({ ...x, k: 'quizzes' })), ...(d.examinations || []).map((x) => ({ ...x, k: 'exams' }))], (a) => h('li', null, h('div', null, h('strong', null, a.title), h('div', { class: 'small muted' }, `${a.k === 'exams' ? 'Exam' : 'Quiz'} · closes ${fmtDateTime(a.availableUntil)}`)), linkTo('View', '#/work')), 'No open quizzes or exams.')),
      card('Recent grades', list(d.recentGrades, (g) => h('li', null, h('span', null, `${g.refType} · ${fmtDate(g.gradedAt)}`), h('strong', null, `${g.score} / ${g.totalMarks}`)), 'No graded work yet.')),
      card('Notifications', list(d.notifications?.recent, (n) => h('li', null, h('div', null, h('strong', null, n.title), h('div', { class: 'small muted' }, n.message)), !n.read && statusBadge('new')), 'No notifications.'))));
}
