const express = require('express');
const { body } = require('express-validator');
const { authMiddleware } = require('../middleware/authMiddleware');
const validate = require('../middleware/validate.middleware');
const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const env = require('../config/env');
const pushService = require('../services/pushService');

const router = express.Router();

// Public key is meant to be public: the browser needs it to subscribe.
router.get('/public-key', (req, res) => ApiResponse.ok(res, { enabled: pushService.isEnabled(), publicKey: env.push.publicKey }, 'Push configuration'));

router.use(authMiddleware);

router.post(
  '/subscribe',
  validate([
    body('endpoint').isString().isLength({ min: 10, max: 1000 }),
    body('kind').optional().isIn(['webpush', 'fcm']),
    body('keys.p256dh').if(body('kind').not().equals('fcm')).isString().isLength({ max: 200 }),
    body('keys.auth').if(body('kind').not().equals('fcm')).isString().isLength({ max: 100 })
  ]),
  asyncHandler(async (req, res) => {
    const { endpoint, keys, kind } = req.body;
    // Web Push endpoints are always https URLs on the browser vendor's push service.
    if ((kind || 'webpush') === 'webpush' && !/^https:\/\//.test(endpoint)) {
      return res.status(400).json({ success: false, message: 'Invalid push endpoint' });
    }
    await pushService.subscribe(req.user.id, { kind, endpoint, keys, userAgent: (req.get('user-agent') || '').slice(0, 300) });
    return ApiResponse.ok(res, null, 'Subscribed to notifications');
  })
);

router.post(
  '/unsubscribe',
  validate([body('endpoint').isString().isLength({ min: 10, max: 1000 })]),
  asyncHandler(async (req, res) => {
    await pushService.unsubscribe(req.user.id, req.body.endpoint);
    return ApiResponse.ok(res, null, 'Unsubscribed');
  })
);

module.exports = router;
