const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const assessmentService = require('../services/assessmentService');
const examResultService = require('../services/examResultService');

const KIND = 'exam';

// POST /api/courses/:courseId/exams
const createExam = asyncHandler(async (req, res) => {
  const exam = await assessmentService.createAssessment(KIND, req.course._id, req.user.id, req.body);
  return ApiResponse.created(res, exam, 'Exam created successfully');
});

// GET /api/courses/:courseId/exams
const listExams = asyncHandler(async (req, res) => {
  const exams = await assessmentService.listAssessments(KIND, req.course._id, req.query.status);
  return ApiResponse.ok(res, exams, 'Exams retrieved');
});

// GET /api/exams/:id
const getExam = asyncHandler(async (req, res) => {
  const exam = await assessmentService.getAssessmentWithAnswerKey(req.resource);
  return ApiResponse.ok(res, exam, 'Exam retrieved');
});

// PUT /api/exams/:id
const updateExam = asyncHandler(async (req, res) => {
  const exam = await assessmentService.updateAssessment(req.resource, req.body);
  return ApiResponse.ok(res, exam, 'Exam updated successfully');
});

// DELETE /api/exams/:id
const deleteExam = asyncHandler(async (req, res) => {
  await assessmentService.deleteAssessment(req.resource);
  return ApiResponse.ok(res, null, 'Exam deleted successfully');
});

// GET /api/exams/:id/results — every student's attempt(s) for this exam (gradebook view)
const getResults = asyncHandler(async (req, res) => {
  const results = await examResultService.getAllResultsForAssessment(req.resource);
  return ApiResponse.ok(res, results, 'Exam results retrieved');
});

module.exports = { createExam, listExams, getExam, updateExam, deleteExam, getResults };
