const Submission = require('../models/submission.model');
const Assignment = require('../models/assignment.model');
const ApiError = require('../utils/ApiError');

async function listAssignments(courseId) {
  return Assignment.find({ courseId, status: 'published' }).sort({ dueDate: 1 });
}

async function submitAssignment(assignment, studentId, { textAnswer, files }) {
  const now = new Date();
  const isLate = now > assignment.dueDate;

  if (isLate && !assignment.allowLateSubmission) {
    throw ApiError.badRequest('The due date for this assignment has passed and late submissions are not allowed');
  }

  const existing = await Submission.findOne({ refType: 'assignment', refId: assignment._id, studentId });
  if (existing) {
    if (existing.status === 'graded') {
      throw ApiError.conflict('This assignment has already been graded and cannot be resubmitted');
    }
    if (!assignment.allowResubmission) {
      throw ApiError.forbidden('Resubmission is not allowed for this assignment');
    }
    existing.textAnswer = textAnswer || existing.textAnswer;
    existing.files = files.length > 0 ? files : existing.files;
    existing.submittedAt = now;
    existing.isLate = isLate;
    await existing.save();
    return existing;
  }

  return Submission.create({
    refType: 'assignment',
    refId: assignment._id,
    courseId: assignment.courseId,
    studentId,
    textAnswer: textAnswer || null,
    files,
    submittedAt: now,
    isLate
  });
}

module.exports = { listAssignments, submitAssignment };
