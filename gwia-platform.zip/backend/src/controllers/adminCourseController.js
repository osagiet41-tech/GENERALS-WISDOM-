const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const adminCourseService = require('../services/adminCourseService');
const auditLogService = require('../services/auditLogService');

const listCourses = asyncHandler(async (req, res) => {
  const { status, category, search, page, limit } = req.query;
  const result = await adminCourseService.listCourses({ status, category, search, page, limit });
  return ApiResponse.ok(res, result.items, 'Courses retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

const getCourse = asyncHandler(async (req, res) => {
  const detail = await adminCourseService.getCourseDetail(req.params.id);
  return ApiResponse.ok(res, detail, 'Course detail retrieved');
});

const updateCourseStatus = asyncHandler(async (req, res) => {
  const course = await adminCourseService.updateCourseStatus(req.params.id, req.body.status);
  await auditLogService.record(
    req.user.id,
    'course.status_change',
    'Course',
    req.params.id,
    { newStatus: req.body.status },
    req.ip
  );
  return ApiResponse.ok(res, course, 'Course status updated');
});

const listSubjects = asyncHandler(async (req, res) => {
  const { courseId, page, limit } = req.query;
  const result = await adminCourseService.listSubjects({ courseId, page, limit });
  return ApiResponse.ok(res, result.items, 'Subjects retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

module.exports = { listCourses, getCourse, updateCourseStatus, listSubjects };
