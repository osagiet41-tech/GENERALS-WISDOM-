const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const forumService = require('../services/forumService');

// POST /api/courses/:courseId/forum/posts
const createPost = asyncHandler(async (req, res) => {
  const post = await forumService.createPost(req.course._id, req.user, req.body);
  return ApiResponse.created(res, post, 'Post created successfully');
});

// GET /api/courses/:courseId/forum/posts
const listPosts = asyncHandler(async (req, res) => {
  const { type, page, limit, sort } = req.query;
  const result = await forumService.listPosts(req.course._id, { type, page, limit, sort, isModerator: req.isForumModerator });
  return ApiResponse.ok(res, result.items, 'Posts retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

// GET /api/courses/:courseId/forum/search?q=
const searchPosts = asyncHandler(async (req, res) => {
  const { q, page, limit } = req.query;
  const result = await forumService.searchPosts(req.course._id, q, { page, limit, isModerator: req.isForumModerator });
  return ApiResponse.ok(res, result.items, 'Search results retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

// GET /api/forum-posts/:id
const getPost = asyncHandler(async (req, res) => {
  return ApiResponse.ok(res, req.post, 'Post retrieved');
});

// GET /api/forum-posts/:id/replies
const listReplies = asyncHandler(async (req, res) => {
  const { page, limit } = req.query;
  const result = await forumService.listReplies(req.post._id, { page, limit, isModerator: req.isForumModerator });
  return ApiResponse.ok(res, result.items, 'Replies retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

// POST /api/forum-posts/:id/replies
const createReply = asyncHandler(async (req, res) => {
  const reply = await forumService.createReply(req.post, req.user, req.body);
  return ApiResponse.created(res, reply, 'Reply posted successfully');
});

// PUT /api/forum-posts/:id
const editPost = asyncHandler(async (req, res) => {
  const post = await forumService.editPost(req.post, req.user, req.body);
  return ApiResponse.ok(res, post, 'Post updated successfully');
});

// DELETE /api/forum-posts/:id
const deletePost = asyncHandler(async (req, res) => {
  await forumService.deletePost(req.post, req.user, req.isForumModerator);
  return ApiResponse.ok(res, null, 'Post deleted successfully');
});

// POST /api/forum-posts/:id/like
const toggleLike = asyncHandler(async (req, res) => {
  const result = await forumService.toggleLike(req.post, req.user.id);
  return ApiResponse.ok(res, result, result.liked ? 'Post liked' : 'Like removed');
});

// POST /api/forum-posts/:id/report
const reportPost = asyncHandler(async (req, res) => {
  const report = await forumService.reportPost(req.post, req.user.id, req.body);
  return ApiResponse.created(res, report, 'Post reported. A teacher will review it.');
});

function requireModerator(req) {
  if (!req.isForumModerator) {
    throw ApiError.forbidden('Only a teacher of this course or an admin can perform this action');
  }
}

const pinPost = asyncHandler(async (req, res) => {
  requireModerator(req);
  const post = await forumService.setPinned(req.post, true);
  return ApiResponse.ok(res, post, 'Post pinned');
});

const unpinPost = asyncHandler(async (req, res) => {
  requireModerator(req);
  const post = await forumService.setPinned(req.post, false);
  return ApiResponse.ok(res, post, 'Post unpinned');
});

const lockPost = asyncHandler(async (req, res) => {
  requireModerator(req);
  const post = await forumService.setLocked(req.post, true);
  return ApiResponse.ok(res, post, 'Post locked');
});

const unlockPost = asyncHandler(async (req, res) => {
  requireModerator(req);
  const post = await forumService.setLocked(req.post, false);
  return ApiResponse.ok(res, post, 'Post unlocked');
});

const hidePost = asyncHandler(async (req, res) => {
  requireModerator(req);
  const post = await forumService.setHidden(req.post, true, req.user.id, req.body.reason);
  return ApiResponse.ok(res, post, 'Post hidden');
});

const unhidePost = asyncHandler(async (req, res) => {
  requireModerator(req);
  const post = await forumService.setHidden(req.post, false, req.user.id, null);
  return ApiResponse.ok(res, post, 'Post unhidden');
});

// GET /api/courses/:courseId/forum/reports
const listReports = asyncHandler(async (req, res) => {
  requireModerator(req);
  const { status, page, limit } = req.query;
  const result = await forumService.listReports(req.course._id, { status, page, limit });
  return ApiResponse.ok(res, result.items, 'Reports retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

// PUT /api/forum-reports/:reportId/review  { action: 'dismiss'|'hide'|'delete' }
const reviewReport = asyncHandler(async (req, res) => {
  requireModerator(req);
  const report = await forumService.reviewReport(req.report, req.user.id, req.body.action);
  return ApiResponse.ok(res, report, 'Report reviewed');
});

module.exports = {
  createPost,
  listPosts,
  searchPosts,
  getPost,
  listReplies,
  createReply,
  editPost,
  deletePost,
  toggleLike,
  reportPost,
  pinPost,
  unpinPost,
  lockPost,
  unlockPost,
  hidePost,
  unhidePost,
  listReports,
  reviewReport
};
