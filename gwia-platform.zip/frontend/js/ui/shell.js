import { h, icon, mount, $ } from '../core/dom.js';
import { session, redirectToLogin } from '../core/session.js';
import { api } from '../core/http.js';
import { config } from '../core/config.js';
import { toggleTheme, currentTheme } from '../core/theme.js';
import { initials, relTime } from '../core/format.js';
import { errorState, loading } from './states.js';
import { toast } from './toast.js';
import { pushState, enablePush, disablePush, canInstall, install } from '../pwa.js';

export async function logout() {
  try { await api.post('/auth/logout', { refreshToken: session.refreshToken }); } catch { /* token may already be invalid; still sign out locally */ }
  session.clear(); location.replace('auth.html?mode=login');
}
const themeBtn = () => {
  const b = h('button', { class: 'btn btn-ghost btn-icon', type: 'button', 'aria-label': 'Toggle dark mode' });
  const paint = () => { b.replaceChildren(icon(currentTheme() === 'dark' ? 'sun' : 'moon')); b.setAttribute('aria-pressed', currentTheme() === 'dark'); };
  b.addEventListener('click', toggleTheme); document.addEventListener('themechange', paint); paint(); return b;
};

function notificationBell() {
  const count = h('span', { class: 'badge-count hidden', style: 'position:absolute;top:2px;right:2px' }); const wrap = h('div', { style: 'position:relative' });
  const btn = h('button', { class: 'btn btn-ghost btn-icon', type: 'button', 'aria-label': 'Notifications', 'aria-haspopup': 'true', 'aria-expanded': 'false' }, icon('bell'), count);
  let menu = null; const closeMenu = () => { menu?.remove(); menu = null; btn.setAttribute('aria-expanded', 'false'); };
  async function refresh() { try { const { meta } = await api.get('/notifications', { limit: 1, unreadOnly: true }); const n = meta?.unreadCount || 0; count.textContent = n > 99 ? '99+' : n; count.classList.toggle('hidden', !n); } catch { /* bell is non-critical */ } }
  btn.addEventListener('click', async () => {
    if (menu) return closeMenu();
    menu = h('div', { class: 'menu', style: 'min-width:min(340px,92vw)', role: 'menu' }, loading(3)); wrap.append(menu); btn.setAttribute('aria-expanded', 'true');
    try {
      const { data } = await api.get('/notifications', { limit: 8 });
      mount(menu, h('div', { class: 'menu-head spread' }, h('strong', null, 'Notifications'), h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: async () => { await api.put('/notifications/read-all'); refresh(); closeMenu(); } }, 'Mark all read')),
        data.length ? data.map((n) => h('button', { type: 'button', role: 'menuitem', onclick: async () => { if (!n.read) { await api.put(`/notifications/${n._id}/read`).catch(() => {}); refresh(); } closeMenu(); } },
          h('span', { style: 'flex:1;min-width:0' }, h('strong', { class: 'small' }, n.title || 'Notification'), h('br'), h('span', { class: 'small muted' }, n.message || ''), h('br'), h('span', { class: 'small muted' }, relTime(n.createdAt))), !n.read && h('span', { class: 'dot on', title: 'Unread' })))
          : h('p', { class: 'muted small', style: 'padding:12px' }, 'You are all caught up.'));
    } catch (e) { mount(menu, errorState(e)); }
  });
  document.addEventListener('click', (e) => { if (menu && !wrap.contains(e.target)) closeMenu(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && menu) { closeMenu(); btn.focus(); } });
  refresh(); setInterval(refresh, 60000); wrap.append(btn); return wrap;
}

function userMenu(user) {
  const wrap = h('div', { style: 'position:relative' }); let menu = null;
  const btn = h('button', { class: 'btn btn-ghost', type: 'button', 'aria-haspopup': 'true', 'aria-expanded': 'false' }, h('span', { class: 'avatar', 'aria-hidden': 'true' }, initials(user.name)), h('span', { class: 'small', style: 'max-width:140px;overflow:hidden;text-overflow:ellipsis' }, user.name));
  const close = () => { menu?.remove(); menu = null; btn.setAttribute('aria-expanded', 'false'); };
  btn.addEventListener('click', () => {
    if (menu) return close();
    const extras = h('div');
    menu = h('div', { class: 'menu', role: 'menu' }, h('div', { class: 'menu-head' }, h('strong', null, user.name), h('div', { class: 'small muted' }, user.email), h('div', { class: 'small muted' }, user.role)),
      h('a', { href: `${location.pathname.split('/').pop()}#/profile`, role: 'menuitem', onclick: close }, icon('settings'), 'Profile & password'),
      extras,
      h('button', { type: 'button', role: 'menuitem', onclick: logout }, icon('logout'), 'Sign out'));
    wrap.append(menu); btn.setAttribute('aria-expanded', 'true');
    /* App features that depend on the browser: shown only when they can work. */
    if (canInstall()) extras.append(h('button', { type: 'button', role: 'menuitem', onclick: async () => { close(); await install(); } }, icon('download'), 'Install app'));
    pushState().then((st) => {
      if (st === 'off') extras.append(h('button', { type: 'button', role: 'menuitem', onclick: async () => { close(); try { await enablePush(); toast.success('Notifications turned on for this device.'); } catch (e) { toast.error(e.message); } } }, icon('bell'), 'Turn on notifications'));
      if (st === 'on') extras.append(h('button', { type: 'button', role: 'menuitem', onclick: async () => { close(); await disablePush(); toast.info('Notifications turned off for this device.'); } }, icon('bell'), 'Turn off notifications'));
    }).catch(() => {});
  });
  document.addEventListener('click', (e) => { if (menu && !wrap.contains(e.target)) close(); });
  wrap.append(btn); return wrap;
}

/* Dashboard shell: sidebar (drawer on mobile) + top bar + <main>. Hash router lives in router.js. */
export function createShell({ user, nav, root = document.body, title = config.institution }) {
  const sidebar = h('aside', { class: 'sidebar', id: 'sidebar', 'aria-label': 'Primary' });
  const scrim = h('div', { class: 'scrim hidden' });
  const toggle = h('button', { class: 'btn btn-ghost btn-icon menu-toggle', type: 'button', 'aria-label': 'Open menu', 'aria-controls': 'sidebar', 'aria-expanded': 'false' }, icon('menu'));
  const setOpen = (o) => { sidebar.dataset.open = o; scrim.classList.toggle('hidden', !o); toggle.setAttribute('aria-expanded', o); };
  toggle.addEventListener('click', () => setOpen(sidebar.dataset.open !== 'true')); scrim.addEventListener('click', () => setOpen(false));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOpen(false); });
  const links = new Map();
  const list = h('ul', { class: 'nav' }, nav.map((n) => {
    const a = h('a', { href: n.href || `#/${n.id}`, ...(n.href && { target: null }) }, icon(n.icon), h('span', null, n.label)); links.set(n.id, a);
    a.addEventListener('click', () => setOpen(false)); return h('li', null, a);
  }));
  mount(sidebar, h('a', { class: 'brand', href: 'index.html' }, h('span', { class: 'seal', 'aria-hidden': 'true' }, 'GW'), h('span', null, title)), h('nav', { 'aria-label': 'Sections' }, list),
    h('div', { class: 'sidebar-foot' }, `Signed in as ${user.role}`));
  /* Mobile bottom navigation: the first four sections plus "More" (opens the full menu). Hidden on desktop by CSS. */
  const bottomLinks = new Map();
  const bottom = h('nav', { class: 'bottom-nav', 'aria-label': 'Quick navigation' },
    nav.slice(0, 4).map((n) => { const a = h('a', { href: n.href || `#/${n.id}` }, icon(n.icon), h('span', null, (n.label.split(/[ &]/)[0]) || n.label)); bottomLinks.set(n.id, a); return a; }),
    h('button', { type: 'button', 'aria-label': 'More sections', onclick: () => setOpen(true) }, icon('menu'), h('span', null, 'More')));
  const main = h('main', { class: 'main', id: 'main', tabindex: '-1' });
  const topbar = h('header', { class: 'topbar' }, toggle, h('span', { class: 'brand-mini' }, title), h('span', { class: 'spacer' }), themeBtn(), notificationBell(), userMenu(user));
  root.append(h('a', { class: 'skip-link', href: '#main', onclick: (e) => { e.preventDefault(); main.focus(); } }, 'Skip to content'), h('div', { class: 'app' }, sidebar, topbar, main), bottom, scrim);
  return {
    main,
    setActive(id) { [links, bottomLinks].forEach((m) => m.forEach((a, key) => key === id ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'))); },
    setBadge(id, n) { const a = links.get(id); if (!a) return; a.querySelector('.badge-count')?.remove(); if (n) a.append(h('span', { class: 'badge-count' }, n)); }
  };
}

/* Slim bar for full-screen tools (classroom, exam, learn, messages, AI). */
export function createToolBar({ title, backHref, backLabel = 'Back', extra = [] }) {
  return h('header', { class: 'tool-bar' }, backHref && h('a', { class: 'btn btn-ghost btn-sm', href: backHref }, icon('back'), backLabel), h('h1', { id: 'tool-title' }, title), ...extra, themeBtn());
}
export { redirectToLogin, toast, $ };
