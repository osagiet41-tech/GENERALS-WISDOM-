import { h, icon } from '../core/dom.js';
import { fmtDate } from '../core/format.js';
import { certificatesApi } from '../api/certificates.js';
import { ApiError } from '../core/http.js';
/* Runs the public verification call and returns a Node for every outcome (valid / revoked / not found / network). */
export async function verifyCertificate(id) {
  try {
    const { data } = await certificatesApi.verify(id);
    if (data.valid) return h('div', { class: 'cert-result', role: 'status' }, h('strong', null, 'This certificate is genuine.'),
      h('dl', null, row('Certificate ID', data.certificateId), row('Awarded to', data.studentName), row('Course', data.courseTitle), row('Institution', data.institutionName),
        data.instructors?.length ? row('Instructor', data.instructors.join(', ')) : null, row('Completed', fmtDate(data.completionDate)), row('Issued', fmtDate(data.issuedAt))));
    return h('div', { class: 'cert-result bad', role: 'status' }, h('strong', null, 'This certificate has been revoked.'), h('p', { class: 'small' }, `Certificate ${data.certificateId} was revoked on ${fmtDate(data.revokedAt)}. It is no longer valid.`));
  } catch (e) {
    const notFound = e instanceof ApiError && e.status === 404;
    return h('div', { class: 'cert-result bad', role: 'alert' }, icon('alert'), h('strong', null, notFound ? ' No certificate matches this ID.' : ' We could not check right now.'),
      h('p', { class: 'small' }, notFound ? 'Check the ID for typing mistakes. IDs look like CERT-7F3K-9QXD-M2WA; letters are not case-sensitive.' : e.message));
  }
}
const row = (k, v) => [h('dt', null, k), h('dd', null, v ?? '—')];
