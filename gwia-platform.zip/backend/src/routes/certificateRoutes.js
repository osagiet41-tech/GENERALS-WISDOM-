const express = require('express');
const multer = require('multer');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyLimiter } = require('../middleware/rateLimiter.middleware');
const controller = require('../controllers/certificateController');
const { MAX_BYTES } = require('../services/certificates/signatureStore');

const router = express.Router();

// Held in memory only: the bytes are validated (real PNG/JPEG magic numbers) before anything touches the disk.
const uploadSignature = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_BYTES, files: 1 } });

// --- Public: anyone can verify a certificate (rate limited so IDs can't be brute-forced) ---
router.get('/verify/:certificateId', verifyLimiter, controller.verify);

// --- Instructors manage the signature printed on their courses' certificates ---
router.put('/signature', authMiddleware, requireTeacherOrAdmin, uploadSignature.single('signature'), controller.uploadSignature);
router.delete('/signature', authMiddleware, requireTeacherOrAdmin, controller.removeSignature);

module.exports = router;
