/**
 * Money helpers. Internally every payable amount is an INTEGER in the currency's
 * minor unit (kobo, cents). Floats are only used at the edges (display, legacy
 * `amount` field, Flutterwave's major-unit API).
 */
const ZERO_DECIMAL = new Set([
  'BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF'
]);

function exponent(currency) {
  return ZERO_DECIMAL.has(String(currency).toUpperCase()) ? 0 : 2;
}

function toMinor(major, currency) {
  const n = Number(major);
  if (!Number.isFinite(n) || n < 0) throw new RangeError(`Invalid amount: ${major}`);
  return Math.round(n * 10 ** exponent(currency));
}

function fromMinor(minor, currency) {
  const exp = exponent(currency);
  return exp === 0 ? Number(minor) : Number((Number(minor) / 10 ** exp).toFixed(exp));
}

function formatMoney(minor, currency) {
  const exp = exponent(currency);
  const major = fromMinor(minor, currency);
  return `${String(currency).toUpperCase()} ${major.toLocaleString('en-US', {
    minimumFractionDigits: exp,
    maximumFractionDigits: exp
  })}`;
}

module.exports = { exponent, toMinor, fromMinor, formatMoney };
