const path = require('path');
const { FakePdfDoc } = require('./fakePdfDoc');
const { drawCertificate, registerFonts } = require('../../src/services/certificates/renderer');

const base = {
  studentName: 'Adaeze Chukwuemeka Okonkwo',
  courseTitle: 'Introduction to Python Programming',
  institutionName: 'Generals Wisdom International Academy',
  completionDate: new Date('2026-10-09T10:00:00Z'),
  issuedAt: new Date('2026-10-09T10:00:00Z'),
  certificateId: 'CERT-7F3K-9QXD-M2WA',
  verifyUrl: 'https://academy.example.com/verify/CERT-7F3K-9QXD-M2WA',
  instructors: [{ name: 'Mr. Osagie Thomas' }],
  signatory: null,
  finalScorePercent: null
};

// fake QR: deterministic 29x29 pattern (layout test only; the real one comes from the `qrcode` package)
const fakeQr = { size: 29, get: (r, c) => ((r * 7 + c * 13 + r * c) % 3 === 0) };

function render(overrides = {}, assets = {}) {
  const doc = new FakePdfDoc();
  const fonts = registerFonts(doc);
  drawCertificate(doc, { ...base, ...overrides }, { fonts, qr: fakeQr, instructorImages: [], signatoryImage: null, ...assets });
  return doc;
}

module.exports = { base, render, fakeQr };
