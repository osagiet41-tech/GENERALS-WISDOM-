const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const assignmentService = require('../services/assignmentService');
const notificationService = require('../services/notificationService');
const { Course } = require('../models/course.model');

// POST /api/courses/:courseId/assignments
const createAssignment = asyncHandler(async (req, res) => {
  const assignment = await assignmentService.createAssignment(req.course._id, req.user.id, req.body);
  return ApiResponse.created(res, assignment, 'Assignment created successfully');
});

// GET /api/courses/:courseId/assignments
const listAssignments = asyncHandler(async (req, res) => {
  const assignments = await assignmentService.listAssignments(req.course._id, req.query.status);
  return ApiResponse.ok(res, assignments, 'Assignments retrieved');
});

// PUT /api/assignments/:id
const updateAssignment = asyncHandler(async (req, res) => {
  const assignment = await assignmentService.updateAssignment(req.resource, req.body);
  return ApiResponse.ok(res, assignment, 'Assignment updated successfully');
});

// DELETE /api/assignments/:id
const deleteAssignment = asyncHandler(async (req, res) => {
  await assignmentService.deleteAssignment(req.resource);
  return ApiResponse.ok(res, null, 'Assignment deleted successfully');
});

// POST /api/assignments/:id/publish
const publishAssignment = asyncHandler(async (req, res) => {
  const assignment = await assignmentService.publishAssignment(req.resource);

  const course = await Course.findById(assignment.courseId);
  if (course) {
    await notificationService.notifyNewAssignment(course.enrolledStudentIds, {
      assignmentId: assignment._id,
      courseId: assignment.courseId,
      title: assignment.title,
      dueDate: assignment.dueDate
    });
  }

  return ApiResponse.ok(res, assignment, 'Assignment published successfully');
});

// POST /api/assignments/:id/unpublish
const unpublishAssignment = asyncHandler(async (req, res) => {
  const assignment = await assignmentService.unpublishAssignment(req.resource);
  return ApiResponse.ok(res, assignment, 'Assignment unpublished successfully');
});

// POST /api/assignments/:id/attachments
const addAttachment = asyncHandler(async (req, res) => {
  const assignment = await assignmentService.addAttachment(req.resource, req.file);
  return ApiResponse.ok(res, assignment, 'Attachment uploaded successfully');
});

module.exports = {
  createAssignment,
  listAssignments,
  updateAssignment,
  deleteAssignment,
  publishAssignment,
  unpublishAssignment,
  addAttachment
};
