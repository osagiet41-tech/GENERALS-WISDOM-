const MediaTransportAdapter = require('./MediaTransportAdapter');
const classroomPresenceService = require('../classroomPresenceService');

/**
 * Mesh WebRTC: every participant opens a direct RTCPeerConnection to
 * every other participant. This scales to small classes (roughly
 * ≤10-15 concurrent video participants before client CPU/bandwidth
 * becomes the bottleneck) — appropriate for typical classroom sizes,
 * but not for large lecture halls or webinars. That's exactly the
 * ceiling an SFU adapter would raise later without touching any
 * calling code.
 */
class MeshSignalingAdapter extends MediaTransportAdapter {
  async getConnectionInfo(liveClass, participant) {
    return {
      mode: 'mesh',
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
      // A TURN server should be added here for production use behind
      // restrictive NATs/firewalls — omitted since none is provisioned
      // in this environment.
    };
  }

  relaySignal(nsp, liveClassId, fromUserId, toUserId, payload) {
    const target = classroomPresenceService.getParticipant(liveClassId, toUserId);
    if (!target) return false;

    nsp.to(target.socketId).emit('webrtc:signal', {
      fromUserId,
      ...payload
    });
    return true;
  }
}

module.exports = MeshSignalingAdapter;
