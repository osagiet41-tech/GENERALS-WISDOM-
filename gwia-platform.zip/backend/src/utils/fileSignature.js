const fs = require('fs');

/**
 * Magic-number (file signature) verification. Browsers/clients choose the Content-Type and file name,
 * so neither can be trusted: a script or HTML page renamed to .png would otherwise be stored and served.
 * We read the first bytes of the stored file and require them to match the declared MIME type.
 */
const MIME_TO_EXT = Object.freeze({
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/gif': '.gif',
  'application/pdf': '.pdf',
  'application/msword': '.doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
  'application/vnd.ms-excel': '.xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
  'application/vnd.ms-powerpoint': '.ppt',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': '.pptx',
  'video/mp4': '.mp4',
  'video/webm': '.webm',
  'video/quicktime': '.mov',
  'audio/mpeg': '.mp3',
  'audio/mp3': '.mp3',
  'audio/wav': '.wav',
  'audio/ogg': '.ogg',
  'audio/mp4': '.m4a',
  'text/plain': '.txt',
  'application/zip': '.zip',
  'application/x-zip-compressed': '.zip'
});

const startsWith = (buf, bytes, offset = 0) => bytes.every((b, i) => buf[offset + i] === b);
const ascii = (buf, str, offset = 0) => buf.slice(offset, offset + str.length).toString('latin1') === str;

const CHECKS = {
  'image/jpeg': (b) => startsWith(b, [0xff, 0xd8, 0xff]),
  'image/png': (b) => startsWith(b, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
  'image/gif': (b) => ascii(b, 'GIF87a') || ascii(b, 'GIF89a'),
  'image/webp': (b) => ascii(b, 'RIFF') && ascii(b, 'WEBP', 8),
  'application/pdf': (b) => ascii(b.slice(0, 1024), '%PDF-') || b.slice(0, 1024).includes('%PDF-'),
  'application/zip': (b) => startsWith(b, [0x50, 0x4b, 0x03, 0x04]) || startsWith(b, [0x50, 0x4b, 0x05, 0x06]),
  'application/msword': (b) => startsWith(b, [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]),
  'video/mp4': (b) => ascii(b, 'ftyp', 4),
  'video/quicktime': (b) => ascii(b, 'ftyp', 4) || ascii(b, 'moov', 4) || ascii(b, 'mdat', 4) || ascii(b, 'wide', 4),
  'video/webm': (b) => startsWith(b, [0x1a, 0x45, 0xdf, 0xa3]),
  'audio/mpeg': (b) => ascii(b, 'ID3') || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0),
  'audio/wav': (b) => ascii(b, 'RIFF') && ascii(b, 'WAVE', 8),
  'audio/ogg': (b) => ascii(b, 'OggS'),
  'audio/mp4': (b) => ascii(b, 'ftyp', 4),
  // Plain text: no NUL bytes (a binary/executable disguised as .txt contains them)
  'text/plain': (b) => !b.includes(0)
};
CHECKS['audio/mp3'] = CHECKS['audio/mpeg'];
CHECKS['application/x-zip-compressed'] = CHECKS['application/zip'];
// OOXML documents are ZIP containers; legacy Office files are OLE2 containers.
for (const m of [
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation'
]) CHECKS[m] = CHECKS['application/zip'];
for (const m of ['application/vnd.ms-excel', 'application/vnd.ms-powerpoint']) CHECKS[m] = CHECKS['application/msword'];

/** True when `buffer` (first bytes of a file) looks like the declared MIME type. Unknown types are rejected. */
function matchesMime(buffer, mime) {
  const check = CHECKS[mime];
  if (!check || !buffer || buffer.length === 0) return false;
  return check(buffer);
}

/** Safe extension derived from the validated MIME type (never from the client-supplied file name). */
function extensionFor(mime) {
  return MIME_TO_EXT[mime] || '';
}

function readHead(filePath, bytes = 4096) {
  return new Promise((resolve, reject) => {
    fs.open(filePath, 'r', (err, fd) => {
      if (err) return reject(err);
      const buf = Buffer.alloc(bytes);
      fs.read(fd, buf, 0, bytes, 0, (readErr, n) => {
        fs.close(fd, () => {});
        if (readErr) return reject(readErr);
        resolve(buf.slice(0, n));
      });
    });
  });
}

async function fileMatchesMime(filePath, mime) {
  return matchesMime(await readHead(filePath), mime);
}

module.exports = { MIME_TO_EXT, matchesMime, extensionFor, fileMatchesMime, readHead };
