const LiveClass = require('../models/liveClass.model');
const Assignment = require('../models/assignment.model');
const { Assessment } = require('../models/assessment.model');
const Submission = require('../models/submission.model');
const { Course } = require('../models/course.model');
const notificationService = require('../services/notificationService');
const logger = require('../utils/logger');

const SWEEP_INTERVAL_MS = 5 * 60 * 1000;

const LIVE_CLASS_REMINDER_WINDOW_MS = 15 * 60 * 1000;
const ASSIGNMENT_REMINDER_WINDOW_MS = 24 * 60 * 60 * 1000;
const EXAM_REMINDER_WINDOW_MS = 24 * 60 * 60 * 1000;

async function sweepLiveClassReminders() {
  const now = new Date();
  const windowEnd = new Date(now.getTime() + LIVE_CLASS_REMINDER_WINDOW_MS);

  const upcoming = await LiveClass.find({
    status: 'scheduled',
    reminderSentAt: null,
    scheduledAt: { $gt: now, $lte: windowEnd }
  });

  for (const liveClass of upcoming) {
    try {
      const course = await Course.findById(liveClass.courseId);
      if (!course) continue;

      const recipientIds = [...course.enrolledStudentIds.map((id) => id.toString()), liveClass.teacherId.toString()];

      await notificationService.notifyLiveClassReminder(recipientIds, {
        liveClassId: liveClass._id,
        courseId: liveClass.courseId,
        title: liveClass.title,
        scheduledAt: liveClass.scheduledAt
      });

      liveClass.reminderSentAt = now;
      await liveClass.save();
    } catch (err) {
      logger.error(`Live class reminder failed for ${liveClass._id}: ${err.message}`);
    }
  }
}

async function sweepAssignmentDeadlineReminders() {
  const now = new Date();
  const windowEnd = new Date(now.getTime() + ASSIGNMENT_REMINDER_WINDOW_MS);

  const dueSoon = await Assignment.find({
    status: 'published',
    deadlineReminderSentAt: null,
    dueDate: { $gt: now, $lte: windowEnd }
  });

  for (const assignment of dueSoon) {
    try {
      const course = await Course.findById(assignment.courseId);
      if (!course) continue;

      const submitted = await Submission.find({ refType: 'assignment', refId: assignment._id }, 'studentId');
      const submittedIds = new Set(submitted.map((s) => s.studentId.toString()));

      const notSubmittedIds = course.enrolledStudentIds
        .map((id) => id.toString())
        .filter((id) => !submittedIds.has(id));

      await notificationService.notifyAssignmentDeadline(notSubmittedIds, {
        assignmentId: assignment._id,
        courseId: assignment.courseId,
        title: assignment.title,
        dueDate: assignment.dueDate
      });

      assignment.deadlineReminderSentAt = now;
      await assignment.save();
    } catch (err) {
      logger.error(`Assignment deadline reminder failed for ${assignment._id}: ${err.message}`);
    }
  }
}

async function sweepExamReminders() {
  const now = new Date();
  const windowEnd = new Date(now.getTime() + EXAM_REMINDER_WINDOW_MS);

  const closingSoon = await Assessment.find({
    status: 'published',
    reminderSentAt: null,
    availableUntil: { $gt: now, $lte: windowEnd }
  });

  for (const assessment of closingSoon) {
    try {
      const course = await Course.findById(assessment.courseId);
      if (!course) continue;

      const completed = await Submission.find({ refType: assessment.kind, refId: assessment._id }, 'studentId');
      const completedIds = new Set(completed.map((s) => s.studentId.toString()));

      let eligibleIds = course.enrolledStudentIds.map((id) => id.toString());
      if (assessment.allowedStudentIds && assessment.allowedStudentIds.length > 0) {
        const allowedSet = new Set(assessment.allowedStudentIds.map((id) => id.toString()));
        eligibleIds = eligibleIds.filter((id) => allowedSet.has(id));
      }

      const notCompletedIds = eligibleIds.filter((id) => !completedIds.has(id));

      await notificationService.notifyExamReminder(notCompletedIds, {
        assessmentId: assessment._id,
        kind: assessment.kind,
        courseId: assessment.courseId,
        title: assessment.title,
        availableUntil: assessment.availableUntil
      });

      assessment.reminderSentAt = now;
      await assessment.save();
    } catch (err) {
      logger.error(`Exam reminder failed for ${assessment._id}: ${err.message}`);
    }
  }
}

async function runAllReminderSweeps() {
  await sweepLiveClassReminders();
  await sweepAssignmentDeadlineReminders();
  await sweepExamReminders();
}

let intervalHandle = null;

function startReminderJobs() {
  if (intervalHandle) return;
  intervalHandle = setInterval(() => {
    runAllReminderSweeps().catch((err) => logger.error(`Reminder sweep failed: ${err.message}`));
  }, SWEEP_INTERVAL_MS);
  intervalHandle.unref?.();
  logger.info('Reminder background jobs started (checking every 5 minutes)');
}

function stopReminderJobs() {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
  }
}

module.exports = {
  startReminderJobs,
  stopReminderJobs,
  sweepLiveClassReminders,
  sweepAssignmentDeadlineReminders,
  sweepExamReminders,
  runAllReminderSweeps
};
