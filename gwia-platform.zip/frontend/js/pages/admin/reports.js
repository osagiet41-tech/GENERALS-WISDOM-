import { h } from '../../core/dom.js';
import { adminApi } from '../../api/admin.js';
import { pageHead, items } from '../../ui/page.js';
import { withState, busy, empty } from '../../ui/states.js';
import { dataTable } from '../../ui/table.js';
import { toast } from '../../ui/toast.js';
import { cap } from '../../core/format.js';

const TYPES = ['users', 'courses', 'payments', 'enrollments', 'attendance', 'performance'];
export default async function render() {
  const out = h('div', { class: 'card card-flush' }); let type = TYPES[0], from = '', to = '';
  const sel = h('select', { class: 'input', style: 'width:auto', 'aria-label': 'Report type', onchange: () => { type = sel.value; load(); } }, TYPES.map((t) => h('option', { value: t }, cap(t))));
  const f = (label, set) => { const i = h('input', { class: 'input', type: 'date', style: 'width:auto', 'aria-label': label, onchange: () => { set(i.value); load(); } }); return i; };
  const range = () => ({ ...(from && { from }), ...(to && { to }) });
  const load = () => withState(out, () => adminApi.report(type, range()), ({ data }) => { const rows = items(data?.rows || data); if (!rows.length) return empty({ title: 'No data for this report', iconName: 'chart' }); const keys = Object.keys(rows[0]).filter((k) => typeof rows[0][k] !== 'object').slice(0, 7);
    return dataTable({ rows, rowKey: (r) => JSON.stringify(r), caption: `${cap(type)} report`, columns: keys.map((k) => ({ label: cap(k), render: (r) => String(r[k] ?? '—') })) }); }, { rows: 5 });
  load();
  return h('div', { class: 'stack' }, pageHead('Reports', 'Preview here, export to Excel for the full data.', h('button', { class: 'btn', type: 'button', onclick: async (e) => { try { await busy(e.currentTarget, () => adminApi.exportReport(type, range())); } catch (err) { toast.error(err.message); } } }, 'Export to Excel')),
    h('div', { class: 'row' }, sel, h('span', { class: 'muted small' }, 'From'), f('From date', (v) => { from = v; }), h('span', { class: 'muted small' }, 'To'), f('To date', (v) => { to = v; })), out);
}
