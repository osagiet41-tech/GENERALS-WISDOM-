import { h, icon, $$ } from '../core/dom.js';
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
let uid = 0;
/* openModal({ title, body: Node, actions: [{label, variant, onClick}], size }) -> { close, el }. Esc / backdrop / X close it. */
export function openModal({ title, body, actions = [], size = '', onClose }) {
  const opener = document.activeElement, id = `m${++uid}`;
  const close = () => { document.removeEventListener('keydown', onKey); backdrop.remove(); document.body.style.overflow = ''; opener?.focus?.(); onClose?.(); };
  const foot = actions.length ? h('div', { class: 'modal-foot' }, actions.map((a) => h('button', { class: `btn ${a.variant ? 'btn-' + a.variant : ''}`, type: 'button', onclick: async (e) => { const r = await a.onClick?.(e, { close }); if (r !== false && !a.keepOpen) close(); } }, a.label))) : null;
  const dialog = h('div', { class: `modal ${size}`, role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': id },
    h('div', { class: 'modal-head' }, h('h2', { id }, title), h('button', { class: 'btn btn-ghost btn-icon', type: 'button', 'aria-label': 'Close dialog', onclick: close }, icon('x'))),
    h('div', { class: 'modal-body' }, body), foot);
  const backdrop = h('div', { class: 'modal-backdrop', onmousedown: (e) => { if (e.target === backdrop) close(); } }, dialog);
  function onKey(e) {
    if (e.key === 'Escape') return close();
    if (e.key !== 'Tab') return;
    const f = $$(FOCUSABLE, dialog); if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  document.addEventListener('keydown', onKey); document.body.append(backdrop); document.body.style.overflow = 'hidden';
  (dialog.querySelector('[autofocus],input,select,textarea') || dialog.querySelector('.modal-head button')).focus();
  return { close, el: dialog };
}
export function confirmDialog({ title = 'Are you sure?', message, confirmLabel = 'Confirm', danger = false }) {
  return new Promise((resolve) => {
    let settled = false; const done = (v) => { if (!settled) { settled = true; resolve(v); } };
    openModal({ title, body: h('p', null, message), onClose: () => done(false), actions: [
      { label: 'Cancel', variant: 'secondary', onClick: () => done(false) },
      { label: confirmLabel, variant: danger ? 'danger' : '', onClick: () => done(true) }] });
  });
}
