const ApiError = require('../../utils/ApiError');

/**
 * Minimal JSON-over-HTTPS client for gateway APIs (Node >= 18 global fetch).
 * Returns { status, ok, body }. Network failures/timeouts throw a 502 ApiError;
 * HTTP error statuses are returned to the caller, which knows what they mean
 * (e.g. 404 "transaction not found" is a normal state for a not-yet-paid reference).
 */
async function requestJson(url, { method = 'GET', headers = {}, body, timeoutMs = 20000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...headers },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal
    });
    const text = await res.text();
    let parsed = null;
    try {
      parsed = text ? JSON.parse(text) : null;
    } catch (e) {
      parsed = { raw: text.slice(0, 500) };
    }
    return { status: res.status, ok: res.ok, body: parsed };
  } catch (err) {
    throw new ApiError(502, err.name === 'AbortError' ? 'Payment provider timed out' : 'Payment provider unreachable');
  } finally {
    clearTimeout(timer);
  }
}

module.exports = { requestJson };
