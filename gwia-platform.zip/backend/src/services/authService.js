const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const env = require('../config/env');
const logger = require('../utils/logger');
const { sendEmail } = require('../utils/email.util');
const { hashToken, escapeHtml } = require('../utils/security');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/tokens');

const SALT_ROUNDS = env.security.bcryptRounds;
const MAX_SESSIONS = 5;

// Compared against when the e-mail does not exist, so "unknown account" and "wrong password" take the same time.
const DUMMY_HASH = bcrypt.hashSync('timing-equalisation-dummy-password', SALT_ROUNDS);

function linkWithToken(basePath, token) {
  const sep = basePath.includes('?') ? '&' : '?';
  return `${env.clientUrl.replace(/\/$/, '')}${basePath}${sep}token=${encodeURIComponent(token)}`;
}

// ---------------------------------------------------------------------
// Registration & email verification
// ---------------------------------------------------------------------

async function register({ name, email, password, role }) {
  const existing = await User.findOne({ email });
  if (existing) {
    throw ApiError.conflict('An account with this email already exists');
  }

  // Privilege-escalation guard: public sign-up creates students. Teacher accounts are created or promoted by an
  // administrator unless ALLOW_TEACHER_SELF_REGISTRATION=true is set deliberately.
  const effectiveRole = role === 'teacher' && env.security.allowTeacherSelfRegistration ? 'teacher' : 'student';

  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
  const rawToken = crypto.randomBytes(32).toString('hex');
  const emailVerificationExpires = new Date(Date.now() + 24 * 60 * 60 * 1000);

  const user = await User.create({
    name,
    email,
    passwordHash,
    role: effectiveRole,
    status: 'pending',
    emailVerificationToken: hashToken(rawToken), // only the hash is stored
    emailVerificationExpires
  });

  const verifyUrl = linkWithToken(env.emailLinks.verifyPath, rawToken);

  try {
    await sendEmail({
      to: user.email,
      subject: 'Verify your account',
      html: `<p>Hi ${escapeHtml(user.name)},</p><p>Please verify your account by clicking <a href="${escapeHtml(verifyUrl)}">this link</a>. This link expires in 24 hours.</p>`
    });
  } catch (err) {
    logger.warn(`Registration succeeded but verification email failed for ${user.email}: ${err.message}`);
  }

  return user.toSafeObject();
}

async function verifyEmail(token) {
  if (typeof token !== 'string' || !token) throw ApiError.badRequest('Invalid or expired verification token');

  const user = await User.findOne({
    emailVerificationToken: hashToken(token),
    emailVerificationExpires: { $gt: new Date() }
  }).select('+emailVerificationToken +emailVerificationExpires');

  if (!user) {
    throw ApiError.badRequest('Invalid or expired verification token');
  }

  user.isEmailVerified = true;
  // Never lift a suspension through an e-mail link: only a pending account becomes active.
  if (user.status === 'pending') user.status = 'active';
  user.emailVerificationToken = undefined;
  user.emailVerificationExpires = undefined;
  await user.save();

  return user.toSafeObject();
}

// ---------------------------------------------------------------------
// Login / logout / tokens — with account-lockout protection
// ---------------------------------------------------------------------

async function login({ email, password }) {
  const user = await User.findOne({ email }).select(
    '+passwordHash +refreshTokens +failedLoginAttempts +lockUntil'
  );

  // Same generic error and same amount of work whether the email exists or not (no account enumeration).
  if (!user) {
    await bcrypt.compare(String(password), DUMMY_HASH);
    throw ApiError.unauthorized('Invalid email or password');
  }

  if (user.isLocked) {
    // Deliberately identical to a wrong-password response so lock-outs do not reveal which e-mails exist.
    await bcrypt.compare(String(password), DUMMY_HASH);
    throw ApiError.unauthorized('Invalid email or password, or the account is temporarily locked. Try again later.');
  }

  const isMatch = await user.comparePassword(password);
  if (!isMatch) {
    await user.registerFailedLogin();
    throw ApiError.unauthorized('Invalid email or password');
  }

  if (user.status === 'suspended') {
    throw ApiError.forbidden('This account has been suspended');
  }
  if (user.status === 'pending') {
    throw ApiError.forbidden('Please verify your email before logging in');
  }

  await user.registerSuccessfulLogin();

  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);

  // Only hashes of refresh tokens are stored (keep the last MAX_SESSIONS sessions).
  user.refreshTokens = [...(user.refreshTokens || []).slice(-(MAX_SESSIONS - 1)), hashToken(refreshToken)];
  await user.save();

  return { user: user.toSafeObject(), accessToken, refreshToken };
}

async function refreshAccessToken(refreshToken) {
  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch (err) {
    throw ApiError.unauthorized('Invalid or expired refresh token');
  }

  const user = await User.findById(payload.sub).select('+refreshTokens');
  if (!user) throw ApiError.unauthorized('Refresh token not recognized');

  const presented = hashToken(refreshToken);
  if (!user.refreshTokens.includes(presented)) {
    // A correctly signed refresh token that is no longer on file was already rotated: it has been stolen or replayed.
    // Revoke every session of this user so the thief (and the owner) must sign in again.
    logger.warn(`Refresh-token reuse detected for user ${user._id}; all sessions revoked`);
    user.refreshTokens = [];
    await user.save();
    throw ApiError.unauthorized('Refresh token not recognized');
  }
  if (user.status !== 'active') throw ApiError.forbidden('Account is not active');
  if (user.passwordChangedAt && payload.iat * 1000 < user.passwordChangedAt.getTime() - 1000) {
    throw ApiError.unauthorized('Session expired, please sign in again');
  }

  const newAccessToken = signAccessToken(user);
  const newRefreshToken = signRefreshToken(user);

  user.refreshTokens = user.refreshTokens.filter((t) => t !== presented).concat(hashToken(newRefreshToken));
  await user.save();

  return { accessToken: newAccessToken, refreshToken: newRefreshToken };
}

async function logout(userId, refreshToken) {
  const user = await User.findById(userId).select('+refreshTokens');
  if (!user) return;

  if (refreshToken && typeof refreshToken === 'string') {
    const h = hashToken(refreshToken);
    user.refreshTokens = (user.refreshTokens || []).filter((t) => t !== h);
  } else {
    user.refreshTokens = []; // no token supplied: clear all sessions
  }
  await user.save();
}

// ---------------------------------------------------------------------
// Password reset & change
// ---------------------------------------------------------------------

async function forgotPassword(email) {
  const user = await User.findOne({ email });
  if (!user || user.status === 'suspended') {
    return false; // do not reveal whether the email exists
  }

  const rawToken = crypto.randomBytes(32).toString('hex');
  user.passwordResetToken = hashToken(rawToken);
  user.passwordResetExpires = new Date(Date.now() + 60 * 60 * 1000);
  await user.save();

  const resetUrl = linkWithToken(env.emailLinks.resetPath, rawToken);

  try {
    await sendEmail({
      to: user.email,
      subject: 'Reset your password',
      html: `<p>Hi ${escapeHtml(user.name)},</p><p>Reset your password by clicking <a href="${escapeHtml(resetUrl)}">this link</a>. This link expires in 1 hour. If you did not request this, ignore this email.</p>`
    });
  } catch (err) {
    // Never let an SMTP failure change the response (it would reveal that the account exists).
    logger.error(`Password reset email failed for ${user.email}: ${err.message}`);
    return false;
  }
  return true;
}

async function resetPassword(token, newPassword) {
  if (typeof token !== 'string' || !token) throw ApiError.badRequest('Invalid or expired reset token');

  const user = await User.findOne({
    passwordResetToken: hashToken(token),
    passwordResetExpires: { $gt: new Date() }
  }).select('+passwordResetToken +passwordResetExpires +refreshTokens');

  if (!user) {
    throw ApiError.badRequest('Invalid or expired reset token');
  }

  user.passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
  user.passwordChangedAt = new Date();
  user.passwordResetToken = undefined;
  user.passwordResetExpires = undefined;
  user.refreshTokens = []; // force re-login on all devices
  user.failedLoginAttempts = 0;
  user.lockUntil = null;
  await user.save();
}

async function changePassword(userId, currentPassword, newPassword) {
  const user = await User.findById(userId).select('+passwordHash +refreshTokens');
  if (!user) {
    throw ApiError.notFound('User not found');
  }

  const isMatch = await user.comparePassword(currentPassword);
  if (!isMatch) {
    throw ApiError.unauthorized('Current password is incorrect');
  }

  const isSameAsOld = await bcrypt.compare(newPassword, user.passwordHash);
  if (isSameAsOld) {
    throw ApiError.badRequest('New password must be different from the current password');
  }

  user.passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
  user.passwordChangedAt = new Date();
  user.refreshTokens = []; // force re-login on all devices after a password change
  await user.save();
}

// ---------------------------------------------------------------------
// Profile management
// ---------------------------------------------------------------------

async function updateProfile(userId, updates) {
  const user = await User.findById(userId);
  if (!user) {
    throw ApiError.notFound('User not found');
  }

  // Explicit allow-list: role, status, email etc. can never be set through this endpoint.
  if (typeof updates.name === 'string') {
    user.name = updates.name;
  }
  if (typeof updates.phone === 'string') {
    user.profile.phone = updates.phone;
  }
  if (typeof updates.bio === 'string') {
    user.profile.bio = updates.bio;
  }

  await user.save();
  return user.toSafeObject();
}

async function updateProfilePicture(userId, file) {
  if (!file) {
    throw ApiError.badRequest('No file uploaded');
  }

  const user = await User.findById(userId);
  if (!user) {
    // Clean up the orphaned upload if the user record can't be found.
    fs.unlink(file.path, () => {});
    throw ApiError.notFound('User not found');
  }

  // Remove the previous avatar file from disk if one exists and is a local upload (basename only: no path traversal).
  if (user.profile.avatarUrl && user.profile.avatarUrl.startsWith('/uploads/avatars/')) {
    const oldPath = path.join(__dirname, '..', '..', 'uploads', 'avatars', path.basename(user.profile.avatarUrl));
    fs.unlink(oldPath, () => {}); // best-effort cleanup, ignore errors
  }

  const relativePath = `/uploads/avatars/${file.filename}`;
  user.profile.avatarUrl = relativePath;
  await user.save();

  return user.toSafeObject();
}

module.exports = {
  register,
  verifyEmail,
  login,
  refreshAccessToken,
  logout,
  forgotPassword,
  resetPassword,
  changePassword,
  updateProfile,
  updateProfilePicture
};
