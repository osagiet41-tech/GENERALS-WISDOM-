const { body } = require('express-validator');

const createPostValidator = [
  body('type').optional().isIn(['discussion', 'question']),
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 200 }),
  body('content').trim().notEmpty().withMessage('Content is required').isLength({ max: 5000 })
];

const editPostValidator = [
  body('title').optional().trim().notEmpty().isLength({ max: 200 }),
  body('content').optional().trim().notEmpty().isLength({ max: 5000 })
];

const createReplyValidator = [
  body('content').trim().notEmpty().withMessage('Content is required').isLength({ max: 5000 })
];

const reportPostValidator = [
  body('reason')
    .isIn(['spam', 'harassment', 'inappropriate', 'off_topic', 'other'])
    .withMessage('A valid reason is required'),
  body('details').optional().trim().isLength({ max: 1000 })
];

const hidePostValidator = [body('reason').optional().trim().isLength({ max: 500 })];

const reviewReportValidator = [
  body('action').isIn(['dismiss', 'hide', 'delete']).withMessage('action must be dismiss, hide, or delete')
];

module.exports = {
  createPostValidator,
  editPostValidator,
  createReplyValidator,
  reportPostValidator,
  hidePostValidator,
  reviewReportValidator
};
