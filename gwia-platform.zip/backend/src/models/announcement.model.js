const mongoose = require('mongoose');
const { Schema } = mongoose;

const announcementSchema = new Schema(
  {
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    teacherId: { type: Schema.Types.ObjectId, ref: 'User', required: true },

    title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 200 },
    content: { type: String, required: [true, 'Content is required'] },

    pinned: { type: Boolean, default: false }
  },
  { timestamps: true }
);

announcementSchema.index({ courseId: 1, createdAt: -1 });

module.exports = mongoose.model('Announcement', announcementSchema);
