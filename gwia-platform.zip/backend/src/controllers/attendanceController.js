const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const attendanceService = require('../services/attendanceService');

// POST /api/courses/:courseId/attendance
const markAttendance = asyncHandler(async (req, res) => {
  const attendance = await attendanceService.createOrUpdateSession(req.course, req.user.id, req.body);
  return ApiResponse.ok(res, attendance, 'Attendance recorded successfully');
});

// GET /api/courses/:courseId/attendance
const listSessions = asyncHandler(async (req, res) => {
  const sessions = await attendanceService.listSessions(req.course._id, req.query);
  return ApiResponse.ok(res, sessions, 'Attendance sessions retrieved');
});

// GET /api/courses/:courseId/attendance/students/:studentId
const getStudentSummary = asyncHandler(async (req, res) => {
  const summary = await attendanceService.getStudentAttendanceSummary(req.course._id, req.params.studentId);
  return ApiResponse.ok(res, summary, 'Attendance summary retrieved');
});

// PUT /api/attendance/:id/students/:studentId
const updateRecord = asyncHandler(async (req, res) => {
  const attendance = await attendanceService.updateSingleRecord(
    req.resource,
    req.params.studentId,
    req.body.status,
    req.body.note
  );
  return ApiResponse.ok(res, attendance, 'Attendance record updated');
});

module.exports = { markAttendance, listSessions, getStudentSummary, updateRecord };
