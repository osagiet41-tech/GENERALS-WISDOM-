const { ForumPost, ForumReport } = require('../models/forum.model');
const ApiError = require('../utils/ApiError');
const notificationService = require('./notificationService');

async function createPost(courseId, user, { type, title, content }) {
  if (!title || !title.trim()) {
    throw ApiError.badRequest('Title is required for a new post or question');
  }

  return ForumPost.create({
    courseId,
    parentId: null,
    type: type || 'discussion',
    title: title.trim(),
    content,
    authorId: user.id,
    authorRole: user.role
  });
}

async function createReply(parentPost, user, { content }) {
  if (parentPost.parentId) {
    throw ApiError.badRequest('Replies can only be added to a top-level post, not to another reply');
  }
  if (parentPost.isDeleted) {
    throw ApiError.notFound('This post no longer exists');
  }
  if (parentPost.isLocked) {
    throw ApiError.forbidden('This discussion is locked and no longer accepting replies');
  }

  const reply = await ForumPost.create({
    courseId: parentPost.courseId,
    parentId: parentPost._id,
    content,
    authorId: user.id,
    authorRole: user.role
  });

  parentPost.replyCount += 1;
  parentPost.lastActivityAt = new Date();
  await parentPost.save();

  if (
    parentPost.type === 'question' &&
    parentPost.authorRole === 'student' &&
    parentPost.authorId.toString() !== user.id
  ) {
    await notificationService.createNotification(
      parentPost.authorId,
      'forum_reply',
      'New reply to your question',
      `${user.role === 'teacher' ? 'A teacher' : 'Someone'} replied to "${parentPost.title}"`,
      { postId: parentPost._id, replyId: reply._id, courseId: parentPost.courseId }
    );
  }

  return reply;
}

async function listPosts(courseId, { type, isModerator, page = 1, limit = 20, sort = 'recent' } = {}) {
  const filter = { courseId, parentId: null, isDeleted: false };
  if (!isModerator) filter.isHidden = false;
  if (type) filter.type = type;

  const sortSpec =
    sort === 'popular' ? { isPinned: -1, replyCount: -1, lastActivityAt: -1 } : { isPinned: -1, lastActivityAt: -1 };

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    ForumPost.find(filter)
      .populate('authorId', 'name role profile.avatarUrl')
      .sort(sortSpec)
      .skip(skip)
      .limit(Number(limit)),
    ForumPost.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function listReplies(parentId, { isModerator, page = 1, limit = 50 } = {}) {
  const filter = { parentId, isDeleted: false };
  if (!isModerator) filter.isHidden = false;

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    ForumPost.find(filter)
      .populate('authorId', 'name role profile.avatarUrl')
      .sort({ createdAt: 1 })
      .skip(skip)
      .limit(Number(limit)),
    ForumPost.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function searchPosts(courseId, query, { isModerator, page = 1, limit = 20 } = {}) {
  if (!query || !query.trim()) {
    throw ApiError.badRequest('A search query is required');
  }

  const filter = { courseId, isDeleted: false, $text: { $search: query } };
  if (!isModerator) filter.isHidden = false;

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    ForumPost.find(filter, { score: { $meta: 'textScore' } })
      .populate('authorId', 'name role profile.avatarUrl')
      .sort({ score: { $meta: 'textScore' } })
      .skip(skip)
      .limit(Number(limit)),
    ForumPost.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function editPost(post, user, { title, content }) {
  if (post.authorId.toString() !== user.id) {
    throw ApiError.forbidden('You may only edit your own posts');
  }
  if (post.isDeleted) {
    throw ApiError.notFound('This post no longer exists');
  }

  if (title !== undefined) {
    if (post.parentId) {
      throw ApiError.badRequest('Replies do not have a title to edit');
    }
    post.title = title.trim();
  }
  if (content !== undefined) {
    post.content = content;
  }

  await post.save();
  return post;
}

async function deletePost(post, user, isModerator) {
  const isOwner = post.authorId.toString() === user.id;
  if (!isOwner && !isModerator) {
    throw ApiError.forbidden('You may only delete your own posts');
  }

  post.isDeleted = true;
  post.deletedBy = user.id;
  post.deletedAt = new Date();
  post.content = '';
  await post.save();
  return post;
}

async function toggleLike(post, userId) {
  const alreadyLiked = post.likes.some((id) => id.toString() === userId);
  if (alreadyLiked) {
    post.likes = post.likes.filter((id) => id.toString() !== userId);
  } else {
    post.likes.push(userId);
  }
  await post.save();
  return { liked: !alreadyLiked, likeCount: post.likes.length };
}

async function reportPost(post, reporterId, { reason, details }) {
  const existing = await ForumReport.findOne({ postId: post._id, reporterId });
  if (existing) {
    throw ApiError.conflict('You have already reported this post');
  }

  const report = await ForumReport.create({
    postId: post._id,
    courseId: post.courseId,
    reporterId,
    reason,
    details: details || ''
  });

  post.reportCount += 1;
  await post.save();

  return report;
}

async function setPinned(post, pinned) {
  if (post.parentId) {
    throw ApiError.badRequest('Only top-level posts can be pinned');
  }
  post.isPinned = pinned;
  await post.save();
  return post;
}

async function setLocked(post, locked) {
  if (post.parentId) {
    throw ApiError.badRequest('Only top-level posts can be locked');
  }
  post.isLocked = locked;
  await post.save();
  return post;
}

async function setHidden(post, hidden, moderatorId, reason) {
  post.isHidden = hidden;
  post.hiddenBy = hidden ? moderatorId : null;
  post.hiddenAt = hidden ? new Date() : null;
  post.hiddenReason = hidden ? reason || null : null;
  await post.save();
  return post;
}

async function listReports(courseId, { status = 'pending', page = 1, limit = 20 } = {}) {
  const filter = { courseId };
  if (status) filter.status = status;

  const skip = (page - 1) * limit;
  const [items, total] = await Promise.all([
    ForumReport.find(filter)
      .populate('reporterId', 'name role')
      .populate('postId')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    ForumReport.countDocuments(filter)
  ]);

  return { items, total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / limit) };
}

async function reviewReport(report, moderatorId, action) {
  const post = await ForumPost.findById(report.postId);

  if (action === 'hide' && post) {
    await setHidden(post, true, moderatorId, `Reported: ${report.reason}`);
  } else if (action === 'delete' && post) {
    post.isDeleted = true;
    post.deletedBy = moderatorId;
    post.deletedAt = new Date();
    post.content = '';
    await post.save();
  }

  report.status = action === 'dismiss' ? 'dismissed' : 'reviewed';
  report.reviewedBy = moderatorId;
  report.reviewedAt = new Date();
  report.resultAction = action === 'dismiss' ? 'none' : action === 'hide' ? 'hidden' : 'deleted';
  await report.save();

  return report;
}

module.exports = {
  createPost,
  createReply,
  listPosts,
  listReplies,
  searchPosts,
  editPost,
  deletePost,
  toggleLike,
  reportPost,
  setPinned,
  setLocked,
  setHidden,
  listReports,
  reviewReport
};
