const LiveClass = require('../models/liveClass.model');
const ClassroomMessage = require('../models/classroomMessage.model');
const ApiError = require('../utils/ApiError');

async function updateSettings(liveClass, settings) {
  const allowed = ['chatEnabled', 'studentMicEnabledByDefault', 'studentCameraEnabledByDefault', 'studentScreenShareAllowed'];
  for (const field of allowed) {
    if (settings[field] !== undefined) {
      liveClass.settings[field] = settings[field];
    }
  }
  await liveClass.save();
  return liveClass;
}

async function startRecording(liveClass) {
  if (liveClass.status !== 'live') {
    throw ApiError.badRequest('Recording can only be started while the class is live');
  }
  if (liveClass.recording.status === 'recording') {
    throw ApiError.conflict('Recording is already in progress');
  }

  liveClass.recording.status = 'recording';
  liveClass.recording.startedAt = new Date();
  liveClass.recording.endedAt = null;
  await liveClass.save();
  return liveClass;
}

async function stopRecording(liveClass) {
  if (liveClass.recording.status !== 'recording') {
    throw ApiError.badRequest('No recording is currently in progress');
  }

  liveClass.recording.status = 'processing';
  liveClass.recording.endedAt = new Date();
  if (liveClass.recording.startedAt) {
    liveClass.recording.durationSeconds = Math.round(
      (liveClass.recording.endedAt.getTime() - liveClass.recording.startedAt.getTime()) / 1000
    );
  }
  await liveClass.save();
  return liveClass;
}

/**
 * Called once the actual recording file has finished processing
 * (e.g. by a background job or storage webhook) to attach the final
 * file metadata.
 */
async function finalizeRecording(liveClass, { fileUrl, sizeBytes }) {
  liveClass.recording.status = 'available';
  liveClass.recording.fileUrl = fileUrl;
  liveClass.recording.sizeBytes = sizeBytes || null;
  liveClass.recordingRef = fileUrl; // keep legacy field in sync
  await liveClass.save();
  return liveClass;
}

async function addSharedMaterial(liveClass, teacherId, file, title) {
  if (!file) throw ApiError.badRequest('No file uploaded');

  liveClass.sharedMaterials.push({
    title: title || file.originalname,
    fileName: file.originalname,
    fileUrl: `/uploads/materials/${file.filename}`,
    mimeType: file.mimetype,
    size: file.size,
    sharedBy: teacherId
  });
  await liveClass.save();
  return liveClass;
}

async function removeSharedMaterial(liveClass, materialId) {
  const material = liveClass.sharedMaterials.id(materialId);
  if (!material) throw ApiError.notFound('Shared material not found in this classroom');
  material.deleteOne();
  await liveClass.save();
  return liveClass;
}

async function postAnnouncement(liveClass, teacherId, text) {
  return ClassroomMessage.create({
    liveClassId: liveClass._id,
    senderId: teacherId,
    senderRole: 'teacher',
    type: 'announcement',
    text
  });
}

async function getChatHistory(liveClassId, { page = 1, limit = 100 } = {}) {
  const skip = (page - 1) * limit;
  const messages = await ClassroomMessage.find({ liveClassId })
    .populate('senderId', 'name role profile.avatarUrl')
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
  return messages.reverse();
}

async function getParticipantLogSummary(liveClass) {
  const summary = new Map();
  for (const entry of liveClass.participantLog) {
    const key = entry.userId.toString();
    const leftAt = entry.leftAt || new Date();
    const durationSeconds = Math.max(0, Math.round((leftAt.getTime() - entry.joinedAt.getTime()) / 1000));

    if (!summary.has(key)) {
      summary.set(key, { userId: entry.userId, role: entry.role, totalDurationSeconds: 0, sessions: 0 });
    }
    const running = summary.get(key);
    running.totalDurationSeconds += durationSeconds;
    running.sessions += 1;
  }
  return Array.from(summary.values());
}

/**
 * Closes the most recent open (leftAt: null) participant-log entry for
 * this user, if one exists. Shared by the Socket.IO disconnect handler
 * and the REST leave endpoint, so a student leaving via either path
 * gets the same attendance-relevant record.
 */
async function logParticipantLeave(liveClassId, userId) {
  const liveClass = await LiveClass.findById(liveClassId);
  if (!liveClass) return null;

  const openEntry = [...liveClass.participantLog].reverse().find((e) => e.userId.toString() === userId.toString() && !e.leftAt);
  if (openEntry) {
    openEntry.leftAt = new Date();
    await liveClass.save();
  }
  return liveClass;
}

module.exports = {
  updateSettings,
  startRecording,
  stopRecording,
  finalizeRecording,
  addSharedMaterial,
  removeSharedMaterial,
  postAnnouncement,
  getChatHistory,
  getParticipantLogSummary,
  logParticipantLeave
};
