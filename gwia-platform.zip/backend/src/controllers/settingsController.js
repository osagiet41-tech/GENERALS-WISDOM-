const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const settingsService = require('../services/settingsService');
const auditLogService = require('../services/auditLogService');

const getSettings = asyncHandler(async (req, res) => {
  const settings = await settingsService.getSettings();
  return ApiResponse.ok(res, settings, 'Settings retrieved');
});

const updateSettings = asyncHandler(async (req, res) => {
  const settings = await settingsService.updateSettings(req.body, req.user.id);
  await auditLogService.record(req.user.id, 'settings.update', 'Settings', settings._id, req.body, req.ip);
  return ApiResponse.ok(res, settings, 'Settings updated');
});

module.exports = { getSettings, updateSettings };
