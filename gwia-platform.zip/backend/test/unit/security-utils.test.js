const test = require('node:test');
const assert = require('node:assert/strict');
const { hashToken, escapeHtml, escapeRegex, safeEqual } = require('../../src/utils/security');

test('hashToken is deterministic, hex, and never equals the input', () => {
  const h = hashToken('abc');
  assert.equal(h, hashToken('abc'));
  assert.match(h, /^[a-f0-9]{64}$/);
  assert.notEqual(h, 'abc');
  assert.notEqual(hashToken('abc'), hashToken('abd'));
});

test('escapeHtml neutralises markup (email HTML injection)', () => {
  assert.equal(escapeHtml('<img src=x onerror=alert(1)>'), '&lt;img src=x onerror=alert(1)&gt;');
  assert.equal(escapeHtml('"a" & \'b\''), '&quot;a&quot; &amp; &#39;b&#39;');
  assert.equal(escapeHtml(null), '');
});

test('escapeRegex makes user input literal (regex injection / ReDoS)', () => {
  const evil = '(a+)+$';
  const rx = new RegExp(escapeRegex(evil), 'i');
  assert.ok(rx.test('xx(a+)+$yy'));
  assert.ok(!rx.test('aaaa'));
  assert.equal(escapeRegex('.*'), '\\.\\*');
});

test('safeEqual compares in constant time and handles length mismatch', () => {
  assert.ok(safeEqual('abc', 'abc'));
  assert.ok(!safeEqual('abc', 'abd'));
  assert.ok(!safeEqual('abc', 'abcd'));
});
