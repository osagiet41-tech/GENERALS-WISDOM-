const { Assessment, Question } = require('../models/assessment.model');
const { Course } = require('../models/course.model');
const ApiError = require('../utils/ApiError');

async function createAssessment(kind, courseId, teacherId, data) {
  if (!data.questions || data.questions.length === 0) {
    throw ApiError.badRequest('At least one question is required');
  }

  const questionIds = data.questions.map((q) => q.questionId);
  const foundCount = await Question.countDocuments({ _id: { $in: questionIds }, courseId });
  if (foundCount !== questionIds.length) {
    throw ApiError.badRequest('One or more questions do not belong to this course question bank');
  }

  if (data.randomization?.enabled) {
    const count = data.randomization.questionCount;
    if (!count || count < 1) {
      throw ApiError.badRequest('randomization.questionCount is required and must be at least 1 when randomization is enabled');
    }
    if (count > data.questions.length) {
      throw ApiError.badRequest(
        `randomization.questionCount (${count}) cannot exceed the number of questions in the pool (${data.questions.length})`
      );
    }
  }

  if (data.allowedStudentIds && data.allowedStudentIds.length > 0) {
    const course = await Course.findById(courseId);
    const enrolledSet = new Set(course.enrolledStudentIds.map((id) => id.toString()));
    const invalid = data.allowedStudentIds.filter((id) => !enrolledSet.has(id.toString()));
    if (invalid.length > 0) {
      throw ApiError.badRequest('allowedStudentIds must all be students enrolled in this course');
    }
  }

  const totalMarks = data.questions.reduce((sum, q) => sum + q.marks, 0);

  return Assessment.create({
    kind,
    courseId,
    subjectId: data.subjectId || null,
    moduleId: data.moduleId || null,
    title: data.title,
    instructions: data.instructions || '',
    questions: data.questions,
    totalMarks,
    passingMarks: data.passingMarks || 0,
    durationMinutes: data.durationMinutes,
    availableFrom: data.availableFrom,
    availableUntil: data.availableUntil,
    shuffleQuestions: !!data.shuffleQuestions,
    shuffleOptions: !!data.shuffleOptions,
    randomization: {
      enabled: !!data.randomization?.enabled,
      questionCount: data.randomization?.questionCount || null
    },
    maxAttempts: data.maxAttempts || 1,
    allowedStudentIds: data.allowedStudentIds || [],
    status: data.status || 'draft',
    createdBy: teacherId
  });
}

async function updateAssessment(assessment, updates) {
  const allowed = [
    'title',
    'instructions',
    'questions',
    'passingMarks',
    'durationMinutes',
    'availableFrom',
    'availableUntil',
    'shuffleQuestions',
    'shuffleOptions',
    'maxAttempts',
    'allowedStudentIds',
    'status',
    'subjectId',
    'moduleId'
  ];
  for (const field of allowed) {
    if (updates[field] !== undefined) {
      assessment[field] = updates[field];
    }
  }
  if (updates.randomization) {
    if (updates.randomization.enabled !== undefined) assessment.randomization.enabled = updates.randomization.enabled;
    if (updates.randomization.questionCount !== undefined) {
      assessment.randomization.questionCount = updates.randomization.questionCount;
    }
  }
  if (updates.questions) {
    assessment.totalMarks = updates.questions.reduce((sum, q) => sum + q.marks, 0);
  }
  if (assessment.randomization.enabled && assessment.randomization.questionCount > assessment.questions.length) {
    throw ApiError.badRequest('randomization.questionCount cannot exceed the number of questions in the pool');
  }
  await assessment.save();
  return assessment;
}

async function deleteAssessment(assessment) {
  await assessment.deleteOne();
}

async function listAssessments(kind, courseId, status) {
  const filter = { kind, courseId };
  if (status) filter.status = status;
  return Assessment.find(filter).sort({ availableFrom: -1 });
}

async function getAssessmentWithAnswerKey(assessment) {
  // Teacher-facing view includes correct answers; student-facing view (built
  // in the student module) strips them before sending questions to attempt.
  return Assessment.findById(assessment._id).populate('questions.questionId');
}

module.exports = {
  createAssessment,
  updateAssessment,
  deleteAssessment,
  listAssessments,
  getAssessmentWithAnswerKey
};
