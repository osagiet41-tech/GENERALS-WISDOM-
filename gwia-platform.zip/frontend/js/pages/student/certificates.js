import { h, mount, icon } from '../../core/dom.js';
import { studentApi } from '../../api/student.js';
import { certificatesApi } from '../../api/certificates.js';
import { pageHead, items, idOf } from '../../ui/page.js';
import { empty, busy } from '../../ui/states.js';
import { courseSelect } from '../shared/courseSelect.js';
import { dataTable, statusBadge } from '../../ui/table.js';
import { fmtDate } from '../../core/format.js';
import { toast } from '../../ui/toast.js';

export default async function render() {
  const [{ data: certs }, { data: courses }] = await Promise.all([certificatesApi.list(), studentApi.courses()]);
  const rows = items(certs); const eligBox = h('div');
  const act = (fn) => async (e) => { try { await busy(e.currentTarget, fn); } catch (err) { toast.error(err.message); } };
  const table = h('div', { class: 'card card-flush' }, dataTable({ rows, caption: 'Your certificates', emptyState: empty({ title: 'No certificates yet', message: 'Complete a course’s requirements and your certificate is issued automatically.', iconName: 'award' }),
    columns: [{ label: 'Course', render: (r) => h('strong', null, r.courseTitle || r.snapshot?.courseTitle || r.courseId?.title || 'Course') }, { label: 'Certificate ID', render: (r) => h('code', null, r.certificateId) }, { label: 'Issued', render: (r) => fmtDate(r.issuedAt) }, { label: 'Status', render: (r) => statusBadge(r.status || 'valid') }],
    actions: (r) => h('div', { class: 'row', style: 'justify-content:flex-end' }, h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: act(() => certificatesApi.view(idOf(r))) }, 'View'),
      h('button', { class: 'btn btn-sm', type: 'button', onclick: act(() => certificatesApi.download(idOf(r), r.certificateId)) }, icon('download'), 'PDF'),
      h('a', { class: 'btn btn-ghost btn-sm', href: `verify.html?id=${encodeURIComponent(r.certificateId)}`, target: '_blank', rel: 'noopener' }, 'Verify page')) }));
  const cs = courseSelect(courses, { storageKey: 'student.cert.course', label: 'Check my progress toward a certificate in', onChange: () => {} });
  const check = h('button', { class: 'btn btn-secondary', type: 'button', onclick: async (e) => {
    try { const { data } = await busy(e.currentTarget, () => certificatesApi.eligibility(cs.value)); mount(eligBox, eligibility(data, cs.value)); } catch (err) { toast.error(err.message); } } }, 'Check requirements');
  return h('div', { class: 'stack' }, pageHead('Certificates', 'Download your certificates or check what is still needed.'), table,
    cs.count ? h('section', { class: 'card stack' }, h('h2', null, 'Requirements'), h('div', { class: 'row' }, cs.el, check), eligBox) : null);
}
function eligibility(d, courseId) {
  if (d.issued) return h('div', { class: 'banner ok' }, 'A certificate has already been issued for this course. It is in the list above.');
  if (d.enabled === false) return h('div', { class: 'banner info' }, 'This course does not issue certificates.');
  const checks = d.checks || d.requirements || [];
  return h('div', { class: 'stack-sm' }, d.eligible ? h('div', { class: 'banner ok' }, 'You meet every requirement.', h('button', { class: 'btn btn-sm', type: 'button', onclick: async () => { try { await certificatesApi.request(courseId); toast.success('Certificate requested.'); location.hash = `#/certificates?r=${Date.now()}`; } catch (e) { toast.error(e.message); } } }, 'Get certificate')) : h('div', { class: 'banner' }, 'Not yet eligible.'),
    checks.length ? dataTable({ rows: checks, rowKey: (r) => r.key || r.label, columns: [{ label: 'Requirement', render: (r) => r.label || r.key }, { label: 'Required', render: (r) => String(r.required ?? '—') }, { label: 'Yours', render: (r) => String(r.actual ?? '—') }, { label: 'Met', render: (r) => statusBadge(r.met ? 'completed' : 'pending') }] }) : null);
}
