const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const paymentService = require('../services/paymentService');
const logger = require('../utils/logger');

const router = express.Router();

// Signature verification needs the EXACT bytes the gateway sent, so these routes use express.raw().
// This router must be mounted BEFORE express.json() in app.js (see app.js).
const raw = express.raw({ type: '*/*', limit: '1mb' });

function handler(providerName) {
  return asyncHandler(async (req, res) => {
    try {
      const result = await paymentService.handleWebhook(providerName, req.body, req.headers);
      return res.status(200).json({ received: true, outcome: result.outcome });
    } catch (err) {
      // 401 (bad signature) / 400 (bad body) are final. Anything else is surfaced as 5xx so the gateway retries.
      const status = err.statusCode && err.statusCode < 500 ? err.statusCode : 500;
      if (status >= 500) logger.error(`Webhook ${providerName} processing error: ${err.stack || err.message}`);
      else logger.warn(`Webhook ${providerName} rejected: ${err.message}`);
      return res.status(status).json({ received: false });
    }
  });
}

router.post('/paystack', raw, handler('paystack'));
router.post('/flutterwave', raw, handler('flutterwave'));

module.exports = router;
