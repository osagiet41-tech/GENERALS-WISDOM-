const express = require('express');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireStudent } = require('../middleware/roleMiddleware');
const { paymentLimiter } = require('../middleware/rateLimiter.middleware');
const validate = require('../middleware/validate.middleware');
const ctrl = require('../controllers/paymentController');
const {
  checkoutValidator,
  validateDiscountValidator,
  startTrialValidator,
  verifyPaymentValidator
} = require('../validators/billingValidator');

const router = express.Router();

// Public: plan catalogue for the pricing page.
router.get('/plans', ctrl.listPlans);

router.use(authMiddleware);

// Read-only views any signed-in user may call for their own data.
router.get('/subscription', ctrl.mySubscription);
router.get('/payments', ctrl.listPayments);
router.get('/payments/:id', ctrl.getPayment);
router.get('/payments/:id/receipt', ctrl.getReceipt);
router.get('/payments/:id/receipt.pdf', ctrl.downloadReceipt);
router.get('/courses/:courseId/access', ctrl.courseAccess);

// Buying: students only.
router.post('/discounts/validate', requireStudent, paymentLimiter, validate(validateDiscountValidator), ctrl.validateDiscount);
router.post('/checkout', requireStudent, paymentLimiter, validate(checkoutValidator), ctrl.checkout);
router.post('/payments/:reference/verify', requireStudent, paymentLimiter, validate(verifyPaymentValidator), ctrl.verifyPayment);
router.post('/trial', requireStudent, paymentLimiter, validate(startTrialValidator), ctrl.startTrial);

module.exports = router;
