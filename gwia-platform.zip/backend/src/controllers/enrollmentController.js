const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const enrollmentService = require('../services/enrollmentService');
const notificationService = require('../services/notificationService');
const accessService = require('../services/accessService');

// POST /api/student/enrollments  { courseId }
const enroll = asyncHandler(async (req, res) => {
  const course = await enrollmentService.enrollInCourse(req.user.id, req.body.courseId);

  await notificationService.createNotification(
    req.user.id,
    'enrollment',
    'Enrollment confirmed',
    `You are now enrolled in ${course.title}`,
    { courseId: course._id }
  );

  return ApiResponse.created(res, course, 'Enrolled successfully');
});

// GET /api/student/courses
const listMyCourses = asyncHandler(async (req, res) => {
  const courses = await enrollmentService.listEnrolledCourses(req.user.id);
  // Expired/unpaid courses stay listed (progress is kept) but are flagged so the UI can show a paywall.
  const withAccess = await Promise.all(
    courses.map(async (c) => ({ ...c.toObject(), access: await accessService.getCourseAccess(req.user.id, c) }))
  );
  return ApiResponse.ok(res, withAccess, 'Enrolled courses retrieved');
});

// DELETE /api/student/enrollments/:courseId
const unenroll = asyncHandler(async (req, res) => {
  await enrollmentService.unenroll(req.user.id, req.params.courseId);
  return ApiResponse.ok(res, null, 'Unenrolled successfully');
});

module.exports = { enroll, listMyCourses, unenroll };
