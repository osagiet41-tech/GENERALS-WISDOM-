const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const courseModuleService = require('../services/courseModuleService');

// POST /api/courses/:courseId/subjects/:subjectId/modules
const createModule = asyncHandler(async (req, res) => {
  const courseModule = await courseModuleService.createModule(
    req.course._id,
    req.params.subjectId,
    req.user.id,
    req.body
  );
  return ApiResponse.created(res, courseModule, 'Module created successfully');
});

// GET /api/courses/:courseId/subjects/:subjectId/modules
const listModules = asyncHandler(async (req, res) => {
  const modules = await courseModuleService.listModules(req.params.subjectId);
  return ApiResponse.ok(res, modules, 'Modules retrieved');
});

// GET /api/courses/:courseId/modules  (all modules across the whole course, any subject)
const listModulesForCourse = asyncHandler(async (req, res) => {
  const modules = await courseModuleService.listModulesForCourse(req.course._id);
  return ApiResponse.ok(res, modules, 'Modules retrieved');
});

// PUT /api/modules/:id  (req.resource set by verifyResourceOwnership)
const updateModule = asyncHandler(async (req, res) => {
  const courseModule = await courseModuleService.updateModule(req.resource, req.body);
  return ApiResponse.ok(res, courseModule, 'Module updated successfully');
});

// DELETE /api/modules/:id
const deleteModule = asyncHandler(async (req, res) => {
  await courseModuleService.deleteModule(req.resource);
  return ApiResponse.ok(res, null, 'Module deleted successfully');
});

module.exports = { createModule, listModules, listModulesForCourse, updateModule, deleteModule };
