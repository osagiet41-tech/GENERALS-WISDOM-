const userSockets = new Map(); // userId (string) -> Set<socketId>
const lastSeenAt = new Map(); // userId (string) -> Date

function addSocket(userId, socketId) {
  const key = userId.toString();
  const wasOffline = !userSockets.has(key) || userSockets.get(key).size === 0;

  if (!userSockets.has(key)) userSockets.set(key, new Set());
  userSockets.get(key).add(socketId);

  return wasOffline; // true if this connection just brought the user online
}

function removeSocket(userId, socketId) {
  const key = userId.toString();
  const sockets = userSockets.get(key);
  if (!sockets) return false;

  sockets.delete(socketId);

  if (sockets.size === 0) {
    userSockets.delete(key);
    lastSeenAt.set(key, new Date());
    return true; // true if the user just went fully offline
  }
  return false;
}

function isOnline(userId) {
  const sockets = userSockets.get(userId.toString());
  return !!sockets && sockets.size > 0;
}

function getStatus(userId) {
  const key = userId.toString();
  return {
    userId: key,
    online: isOnline(key),
    lastSeenAt: lastSeenAt.get(key) || null
  };
}

function getStatuses(userIds) {
  return userIds.map((id) => getStatus(id));
}

module.exports = { addSocket, removeSocket, isOnline, getStatus, getStatuses };
