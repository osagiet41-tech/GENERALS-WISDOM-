const mongoose = require('mongoose');
const { Schema } = mongoose;

const studentAttendanceSchema = new Schema(
  {
    studentId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    status: { type: String, enum: ['present', 'absent', 'late', 'excused'], default: 'absent' },
    markedAt: { type: Date, default: Date.now },
    note: { type: String, default: null }
  },
  { _id: false }
);

const attendanceSchema = new Schema(
  {
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    liveClassId: { type: Schema.Types.ObjectId, ref: 'LiveClass', default: null, index: true },

    sessionDate: { type: Date, required: true },
    teacherId: { type: Schema.Types.ObjectId, ref: 'User', required: true },

    records: { type: [studentAttendanceSchema], default: [] }
  },
  { timestamps: true }
);

attendanceSchema.index({ courseId: 1, sessionDate: 1 });

module.exports = mongoose.model('Attendance', attendanceSchema);
