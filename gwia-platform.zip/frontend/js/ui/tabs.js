import { h, mount } from '../core/dom.js';
/* tabs([{id,label,render(panel)}]) -> Node. Arrow keys move between tabs; panel renders lazily on first view each time it is selected. */
export function tabs(items, initial = items[0].id) {
  const panel = h('div', { role: 'tabpanel', tabindex: '0' }); const bar = h('div', { class: 'tabs', role: 'tablist' });
  const select = (id) => {
    [...bar.children].forEach((b) => { const on = b.dataset.id === id; b.setAttribute('aria-selected', on); b.tabIndex = on ? 0 : -1; });
    mount(panel); items.find((i) => i.id === id).render(panel);
  };
  items.forEach((i) => bar.append(h('button', { role: 'tab', type: 'button', 'data-id': i.id, onclick: () => select(i.id),
    onkeydown: (e) => { const all = [...bar.children], k = all.indexOf(e.currentTarget); const n = e.key === 'ArrowRight' ? all[(k + 1) % all.length] : e.key === 'ArrowLeft' ? all[(k - 1 + all.length) % all.length] : null; if (n) { e.preventDefault(); n.focus(); n.click(); } } }, i.label)));
  select(initial); return h('div', null, bar, panel);
}
