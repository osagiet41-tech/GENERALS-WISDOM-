import { h } from '../../core/dom.js';
import { adminApi } from '../../api/admin.js';
import { pageHead, idOf } from '../../ui/page.js';
import { listView } from '../shared/listView.js';
import { statusBadge } from '../../ui/table.js';
import { toast } from '../../ui/toast.js';
import { fmtMoney } from '../../core/format.js';

export default async function render() {
  const lv = listView({ searchPlaceholder: 'Search courses…', caption: 'Courses', fetcher: (q) => adminApi.courses(q), filters: [{ name: 'status', label: 'All statuses', options: ['draft', 'published', 'archived'].map((v) => ({ value: v, label: v })) }],
    columns: [{ label: 'Course', render: (c) => h('div', null, h('strong', null, c.title), h('div', { class: 'small muted' }, c.category || '')) }, { label: 'Status', render: (c) => statusBadge(c.status) }, { label: 'Price', render: (c) => (c.price ? fmtMoney(c.price, c.currency || undefined) : 'Free') }, { label: 'Students', render: (c) => c.enrolledStudentIds?.length ?? c.enrolledCount ?? '—' }],
    actions: (c) => { const s = h('select', { class: 'input', style: 'width:auto;min-height:32px;padding:2px 8px', 'aria-label': `Status of ${c.title}`, onchange: async () => { try { await adminApi.setCourseStatus(idOf(c), s.value); toast.success('Status updated.'); lv.reload(); } catch (e) { toast.error(e.message); s.value = c.status; } } },
      ['draft', 'published', 'archived'].map((v) => h('option', { value: v, selected: v === c.status }, v))); return s; } });
  return h('div', { class: 'stack' }, pageHead('Courses', 'Publish, archive and review every course.'), lv.el);
}
