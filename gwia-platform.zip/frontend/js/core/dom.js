/* Tiny DOM helpers. h() only ever sets text via text nodes, so API data can never inject markup. */
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function h(tag, props, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value' || k === 'checked' || k === 'disabled' || k === 'selected') el[k] = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  append(el, children);
  return el;
}
function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
}
export function clear(node) { node.replaceChildren(); return node; }
export function mount(node, ...children) { node.replaceChildren(); append(node, children); return node; }

const ICONS = {
  home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10', book: 'M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2zM4 19a2 2 0 012-2h13', users: 'M16 20v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 10a4 4 0 100-8 4 4 0 000 8zM22 20v-2a4 4 0 00-3-3.9M16 2.1a4 4 0 010 7.8',
  calendar: 'M3 6h18v15H3zM3 10h18M8 3v4M16 3v4', file: 'M14 3H6a1 1 0 00-1 1v16a1 1 0 001 1h12a1 1 0 001-1V8zM14 3v5h5M9 13h6M9 17h6', award: 'M12 15a6 6 0 100-12 6 6 0 000 12zM8.5 14l-1.5 7 5-3 5 3-1.5-7',
  card: 'M2 6h20v12H2zM2 10h20M6 15h4', bell: 'M6 8a6 6 0 1112 0c0 7 3 8 3 8H3s3-1 3-8M10 21a2 2 0 004 0', message: 'M21 12a8 8 0 01-11.6 7.1L3 21l1.9-5.4A8 8 0 1121 12z', bot: 'M12 3v3M5 8h14a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2v-8a2 2 0 012-2zM9 14h.01M15 14h.01',
  settings: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 .5-1.5-1-.5-2.5h-4L10 6.5l-1.5 1L6.5 7l-2 4 2 1v1l-2 1 2 4 2-.5 1.5 1 .5 2.5h4l.5-2.5 1.5-1 2 .5 2-4-2-1z', search: 'M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3', menu: 'M3 6h18M3 12h18M3 18h18',
  sun: 'M12 17a5 5 0 100-10 5 5 0 000 10zM12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4', moon: 'M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z',
  logout: 'M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9', plus: 'M12 5v14M5 12h14', video: 'M15 10l6-4v12l-6-4zM3 6h12v12H3z', edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z',
  trash: 'M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6', download: 'M12 3v12M7 10l5 5 5-5M4 21h16', check: 'M5 13l4 4L19 7', x: 'M6 6l12 12M18 6L6 18', alert: 'M12 9v4M12 17h.01M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z',
  chart: 'M3 3v18h18M7 15l4-4 3 3 5-6', shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z', clock: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2', send: 'M22 2L11 13M22 2l-7 20-4-9-9-4z',
  mic: 'M12 15a3 3 0 003-3V6a3 3 0 00-6 0v6a3 3 0 003 3zM19 11a7 7 0 01-14 0M12 18v3', micoff: 'M3 3l18 18M9 9v3a3 3 0 005.1 2.1M15 9.3V6a3 3 0 00-5.7-1.3M19 11a7 7 0 01-1 3.6M5 11a7 7 0 007 7v3', camoff: 'M3 3l18 18M16 16H3V6h2M10 6h6v4l5-3v10M7 6h3',
  screen: 'M3 4h18v12H3zM8 21h8M12 16v5', hand: 'M8 13V5a1.5 1.5 0 013 0v6M11 11V3.5a1.5 1.5 0 013 0V11M14 11V5.5a1.5 1.5 0 013 0V14a7 7 0 01-7 7c-3 0-4-2-5.5-4.5L3 13a1.5 1.5 0 012.5-1.5L8 14', phone: 'M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z',
  paperclip: 'M21 11l-9 9a5 5 0 01-7-7l9-9a3.5 3.5 0 015 5l-9 9a2 2 0 01-3-3l8-8', back: 'M15 18l-6-6 6-6', play: 'M6 4l14 8-14 8z', external: 'M14 3h7v7M21 3l-9 9M19 14v6H4V5h6', flag: 'M5 21V4M5 4h12l-2 4 2 4H5', refresh: 'M21 12a9 9 0 11-3-6.7L21 8M21 3v5h-5'
};
export function icon(name, label) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('class', 'icon');
  if (label) { svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', label); } else svg.setAttribute('aria-hidden', 'true');
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', ICONS[name] || ICONS.file); svg.append(p);
  return svg;
}
