import { h } from '../core/dom.js';
/* Minimal, safe renderer for lesson text: headings, paragraphs, bullet/numbered lists, **bold**, *italic*, `code`, [text](https://link).
   Builds DOM nodes (never innerHTML), and only http(s)/mailto links are made clickable. */
function inline(text) {
  const out = []; const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\([^)\s]+\))/g; let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index)); const t = m[0];
    if (t.startsWith('**')) out.push(h('strong', null, t.slice(2, -2))); else if (t.startsWith('`')) out.push(h('code', null, t.slice(1, -1))); else if (t.startsWith('[')) {
      const [, label, url] = /\[([^\]]+)\]\(([^)]+)\)/.exec(t); out.push(/^(https?:|mailto:)/i.test(url) ? h('a', { href: url, target: '_blank', rel: 'noopener noreferrer' }, label) : label);
    } else out.push(h('em', null, t.slice(1, -1)));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(text.slice(last)); return out;
}
export function renderText(src = '') {
  const root = h('div', { class: 'lesson-body' }); let list = null, para = [];
  const flush = () => { if (para.length) { root.append(h('p', null, ...inline(para.join(' ')))); para = []; } };
  const endList = () => { list = null; };
  for (const raw of String(src).split(/\r?\n/)) {
    const line = raw.trimEnd(); let m;
    if (!line.trim()) { flush(); endList(); } else if ((m = /^(#{1,3})\s+(.*)/.exec(line))) { flush(); endList(); root.append(h(`h${m[1].length + 1}`, null, ...inline(m[2]))); }
    else if ((m = /^\s*([-*]|\d+\.)\s+(.*)/.exec(line))) { flush(); const tag = /\d/.test(m[1]) ? 'ol' : 'ul'; if (!list || list.tagName.toLowerCase() !== tag) { list = h(tag); root.append(list); } list.append(h('li', null, ...inline(m[2]))); }
    else { endList(); para.push(line.trim()); }
  }
  flush(); return root;
}
