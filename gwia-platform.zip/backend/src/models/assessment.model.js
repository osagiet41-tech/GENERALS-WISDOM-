const mongoose = require('mongoose');
const { Schema } = mongoose;

// --- Question bank: reusable pool of questions per course ---
const questionSchema = new Schema(
  {
    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },

    type: {
      type: String,
      enum: ['mcq', 'true_false', 'short_answer', 'essay'],
      required: true
    },
    text: { type: String, required: [true, 'Question text is required'], trim: true },
    options: {
      type: [String],
      default: [],
      validate: {
        validator: function validateOptions(opts) {
          if (this.type === 'mcq') return opts.length >= 2;
          return true;
        },
        message: 'MCQ questions require at least 2 options'
      }
    },
    correctAnswer: { type: Schema.Types.Mixed, required: true }, // index/string for mcq/true_false, model answer text for short/essay
    marks: { type: Number, required: true, min: 1, default: 1 },
    difficulty: { type: String, enum: ['easy', 'medium', 'hard'], default: 'medium' },
    tags: { type: [String], default: [] },

    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true }
  },
  { timestamps: true }
);

questionSchema.index({ courseId: 1, tags: 1 });
questionSchema.index({ text: 'text' });

// --- Shared assessment schema for quizzes and exams (distinguished by `kind`) ---
const assessmentQuestionRefSchema = new Schema(
  {
    questionId: { type: Schema.Types.ObjectId, ref: 'Question', required: true },
    marks: { type: Number, required: true, min: 1 } // allows overriding the bank's default mark value per assessment
  },
  { _id: false }
);

const assessmentSchema = new Schema(
  {
    kind: { type: String, enum: ['quiz', 'exam'], required: true, index: true },

    courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true, index: true },
    subjectId: { type: Schema.Types.ObjectId, ref: 'Subject', default: null },
    moduleId: { type: Schema.Types.ObjectId, ref: 'CourseModule', default: null, index: true },

    title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 200 },
    instructions: { type: String, default: '' },

    questions: { type: [assessmentQuestionRefSchema], default: [] }, // the question pool this assessment draws from
    totalMarks: { type: Number, required: true, min: 1 },
    passingMarks: { type: Number, default: 0 },

    durationMinutes: { type: Number, required: true, min: 1 },
    availableFrom: { type: Date, required: true },
    availableUntil: { type: Date, required: true },

    // Exams typically require stricter proctoring/order controls than quizzes.
    shuffleQuestions: { type: Boolean, default: false },
    shuffleOptions: { type: Boolean, default: false }, // randomize MCQ option display order per attempt

    // Random question selection: when enabled, each attempt draws `questionCount`
    // random questions from the `questions` pool above rather than presenting
    // every pooled question. totalMarks in that case reflects the full pool;
    // an individual attempt's achievable marks is the sum of its drawn subset.
    randomization: {
      enabled: { type: Boolean, default: false },
      questionCount: { type: Number, default: null, min: 1 }
    },

    maxAttempts: { type: Number, default: 1, min: 1 },

    // Class restriction: when non-empty, only these enrolled students may
    // attempt this assessment (e.g. a specific section/group within the
    // course). Empty means every enrolled student is eligible.
    allowedStudentIds: { type: [Schema.Types.ObjectId], ref: 'User', default: [] },

    // Set once the "closing soon" reminder has gone out, so the reminder
    // sweep never sends it twice for the same assessment.
    reminderSentAt: { type: Date, default: null },

    status: { type: String, enum: ['draft', 'published', 'closed'], default: 'draft', index: true },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true }
  },
  { timestamps: true }
);

assessmentSchema.index({ courseId: 1, kind: 1, availableFrom: 1 });

module.exports = {
  Question: mongoose.model('Question', questionSchema),
  Assessment: mongoose.model('Assessment', assessmentSchema)
};
