import { h, mount, icon } from '../core/dom.js';
import { requireRole, session, homeFor } from '../core/session.js';
import { messagesApi } from '../api/messages.js';
import { studentApi } from '../api/student.js';
import { teacherApi } from '../api/teacher.js';
import { adminApi } from '../api/admin.js';
import { connect } from '../ui/socket.js';
import { createToolBar } from '../ui/shell.js';
import { loading, errorState, empty } from '../ui/states.js';
import { openModal } from '../ui/modal.js';
import { buildForm } from '../ui/form.js';
import { searchBox } from '../ui/search.js';
import { toast } from '../ui/toast.js';
import { initials, fmtTime, relTime } from '../core/format.js';
import { bindFile } from '../core/files.js';
import { items, idOf } from '../ui/page.js';

const user = await requireRole('student', 'teacher', 'admin'); const me = user.id || user._id;
const listEl = h('div'), log = h('div', { class: 'messages', role: 'log', 'aria-live': 'polite' }), headEl = h('div', { class: 'toolbar' }, h('span', { class: 'muted' }, 'Select a conversation'));
const typingEl = h('div', { class: 'small muted', style: 'padding:0 16px;min-height:20px', 'aria-live': 'polite' });
const input = h('textarea', { class: 'input', rows: 1, placeholder: 'Write a message…', 'aria-label': 'Message', maxlength: 5000 }), file = h('input', { type: 'file', multiple: true, hidden: true });
const chat = h('div', { class: 'chat', 'data-view': 'list' }); let convos = [], active = null, socket = null, typingTimer = null;

const composer = h('form', { class: 'composer', onsubmit: send }, h('button', { class: 'btn btn-ghost btn-icon', type: 'button', 'aria-label': 'Attach files', onclick: () => file.click() }, icon('paperclip')), file, input, h('button', { class: 'btn btn-icon', type: 'submit', 'aria-label': 'Send' }, icon('send')));
input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); composer.requestSubmit(); } });
input.addEventListener('input', () => { if (!active || !socket) return; socket.emit('typing:start', { conversationId: active.conversationId }); clearTimeout(typingTimer); typingTimer = setTimeout(() => socket.emit('typing:stop', { conversationId: active.conversationId }), 1500); });
const pane = h('section', { class: 'chat-pane', 'aria-label': 'Conversation' }, h('div', null, headEl, typingEl), log, composer);
const newBtn = h('button', { class: 'btn btn-sm', type: 'button', onclick: newChat }, icon('plus'), 'New');
chat.append(h('aside', { class: 'chat-list', 'aria-label': 'Conversations' }, h('div', { class: 'toolbar' }, h('strong', null, 'Messages'), newBtn), searchBox({ placeholder: 'Search messages…', label: 'Search messages', onSearch: doSearch }), listEl), pane);
document.body.append(h('div', { class: 'tool' }, createToolBar({ title: 'Messages', backHref: homeFor(user.role), backLabel: 'Dashboard' }), chat));

async function loadList() {
  try { convos = (await messagesApi.conversations()).data || []; drawList(); } catch (e) { mount(listEl, errorState(e, loadList)); }
}
function drawList() {
  mount(listEl, convos.length ? convos.map((c) => h('button', { class: 'convo', type: 'button', 'aria-current': active?.conversationId === c.conversationId ? 'true' : null, onclick: () => open(c) }, h('span', { class: 'avatar' }, initials(c.partner?.name)),
    h('span', { class: 'grow' }, h('strong', null, c.partner?.name || 'Unknown'), h('span', { class: 'small muted' }, ` · ${c.partner?.role || ''}`), h('div', { class: 'last' }, c.lastMessagePreview || 'No messages yet')),
    h('span', { style: 'text-align:right' }, h('span', { class: `dot ${c.partner?.online || c.partner?.isOnline ? 'on' : ''}`, title: c.partner?.online ? 'Online' : 'Offline' }), h('div', { class: 'small muted' }, c.lastMessageAt ? relTime(c.lastMessageAt) : ''), c.unreadCount > 0 && h('span', { class: 'badge-count', style: 'background:var(--gold);color:#111;border-radius:999px;padding:0 8px;font-size:.75rem;font-weight:700' }, c.unreadCount)))) : empty({ title: 'No conversations yet', message: 'Use “New” to message a teacher or student.', iconName: 'message' }));
}
async function open(c) {
  active = c; chat.dataset.view = 'pane'; drawList();
  mount(headEl, h('button', { class: 'btn btn-ghost btn-sm back', type: 'button', onclick: () => { chat.dataset.view = 'list'; } }, icon('back'), 'Back'), h('strong', null, c.partner?.name), h('span', { class: 'small muted' }, c.partner?.role));
  mount(log, loading(3)); socket?.emit('conversation:join', { conversationId: c.conversationId });
  try { const { data, meta } = await messagesApi.list(c.conversationId, { limit: 50 }); mount(log); if (meta?.hasMore) log.append(h('button', { class: 'btn btn-ghost btn-sm', style: 'align-self:center', type: 'button', onclick: (e) => older(e.currentTarget, meta.nextCursor) }, 'Load earlier messages')); data.forEach(addMsg); scroll();
    await messagesApi.read(c.conversationId).catch(() => {}); c.unreadCount = 0; drawList(); } catch (e) { mount(log, errorState(e, () => open(c))); }
}
async function older(btn, before) { const { data, meta } = await messagesApi.list(active.conversationId, { limit: 50, before }); const h0 = log.scrollHeight; const nodes = data.map((m) => bubble(m)); btn.after(...nodes); if (meta?.hasMore) btn.onclick = () => older(btn, meta.nextCursor); else btn.remove(); log.scrollTop += log.scrollHeight - h0; }
function bubble(m) {
  const mine = String(m.senderId?._id || m.senderId) === String(me);
  return h('div', { class: `bubble ${mine ? 'me' : ''} ${m.isDeletedForEveryone ? 'deleted' : ''}`, 'data-id': m.id || m._id }, m.text && h('div', null, m.text),
    ...(m.attachments || []).map((a) => h('div', null, a.kind === 'image' ? bindFile(h('img', { alt: a.fileName, style: 'max-width:220px;border-radius:8px' }), 'src', a.fileUrl) : bindFile(h('a', { target: '_blank', rel: 'noopener', style: 'color:inherit' }, icon('paperclip'), a.fileName), 'href', a.fileUrl))),
    h('time', null, fmtTime(m.createdAt), mine && !m.isDeletedForEveryone && h('button', { class: 'btn btn-ghost btn-sm', type: 'button', style: 'color:inherit;min-height:20px;padding:0 6px', onclick: () => remove(m) }, 'Delete')));
}
function addMsg(m) { if (log.querySelector(`[data-id="${m.id || m._id}"]`)) return; log.append(bubble(m)); }
const scroll = () => { log.scrollTop = log.scrollHeight; };
async function remove(m) { try { await messagesApi.remove(m.id || m._id); const el = log.querySelector(`[data-id="${m.id || m._id}"]`); el?.remove(); } catch (e) { toast.error(e.message); } }
async function send(e) {
  e.preventDefault(); if (!active) return toast.info('Pick a conversation first.'); const text = input.value.trim(), files = file.files; if (!text && !files.length) return; input.value = ''; file.value = '';
  try { const { data } = await messagesApi.send(active.conversationId, text, files); addMsg(data); scroll(); active.lastMessagePreview = text || 'Attachment'; active.lastMessageAt = new Date().toISOString(); convos = [active, ...convos.filter((c) => c !== active)]; drawList(); }
  catch (err) { toast.error(err.message); input.value = text; }
}
async function doSearch(term) {
  if (!term) return drawList(); mount(listEl, loading(3));
  try { const { data } = await messagesApi.search(term); mount(listEl, data?.length ? data.map((r) => h('button', { class: 'convo', type: 'button', onclick: () => { const c = convos.find((x) => x.conversationId === String(r.conversationId)); if (c) open(c); } }, h('span', { class: 'grow' }, h('div', { class: 'last' }, r.text || r.snippet || 'Match'), h('div', { class: 'small muted' }, relTime(r.createdAt))))) : empty({ title: 'No messages match', iconName: 'search' })); } catch (e) { mount(listEl, errorState(e)); }
}
async function newChat() {
  const body = h('div', { class: 'stack' }); const m = openModal({ title: 'New message', body });
  const start = async (recipientId, courseId) => { try { const { data } = await messagesApi.start(recipientId, courseId); m.close(); await loadList(); open(convos.find((c) => c.conversationId === String(data._id || data.id)) || { conversationId: data._id || data.id, partner: null }); } catch (e) { toast.error(e.message); } };
  const manual = buildForm({ grid: false, submitLabel: 'Start conversation', fields: [{ name: 'recipientId', label: 'Person’s user ID', required: true, hint: 'Ask them for the ID shown on their profile, or use the list above.' }], onSubmit: async (v) => start(v.recipientId) });
  try {
    if (user.role === 'student') { const courses = items((await studentApi.courses()).data); mount(body, h('p', { class: 'muted small' }, 'Message your teachers:'), courses.length ? courses.map((c) => h('button', { class: 'btn btn-secondary', type: 'button', disabled: !c.teacherIds?.length, onclick: () => start(String(c.teacherIds[0]?._id || c.teacherIds[0]), idOf(c)) }, `${c.title}: teacher`)) : empty({ title: 'Enrol in a course to message its teacher' })); }
    else if (user.role === 'teacher') mount(body, h('p', { class: 'muted small' }, 'Students you teach can be messaged by user ID. They can also message you from their course page.'), manual);
    else { const users = items((await adminApi.users({ limit: 8 })).data); mount(body, searchBox({ placeholder: 'Find a user…', onSearch: async (t) => { const r = items((await adminApi.users({ search: t, limit: 8 })).data); mount(res, r.map(row)); } }), res = h('div', { class: 'stack-sm' }, users.map(row)), manual); }
  } catch (e) { mount(body, errorState(e)); }
  function row(u) { return h('button', { class: 'btn btn-secondary', type: 'button', style: 'justify-content:flex-start', onclick: () => start(idOf(u)) }, `${u.name} · ${u.role}`); }
  var res;
}

loadList();
connect('/', session.accessToken).then((s) => {
  socket = s;
  s.on('message:new', (m) => { if (active && String(m.conversationId) === String(active.conversationId)) { addMsg(m); scroll(); if (String(m.senderId) !== String(me)) messagesApi.read(active.conversationId).catch(() => {}); } else loadList(); });
  s.on('message:deleted', ({ messageId }) => log.querySelector(`[data-id="${messageId}"]`)?.remove());
  s.on('typing:start', ({ conversationId, userId }) => { if (active && conversationId === String(active.conversationId) && userId !== me) typingEl.textContent = `${active.partner?.name || 'They'} is typing…`; });
  s.on('typing:stop', () => { typingEl.textContent = ''; });
  const pres = (on) => ({ userId }) => { const c = convos.find((x) => String(x.partner?.id) === String(userId)); if (c?.partner) { c.partner.online = on; drawList(); } }; s.on('presence:online', pres(true)); s.on('presence:offline', pres(false));
  s.on('connect_error', () => {}); if (active) s.emit('conversation:join', { conversationId: active.conversationId });
}).catch(() => toast.info('Live updates are unavailable. Messages still send; refresh to see new ones.'));
