import { h, mount, icon } from '../../core/dom.js';
import { billingApi } from '../../api/billing.js';
import { pageHead, items, idOf, card } from '../../ui/page.js';
import { empty, withState, busy } from '../../ui/states.js';
import { tabs } from '../../ui/tabs.js';
import { dataTable, statusBadge } from '../../ui/table.js';
import { pagination } from '../../ui/pagination.js';
import { openModal } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { planCard, planCurrencies, currencySelect, defaultCurrency } from '../../ui/plans.js';
import { fmtMoney, fmtDate, fmtDateTime, cap } from '../../core/format.js';

export default async function render({ query }) {
  const view = h('div', { class: 'stack' });
  mount(view, pageHead('Billing', 'Plans, your subscription and payment history.'), tabs([
    { id: 'plans', label: 'Plans', render: plansTab }, { id: 'sub', label: 'My subscription', render: subTab }, { id: 'pay', label: 'Payment history', render: payTab }], query.tab || 'plans'));
  return view;
}

function plansTab(panel) {
  withState(panel, async () => { const [p, s] = await Promise.all([billingApi.plans(), billingApi.subscription().catch(() => ({ data: null }))]); return { plans: (p.data || []).filter((x) => x.active !== false), sub: s.data }; }, ({ plans, sub }) => {
    if (!plans.length) return empty({ title: 'No plans available right now', iconName: 'card' });
    const currencies = planCurrencies(plans); let cur = defaultCurrency(currencies); const grid = h('div', { class: 'grid grid-3' });
    const hasActive = sub && ['active', 'trialing'].includes(sub.status);
    const trialBtn = (p) => h('button', { class: 'btn btn-secondary', type: 'button', onclick: async (e) => { try { await busy(e.currentTarget, () => billingApi.startTrial(p.code)); toast.success('Your free trial has started.'); location.hash = '#/billing?tab=sub&r=' + Date.now(); } catch (err) { toast.error(err.message); } } }, 'Start free trial');
    const draw = () => mount(grid, plans.map((p) => { const node = planCard(p, { currency: cur, featured: p.billingCycle === 'annual', cta: { label: hasActive ? 'Switch to this plan' : 'Subscribe', onClick: () => checkoutModal(p, cur) } }); if (p.trialDays > 0 && !hasActive) node.append(trialBtn(p)); return node; }));
    draw();
    return h('div', { class: 'stack' }, hasActive && h('div', { class: 'banner info' }, `You are on the ${cap(sub.plan)} plan (${sub.status}) until ${fmtDate(sub.endDate)}.`),
      currencies.length > 1 && h('div', { class: 'row' }, h('span', { class: 'muted' }, 'Show prices in'), currencySelect(currencies, cur, (c) => { cur = c; draw(); })), grid);
  }, { rows: 3 });
}

function checkoutModal(plan, currency) {
  const summary = h('div', { class: 'small muted', 'aria-live': 'polite' });
  const form = buildForm({ grid: false, submitLabel: 'Continue to payment', fields: [
    { name: 'discountCode', label: 'Discount code (optional)', hint: 'The final amount is always calculated on the server.' },
    { name: 'provider', label: 'Pay with', type: 'select', options: [{ value: '', label: 'Recommended for me' }, { value: 'paystack', label: 'Paystack' }, { value: 'flutterwave', label: 'Flutterwave' }] }],
    onSubmit: async (v) => {
      const { data } = await billingApi.checkout({ purpose: 'subscription', planCode: plan.code, currency, ...(v.provider && { provider: v.provider }), ...(v.discountCode && { discountCode: v.discountCode }) });
      if (data.free || !data.checkoutUrl) { m.close(); toast.success('Subscription activated.'); location.hash = '#/billing?tab=sub&r=' + Date.now(); } else location.href = data.checkoutUrl;
    } });
  const check = h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: async (e) => {
    const code = form.fieldInputs.discountCode.value.trim(); if (!code) return;
    try { const { data } = await busy(e.currentTarget, () => billingApi.validateDiscount({ code, purpose: 'subscription', planCode: plan.code, currency })); mount(summary, data.valid === false ? `This code can’t be used: ${data.message || 'invalid'}` : `Code applied. New total: ${data.total ?? fmtMoney(data.finalMinor, currency, { minor: true })}`); } catch (err) { mount(summary, err.message); } } }, 'Check code');
  const m = openModal({ title: `${plan.name} · ${currency}`, body: h('div', { class: 'stack' }, form, h('div', { class: 'row' }, check, summary)) });
}

function subTab(panel) {
  withState(panel, () => billingApi.subscription().then((r) => r.data), (s) => {
    if (!s) return empty({ title: 'No active subscription', message: 'Pick a plan to unlock every course included in it.', iconName: 'card', action: h('button', { class: 'btn', type: 'button', onclick: () => { location.hash = '#/billing?tab=plans'; } }, 'See plans') });
    const row = (k, v) => [h('dt', { class: 'muted' }, k), h('dd', { style: 'margin:0' }, v)];
    return h('section', { class: 'card stack' }, h('div', { class: 'spread' }, h('h2', { style: 'margin:0' }, `${cap(s.plan)} plan`), statusBadge(s.status)),
      h('dl', { style: 'display:grid;grid-template-columns:max-content 1fr;gap:6px 20px;margin:0' }, row('Billing', cap(s.billingCycle || 'one-off')), row('Amount', fmtMoney(s.amount, s.currency)), row('Started', fmtDate(s.startDate)), row('Ends', fmtDate(s.endDate)), row('Auto-renew', s.autoRenew ? 'Yes' : 'No')),
      s.status === 'expired' && h('div', { class: 'banner err' }, 'Your subscription has expired and access to subscription courses is paused.', h('a', { class: 'btn btn-sm', href: '#/billing?tab=plans' }, 'Renew')));
  }, { rows: 3 });
}

function payTab(panel) {
  let page = 1;
  const load = () => withState(panel, () => billingApi.payments({ page, limit: 10 }), ({ data, meta }) => h('div', { class: 'card card-flush' }, dataTable({ rows: items(data), caption: 'Payments', emptyState: empty({ title: 'No payments yet', iconName: 'card' }),
    columns: [{ label: 'Date', render: (r) => fmtDateTime(r.createdAt) }, { label: 'For', render: (r) => r.description || cap(r.purpose) }, { label: 'Reference', render: (r) => h('code', { class: 'small' }, r.reference) },
      { label: 'Amount', align: 'right', render: (r) => fmtMoney(r.amountMinor, r.currency, { minor: true }) }, { label: 'Status', render: (r) => statusBadge(r.status) }],
    actions: (r) => r.status === 'completed' ? h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: async (e) => { try { await busy(e.currentTarget, () => billingApi.receiptPdf(idOf(r))); } catch (err) { toast.error(err.message); } } }, icon('download'), 'Receipt')
      : r.status === 'pending' ? h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: async (e) => { try { const res = await busy(e.currentTarget, () => billingApi.verify(r.reference)); toast.info(res.message || 'Checked.'); load(); } catch (err) { toast.error(err.message); } } }, 'Check status') : null }),
    pagination({ ...(meta || {}), onChange: (p) => { page = p; load(); } })), { rows: 4 });
  load();
}
