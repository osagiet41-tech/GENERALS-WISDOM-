/**
 * ONE-TIME migration. Run BEFORE turning on access enforcement for an existing platform.
 *
 * Why: before this module, enrolling in a priced course needed no payment. Once enforcement is on, those
 * students would suddenly be locked out of courses they were already in. This script gives every currently
 * enrolled student of a priced course a permanent "grandfathered" access record, so only NEW enrollments
 * are charged. Safe to re-run (it skips students who already have a record).
 *
 *   node scripts/grandfather-enrollments.js            # dry run, prints what it would do
 *   node scripts/grandfather-enrollments.js --apply    # writes the records
 */
require('dotenv').config();
const mongoose = require('mongoose');
const env = require('../src/config/env');
const { Course } = require('../src/models/course.model');
const { CourseAccess } = require('../src/models/billing.model');
const { isCourseFree } = require('../src/services/pricingService');

(async () => {
  const apply = process.argv.includes('--apply');
  await mongoose.connect(env.mongodbUri);

  let granted = 0;
  const courses = await Course.find({});
  for (const course of courses) {
    if (isCourseFree(course)) continue;
    for (const userId of course.enrolledStudentIds) {
      const exists = await CourseAccess.exists({ userId, courseId: course._id, status: 'active' });
      if (exists) continue;
      granted += 1;
      if (apply) await CourseAccess.create({ userId, courseId: course._id, source: 'grandfathered', status: 'active' });
    }
  }
  console.log(`${apply ? 'Granted' : 'Would grant'} grandfathered access to ${granted} enrollment(s).${apply ? '' : ' Re-run with --apply.'}`);
  await mongoose.disconnect();
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
