import { h } from '../../core/dom.js';
import { studentApi } from '../../api/student.js';
import { pageHead, statCard } from '../../ui/page.js';
import { empty } from '../../ui/states.js';
import { fmtPercent, fmtDateTime } from '../../core/format.js';

export default async function render() {
  const { data } = await studentApi.progress(); const courses = data.courses || [];
  return h('div', { class: 'stack' }, pageHead('Your progress', 'How you are doing in each course.'),
    h('div', { class: 'grid grid-stats' }, statCard('Courses', data.enrolledCourseCount), statCard('Average completion', fmtPercent(data.averageCompletionPercent))),
    courses.length ? h('div', { class: 'grid grid-2' }, courses.map((c) => h('section', { class: 'card stack-sm' }, h('div', { class: 'spread' }, h('h3', { style: 'margin:0' }, c.title), h('strong', null, fmtPercent(c.overallCompletionPercent))),
      h('div', { class: 'progress', role: 'progressbar', 'aria-valuenow': c.overallCompletionPercent, 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-label': `${c.title} completion` }, h('span', { style: `width:${c.overallCompletionPercent}%` })),
      h('dl', { class: 'small', style: 'display:grid;grid-template-columns:max-content 1fr;gap:4px 16px;margin:0' },
        h('dt', { class: 'muted' }, 'Lessons'), h('dd', { style: 'margin:0' }, `${c.lessonCompletion.completed} of ${c.lessonCompletion.total} (${fmtPercent(c.lessonCompletion.percent)})`),
        h('dt', { class: 'muted' }, 'Assignments'), h('dd', { style: 'margin:0' }, `${fmtPercent(c.performance.assignments.averagePercent)} avg · ${c.performance.assignments.count} graded`),
        h('dt', { class: 'muted' }, 'Quizzes'), h('dd', { style: 'margin:0' }, `${fmtPercent(c.performance.quizzes.averagePercent)} avg · ${c.performance.quizzes.count} graded`),
        h('dt', { class: 'muted' }, 'Exams'), h('dd', { style: 'margin:0' }, `${fmtPercent(c.performance.exams.averagePercent)} avg · ${c.performance.exams.count} graded`),
        h('dt', { class: 'muted' }, 'Attendance'), h('dd', { style: 'margin:0' }, fmtPercent(c.attendance.ratePercent)),
        h('dt', { class: 'muted' }, 'Last visit'), h('dd', { style: 'margin:0' }, fmtDateTime(c.lastAccessedAt))),
      h('a', { class: 'btn btn-secondary btn-sm', href: `learn.html?course=${c.courseId}` }, 'Continue')))) : empty({ title: 'No progress yet', message: 'Start a lesson and your progress will show here.', iconName: 'chart' }));
}
