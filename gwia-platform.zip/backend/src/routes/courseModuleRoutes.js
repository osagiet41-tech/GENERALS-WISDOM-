const express = require('express');
const controller = require('../controllers/courseModuleController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership, verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { courseModuleValidator } = require('../validators/courseModuleValidator');
const CourseModule = require('../models/courseModule.model');

// Nested under /api/courses/:courseId/subjects/:subjectId/modules
const nestedRouter = express.Router({ mergeParams: true });
nestedRouter.use(authMiddleware, requireTeacherOrAdmin);
nestedRouter.get('/', verifyCourseOwnership(), controller.listModules);
nestedRouter.post('/', verifyCourseOwnership(), validate(courseModuleValidator), controller.createModule);

// Nested under /api/courses/:courseId/modules — all modules in the course
const courseWideRouter = express.Router({ mergeParams: true });
courseWideRouter.use(authMiddleware, requireTeacherOrAdmin);
courseWideRouter.get('/', verifyCourseOwnership(), controller.listModulesForCourse);

// Top-level /api/modules/:id for item-scoped operations
const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);
itemRouter.put(
  '/:id',
  verifyResourceOwnership(CourseModule, 'id'),
  validate(courseModuleValidator),
  controller.updateModule
);
itemRouter.delete('/:id', verifyResourceOwnership(CourseModule, 'id'), controller.deleteModule);

module.exports = { nestedRouter, courseWideRouter, itemRouter };
