import { h, icon } from '../core/dom.js';
import { debounce } from '../core/format.js';
export function searchBox({ placeholder = 'Search…', value = '', onSearch, label = 'Search' }) {
  const input = h('input', { class: 'input', type: 'search', placeholder, value, 'aria-label': label, autocomplete: 'off' });
  input.addEventListener('input', debounce(() => onSearch(input.value.trim()), 350));
  return h('div', { class: 'searchbox', role: 'search' }, icon('search'), input);
}
