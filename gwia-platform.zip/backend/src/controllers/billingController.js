const asyncHandler = require('../utils/asyncHandler');
const ApiResponse = require('../utils/ApiResponse');
const ApiError = require('../utils/ApiError');
const billingService = require('../services/billingService');
const auditLogService = require('../services/auditLogService');
const { Payment, Subscription } = require('../models/billing.model');
const User = require('../models/User');
const receiptService = require('../services/receiptService');

const listPayments = asyncHandler(async (req, res) => {
  const { status, userId, provider, purpose, needsReview, page, limit } = req.query;
  const result = await billingService.listPayments({ status, userId, provider, purpose, needsReview, page, limit });
  return ApiResponse.ok(res, result.items, 'Payments retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

const createPayment = asyncHandler(async (req, res) => {
  const payment = await billingService.createManualPayment(req.body);
  await auditLogService.record(req.user.id, 'payment.create', 'Payment', payment._id, { amount: payment.amount }, req.ip);
  return ApiResponse.created(res, payment, 'Payment record created');
});

const updatePaymentStatus = asyncHandler(async (req, res) => {
  const payment = await Payment.findById(req.params.id);
  if (!payment) throw ApiError.notFound('Payment not found');

  const updated = await billingService.updatePaymentStatus(payment, req.body.status);
  await auditLogService.record(
    req.user.id,
    'payment.status_change',
    'Payment',
    req.params.id,
    { newStatus: req.body.status },
    req.ip
  );
  return ApiResponse.ok(res, updated, 'Payment status updated');
});

const listSubscriptions = asyncHandler(async (req, res) => {
  const { status, userId, page, limit } = req.query;
  const result = await billingService.listSubscriptions({ status, userId, page, limit });
  return ApiResponse.ok(res, result.items, 'Subscriptions retrieved', {
    page: result.page,
    limit: result.limit,
    total: result.total,
    pages: result.pages
  });
});

const createSubscription = asyncHandler(async (req, res) => {
  const subscription = await billingService.createSubscription(req.body);
  await auditLogService.record(
    req.user.id,
    'subscription.create',
    'Subscription',
    subscription._id,
    { plan: subscription.plan },
    req.ip
  );
  return ApiResponse.created(res, subscription, 'Subscription created');
});

const cancelSubscription = asyncHandler(async (req, res) => {
  const subscription = await Subscription.findById(req.params.id);
  if (!subscription) throw ApiError.notFound('Subscription not found');

  const updated = await billingService.cancelSubscription(subscription);
  await auditLogService.record(req.user.id, 'subscription.cancel', 'Subscription', req.params.id, {}, req.ip);
  return ApiResponse.ok(res, updated, 'Subscription cancelled');
});

const extendSubscription = asyncHandler(async (req, res) => {
  const subscription = await Subscription.findById(req.params.id);
  if (!subscription) throw ApiError.notFound('Subscription not found');

  const updated = await billingService.extendSubscription(subscription, req.body.endDate);
  await auditLogService.record(
    req.user.id,
    'subscription.extend',
    'Subscription',
    req.params.id,
    { newEndDate: req.body.endDate },
    req.ip
  );
  return ApiResponse.ok(res, updated, 'Subscription extended');
});

const verifyPayment = asyncHandler(async (req, res) => {
  const payment = await Payment.findById(req.params.id);
  if (!payment) throw ApiError.notFound('Payment not found');
  const updated = await billingService.adminVerifyPayment(payment);
  await auditLogService.record(req.user.id, 'payment.verify', 'Payment', req.params.id, { result: updated.status }, req.ip);
  return ApiResponse.ok(res, updated, updated.status === 'completed' ? 'Payment confirmed with provider' : 'Provider has not confirmed this payment');
});

const downloadReceipt = asyncHandler(async (req, res) => {
  const payment = await Payment.findById(req.params.id);
  if (!payment) throw ApiError.notFound('Payment not found');
  if (!payment.receiptNumber) throw ApiError.badRequest('This payment has no receipt');
  const user = await User.findById(payment.userId);
  const pdf = await receiptService.renderReceiptPdf(receiptService.buildReceipt(payment, user));
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${payment.receiptNumber}.pdf"`);
  return res.send(pdf);
});

const listPlans = asyncHandler(async (req, res) => ApiResponse.ok(res, await billingService.listPlans(), 'Plans retrieved'));

const createPlan = asyncHandler(async (req, res) => {
  const plan = await billingService.createPlan(req.body);
  await auditLogService.record(req.user.id, 'plan.create', 'Plan', plan._id, { code: plan.code }, req.ip);
  return ApiResponse.created(res, plan, 'Plan created');
});

const updatePlan = asyncHandler(async (req, res) => {
  const plan = await billingService.updatePlan(req.params.id, req.body);
  await auditLogService.record(req.user.id, 'plan.update', 'Plan', plan._id, { fields: Object.keys(req.body) }, req.ip);
  return ApiResponse.ok(res, plan, 'Plan updated');
});

const listDiscountCodes = asyncHandler(async (req, res) => {
  const result = await billingService.listDiscountCodes(req.query);
  return ApiResponse.ok(res, result.items, 'Discount codes retrieved', { page: result.page, limit: result.limit, total: result.total, pages: result.pages });
});

const createDiscountCode = asyncHandler(async (req, res) => {
  const code = await billingService.createDiscountCode(req.body, req.user.id);
  await auditLogService.record(req.user.id, 'discount.create', 'DiscountCode', code._id, { code: code.code }, req.ip);
  return ApiResponse.created(res, code, 'Discount code created');
});

const updateDiscountCode = asyncHandler(async (req, res) => {
  const code = await billingService.updateDiscountCode(req.params.id, req.body);
  await auditLogService.record(req.user.id, 'discount.update', 'DiscountCode', code._id, { fields: Object.keys(req.body) }, req.ip);
  return ApiResponse.ok(res, code, 'Discount code updated');
});

module.exports = {
  verifyPayment,
  downloadReceipt,
  listPlans,
  createPlan,
  updatePlan,
  listDiscountCodes,
  createDiscountCode,
  updateDiscountCode,
  listPayments,
  createPayment,
  updatePaymentStatus,
  listSubscriptions,
  createSubscription,
  cancelSubscription,
  extendSubscription
};
