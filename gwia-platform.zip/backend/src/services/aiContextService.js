const { Course, Subject } = require('../models/course.model');
const Lesson = require('../models/lesson.model');
const ApiError = require('../utils/ApiError');

/**
 * Loads whichever of course/subject/lesson were referenced in the
 * request, verifying the requesting user actually has access to them
 * (teacher must own the course; student must be enrolled) — the same
 * trust boundary as the rest of the app, just applied before we hand
 * the content to an external AI provider rather than before a DB
 * write. Returns both the raw docs (for controllers that want them)
 * and a compact text block ready to drop into a system prompt.
 */
async function buildContext(user, { courseId, subjectId, lessonId } = {}) {
  let course = null;
  let subject = null;
  let lesson = null;

  if (courseId) {
    course = await Course.findById(courseId);
    if (!course) {
      throw ApiError.notFound('Course not found');
    }

    const isOwner = user.role === 'admin' || course.teacherIds.some((id) => id.toString() === user.id);
    const isEnrolled = course.enrolledStudentIds.some((id) => id.toString() === user.id);

    if (user.role === 'teacher' && !isOwner) {
      throw ApiError.forbidden('You are not authorized to use this course as AI context');
    }
    if (user.role === 'student' && !isEnrolled) {
      throw ApiError.forbidden('You are not enrolled in this course');
    }
  }

  if (subjectId) {
    subject = await Subject.findById(subjectId);
    if (!subject || (course && subject.courseId.toString() !== course._id.toString())) {
      throw ApiError.badRequest('subjectId does not belong to the given course');
    }
  }

  if (lessonId) {
    lesson = await Lesson.findById(lessonId);
    if (!lesson || (course && lesson.courseId.toString() !== course._id.toString())) {
      throw ApiError.badRequest('lessonId does not belong to the given course');
    }
    if (user.role === 'student' && lesson.status !== 'published') {
      throw ApiError.forbidden('This lesson is not available');
    }
  }

  const lines = [];
  if (course) {
    lines.push(`Course: "${course.title}" (category: ${course.category}, class level: ${course.level}).`);
  }
  if (subject) {
    lines.push(`Subject: "${subject.title}".`);
  }
  if (lesson) {
    const snippet = lesson.text ? lesson.text.slice(0, 1500) : '';
    lines.push(`Current lesson: "${lesson.title}".${snippet ? ` Lesson content excerpt: ${snippet}` : ''}`);
  }

  return {
    course,
    subject,
    lesson,
    contextBlock: lines.length > 0 ? lines.join('\n') : ''
  };
}

module.exports = { buildContext };
