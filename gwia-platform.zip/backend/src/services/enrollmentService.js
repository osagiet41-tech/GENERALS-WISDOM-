const { Course } = require('../models/course.model');
const Progress = require('../models/progress.model');
const ApiError = require('../utils/ApiError');
const accessService = require('./accessService');

async function enrollInCourse(studentId, courseId) {
  const course = await Course.findById(courseId);
  if (!course) {
    throw ApiError.notFound('Course not found');
  }
  if (course.status !== 'published') {
    throw ApiError.badRequest('This course is not currently open for enrollment');
  }

  // Free courses enroll directly. Paid courses require a purchase or live subscription first (402 otherwise);
  // paying through /api/billing/checkout enrolls the student automatically.
  await accessService.assertCourseAccess(studentId, course);

  const alreadyEnrolled = course.enrolledStudentIds.some((id) => id.toString() === studentId);
  if (alreadyEnrolled) {
    throw ApiError.conflict('You are already enrolled in this course');
  }

  course.enrolledStudentIds.push(studentId);
  await course.save();

  await Progress.findOneAndUpdate(
    { studentId, courseId },
    { $setOnInsert: { studentId, courseId, enrolledAt: new Date() } },
    { upsert: true, new: true }
  );

  return course;
}

async function listEnrolledCourses(studentId) {
  return Course.find({ enrolledStudentIds: studentId, status: { $ne: 'archived' } }).sort({ updatedAt: -1 });
}

async function unenroll(studentId, courseId) {
  const course = await Course.findById(courseId);
  if (!course) {
    throw ApiError.notFound('Course not found');
  }
  course.enrolledStudentIds = course.enrolledStudentIds.filter((id) => id.toString() !== studentId);
  await course.save();
}

module.exports = { enrollInCourse, listEnrolledCourses, unenroll };
