const ExamAttempt = require('../models/examAttempt.model');
const certificateService = require('./certificateService');
const Submission = require('../models/submission.model');
const { Question } = require('../models/assessment.model');
const ApiError = require('../utils/ApiError');
const logger = require('../utils/logger');

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function isEligibleForAssessment(assessment, studentId) {
  if (!assessment.allowedStudentIds || assessment.allowedStudentIds.length === 0) return true;
  return assessment.allowedStudentIds.some((id) => id.toString() === studentId.toString());
}

async function countCompletedAttempts(assessment, studentId) {
  return Submission.countDocuments({ refType: assessment.kind, refId: assessment._id, studentId });
}

async function getInProgressAttempt(assessmentId, studentId) {
  return ExamAttempt.findOne({ assessmentId, studentId, status: 'in_progress' });
}

/**
 * Builds the fixed question order + per-attempt option shuffle for a
 * brand-new attempt: applies random question selection (if enabled),
 * question-order shuffling, and option-order shuffling, all decided
 * once at start time and then held fixed for the life of the attempt.
 */
async function buildQuestionOrder(assessment) {
  const pool = assessment.questions;
  if (pool.length === 0) {
    throw ApiError.badRequest('This assessment has no questions configured');
  }

  let selected;
  if (assessment.randomization?.enabled) {
    const count = Math.min(assessment.randomization.questionCount || pool.length, pool.length);
    selected = shuffleArray(pool).slice(0, count);
  } else {
    selected = [...pool];
  }

  if (assessment.shuffleQuestions) {
    selected = shuffleArray(selected);
  }

  const questionDocs = await Question.find({ _id: { $in: selected.map((s) => s.questionId) } });
  const questionMap = new Map(questionDocs.map((q) => [q._id.toString(), q]));

  return selected.map((s) => {
    const question = questionMap.get(s.questionId.toString());
    if (!question) {
      throw ApiError.internal(`Question ${s.questionId} referenced by this assessment no longer exists`);
    }

    const entry = { questionId: s.questionId, marks: s.marks };
    if (question.type === 'mcq' && assessment.shuffleOptions) {
      entry.shuffledOptions = shuffleArray(question.options);
    }
    return entry;
  });
}

function computeExpiry(assessment, startedAt) {
  const durationMs = assessment.durationMinutes * 60 * 1000;
  const hardDeadlineMs = new Date(assessment.availableUntil).getTime();
  return new Date(Math.min(startedAt.getTime() + durationMs, hardDeadlineMs));
}

/**
 * Starts a new attempt, or resumes an already-in-progress one. If a
 * previously started attempt has run past its expiry without being
 * submitted, it is auto-finalized first (auto-submission) and a new
 * attempt is started in its place, subject to the attempt limit.
 */
async function startOrResumeAttempt(assessment, student) {
  const now = new Date();

  if (now < assessment.availableFrom || now > assessment.availableUntil) {
    throw ApiError.badRequest('This assessment is not currently available');
  }
  if (!isEligibleForAssessment(assessment, student.id)) {
    throw ApiError.forbidden('You are not eligible to attempt this assessment');
  }

  const existing = await getInProgressAttempt(assessment._id, student.id);
  if (existing) {
    if (existing.expiresAt > now) {
      return { attempt: existing, resumed: true };
    }
    await finalizeAttempt(existing, assessment, { auto: true });
  }

  const completedCount = await countCompletedAttempts(assessment, student.id);
  if (completedCount >= assessment.maxAttempts) {
    throw ApiError.forbidden('You have used all allowed attempts for this assessment');
  }

  const questionOrder = await buildQuestionOrder(assessment);
  const startedAt = now;
  const expiresAt = computeExpiry(assessment, startedAt);

  const attempt = await ExamAttempt.create({
    assessmentId: assessment._id,
    studentId: student.id,
    attemptNumber: completedCount + 1,
    questionOrder,
    answers: [],
    startedAt,
    expiresAt,
    status: 'in_progress'
  });

  return { attempt, resumed: false };
}

/**
 * Returns the attempt in the shape the client needs to render the
 * question palette and navigation: question text/type/marks/options
 * (shuffled if applicable) WITHOUT correctAnswer, merged with any
 * saved answers and mark-for-review flags, plus remaining time.
 */
async function getAttemptView(attempt) {
  const questionIds = attempt.questionOrder.map((q) => q.questionId);
  const questionDocs = await Question.find({ _id: { $in: questionIds } });
  const questionMap = new Map(questionDocs.map((q) => [q._id.toString(), q]));
  const answerMap = new Map(attempt.answers.map((a) => [a.questionId.toString(), a]));

  const questions = attempt.questionOrder.map((entry) => {
    const question = questionMap.get(entry.questionId.toString());
    const savedAnswer = answerMap.get(entry.questionId.toString());

    return {
      questionId: entry.questionId,
      type: question.type,
      text: question.text,
      options: entry.shuffledOptions || question.options,
      marks: entry.marks,
      response: savedAnswer ? savedAnswer.response : null,
      markedForReview: savedAnswer ? savedAnswer.markedForReview : false,
      visited: savedAnswer ? savedAnswer.visited : false
    };
  });

  const remainingMs = Math.max(0, attempt.expiresAt.getTime() - Date.now());

  return {
    attemptId: attempt._id,
    attemptNumber: attempt.attemptNumber,
    status: attempt.status,
    startedAt: attempt.startedAt,
    expiresAt: attempt.expiresAt,
    remainingSeconds: Math.floor(remainingMs / 1000),
    questions
  };
}

/**
 * Auto-saves progress: upserts the response/markedForReview/visited
 * state for one or more questions. If the attempt has already expired,
 * it is auto-finalized instead of saved, and the caller is told so.
 */
async function saveProgress(attempt, assessment, updates) {
  if (attempt.status !== 'in_progress') {
    throw ApiError.conflict('This attempt has already been submitted and can no longer be modified');
  }
  if (attempt.expiresAt <= new Date()) {
    await finalizeAttempt(attempt, assessment, { auto: true });
    throw ApiError.conflict('Time is up — this attempt has been automatically submitted');
  }

  const validQuestionIds = new Set(attempt.questionOrder.map((q) => q.questionId.toString()));

  for (const update of updates) {
    if (!validQuestionIds.has(update.questionId)) {
      throw ApiError.badRequest(`Question ${update.questionId} is not part of this attempt`);
    }

    let existing = attempt.answers.find((a) => a.questionId.toString() === update.questionId);
    if (!existing) {
      existing = { questionId: update.questionId, response: null, markedForReview: false, visited: false };
      attempt.answers.push(existing);
    }

    if (update.response !== undefined) existing.response = update.response;
    if (update.markedForReview !== undefined) existing.markedForReview = update.markedForReview;
    if (update.visited !== undefined) existing.visited = update.visited;
  }

  attempt.lastSavedAt = new Date();
  await attempt.save();
  return attempt;
}

/**
 * Grades objective answers (mcq/true_false) against the answer key and
 * leaves subjective ones (short_answer/essay) for manual teacher
 * grading, then creates the final Submission record and closes out
 * the attempt. Used for both student-triggered submission and
 * server-triggered auto-submission on timeout.
 */
async function finalizeAttempt(attempt, assessment, { auto = false } = {}) {
  if (attempt.status !== 'in_progress') {
    return { attempt, submission: null }; // already finalized — idempotent
  }

  const questionIds = attempt.questionOrder.map((q) => q.questionId);
  const questionDocs = await Question.find({ _id: { $in: questionIds } });
  const questionMap = new Map(questionDocs.map((q) => [q._id.toString(), q]));
  const answerMap = new Map(attempt.answers.map((a) => [a.questionId.toString(), a]));

  let totalAwarded = 0;
  let allObjective = true;
  let attemptTotalMarks = 0;

  const gradedAnswers = attempt.questionOrder.map((entry) => {
    const question = questionMap.get(entry.questionId.toString());
    const draft = answerMap.get(entry.questionId.toString());
    const response = draft ? draft.response : null;

    attemptTotalMarks += entry.marks;

    let marksAwarded = null;
    if (question.type === 'mcq' || question.type === 'true_false') {
      const isCorrect = response !== null && String(response) === String(question.correctAnswer);
      marksAwarded = isCorrect ? entry.marks : 0;
      totalAwarded += marksAwarded;
    } else {
      allObjective = false;
    }

    return { questionId: entry.questionId, response, marksAwarded };
  });

  const submission = await Submission.create({
    refType: assessment.kind,
    refId: assessment._id,
    courseId: assessment.courseId,
    studentId: attempt.studentId,
    answers: gradedAnswers,
    attemptNumber: attempt.attemptNumber,
    submittedAt: new Date(),
    isLate: false,
    status: allObjective ? 'graded' : 'submitted',
    grade: allObjective
      ? { score: totalAwarded, totalMarks: attemptTotalMarks, gradedBy: null, gradedAt: new Date() }
      : undefined
  });

  attempt.status = auto ? 'expired' : 'submitted';
  attempt.submissionId = submission._id;
  await attempt.save();

  // Objective-only exams are graded instantly: this may complete the certificate requirements.
  if (allObjective) certificateService.queueEvaluation(attempt.studentId, assessment.courseId);

  if (auto) {
    logger.info(
      `Auto-submitted expired exam attempt ${attempt._id} (assessment ${assessment._id}, student ${attempt.studentId})`
    );
  }

  return { attempt, submission };
}

module.exports = {
  isEligibleForAssessment,
  countCompletedAttempts,
  getInProgressAttempt,
  startOrResumeAttempt,
  getAttemptView,
  saveProgress,
  finalizeAttempt
};
