import { requireRole } from '../core/session.js';
import { createShell } from '../ui/shell.js';
import { startRouter } from '../ui/router.js';

const user = await requireRole('teacher', 'admin');
const shell = createShell({ user, nav: [
  { id: 'overview', label: 'Overview', icon: 'home' }, { id: 'courses', label: 'My courses', icon: 'book' }, { id: 'live', label: 'Live classes', icon: 'video' },
  { id: 'work', label: 'Assessments & grading', icon: 'file' }, { id: 'questions', label: 'Question bank', icon: 'edit' }, { id: 'announcements', label: 'Announcements', icon: 'bell' },
  { id: 'signature', label: 'Certificate signature', icon: 'award' }, { id: 'messages', label: 'Messages', icon: 'message', href: 'messages.html' }, { id: 'ai', label: 'AI teaching assistant', icon: 'bot', href: 'ai.html' }, { id: 'profile', label: 'Profile', icon: 'settings' }] });
startRouter({ shell, ctx: { user }, fallback: 'overview', routes: {
  overview: () => import('./teacher/overview.js'), courses: () => import('./teacher/courses.js'), live: () => import('./teacher/live.js'), work: () => import('./teacher/work.js'),
  questions: () => import('./teacher/questions.js'), announcements: () => import('./teacher/announcements.js'), signature: () => import('./teacher/signature.js'), profile: () => import('./shared/profile.js') } });
