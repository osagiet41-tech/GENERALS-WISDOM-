const mongoose = require('mongoose');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { Course } = require('../models/course.model');

/**
 * Loads a Course by id and confirms the requesting user is allowed to
 * manage it: either an admin, or a teacher listed in course.teacherIds.
 * Attaches the loaded course to req.course so downstream handlers
 * don't have to re-fetch it.
 *
 * `resolveCourseId` extracts the course id from the request — defaults
 * to req.params.courseId, but callers can pass a custom resolver for
 * routes where the course id comes from the body or from a related
 * document (e.g. a lesson's courseId).
 */
function verifyCourseOwnership(resolveCourseId = (req) => req.params.courseId) {
  return asyncHandler(async (req, res, next) => {
    const courseId = resolveCourseId(req);

    if (!courseId || !mongoose.Types.ObjectId.isValid(courseId)) {
      throw ApiError.badRequest('A valid courseId is required');
    }

    const course = await Course.findById(courseId);
    if (!course) {
      throw ApiError.notFound('Course not found');
    }

    const isAdmin = req.user.role === 'admin';
    const isAssignedTeacher = course.teacherIds.some((id) => id.toString() === req.user.id);

    if (!isAdmin && !isAssignedTeacher) {
      throw ApiError.forbidden('You are not authorized to manage this course');
    }

    req.course = course;
    next();
  });
}

/**
 * For routes operating on a resource that already carries its own
 * courseId (a lesson, assignment, quiz, exam, etc.) — loads the
 * resource via the given Mongoose model, verifies course ownership
 * using its courseId field, and attaches both the resource and its
 * parent course to the request.
 *
 * Usage: verifyResourceOwnership(Lesson, 'id') on a route like
 *        PUT /lessons/:id
 */
function verifyResourceOwnership(Model, paramName = 'id') {
  return asyncHandler(async (req, res, next) => {
    const resourceId = req.params[paramName];

    if (!resourceId || !mongoose.Types.ObjectId.isValid(resourceId)) {
      throw ApiError.badRequest(`A valid ${paramName} is required`);
    }

    const resource = await Model.findById(resourceId);
    if (!resource) {
      throw ApiError.notFound('Resource not found');
    }

    const course = await Course.findById(resource.courseId);
    if (!course) {
      throw ApiError.notFound('Parent course not found');
    }

    const isAdmin = req.user.role === 'admin';
    const isAssignedTeacher = course.teacherIds.some((id) => id.toString() === req.user.id);

    if (!isAdmin && !isAssignedTeacher) {
      throw ApiError.forbidden('You are not authorized to manage this resource');
    }

    req.resource = resource;
    req.course = course;
    next();
  });
}

/**
 * Confirms a student the teacher is trying to view/grade/mark
 * attendance for is actually enrolled in one of the teacher's courses
 * (via req.course, which must already be set by an earlier ownership
 * check). Prevents a teacher from acting on a student outside their
 * own classes.
 */
function verifyStudentInCourse(resolveStudentId = (req) => req.params.studentId || req.body.studentId) {
  return (req, res, next) => {
    if (!req.course) {
      return next(ApiError.internal('verifyStudentInCourse must run after a course ownership check'));
    }

    const studentId = resolveStudentId(req);
    if (!studentId) {
      return next(ApiError.badRequest('A valid studentId is required'));
    }

    const isEnrolled = req.course.enrolledStudentIds.some((id) => id.toString() === studentId);
    if (req.user.role !== 'admin' && !isEnrolled) {
      return next(ApiError.forbidden('This student is not enrolled in your course'));
    }

    next();
  };
}

module.exports = { verifyCourseOwnership, verifyResourceOwnership, verifyStudentInCourse };
