const express = require('express');
const controller = require('../controllers/assignmentController');
const validate = require('../middleware/validate.middleware');
const { authMiddleware } = require('../middleware/authMiddleware');
const { requireTeacherOrAdmin } = require('../middleware/roleMiddleware');
const { verifyCourseOwnership, verifyResourceOwnership } = require('../middleware/teacherOwnership.middleware');
const { uploadMaterial } = require('../config/multer');
const { createAssignmentValidator, updateAssignmentValidator } = require('../validators/assignmentValidator');
const Assignment = require('../models/assignment.model');

const nestedRouter = express.Router({ mergeParams: true });
nestedRouter.use(authMiddleware, requireTeacherOrAdmin);
nestedRouter.get('/', verifyCourseOwnership(), controller.listAssignments);
nestedRouter.post('/', verifyCourseOwnership(), validate(createAssignmentValidator), controller.createAssignment);

const itemRouter = express.Router();
itemRouter.use(authMiddleware, requireTeacherOrAdmin);

itemRouter.put(
  '/:id',
  verifyResourceOwnership(Assignment, 'id'),
  validate(updateAssignmentValidator),
  controller.updateAssignment
);
itemRouter.delete('/:id', verifyResourceOwnership(Assignment, 'id'), controller.deleteAssignment);

itemRouter.post('/:id/publish', verifyResourceOwnership(Assignment, 'id'), controller.publishAssignment);
itemRouter.post('/:id/unpublish', verifyResourceOwnership(Assignment, 'id'), controller.unpublishAssignment);

itemRouter.post(
  '/:id/attachments',
  verifyResourceOwnership(Assignment, 'id'),
  uploadMaterial.single('file'),
  controller.addAttachment
);

module.exports = { nestedRouter, itemRouter };
