const crypto = require('crypto');

/** Constant-time string comparison that tolerates different lengths. */
function safeEqual(a, b) {
  const ba = Buffer.from(String(a ?? ''), 'utf8');
  const bb = Buffer.from(String(b ?? ''), 'utf8');
  if (ba.length !== bb.length) {
    // Still burn a comparison so timing doesn't leak the length check.
    crypto.timingSafeEqual(ba, ba);
    return false;
  }
  return crypto.timingSafeEqual(ba, bb);
}

/** Paystack: x-paystack-signature = HMAC-SHA512(rawBody, secretKey), hex. */
function verifyPaystackSignature(rawBody, signature, secretKey) {
  if (!secretKey || !signature || !Buffer.isBuffer(rawBody)) return false;
  const expected = crypto.createHmac('sha512', secretKey).update(rawBody).digest('hex');
  return safeEqual(expected, String(signature).toLowerCase());
}

/** Flutterwave v3: `verif-hash` header must equal the secret hash configured in the dashboard. */
function verifyFlutterwaveHash(headerValue, secretHash) {
  if (!secretHash || !headerValue) return false;
  return safeEqual(headerValue, secretHash);
}

module.exports = { safeEqual, verifyPaystackSignature, verifyFlutterwaveHash };
