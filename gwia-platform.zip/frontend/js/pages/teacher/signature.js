import { h } from '../../core/dom.js';
import { certificatesApi } from '../../api/certificates.js';
import { pageHead } from '../../ui/page.js';
import { toast } from '../../ui/toast.js';
import { busy } from '../../ui/states.js';
import { confirmDialog } from '../../ui/modal.js';

export default async function render() {
  const file = h('input', { class: 'input', type: 'file', accept: 'image/png,image/jpeg', id: 'sig', required: true });
  const preview = h('img', { alt: 'Signature preview', style: 'max-height:90px;display:none;background:#fff;border:1px solid var(--line);border-radius:6px;padding:6px' });
  file.addEventListener('change', () => { const f = file.files[0]; if (f) { preview.src = URL.createObjectURL(f); preview.style.display = 'block'; } });
  return h('div', { class: 'stack' }, pageHead('Certificate signature', 'Your signature is printed on certificates for courses you teach.'),
    h('section', { class: 'card stack', style: 'max-width:560px' }, h('div', { class: 'field' }, h('label', { for: 'sig' }, 'Signature image'), file, h('div', { class: 'hint' }, 'PNG or JPG on a white or transparent background. Without one, your typed name is used.')), preview,
      h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: async (e) => { if (!file.files[0]) return file.focus(); try { await busy(e.currentTarget, () => certificatesApi.uploadSignature(file.files[0])); toast.success('Signature saved.'); } catch (err) { toast.error(err.message); } } }, 'Upload signature'),
        h('button', { class: 'btn btn-secondary', type: 'button', onclick: async () => { if (await confirmDialog({ title: 'Remove signature?', message: 'Certificates already issued keep the signature they were issued with.', confirmLabel: 'Remove', danger: true })) { try { await certificatesApi.removeSignature(); toast.success('Signature removed.'); preview.style.display = 'none'; } catch (err) { toast.error(err.message); } } } }, 'Remove'))));
}
