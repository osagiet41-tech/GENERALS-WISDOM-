import { h } from '../../core/dom.js';
import { certificatesApi } from '../../api/certificates.js';
import { pageHead, idOf } from '../../ui/page.js';
import { listView } from '../shared/listView.js';
import { statusBadge } from '../../ui/table.js';
import { confirmDialog } from '../../ui/modal.js';
import { toast } from '../../ui/toast.js';
import { fmtDate } from '../../core/format.js';

export default async function render() {
  const lv = listView({ searchPlaceholder: 'Search ID or student…', caption: 'Certificates', fetcher: (q) => certificatesApi.adminList(q), filters: [{ name: 'status', label: 'All', options: [{ value: 'valid', label: 'Valid' }, { value: 'revoked', label: 'Revoked' }] }],
    columns: [{ label: 'Certificate ID', render: (c) => h('code', null, c.certificateId) }, { label: 'Student', render: (c) => c.snapshot?.studentName || c.studentName || '—' }, { label: 'Course', render: (c) => c.snapshot?.courseTitle || c.courseTitle || '—' }, { label: 'Issued', render: (c) => fmtDate(c.issuedAt) }, { label: 'Status', render: (c) => statusBadge(c.status || 'valid') }],
    actions: (c) => c.status === 'revoked' ? h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: async () => { try { await certificatesApi.restore(idOf(c)); toast.success('Restored.'); lv.reload(); } catch (e) { toast.error(e.message); } } }, 'Restore')
      : h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: async () => { if (await confirmDialog({ title: 'Revoke certificate?', message: 'Its public verification page will show it as revoked.', confirmLabel: 'Revoke', danger: true })) { try { await certificatesApi.revoke(idOf(c)); toast.success('Revoked.'); lv.reload(); } catch (e) { toast.error(e.message); } } } }, 'Revoke') });
  return h('div', { class: 'stack' }, pageHead('Certificates', 'Revoking is reversible and recorded in the audit log.'), lv.el);
}
