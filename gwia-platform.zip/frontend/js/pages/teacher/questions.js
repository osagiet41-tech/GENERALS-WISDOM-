import { h, icon } from '../../core/dom.js';
import { teacherApi } from '../../api/teacher.js';
import { pageHead, items, idOf } from '../../ui/page.js';
import { courseSelect } from '../shared/courseSelect.js';
import { withState, empty } from '../../ui/states.js';
import { dataTable, badge } from '../../ui/table.js';
import { pagination } from '../../ui/pagination.js';
import { openModal } from '../../ui/modal.js';
import { buildForm } from '../../ui/form.js';
import { toast } from '../../ui/toast.js';
import { ApiError } from '../../core/http.js';

export default async function render() {
  const { data: courses } = await teacherApi.courses(); const panel = h('div', { class: 'card card-flush' }); let page = 1, type = '', reload;
  const cs = courseSelect(courses, { storageKey: 'teacher.q.course', onChange: () => { page = 1; load(); } });
  if (!cs.count) return h('div', null, pageHead('Question bank'), empty({ title: 'Create a course first', iconName: 'edit' }));
  const load = () => { reload = withState(panel, () => teacherApi.questions(cs.value, { page, limit: 20, type }), ({ data, meta }) => h('div', null, dataTable({ rows: items(data), caption: 'Questions', emptyState: empty({ title: 'No questions yet', message: 'Add multiple-choice, true/false, short-answer and essay questions.', iconName: 'edit' }),
    columns: [{ label: 'Question', render: (r) => r.text }, { label: 'Type', render: (r) => badge(r.type.replace('_', ' ')) }, { label: 'Marks', render: (r) => r.marks ?? 1 }, { label: 'Difficulty', render: (r) => r.difficulty || '—' }]}), pagination({ ...(meta || {}), onChange: (p) => { page = p; load(); } })), { rows: 4 }); };
  const create = () => { const m = openModal({ title: 'New question', size: 'lg', body: buildForm({ submitLabel: 'Add to bank', onCancel: () => m.close(), fields: [
    { name: 'type', label: 'Type', type: 'select', required: true, options: [{ value: 'mcq', label: 'Multiple choice' }, { value: 'true_false', label: 'True / false' }, { value: 'short_answer', label: 'Short answer' }, { value: 'essay', label: 'Essay' }] },
    { name: 'difficulty', label: 'Difficulty', type: 'select', options: ['easy', 'medium', 'hard'].map((v) => ({ value: v, label: v })), value: 'medium' }, { name: 'text', label: 'Question', type: 'textarea', required: true, full: true },
    { name: 'options', label: 'Options (one per line, MCQ only)', type: 'textarea', rows: 4, full: true }, { name: 'correctAnswer', label: 'Correct answer', required: true, hint: 'MCQ: the exact option text. True/false: true or false. Essay: a model answer or "n/a".' }, { name: 'marks', label: 'Marks', type: 'number', min: 1, value: 1 }],
    onSubmit: async (v) => { const options = v.type === 'mcq' ? (v.options || '').split('\n').map((s) => s.trim()).filter(Boolean) : undefined; if (v.type === 'mcq' && options.length < 2) throw new ApiError(400, 'Give at least two options, one per line.');
      await teacherApi.createQuestion(cs.value, { ...v, ...(options && { options }), correctAnswer: v.type === 'true_false' ? String(v.correctAnswer).toLowerCase() === 'true' : v.correctAnswer }); m.close(); toast.success('Question added.'); reload(); } }) }); };
  const filter = h('select', { class: 'input', style: 'width:auto', 'aria-label': 'Filter by type', onchange: () => { type = filter.value; page = 1; load(); } }, [['', 'All types'], ['mcq', 'Multiple choice'], ['true_false', 'True / false'], ['short_answer', 'Short answer'], ['essay', 'Essay']].map(([v, l]) => h('option', { value: v }, l)));
  load();
  return h('div', { class: 'stack' }, pageHead('Question bank', 'Reusable questions for quizzes and exams.', h('button', { class: 'btn', type: 'button', onclick: create }, icon('plus'), 'New question')), h('div', { class: 'row' }, cs.el, filter), panel);
}
